jQuery(function($) {
    //$('#widget').height(400).split({
    //    orientation: 'vertical',
    //    limit: 100,
    //    position: '70%',
    //    percent: true
    //});
});