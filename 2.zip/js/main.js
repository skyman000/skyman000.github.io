var employees = [{
    "ID": 1,
    "DocType": "паспорт",
    "Serial": "46",
    "Number": "242526",
    "Address": "Питер Пионерская",
    "Notes": "вц ц аца ац ца цаца ц"
}, {
    "ID": 2,
    "DocType": "права",
    "Serial": "47",
    "Number": "434356",
    "Address": "Москва Порот",
    "Notes": "йцай ай а йа йа йца йц"
},{
    "ID": 3,
    "DocType": "вид на жительство",
    "Serial": "47",
    "Number": "8888888",
    "Address": "Москва Порот 8 888",
    "Notes": "йцай а8 8 8898 98 98 9 89"
} ];

var SelectGridIndex = -1;

$(function(){
    var dataGrid = $("#gridContainer").dxDataGrid({        
        dataSource: employees,
        rowTemplate: function(container, item) {
            
            var data = item.data,
                markup = "<tbody class='employee dx-row '>" +// + ((item.rowIndex % 2) ? 'dx-row-alt' : '') + "'>" +
                    "<tr class='main-row'>" + 
                    "<td>" + data.DocType + "</td>" +
                    "<td>" + data.Serial + "</td>" +
                    "<td>" + data.Number + "</td>" +
                    "<td>" + data.Address + "</td>" +
                "</tr>" +
                "<tr class='notes-row'>" +
                    "<td colspan='6'><div>" + data.Notes + "</div></td>" +
                "</tr>" +
            "</tbody>";
            //.dxButton({  
            //    text: 'Edit',  
            //    onClick: function(e) {  
            //        rowIndex = rowInfo.rowIndex;  
            //        gridInstance.refresh();  
            //    }  
            //});  
            container.append(markup);
        },
        columnAutoWidth: true,
        showBorders: true,
        height:300,
        selection: {
            mode: "single"
        },
		onSelectionChanged: function (selectedItems) {
            var data = selectedItems.selectedRowsData[0];
            var keys = dataGrid.getSelectedRowKeys();
            
            SelectGridIndex = selectedItems.component.getRowIndexByKey(data);  
			console.log(SelectGridIndex);
        
        },
        onToolbarPreparing: function (e) {
			 
			var toolbarItems = e.toolbarOptions.items;
		 
			
	        toolbarItems.unshift(
			{
                widget: "dxButton", 
                options: { icon: "plus", fontsize:11, text:"Добавить", 
					onClick: function() {  
						var dd = {};
						showInfo(dd);
						var dataSource = dataGrid.getDataSource();
								
							var orders1 = 
							{
								"ID": 111,
								"FIO": "Егоров1 Александр1 Игоревич1",
								"Domain": "BANK",
								"Login": "vtb255395",
								"Role": "Администратор",
								"RegDate": "2019/01/13 9:00", 
							};
					    //dataSource.store().push([
						//	{ type: "insert", data: orders1 }
						//]);
						dataSource.store().insert(orders1).then(function() {
							dataSource.reload();
						})
					} 
				},
                location: "before" 
            },	
			{
                widget: "dxButton", 
                options: { icon: "edit", text:"Изменить", onClick: function() {  } },
                location: "before" 
            },
			{
                widget: "dxButton", 
                options: { icon: "clear", text:"Удалить", 
					onClick: function() { 
						var keys = dataGrid.getSelectedRowKeys();
						var index = dataGrid.getRowIndexByKey(keys[0]);
						dataGrid.deleteRow(index);
					} 
				},
                location: "before" 
            }
			);
			 
        },
        //editing: {
        //    mode: "form",
        //    allowUpdating: true,
        //    form: {
        //        items: [{
        //            itemType: "group",
        //            colCount: 2,
        //            colSpan: 2,
        //            items: ["FirstName", "LastName", "Prefix", "BirthDate", "Position", "HireDate", {
        //                dataField: "Notes",
        //                editorType: "dxTextArea",
        //                colSpan: 2,
        //                editorOptions: {
        //                    height: 100
        //                }
        //            }]
        //        }, {
        //            itemType: "group",
        //            colCount: 2,
        //            colSpan: 2,
        //            caption: "Home Address",
        //            items: ["StateID", "Address"]
        //        }]
        //    }
        //},
        columns: [
            //{
            //    caption: "Photo",
            //    width: 100,
            //    allowFiltering: false,
            //    allowSorting: false
            //}, 
            //{
            //    dataField: "Prefix",
            //    caption: "Title",
            //    width: 70
            //},
            //"FirstName",
            //"LastName", 
            //"Position", {
            //    dataField: "BirthDate",
            //    dataType: "date"
            //}, {
            //    dataField: "HireDate",
            //    dataType: "date"
            //},
            //{
            //    type: "buttons",
            //    buttons: [{
            //        name: "save",
            //        cssClass: "my-class"
            //    }]
            //}
            //{
            //    type: "buttons",
            //    width: 110,
            //    buttons: ["edit", "delete", {
            //        hint: "Clone",
            //        icon: "repeat",
            //        onClick: function(e) {
            //            var clonedItem = $.extend({}, e.row.data, { ID: ++maxID });
            //
            //            employees.splice(e.row.rowIndex, 0, clonedItem);
            //            e.component.refresh(true);
            //            e.event.preventDefault();
            //        },
            //        template: function() {
            //            var link = $("<a>").text("My command")
            //                            .attr("href", "#");
            //            link.on("click", function() {
            //                console.log("My command was clicked");
            //            });
            //            return link;
            //        }
            //    }]
            //}
        ]
    }).dxDataGrid('instance');
    
});