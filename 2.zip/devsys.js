var ATools = (function () {
    function ATools() {
    }
    ATools.Ownership = function (p_class, state) {
        $('#pSimpleTable .k-master-row').each(function () {
            var p = $(this);
            var red = $(this).find('.s-Ownership-' + p_class).length;
            if (red > 0) {
                if (state == 1) {
                    p.removeClass('displayNone');
                }
                else {
                    p.addClass('displayNone');
                }
            }
        });
    };
    ATools.OwnershipTreangle = function (Ownership) {
        if (Ownership == '0')
            return "red";
        else
            return "green";
    };
    ATools.getAttrs = function (node, template) {
        var templateArr = template.split('x');
        try {
            var nodex = node.attributes;
            var a = '';
            for (var i in nodex)
                if (typeof nodex[i].nodeValue !== 'undefined')
                    a += templateArr[0] + nodex[i].nodeName + templateArr[1] + nodex[i].nodeValue + templateArr[2];
            return a;
        }
        catch (e) {
            return "";
        }
    };
    ATools.myXmlTrim = function (inStr) {
        return (inStr.trim())
            .replace(/\<\s*/g, "<")
            .replace(/\>\s*/g, ">")
            .replace(/\s{2,}/g, " ")
            .replace(/\>\s\</g, "><")
            .replace(/\<\s/g, "<")
            .replace(/=\s*\"/g, "=\"");
    };
    ATools.FieldsFromXml = function (xml) {
        var xmldom = $($.parseXML("<Fields>" + xml + "</Fields>"));
        var result = [];
        $(xmldom).find("Field").each(function (i, xmld) {
            result.push($(xmld).attr("ID"));
        });
        return result;
    };
    ATools.DataSourceFromXml = function (xml, path) {
        var xmldom = $($.parseXML("" + xml));
        var attrTemplate = ATools.getAttrs($(xmldom).find(path).get(0), '|x=x').substr(1).split('|');
        var result = [];
        $(xmldom).find(path).each(function (i, xmld) {
            var attrf = new Object();
            for (var j in attrTemplate) {
                var aa = attrTemplate[j].split('=');
                attrf[aa[0]] = $(this).attr(aa[0]);
            }
            $(xmld).children().each(function (i, xmldx) {
                attrf[$(this).context.nodeName] = xmldx.innerHTML;
            });
            var html = (new XMLSerializer()).serializeToString(this);
            if (html.length > 0)
                attrf["html"] = html;
            result[result.length] = attrf;
        });
        return result;
    };
    ATools.DataSourceFilter = function (ds, template) {
        var mytemplate = template.split('=');
        var result = [];
        for (var i in ds)
            if (ds[i][mytemplate[0]] === mytemplate[1])
                result[result.length] = ds[i];
        return result;
    };
    ATools.getXmlVal = function (xml, path, attr) {
        if (attr === void 0) { attr = null; }
        var result = '';
        var xmldom = $($.parseXML("<b>" + xml + "</b>"));
        if (attr == null) {
            var len = $(xmldom).find(path).length;
            if (len > 0) {
                result = (new XMLSerializer()).serializeToString(($(xmldom).find(path))[0]);
                result = result.substr(result.indexOf('>') + 1);
                result = result.substr(0, result.lastIndexOf('<'));
            }
            else {
                result = '';
            }
        }
        else {
            result = $(xmldom).find(path).attr(attr);
        }
        try {
            var t = result.length;
            return result;
        }
        catch (e) {
            return '';
        }
    };
    ATools.getXmlValObj = function (xml, path) {
        return ATools.getXmlVal((new XMLSerializer()).serializeToString(xml), path).trim();
    };
    ATools.alert = function (mess, title) {
        if (title === void 0) { title = "Ошибка:"; }
        if (ATools.alertFlag == false) {
            if (title == 'Ошибка:')
                $("body").prepend("<div id='DevSysAlertWindow'>" + mess + "<br><br>Рекомендуем обновить страницу и повторить попытку, либо связаться с администратором.<br><br><button onclick='location.reload();' class='k-button k-primary'>Обновить страницу</button></div>");
            else
                $("body").prepend("<div id='DevSysAlertWindow'>" + mess + "</div>");
            $("#DevSysAlertWindow").kendoWindow({
                width: "400px",
                title: title,
                modal: true,
                resizable: false,
                draggable: false,
                actions: ["Close"],
                open: function () {
                    ATools.alertFlag = true;
                },
                close: function () {
                    ATools.alertFlag = false;
                    $("#DevSysAlertWindow").remove();
                }
            }).data("kendoWindow").center().open();
        }
    };
    ATools.getDateDDMMYY = function () {
        var now2 = ((new Date()).toLocaleDateString()).split('.');
        now2[2] = (now2[2]).substring(2);
        return (now2.join(','));
    };
    ATools.getdate = function (month) {
        var today = new Date();
        today.setDate(today.getDate() + month * 30);
        var dd = today.getDate();
        var mm = today.getMonth() + 1;
        var yyyy = today.getFullYear();
        dd = (dd < 10) ? '0' + dd : dd;
        mm = (mm < 10) ? '0' + mm : mm;
        return dd + '.' + mm + '.' + yyyy;
    };
    ATools.resize = function (param) {
        var isExist = false;
        for (var i in ATools.resizeArr) {
            if (ATools.resizeArr[i] === param)
                isExist = true;
        }
        if (isExist == false)
            ATools.resizeArr[ATools.resizeArr.length] = param;
        ATools.doResize();
    };
    ATools.doResize = function () {
        for (var i in ATools.resizeArr) {
            if ($("div").is(ATools.resizeArr[i])) {
                $(ATools.resizeArr[i]).data("kendoGrid").resize();
            }
        }
    };
    ATools.editText = function (text, ID, ObjectType, TextType, RequestID) {
        return "<span class='s-edit-text' ID='" + ID + "' ObjectType='" + ObjectType + "' TextType='" + TextType + "' RequestID='" + RequestID + "'><div></div>" + text + "</span>";
    };
    ATools.convertToOracle = function (uc) {
        var base = uc;
        var delv = '';
        if (uc.indexOf('(') > 0) {
            base = uc.substr(0, uc.indexOf('('));
            delv = uc.substr(uc.indexOf('('));
        }
        for (var i = 0; i < pDataTypes.allTypes.length; i++) {
            if (pDataTypes.allTypes[i]['ID'].toUpperCase() == base.toUpperCase()) {
                var result = pDataTypes.allTypes[i]['Size'];
                if ((pDataTypes.allTypes[i]['OracleType'] !== null) && (pDataTypes.allTypes[i]['OracleType'] !== '')) {
                    result += '(' + pDataTypes.allTypes[i]['OracleType'] + ')';
                }
                if (uc.indexOf('(') > 0)
                    return result + delv;
                else
                    return result;
            }
        }
        return (base + delv).toUpperCase();
    };
    ATools.changeTextFix = function (text) {
        if ((text === 'undefined') || (typeof text === 'undefined')) {
            return 'нет описания';
        }
        else
            return text;
    };
    ATools.alertFlag = false;
    ATools.resizeArr = [];
    return ATools;
}());
var DataBaseControl = (function () {
    function DataBaseControl() {
    }
    DataBaseControl.OpenConnect = function (SocketString, callback) {
        if (MainConfig.offlineMode) {
            console.log("offlineMode on");
            callback();
        }
        else {
            try {
                DataBaseControl.WebSocketObject = new WebSocket(SocketString);
            }
            catch (e) {
                ATools.alert('ошибка открытия соединения!');
            }
            ;
            this.intervalSocketConnect = setInterval(function () {
                if (DataBaseControl.WebSocketObject != null &&
                    DataBaseControl.WebSocketObject.readyState == DataBaseControl.WebSocketObject.OPEN) {
                    clearInterval(DataBaseControl.intervalSocketConnect);
                    callback();
                }
                DataBaseControl.timeCounterConnect++;
                if (DataBaseControl.timeCounterConnect > 25) {
                    ATools.alert('Нет связи с сервером!');
                    clearInterval(DataBaseControl.intervalSocketConnect);
                }
            }, 200);
        }
    };
    DataBaseControl.SendRequest = function (request, callback) {
        function get_reqid(xml) { return $($.parseXML("<b>" + xml + "</b>")).find("UCMsg").attr('ID'); }
        var reqidIN = get_reqid(request);
        if (MainConfig.showreq)
            console.log("\u0417\u0410\u041F\u0420\u041E\u0421 -->> \n" + DataBaseControl.beautifulXml(request) + " \n");
        if (MainConfig.offlineMode) {
            var flagreg = true;
            for (var i = 0; i < OfflineQueryes.length; i++) {
                if (ATools.myXmlTrim(OfflineQueryes[i].key) == ATools.myXmlTrim(request)) {
                    if (MainConfig.showreq)
                        console.log("\u041E\u0422\u0412\u0415\u0422 -->> \n" + OfflineQueryes[i].val.trim() + " \n");
                    setTimeout(function () {
                        callback(ATools.myXmlTrim(OfflineQueryes[i].val));
                    }, 500);
                    flagreg = false;
                    break;
                }
            }
            if (flagreg)
                setTimeout(function () {
                    if (MainConfig.showreq)
                        console.log("\u041E\u0422\u0412\u0415\u0422 -->> \n" + request + " \n");
                    callback(request);
                }, 500);
            return;
        }
        if (this.WebSocketObject.readyState != 1) {
            ATools.alert("Связь с сервером прервалась. Обновите страницу");
            return;
        }
        DataBaseControl.RequestTimeCounter[reqidIN] = false;
        setTimeout(function () {
            if (!DataBaseControl.RequestTimeCounter[reqidIN])
                console.log("\u041F\u0440\u0435\u0432\u044B\u0448\u0435\u043D\u043E \u0432\u0440\u0435\u043C\u044F \u043E\u0436\u0438\u0434\u0430\u043D\u0438\u044F \u043D\u0430 \u0437\u0430\u043F\u0440\u043E\u0441 \u2116" + reqidIN + ". \u0421\u0435\u0440\u0432\u0435\u0440 \u043D\u0435 \u043E\u0442\u0432\u0435\u0447\u0430\u0435\u0442.");
        }, 5000);
        var localCallback = callback;
        var listener = function (e) {
            var result = e.data;
            result = (result.indexOf("?>") > 0) ? result.substr(result.indexOf("?>")) : result;
            var reqidOUT = get_reqid(result);
            if (reqidIN === reqidOUT) {
                DataBaseControl.RequestTimeCounter[reqidOUT] = true;
                DataBaseControl.WebSocketObject.removeEventListener("message", listener);
                if (result.indexOf('<Code>-1</Code>') > 0) {
                    var Description = $($.parseXML("<b>" + result + "</b>")).find("Description").html();
                    ATools.alert("\u041E\u0448\u0438\u0431\u043A\u0430 \u043E\u0442\u0432\u0435\u0442\u0430 \u0441\u0435\u0440\u0432\u0435\u0440\u0430 \u043D\u0430 \u0437\u0430\u043F\u0440\u043E\u0441 \u2116" + reqidIN + "! \nDescription: " + Description);
                    pLoginForm.clearLoginCookie();
                }
                else {
                    if (MainConfig.showreq)
                        console.log("\u041E\u0422\u0412\u0415\u0422 -->> \n" + result + " \n");
                    localCallback(result);
                }
            }
        };
        this.WebSocketObject.addEventListener("message", listener);
        this.WebSocketObject.send(request);
    };
    DataBaseControl.beautifulXml = function (xml) {
        var root = $($.parseXML(ATools.myXmlTrim(xml))).children();
        var treeResult = '';
        function buildTree(node, level) {
            var tabs = '';
            for (var i = 0; i < level; i++)
                tabs += '  ';
            for (var i = 0; i < node.length; i++) {
                if (typeof node.get(i).tagName !== 'undefined') {
                    treeResult += (tabs + "<" + node.get(i).tagName + ATools.getAttrs(node.get(i), ' x="x"') + ">");
                    if ($(node.get(i)).children().length > 0) {
                        treeResult += '\n';
                        buildTree($(node.get(i)).children(), level + 1);
                        treeResult += ("" + tabs);
                    }
                    else {
                        var innerHTML = $(node.get(i)).html();
                        if (innerHTML.length > 0)
                            treeResult += (innerHTML);
                    }
                    treeResult += ("</" + node.get(i).tagName + ">\n");
                }
            }
        }
        buildTree(root, 0);
        return treeResult;
    };
    DataBaseControl.timeCounterConnect = 0;
    DataBaseControl.RequestTimeCounter = new Array();
    return DataBaseControl;
}());
var DBCPromise = (function () {
    function DBCPromise() {
        this.ArrCall = new Array();
        this.isProcess = false;
    }
    DBCPromise.prototype.Process = function (flag) {
        var _this = this;
        if ((!this.isProcess) || (flag)) {
            this.isProcess = true;
            var p1 = this.ArrCall.shift();
            DataBaseControl.SendRequest(p1[0], function (xml) {
                p1[1](xml);
                if (_this.ArrCall.length == 0)
                    _this.isProcess = false;
                else
                    _this.Process(true);
            });
        }
    };
    DBCPromise.prototype.then = function (XMLquery, callback) {
        this.ArrCall.push([XMLquery, callback]);
        this.Process(false);
        return this;
    };
    return DBCPromise;
}());
var LoadEventManager = (function () {
    function LoadEventManager() {
    }
    LoadEventManager.execEvent = function (eventName) {
        for (var i = 0; i < this.handlerList.length; i++) {
            if (this.handlerList[i].e == eventName) {
                this.handlerList[i].h();
                this.handlerList.splice(i, 1);
            }
        }
    };
    LoadEventManager.addEventHandler = function (eventName, handler) {
        this.handlerList.push({ e: eventName, h: handler });
    };
    LoadEventManager.handlerList = [];
    return LoadEventManager;
}());
var MainConfig = (function () {
    function MainConfig() {
    }
    MainConfig.socketString = "ws://192.168.45.65:8080/ucdata/endpoint";
    MainConfig.showreq = false;
    MainConfig.offlineMode = false;
    MainConfig.hozObjects = false;
    MainConfig.win_h = $(window).height();
    MainConfig.win_w = $(window).width();
    return MainConfig;
}());
var pOrdersForms = [];
var OfflineQueryes = [
    {
        key: "\n<UCMsg ID=\"1\">\n  <SubSystems></SubSystems>\n  <Context ID=\"0\">\n    <UserName>Leonid</UserName>\n    <UserPassword>O</UserPassword>\n    <IPAddress></IPAddress>\n    <VerMask>\u0412</VerMask>\n    <SubMask>\u0412</SubMask>\n  </Context>\n</UCMsg>",
        val: "\n<UCMsg ID=\"1\">\n  <Status/>\n  <Context ID=\"355\">\n    <UserName>LEONID</UserName>\n    <UserPassword>O</UserPassword>\n    <UserStatus>1</UserStatus>\n    <IPAddress/>\n    <VerMask>\u0412</VerMask>\n    <SubMask>\u0412</SubMask>\n  </Context>\n  <SubSystems>\n    <SubSystem ID=\"online\" SubMask=\"J\">\n      <Version ID=\"online_It\" VerMask=\"J\"/>\n      <Version ID=\"online 2.02\" VerMask=\"K\"/>\n      <Version ID=\"online 2.03\" VerMask=\"L\"/>\n      <Version ID=\"online 2.04\" VerMask=\"M\"/>\n      <Version ID=\"online 2.05\" VerMask=\"N\"/>\n      <Version ID=\"online 2.06\" VerMask=\"O\"/>\n      <Version ID=\"online 2.07\" VerMask=\"P\"/>\n      <Version ID=\"online 2.10\" VerMask=\"Q\"/>\n      <Version ID=\"online 2.15\" VerMask=\"R\"/>\n    </SubSystem>\n    <SubSystem ID=\"office\" SubMask=\"@\">\n      <Version ID=\"office_It\" VerMask=\"@\"/>\n      <Version ID=\"office 5.01\" VerMask=\"A\"/>\n    </SubSystem>\n    <SubSystem ID=\"office_archive\" SubMask=\"T\">\n      <Version ID=\"office_archive_It\" VerMask=\"T\"/>\n    </SubSystem>\n    <SubSystem ID=\"online_archive\" SubMask=\"^\">\n      <Version ID=\"online_archive_It\" VerMask=\"^\"/>\n      <Version ID=\"online_archive 2.02\" VerMask=\"_\"/>\n      <Version ID=\"online_archive 2.03\" VerMask=\"`\"/>\n      <Version ID=\"online_archive 2.04\" VerMask=\"a\"/>\n      <Version ID=\"online_archive 2.05\" VerMask=\"b\"/>\n      <Version ID=\"online_archive 2.06\" VerMask=\"c\"/>\n      <Version ID=\"online_archive 2.07\" VerMask=\"d\"/>\n      <Version ID=\"online_archive 2.10\" VerMask=\"e\"/>\n      <Version ID=\"online_archive 2.15\" VerMask=\"f\"/>\n    </SubSystem>\n    <SubSystem ID=\"monitor\" SubMask=\"h\">\n      <Version ID=\"monitor_It\" VerMask=\"h\"/>\n      <Version ID=\"monitor 2.02\" VerMask=\"i\"/>\n      <Version ID=\"monitor 2.03\" VerMask=\"j\"/>\n      <Version ID=\"monitor 2.04\" VerMask=\"k\"/>\n      <Version ID=\"monitor 2.05\" VerMask=\"l\"/>\n      <Version ID=\"monitor 2.06\" VerMask=\"m\"/>\n      <Version ID=\"monitor 2.07\" VerMask=\"n\"/>\n      <Version ID=\"monitor 2.10\" VerMask=\"o\"/>\n      <Version ID=\"monitor 2.15\" VerMask=\"p\"/>\n    </SubSystem>\n    <SubSystem ID=\"ndc\" SubMask=\"r\">\n      <Version ID=\"ndc_It\" VerMask=\"r\"/>\n      <Version ID=\"ndc 2.02\" VerMask=\"s\"/>\n      <Version ID=\"ndc 2.03\" VerMask=\"t\"/>\n      <Version ID=\"ndc 2.04\" VerMask=\"u\"/>\n      <Version ID=\"ndc 2.05\" VerMask=\"v\"/>\n      <Version ID=\"ndc 2.06\" VerMask=\"w\"/>\n      <Version ID=\"ndc 2.07\" VerMask=\"x\"/>\n      <Version ID=\"ndc 2.10\" VerMask=\"y\"/>\n      <Version ID=\"ndc 2.15\" VerMask=\"z\"/>\n    </SubSystem>\n    <SubSystem ID=\"retail\" SubMask=\"\u0412\">\n      <Version ID=\"retail_It\" VerMask=\"\u0412\"/>\n      <Version ID=\"retail 1.02\" VerMask=\"\u0413\"/>\n      <Version ID=\"retail 1.03\" VerMask=\"\u0414\"/>\n      <Version ID=\"retail 1.04\" VerMask=\"\u0415\"/>\n      <Version ID=\"retail 2.00\" VerMask=\"\u0416\"/>\n      <Version ID=\"retail 2.05\" VerMask=\"\u0417\"/>\n      <Version ID=\"retail 2.06\" VerMask=\"\u0418\"/>\n      <Version ID=\"retail 2.07\" VerMask=\"\u0419\"/>\n    </SubSystem>\n    <SubSystem ID=\"fram\" SubMask=\"|\">\n      <Version ID=\"fram_It\" VerMask=\"|\"/>\n      <Version ID=\"fram 2.06\" VerMask=\"}\"/>\n      <Version ID=\"fram 2.07\" VerMask=\"~\"/>\n      <Version ID=\"fram 2.10\" VerMask=\"\"/>\n      <Version ID=\"fram 2.15\" VerMask=\"\u0402\"/>\n    </SubSystem>\n    <SubSystem ID=\"EDX\" SubMask=\"\u041C\">\n      <Version ID=\"EDX_It\" VerMask=\"\u041C\"/>\n    </SubSystem>\n    <SubSystem ID=\"vcard\" SubMask=\"\u043A\">\n      <Version ID=\"vcard_It\" VerMask=\"\u043A\"/>\n      <Version ID=\"vcard 2.07\" VerMask=\"\u043B\"/>\n      <Version ID=\"vcard 2.10\" VerMask=\"\u043C\"/>\n      <Version ID=\"vcard 2.15\" VerMask=\"\u043D\"/>\n    </SubSystem>\n    <SubSystem ID=\"Balance\" SubMask=\"\u0444\">\n      <Version ID=\"Balance_It\" VerMask=\"\u0444\"/>\n    </SubSystem>\n    <SubSystem ID=\"cort\" SubMask=\"\u044F\">\n      <Version ID=\"cort_It\" VerMask=\"\u044F\"/>\n    </SubSystem>\n  </SubSystems>\n</UCMsg>"
    },
    {
        key: "\n<UCMsg ID=\"2\">\n  <Schema></Schema>\n  <Context ID=\"555\">\n    <UserName>SOMEONE</UserName>\n    <UserPassword>ABSENT</UserPassword>\n    <UserStatus></UserStatus>\n    <IPAddress></IPAddress>\n    <VerMask>\u0412</VerMask>\n    <SubMask>\u0412</SubMask>\n  </Context>\n</UCMsg>",
        val: "\n<UCMsg ID=\"2\">\n  <Status/>\n  <Context ID=\"355\">\n    <UserName>SOMEONE</UserName>\n    <UserPassword>ABSENT</UserPassword>\n    <UserStatus>0</UserStatus>\n    <IPAddress/>\n    <VerMask>\u0412</VerMask>\n    <SubMask>\u0412</SubMask>\n  </Context>\n  <Schema>\n    <ObjectRefs ObjectsType=\"TABLE\">\n      <ObjectRef ID=\"A01\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0440\u043E\u0442\u043E\u043A\u043E\u043B \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u044F \u043F\u0440\u043E\u0446\u0435\u0441\u0441\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"A02\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 ROWID-\u043E\u0432. \u0412 \u043D\u0435\u0435 \u043D\u0430\u043A\u0430\u043F\u043B\u0438\u0432\u0430\u044E\u0442\u0441\u044F ROWID-\u044B \u0441\u0442\u0440\u043E\u043A  \n\u0442\u0430\u0431\u043B\u0438\u0446, \u043F\u043E\u0434\u043B\u0435\u0436\u0430\u0449\u0438\u0445 \u0430\u0440\u0445\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044E\" Ownership=\"1\"/>\n      <ObjectRef ID=\"A03\" ObjectType=\"TABLE\" BriefText=\"\u0412\u0445\u043E\u0434\u044F\u0449\u0438\u0435 \u0442\u0430\u0431\u043B\u0438\u0446\u044B. \u0421 \u043D\u0438\u0445 \u043D\u0430\u0447\u0438\u043D\u0430\u0435\u0442\u0441\u044F \u0440\u0435\u043A\u0443\u0440\u0441\u0438\u0432\u043D\u044B\u0439  \u0430\u043B\u0433\u043E\u0440\u0438\u0442\u043C \u0430\u0440\u0445\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F\" Ownership=\"0\"/>\n      <ObjectRef ID=\"A04\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u044B \u0434\u043B\u044F \u043E\u0447\u0438\u0441\u0442\u043A\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"A05\" ObjectType=\"TABLE\" BriefText=\"\u0421\u0432\u044F\u0437\u0438 \u0442\u0430\u0431\u043B\u0438\u0446\" Ownership=\"0\"/>\n      <ObjectRef ID=\"A06\" ObjectType=\"TABLE\" BriefText=\"\u041A\u0440\u0438\u0442\u0435\u0440\u0438\u0438 \u0430\u0440\u0445\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F\" Ownership=\"0\"/>\n      <ObjectRef ID=\"A07\" ObjectType=\"TABLE\" BriefText=\"\u041C\u0430\u043A\u0440\u043E\u0441\u044B\" Ownership=\"0\"/>\n      <ObjectRef ID=\"A08\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0434\u043B\u044F \u043A\u043E\u043D\u0442\u0440\u043E\u043B\u044F \u043F\u0440\u043E\u0446\u0435\u0441\u0441\u0430 \u0430\u0440\u0445\u0438\u0432\u0430\u0446\u0438\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"A09\" ObjectType=\"TABLE\" BriefText=\"\u0418\u0441\u0442\u043E\u0440\u0438\u044F \u043E\u0447\u0438\u0441\u0442\u043A\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"A12\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0443\u0434\u0430\u043B\u044F\u0435\u043C\u044B\u0445 \u0437\u0430\u043F\u0438\u0441\u0435\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"A13\" ObjectType=\"TABLE\" BriefText=\"\u0418\u0441\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u044F \u0438\u0437 \u0441\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0430\u0446\u0438\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"A14\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0438\u0441\u043E\u043A \u043C\u043E\u0434\u0438\u0444\u0438\u0446\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0445 \u0437\u0430\u043F\u0438\u0441\u0435\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"A15\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0438\u0441\u043A\u0438 \u0442\u0430\u0431\u043B\u0438\u0446 \u0434\u043B\u044F CRM-\u0441\u0438\u0441\u0442\u0435\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"A16\" ObjectType=\"TABLE\" BriefText=\"\u041E\u0431\u044A\u0435\u043A\u0442\u044B \u0430\u0443\u0434\u0438\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"A17\" ObjectType=\"TABLE\" BriefText=\"\u0420\u0430\u0441\u043F\u043E\u043B\u043E\u0436\u0435\u043D\u0438\u0435 \u0430\u0443\u0434\u0438\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"A19\" ObjectType=\"TABLE\" BriefText=\"\u0424\u0430\u043A\u0442\u044B \u0432\u043E\u0437\u043D\u0438\u043A\u043D\u043E\u0432\u0435\u043D\u0438\u044F \u0430\u0443\u0434\u0438\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"A20\" ObjectType=\"TABLE\" BriefText=\"\u041E\u0431\u044A\u0435\u043A\u0442\u044B \u0444\u0430\u043A\u0442\u0430 \u0432\u043E\u0437\u043D\u0438\u043A\u043D\u043E\u0432\u0435\u043D\u0438\u044F \u0430\u0443\u0434\u0438\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B13\" ObjectType=\"TABLE\" BriefText=\"\u0420\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u0442\u0430\u0431\u043B\u0438\u0446\u044B S01 \u0434\u043B\u044F \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0439 \u043F\u043E \u0441\u043C\u0430\u0440\u0442-\u043A\u0430\u0440\u0442\u0430\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B16\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B. \u0441 \u0434\u0430\u0442\u0430\u043C\u0438 \u0438 \u0432\u0440\u0435\u043C\u0435\u043D\u0430\u043C\u0438 \u0438\u043D\u043A\u0430\u0441\u0441\u0430\u0446\u0438\u0439 \u0434\u043B\u044F \u0431\u0430\u043D\u043A\u043E\u043C\u0430\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B19\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0441 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u0430\u043C\u0438 \u0434\u0438\u0437\u0430\u0439\u043D\u043E\u0432 \u043A\u0430\u0440\u0442\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B20\" ObjectType=\"TABLE\" BriefText=\"\u041E\u0433\u0440\u0430\u043D\u0438\u0447\u0435\u043D\u0438\u044F \u043F\u043E \u043E\u0431\u044A\u0435\u043A\u0442\u0430\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B21\" ObjectType=\"TABLE\" BriefText=\"\u0418\u043D\u0434\u0438\u0432\u0438\u0434\u0443\u0430\u043B\u044C\u043D\u044B\u0435 \u043B\u0438\u043C\u0438\u0442\u044B \u0430\u043A\u0442\u0438\u0432\u043D\u043E\u0441\u0442\u0438 \u043F\u043E \u043A\u0430\u0440\u0442\u0430\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B22\" ObjectType=\"TABLE\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B25\" ObjectType=\"TABLE\" BriefText=\"\u042D\u0442\u0430\u043F\u044B \u043A\u043B\u0438p\u0438\u043D\u0433\u043E\u0432\u043E\u0433\u043E \u0446\u0438\u043A\u043B\u0430 \u0444\u0438\u043D\u0430\u043D\u0441\u043E\u0432\u044B\u0445 \u043E\u043F\u0435p\u0430\u0446\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B29\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0438\u043F\u043E\u0432\u044B\u0435 \u043B\u0438\u043C\u0438\u0442\u044B \u0430\u043A\u0442\u0438\u0432\u043D\u043E\u0441\u0442\u0438 \u043F\u043E \u043A\u0430\u0440\u0442\u043E\u0447\u043D\u044B\u043C \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u0438\u043C \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u0430\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B30\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0438\u043F\u043E\u0432\u044B\u0435 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u043A\u0430\u0440\u0442 \u043A\u0430\u0440\u0442\u043E\u0447\u043D\u043E\u0433\u043E \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u043E\u0433\u043E \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B31\" ObjectType=\"TABLE\" BriefText=\"\u041E\u0441\u043D\u043E\u0432\u043D\u044B\u0435 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u043A\u0430\u0440\u0442\u043E\u0447\u043A\u0438 CardDetailes (Issuer, IssuerCenter)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B32\" ObjectType=\"TABLE\" BriefText=\"\u0412\u0437\u0430\u0438\u043C\u043E\u0441\u0432\u044F\u0437\u044C \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u0438\u0445 \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u043E\u0432 \u0438 \u0442\u0438\u043F\u043E\u0432\u044B\u0445 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0439 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u043E\u0432 \u043A\u0430\u0440\u0442\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B33\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0434\u043B\u044F \u043F\u0440\u043E\u0432\u0435\u0434\u0435\u043D\u0438\u044F \u0441\u0432\u0435\u0440\u043A\u0438 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u043E\u0432 \u0438 \u043B\u0438\u043C\u0438\u0442\u043E\u0432 \u043A\u0430\u0440\u0442\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B34\" ObjectType=\"TABLE\" BriefText=\"\u041E\u0441\u0442\u0430\u0442\u043A\u0438 \u043F\u043E \u043A\u0430\u0440\u0442\u0430\u043C, \u0432\u044B\u0433\u0440\u0443\u0436\u0435\u043D\u043D\u044B\u0435 \u0432 \u0444\u0430\u0439\u043B\u0430\u0445\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B35\" ObjectType=\"TABLE\" BriefText=\"\u041D\u043E\u043C\u0435\u0440\u0430 \u043A\u0430\u0440\u0442, \u0441\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0445 \u0432 \u0441\u0438\u0441\u0442\u0435\u043C\u0435\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B37\" ObjectType=\"TABLE\" BriefText=\"\u041E\u0441\u043D\u043E\u0432\u043D\u044B\u0435 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u0434\u0435\u0431\u0435\u0442\u043D\u043E\u0433\u043E \u043F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u044F \u0441\u043C\u0430\u0440\u0442 - \u043A\u0430\u0440\u0442\u044B\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B39\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0441 \u043A\u0430\u0440\u0442\u0430\u043C\u0438 (\u043C\u0430\u0441\u043A\u0430\u043C\u0438 \u043A\u0430\u0440\u0442) \u0434\u043B\u044F \u0441\u0442\u043E\u043F - \u043B\u0438\u0441\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B40\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 K\u0443\u0440\u0441\u043E\u0432\u044B\u0445 \u0441\u0442\u0430\u0432\u043E\u043A \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0435\u043C\u044B\u0445 \u0432\u0430\u043B\u044E\u0442\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B47\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0448\u0430\u0431\u043B\u043E\u043D\u043E\u0432 \u0438 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D\u043E\u0432 \u043D\u043E\u043C\u0435\u0440\u043E\u0432 \u043A\u0430\u0440\u0442 \u043F\u043E \u043E\u0440\u0433\u0430\u043D\u0438\u0437\u0430\u0446\u0438\u044F\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B54\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u044B\u0435 \u0434\u0430\u043D\u043D\u044B\u0435 \u043F\u043E \u0422\u0435\u0440\u043C\u0438\u043D\u0430\u043B\u0430\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B55\" ObjectType=\"TABLE\" BriefText=\"\u041E\u0441\u043D\u043E\u0432\u043D\u044B\u0435 \u0434\u0430\u043D\u043D\u044B\u0435 \u043F\u043E \u0444\u0438\u0440\u043C\u0430\u043C \u0438 \u0444\u0438\u043B\u0438\u0430\u043B\u0430\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B56\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0435\u0446\u0438\u0430\u043B\u044C\u043D\u044B\u0435 \u043B\u0438\u043C\u0438\u0442\u044B \u0431\u0435\u0437\u0430\u0432\u0442\u043E\u0440\u0438\u0437\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0445 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0439 \u0444\u0438\u0440\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B60\" ObjectType=\"TABLE\" BriefText=\"\u041B\u0438\u043C\u0438\u0442\u044B \u0430\u043A\u0442\u0438\u0432\u043D\u043E\u0441\u0442\u0438 \u043F\u043E \u043E\u0440\u0433\u0430\u043D\u0438\u0437\u0430\u0446\u0438\u044F\u043C (\u043F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u044F\u043C)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B61\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u043E\u0432 \u043F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u0439 (\u0433\u0440\u0443\u043F\u043F \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u043E\u0432) \u0432 \u0440\u0430\u043C\u043A\u0430\u0445 \u043A\u043B\u0438\u0435\u043D\u0442\u0441\u043A\u0438\u0445 \u043E\u0440\u0433\u0430\u043D\u0438\u0437\u0430\u0446\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B62\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0434\u0438\u0430\u043F\u043E\u0437\u043E\u043D\u043E\u0432 \u043D\u043E\u043C\u0435\u0440\u043E\u0432 \u043A\u0430\u0440\u0442, \u0440\u0430\u0437\u0440\u0435\u0448\u0435\u043D\u043D\u044B\u0445 \u0434\u043B\u044F \u044D\u043C\u0438\u0441\u0441\u0438\u0438 \u042D\u043C\u0438\u0442\u0435\u043D\u0442\u043E\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B63\" ObjectType=\"TABLE\" BriefText=\"\u041F\u043B\u0430\u0442\u0435\u0436\u043D\u044B\u0435 \u0441\u0438\u0441\u0442\u0435\u043C\u044B \u0434\u043B\u044F \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D\u0430 \u043D\u043E\u043C\u0435\u0440\u043E\u0432 \u043A\u0430\u0440\u0442\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B67\" ObjectType=\"TABLE\" BriefText=\"\u0412\u0430\u043B\u044E\u0442\u044B \u043E\u0431\u0441\u043B\u0443\u0436\u0438\u0432\u0430\u0435\u043C\u044B\u0435 \u0442\u0435\u0440\u043C\u0438\u043D\u0430\u043B\u0430\u043C\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B69\" ObjectType=\"TABLE\" BriefText=\"ReasonCodes\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B71\" ObjectType=\"TABLE\" BriefText=\"\u042D\u043A\u0441\u043F\u043E\u043D\u0435\u043D\u0442\u044B \u0432\u0430\u043B\u044E\u0442 \u0432 \u043A\u043E\u0442\u043E\u0440\u044B\u0445 \u0442\u0435\u0440\u043C\u0438\u043D\u0430\u043B\u044B \u0443\u043A\u0430\u0437\u044B\u0432\u0430\u044E\u0442 \u0441\u0443\u043C\u043C\u0443 \u0442\u0440\u0430\u043D\u0437\u0430\u043A\u0446\u0438\u0438.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B72\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u044B\u0435 \u0434\u0430\u043D\u043D\u044B\u0435 \u043F\u043E \u0442\u0438\u043F\u0430\u043C \u0442\u0435\u0440\u043C\u0438\u043D\u0430\u043B\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B73\" ObjectType=\"TABLE\" BriefText=\"K\u0430\u0440\u0442\u043E\u0447\u043D\u044B\u0435 \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B, \u043E\u0431\u0441\u043B\u0443\u0436\u0438\u0432\u0430\u0435\u043C\u044B\u0435 \u0443\u0447\u0430\u0441\u0442\u043D\u0438\u043A\u043E\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B74\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0438\u0441\u043E\u043A \u043A\u043E\u0434\u043E\u0432 \u0432\u0430\u043B\u044E\u0442\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B77\" ObjectType=\"TABLE\" BriefText=\"K\u043E\u0434\u044B \u0441\u0442\u0430\u0442\u0443\u0441\u043E\u0432 \u043A\u0430\u0440\u0442\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B78\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0438\u0441\u043E\u043A \u043A\u043E\u0434\u043E\u0432 \u0441\u0442\u0440\u0430\u043D\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B79\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 Processing Codes\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B80\" ObjectType=\"TABLE\" BriefText=\"(\u041D\u0415 \u0418\u0421\u041F\u041E\u041B\u042C\u0417\u0423\u0415\u0422\u0421\u042F) \u041A\u043E\u0434\u044B \u043A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u0439 \u0444\u0438\u0440\u043C (\u043A\u043E\u0434\u0438\u0440\u043E\u0432\u043A\u0430 \u042E\u043D\u0438\u043E\u043D \u041A\u0430\u0440\u0434)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B81\" ObjectType=\"TABLE\" BriefText=\"(\u041D\u0415 \u0418\u0421\u041F\u041E\u041B\u042C\u0417\u0423\u0415\u0422\u0421\u042F) \u041A\u043E\u0434\u044B \u043A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u0439 \u0444\u0438\u0440\u043C (\u043A\u043E\u0434\u0438\u0440\u043E\u0432\u043A\u0430 ISO 8583)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B82\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u0435\u0440\u0435\u043F\u043E\u0434\u0447\u0438\u043D\u0435\u043D\u043D\u044B\u0445 \u043E\u0431\u044A\u0435\u043A\u0442\u043E\u0432 \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u0430 \u041A\u041B\u0410\u0414\u0420\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B83\" ObjectType=\"TABLE\" BriefText=\"\u041E\u043F\u0438\u0441\u0430\u043D\u0438\u0435 \u043D\u0430\u0431\u043E\u0440\u043E\u0432 \u043E\u0446\u0435\u043D\u043E\u043A \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432 \u0441\u043A\u043E\u0440\u0438\u043D\u0433\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B84\" ObjectType=\"TABLE\" BriefText=\"\u041A\u0440\u0438\u0442\u0435\u0440\u0438\u0438, \u0444\u043E\u0440\u043C\u0443\u043B\u044B, \u0441\u0432\u044F\u0437\u044C \u0441 \u0442\u0430\u0431\u043B\u0438\u0446\u0435\u0439 B87 (\u0434\u043E\u043F. \u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B85\" ObjectType=\"TABLE\" BriefText=\"\u0425\u0430\u0440\u0430\u043A\u0442\u0435\u0440\u0438\u0441\u0442\u0438\u043A\u0438 \u0438 \u0438\u0445 \u043E\u0446\u0435\u043D\u043A\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B86\" ObjectType=\"TABLE\" BriefText=\"\u041E\u0447\u0435\u0440\u0435\u0434\u043D\u043E\u0441\u0442\u044C \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432 \u0432 \u043E\u0442\u0447\u0435\u0442\u043D\u043E\u0439 \u0444\u043E\u0440\u043C\u0435\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B87\" ObjectType=\"TABLE\" BriefText=\"\u041A\u0430\u0442\u0435\u0433\u043Ep\u0438\u0438 \u0434\u043E\u043F\u043E\u043B\u043D\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0439 \u0438\u043D\u0444\u043Ep\u043C\u0430\u0446\u0438\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B88\" ObjectType=\"TABLE\" BriefText=\"\u0414\u043E\u043F\u043E\u043B\u043D\u0438\u0442\u0435\u043B\u044C\u043D\u0430\u044F \u0438\u043D\u0444\u043Ep\u043C\u0430\u0446\u0438\u044F\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B89\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 BIN&apos;\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B90\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0435\u043A\u0441\u0442\u043E\u0432\u044B\u0435 \u043A\u043E\u043C\u043C\u0435\u043D\u0442\u0430\u0440\u0438\u0438 \u043A\u043E\u0434\u043E\u0432 \u043E\u0442\u0432\u0435\u0442\u043E\u0432 \u043F\u0440\u0438 \u0430\u0432\u0442\u043E\u0440\u0438\u0437\u0430\u0446\u0438\u0438 (\u0440\u0430\u0441\u0448\u0438\u0444\u0440\u043E\u0432\u043A\u0430 \u043A\u043E\u0434\u043E\u0432 \u043E\u0448\u0438\u0431\u043E\u043A)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B91\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u0440\u0438\u0432\u044F\u0437\u043A\u0438 \u043A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u0439 \u0434\u043E\u043F. \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u0438 \u043A \u043E\u0441\u043E\u0431\u0435\u043D\u043D\u043E\u0441\u0442\u044F\u043C \u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u0443\u0435\u043C\u044B\u0445 \u043E\u0431\u044A\u0435\u043A\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B94\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0438\u0441\u043A\u0438 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0439 \u0434\u043E\u043F\u043E\u043B\u043D\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0439 \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B95\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0440\u0430\u0441\u0448\u0438\u0444\u0440\u043E\u0432\u043E\u043A \u0441\u043E\u043A\u0440\u0430\u0449\u0435\u043D\u0438\u0439 \u043D\u0430\u0438\u043C\u0435\u043D\u043E\u0432\u0430\u043D\u0438\u0439 \u043E\u0431\u044A\u0435\u043A\u0442\u043E\u0432 \u043F\u043E \u041A\u041B\u0410\u0414\u0420\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B98\" ObjectType=\"TABLE\" BriefText=\"\u0421\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0430\u0446\u0438\u044F Online \u0438 BackOffice\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C01\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0438\u043F\u043E\u0432\u0430\u044F \u0441\u0432\u044F\u0437\u044C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C02\" ObjectType=\"TABLE\" BriefText=\"\u0423\u0447\u0430\u0441\u0442\u043D\u0438\u043A\u0438 \u0442\u0438\u043F\u043E\u0432\u043E\u0439 \u0441\u0432\u044F\u0437\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C03\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0438\u043F\u043E\u0432\u043E\u0439 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442 \u0441\u043E\u043F\u0440\u043E\u0432\u043E\u0436\u0434\u0430\u044E\u0449\u0438\u0439 \u0434\u043E\u0433\u043E\u0432\u043E\u0440.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C04\" ObjectType=\"TABLE\" BriefText=\"\u0412\u043E\u0437\u043C\u043E\u0436\u043D\u044B\u0435 \u0442\u0438\u043F\u044B \u0432\u043B\u0430\u0434\u0435\u043B\u044C\u0446\u0435\u0432 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C05\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0438\u043F\u043E\u0432\u043E\u0435 \u043E\u0433\u0440\u0430\u043D\u0438\u0447\u0435\u043D\u0438\u0435\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C06\" ObjectType=\"TABLE\" BriefText=\"\u0412\u043E\u0437\u043C\u043E\u0436\u043D\u044B\u0435 \u0441\u0442\u0430\u0442\u0443\u0441\u044B \u0432\u043B\u0430\u0434\u0435\u043B\u044C\u0446\u0435\u0432 \u043E\u0433\u0440\u0430\u043D\u0438\u0447\u0435\u043D\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C07\" ObjectType=\"TABLE\" BriefText=\"\u0420\u043E\u043B\u044C \u0432 \u0442\u0438\u043F\u043E\u0432\u044B\u0445 \u0441\u0432\u044F\u0437\u044F\u0445\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C08\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0438\u0441\u043E\u043A \u0440\u0430\u0437\u0440\u0435\u0448\u0435\u043D\u043D\u044B\u0445/\u0437\u0430\u043F\u0440\u0435\u0449\u0435\u043D\u043D\u044B\u0445 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0439 \u043F\u043E \u043E\u0431\u044A\u0435\u043A\u0442\u0443\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C09\" ObjectType=\"TABLE\" BriefText=\"\u0414\u0435\u0439\u0441\u0442\u0432\u0438\u0439 \u043F\u043E \u0443\u0441\u0442\u0430\u043D\u043E\u0432\u043A\u0435 \u0440\u0430\u0437\u0440\u0435\u0448\u0435\u043D\u043D\u0438\u0439 \u043D\u0430 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438 \u043E\u0431\u044A\u0435\u043A\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C14\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B. \u0444\u0430\u043A\u0442\u0438\u0447. \u043F\u0430\u0440\u0430\u043C. \u043F\u0430\u043A\u0435\u0442\u043E\u0432 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439 (\u0441\u043B\u0438\u043F\u044B, \u0437\u0430\u043F\u0438\u0441\u0438 \u044D\u043B.\u0436\u0443\u0440\u043D.)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C15\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0438\u0441\u043E\u043A \u0442\u0438\u043F\u043E\u0432 \u0440\u0430\u0441\u043F\u0438\u0441\u0430\u043D\u0438\u0439/\u0448\u0430\u0431\u043B\u043E\u043D\u043E\u0432 \u0440\u0430\u0441\u043F\u0438\u0441\u0430\u043D\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C16\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0440\u0438\u0432\u044F\u0437\u043A\u0430 \u0442\u0438\u043F\u043E\u0432 \u0440\u0430\u0441\u043F\u0438\u0441\u0430\u043D\u0438\u0439 \u043A \u0442\u0438\u043F\u0430\u043C \u043E\u0431\u044A\u0435\u043A\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C17\" ObjectType=\"TABLE\" BriefText=\"\u0420\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u044F \u0437\u0430\u043F\u0438\u0441\u0435\u0439 \u0440\u0430\u0441\u043F\u0438\u0441\u0430\u043D\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C18\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0440\u0438\u0432\u044F\u0437\u043A\u0430 \u0440\u0430\u0441\u043F\u0438\u0441\u0430\u043D\u0438\u044F \u043A \u043E\u0431\u044A\u0435\u043A\u0442\u0443\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C23\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0440\u0438\u0432\u044F\u0437\u043A\u0430 STGI \u043A \u044E\u0440\u0438\u0434\u0438\u0447\u0435\u0441\u043A\u0438\u043C \u043B\u0438\u0446\u0430\u043C \u043F\u0440\u043E\u0432\u043E\u0434\u044F\u0449\u0438\u0445 \u0440\u0430\u0441\u0447\u0435\u0442\u044B \u0443\u0447\u0430\u0441\u0442\u043D\u0438\u043A\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C24\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D\u043E\u0432 \u043D\u043E\u043C\u0435\u0440\u043E\u0432 \u043A\u0430\u0440\u0442 \u043F\u043E \u0441\u043F\u043E\u043D\u0441\u0438\u0440\u0443\u0435\u043C\u044B\u043C \u044D\u043C\u0438\u0442\u0435\u043D\u0442\u0430\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C25\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u043F\u0430\u0440\u0442\u0438\u0439 \u043A\u0430\u0440\u0442 \u0434\u0435\u0431\u0435\u0442\u043D\u043E\u0433\u043E-\u0441\u043C\u0430\u0440\u0442 \u043F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u044F\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C30\" ObjectType=\"TABLE\" BriefText=\"\u0421\u0435\u0439\u0444\u043E\u0432\u044B\u0435 \u044F\u0447\u0435\u0439\u043A\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C31\" ObjectType=\"TABLE\" BriefText=\"\u041A\u043B\u044E\u0447\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C32\" ObjectType=\"TABLE\" BriefText=\"\u0420\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u044F \u043F\u043E\u0441\u0435\u0449\u0435\u043D\u0438\u0439 \u044F\u0447\u0435\u0435\u043A\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C33\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043B\u0438\u0442\u043A\u0438 \u0434\u0440\u0430\u0433\u043E\u0446\u0435\u043D\u043D\u044B\u0445 \u043C\u0435\u0442\u0430\u043B\u043B\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C39\" ObjectType=\"TABLE\" BriefText=\"\u0413\u0440\u0443\u043F\u043F\u044B \u043A\u043E\u043C\u0438\u0441\u0441\u0438\u043E\u043D\u043D\u044B\u0445 \u0441\u0442\u0430\u0432\u043E\u043A \u0434\u043B\u044F \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0445 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C40\" ObjectType=\"TABLE\" BriefText=\"\u041E\u043F\u0438\u0441\u0430\u043D\u0438\u044F \u0434\u0435\u0440\u0435\u0432\u044C\u0435\u0432 \u0433\u0440\u0443\u043F\u043F \u043A\u043E\u043C\u0438\u0441\u0441\u0438\u043E\u043D\u043D\u044B\u0445 \u0441\u0442\u0430\u0432\u043E\u043A\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C41\" ObjectType=\"TABLE\" BriefText=\"\u041F\u043E\u0440\u043E\u0433\u0438 \u0434\u043B\u044F \u0433\u0440\u0443\u043F\u043F \u043A\u043E\u043C\u0438\u0441\u0441\u0438\u043E\u043D\u043D\u044B\u0445 \u0441\u0442\u0430\u0432\u043E\u043A\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C42\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0440\u0438\u0432\u044F\u0437\u043A\u0430 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0445 \u0442\u0430\u0440\u0438\u0444\u043E\u0432 \u043A \u043E\u0431\u044A\u0435\u043A\u0442\u0430\u043C \u0441\u0438\u0441\u0442\u0435\u043C\u044B\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C43\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u0438 \u0434\u0435\u0440\u0435\u0432\u0430 \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C44\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0440\u0438\u0432\u044F\u0437\u043A\u0430 \u0434\u0435\u0440\u0435\u0432\u0430 \u043A \u044E\u0440. \u043B\u0438\u0446\u0430\u043C, \u0443\u0447\u0430\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u043C \u0432 \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u0430\u0445\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C45\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u0438 \u0434\u0435\u0440\u0435\u0432\u0430 \u0432\u044B\u0431\u043E\u0440\u0430 \u043F\u043E\u0440\u0442\u0444\u0435\u043B\u044F\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C46\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u0440\u0438\u0432\u044F\u0437\u043A\u0438 \u0434\u0435\u0440\u0435\u0432\u044C\u0435\u0432 \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432 \u043F\u0440\u0438\u0432\u044F\u0437\u043A\u0438 \u0430\u043D\u0430\u043B\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u0441\u0447\u0435\u0442\u043E\u0432 \u043A \u0441\u0447\u0435\u0442\u0430\u043C \u0441\u0432\u043E\u0434\u043D\u043E\u0433\u043E \u0443\u0447\u0435\u0442\u0430 \u043A \u0440\u0430\u0441\u0447\u0435\u0442\u043D\u043E\u043C\u0443 \u0430\u0433\u0435\u043D\u0442\u0443, \u0442\u0438\u043F\u0443 \u043E\u0431\u044A\u0435\u043A\u0442\u0430 \u0438 \u0432\u0430\u043B\u044E\u0442\u044B\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C47\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0434\u0435\u0440\u0435\u0432\u044C\u0435\u0432 \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432 \u043F\u0440\u0438\u0432\u044F\u0437\u043A\u0438 \u0430\u043D\u0430\u043B\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u0441\u0447\u0435\u0442\u043E\u0432 \u043A \u0441\u0447\u0435\u0442\u0430\u043C \u0441\u0432\u043E\u0434\u043D\u043E\u0433\u043E \u0443\u0447\u0435\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C48\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u0440\u0438\u0432\u044F\u0437\u043A\u0438 \u0434\u0435\u0440\u0435\u0432\u044C\u0435\u0432 \u0434\u043B\u044F \u0430\u0432\u0442\u043E\u043C\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u043E\u0433\u043E \u0437\u0430\u043F\u0443\u0441\u043A\u0430 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0439 \u043F\u043E \u043A\u0440\u0435\u0434\u0438\u0442\u043D\u043E\u0439 \u0437\u0430\u044F\u0432\u043A\u0435 \u043A \u0431\u0430\u043D\u043A\u0443 \u0440\u0430\u0441\u0447\u0435\u0442\u043D\u043E\u043C\u0443 \u0430\u0433\u0435\u043D\u0442\u0443\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C49\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0434\u0435\u0440\u0435\u0432\u044C\u0435\u0432 \u0430\u0432\u0442\u043E\u043C\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u043E\u0433\u043E \u0437\u0430\u043F\u0443\u0441\u043A\u0430 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0439 \u043F\u043E \u043A\u0440\u0435\u0434\u0438\u0442\u043D\u043E\u0439 \u0437\u0430\u044F\u0432\u043A\u0435\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C50\" ObjectType=\"TABLE\" BriefText=\"\u0421\u0445\u0435\u043C\u044B \u0440\u0430\u0441\u0447\u0451\u0442\u0430 \u043C\u0438\u043D\u0438\u043C\u0430\u043B\u044C\u043D\u043E\u0433\u043E \u043E\u0431\u044F\u0437\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0433\u043E \u043F\u043B\u0430\u0442\u0435\u0436\u0430 (\u041C\u041E\u041F) \u0434\u043B\u044F \u043A\u0440\u0435\u0434\u0438\u0442\u043D\u044B\u0445 \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u0438\u0445 \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u043E\u0432 \u0438 \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u043E\u0432.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C51\" ObjectType=\"TABLE\" BriefText=\"\u0423\u0441\u043B\u043E\u0432\u0438\u044F \u0441\u0445\u0435\u043C\u044B \u0440\u0430\u0441\u0447\u0451\u0442\u0430 \u0441\u0443\u043C\u043C\u044B \u043C\u0438\u043D\u0438\u043C\u0430\u043B\u044C\u043D\u043E\u0433\u043E \u043E\u0431\u044F\u0437\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0433\u043E \u043F\u043B\u0430\u0442\u0435\u0436\u0430 (\u041C\u041E\u041F).\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C52\" ObjectType=\"TABLE\" BriefText=\"\u0423\u0441\u043B\u043E\u0432\u0438\u044F \u0441\u0445\u0435\u043C\u044B \u0440\u0430\u0441\u0447\u0451\u0442\u0430 \u0434\u0430\u0442 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u044F \u0440\u0435\u0433\u043B\u0430\u043C\u0435\u043D\u0442\u043D\u044B\u0445 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0439.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C53\" ObjectType=\"TABLE\" BriefText=\"\u0420\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u0441\u0445\u0435\u043C\u044B \u0440\u0430\u0441\u0447\u0451\u0442\u0430 \u0434\u0430\u0442 \u0440\u0435\u0433\u043B\u0430\u043C\u0435\u043D\u0442\u043D\u044B\u0445 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0439 \u0434\u043B\u044F \u0437\u0430\u0434\u0430\u043D\u0438\u044F \u0434\u0430\u0442\u044B \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u044F \u043F\u043E\u0441\u043B\u0435\u0434\u0443\u044E\u0449\u0435\u0433\u043E \u0441\u0432\u044F\u0437\u0430\u043D\u043D\u043E\u0433\u043E \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C54\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0440\u0430\u0432\u0438\u043B\u0430 \u043E\u043F\u0440\u0435\u0434\u0435\u043B\u0435\u043D\u0438\u044F \u0441\u043E\u0431\u044B\u0442\u0438\u0439 \u0441\u0438\u0441\u0442\u0435\u043C\u044B\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C60\" ObjectType=\"TABLE\" BriefText=\"\u0418\u043C\u0435\u043D\u043E\u0432\u0430\u043D\u043D\u044B\u0435 \u0441\u043F\u0438\u0441\u043A\u0438 \u043E\u0431\u044A\u0435\u043A\u0442\u043E\u0432 \u0441 \u0434\u0435\u0440\u0435\u0432\u044C\u044F\u043C\u0438 \u0432\u044B\u0431\u043E\u0440\u0430 \u043E\u0431\u044A\u0435\u043A\u0442\u0430 \u043F\u043E \u0443\u043C\u043E\u043B\u0447\u0430\u043D\u0438\u044E.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C61\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u0434\u0435\u0440\u0435\u0432\u044C\u0435\u0432 \u0432\u044B\u0431\u043E\u0440\u0430 \u0438\u0437 \u0441\u043F\u0438\u0441\u043A\u0430 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u043F\u043E \u0443\u043C\u043E\u043B\u0447\u0430\u043D\u0438\u044E.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C62\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043E\u0441\u0442\u0430\u0432 \u0438\u043C\u0435\u043D\u043E\u0432\u0430\u043D\u043D\u043E\u0433\u043E \u0441\u043F\u0438\u0441\u043A\u0430.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C63\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043E\u0441\u0442\u0430\u0432 \u043A\u043E\u043D\u0435\u0447\u043D\u043E\u0433\u043E \u043B\u0438\u0441\u0442\u0430 \u0434\u0435\u0440\u0435\u0432\u0430 \u0438\u043C\u0435\u043D\u043E\u0432\u0430\u043D\u043D\u043E\u0433\u043E \u0441\u043F\u0438\u0441\u043A\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C66\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0430\u0440\u043D\u044B\u0435 \u0441\u0447\u0435\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C70\" ObjectType=\"TABLE\" BriefText=\"\u041A\u043E\u0434\u044B \u043A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u0439 \u0444\u0438\u0440\u043C (\u043A\u043E\u0434\u0438\u0440\u043E\u0432\u043A\u0430 ISO 8583)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C71\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u0433\u0440\u0443\u043F\u043F \u043B\u0438\u043C\u0438\u0442\u043E\u0432 \u0431\u0435\u0437\u0430\u0432\u0442\u043E\u0440\u0438\u0437\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0445 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C72\" ObjectType=\"TABLE\" BriefText=\"\u0412\u0435\u0434\u0435\u043D\u0438\u0435 \u0441\u0447\u0435\u0442\u0447\u0438\u043A\u043E\u0432 \u043F\u043E \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u043C \u0434\u043D\u044F\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C73\" ObjectType=\"TABLE\" BriefText=\"\u0412\u0435\u0434\u0435\u043D\u0438\u0435 \u0441\u0447\u0435\u0442\u0447\u0438\u043A\u043E\u0432 \u043F\u043E \u043E\u0431\u044A\u0435\u043A\u0442\u0430\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C81\" ObjectType=\"TABLE\" BriefText=\"\u041E\u0441\u0442\u0430\u0442\u043A\u0438 \u043D\u0430 \u0441\u0447\u0435\u0442\u0430\u0445 \u0431\u0430\u043D\u043A\u043E\u0432-\u0443\u0447\u0430\u0441\u0442\u043D\u0438\u043A\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C84\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0441\u0432\u044F\u0437\u0438 \u0443\u0447\u0430\u0441\u0442\u043D\u0438\u043A\u043E\u0432(\u044D\u043C\u0438\u0442\u0435\u043D\u0442\u043E\u0432, \u044D\u043A\u0432\u0430\u0439\u0435\u0440\u043E\u0432) \u0441 \u0440\u0435\u0433\u0438\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u043C\u0438 \u0420\u0410\u0426\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C85\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043C\u0430\u0440\u0448\u0440\u0443\u0442\u0438\u0437\u0430\u0446\u0438\u0438 \u043A\u043B\u0438\u0440\u0438\u043D\u0433\u043E\u0432\u044B\u0445 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439, \u0432\u0445\u043E\u0434\u044F\u0449\u0438\u0445 \u0432 \u0441\u043E\u0441\u0442\u0430\u0432 \u0438\u0441\u0445\u043E\u0434\u044F\u0449\u0438\u0445 \u0444\u0430\u0439\u043B\u043E\u0432 (oc)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C89\" ObjectType=\"TABLE\" BriefText=\"\u0428\u0430\u0431\u043B\u043E\u043D\u044B \u043F\u0440\u0438\u0437\u043D\u0430\u043A\u043E\u0432 \u0434\u043B\u044F \u0443\u0447\u0435\u0442\u043D\u044B\u0445 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C90\" ObjectType=\"TABLE\" BriefText=\"\u0421\u0442\u0430\u043D\u0434\u0430\u0440\u0442\u043D\u044B\u0435 \u043A\u043E\u0434\u044B \u043F\u0440\u0438\u0437\u043D\u0430\u043A\u043E\u0432 \u043F\u043E\u0434\u043E\u0437\u0440\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0445 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"D00\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0435\u0445\u043D\u043E\u043B\u043E\u0433\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u0442\u0430\u0431\u043B\u0438\u0446\u0430 \u0434\u043B\u044F \u0445\u0440\u0430\u043D\u0435\u043D\u0438\u044F \u0431\u043B\u043E\u043A\u0430 \u0441 \u043B\u0438\u0446\u0435\u043D\u0437\u0438\u043E\u043D\u043D\u043E\u0439 \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u0435\u0439 \u0438 \u0434\u043B\u044F \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u0438\u044F \u0442\u0435\u043A\u0443\u0449\u0438\u0445 \u0434\u0430\u0442\u044B \u0438 \u0432\u0440\u0435\u043C\u0435\u043D\u0438 \u0441 \u0441\u0435\u0440\u0432\u0435\u0440\u0430 \u0411\u0414\" Ownership=\"0\"/>\n      <ObjectRef ID=\"D01\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0438\u0441\u043E\u043A \u043B\u0438\u0446\u0435\u043D\u0437\u0438\u0439 \u043F\u043E \u0443\u0447\u0430\u0441\u0442\u043D\u0438\u043A\u0430\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"D03\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u0438 \u0434\u043B\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0445 \u043F\u0440\u043E\u0446\u0435\u0434\u0443\u0440\" Ownership=\"0\"/>\n      <ObjectRef ID=\"D04\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043A\u043B\u0438\u0435\u043D\u0442\u043E\u0432 \u0441\u0435\u0440\u0432\u0435\u0440\u0430 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"D05\" ObjectType=\"TABLE\" BriefText=\"SQL-\u0437\u0430\u043F\u0440\u043E\u0441\u044B \u0430\u043F\u0433\u0440\u0435\u0439\u0434\u0430 \u0431\u0430\u0437\u044B\" Ownership=\"0\"/>\n      <ObjectRef ID=\"D06\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0434\u043E\u043F\u043E\u043B\u043D\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0445 \u043E\u0431\u044A\u0435\u043A\u0442\u043E\u0432 \u0441\u0445\u0435\u043C\u044B\" Ownership=\"0\"/>\n      <ObjectRef ID=\"D08\" ObjectType=\"TABLE\" BriefText=\"CacheRegistrationTable\" Ownership=\"0\"/>\n      <ObjectRef ID=\"D48\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u0442\u0435\u0440\u043C\u0438\u043D\u0430\u043B\u0430, \u0441\u0432\u044F\u0437\u0430\u043D\u043D\u044B\u0435 \u0441 \u043E\u0431\u0441\u043B\u0443\u0436\u0438\u0432\u0430\u043D\u0438\u0435\u043C \u0434\u0435\u0431\u0435\u0442\u043D\u043E\u0433\u043E \u043F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u044F \u0441\u043C\u0430\u0440\u0442 - \u043A\u0430\u0440\u0442.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"E01\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B. \u043A\u0443\u0440\u0441\u043E\u0432 \u0432\u0430\u043B\u044E\u0442 Europay\" Ownership=\"0\"/>\n      <ObjectRef ID=\"E02\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B. \u043F\u0440\u0438\u0435\u043C\u0430 Detail Position Europay\" Ownership=\"0\"/>\n      <ObjectRef ID=\"E06\" ObjectType=\"TABLE\" BriefText=\"Passenger Transpor\" Ownership=\"0\"/>\n      <ObjectRef ID=\"E07\" ObjectType=\"TABLE\" BriefText=\"Vehicle Rental\" Ownership=\"0\"/>\n      <ObjectRef ID=\"E08\" ObjectType=\"TABLE\" BriefText=\"LODGING\" Ownership=\"0\"/>\n      <ObjectRef ID=\"E98\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0434\u043B\u044F \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0438\u044F \u043A\u0432\u0430\u0440\u0442\u0430\u043B\u044C\u043D\u044B\u0445 \u043E\u0442\u0447\u0435\u0442\u043E\u0432 \u0434\u043B\u044F EPI\" Ownership=\"0\"/>\n      <ObjectRef ID=\"E99\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 BIN-\u043D\u043E\u0432 \u0434\u043B\u044F EUPOPAY\" Ownership=\"0\"/>\n      <ObjectRef ID=\"F01\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0438 \u043C\u043E\u0448\u0435\u043D\u043D\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u0442\u0440\u0430\u043D\u0437\u0430\u043A\u0446\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"F02\" ObjectType=\"TABLE\" BriefText=\"ReportFormGroup\" Ownership=\"0\"/>\n      <ObjectRef ID=\"F03\" ObjectType=\"TABLE\" BriefText=\"ReportForm\" Ownership=\"0\"/>\n      <ObjectRef ID=\"F04\" ObjectType=\"TABLE\" BriefText=\"ReportFormContent\" Ownership=\"0\"/>\n      <ObjectRef ID=\"F11\" ObjectType=\"TABLE\" BriefText=\"\u041C\u0435\u0442\u0440\u0438\u043A\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"F12\" ObjectType=\"TABLE\" BriefText=\"\u041F\u043B\u0430\u043D \u0441\u0447\u0435\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"F13\" ObjectType=\"TABLE\" BriefText=\"\u0421\u0447\u0435\u0442\u0430 \u0438 \u0441\u0442\u0440\u0443\u043A\u0442\u0443\u0440\u0430 \u043F\u043B\u0430\u043D\u0430 \u0441\u0447\u0435\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"F14\" ObjectType=\"TABLE\" BriefText=\"\u0421\u0440\u043E\u043A\u0438 \u043E\u0442\u043A\u0440\u044B\u0442\u0438\u044F \u0441\u0447\u0435\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"F16\" ObjectType=\"TABLE\" BriefText=\"\u0413\u0440\u0443\u043F\u043F\u0430 \u0440\u0430\u0437\u0440\u0435\u0448\u0451\u043D\u043D\u044B\u0445 \u043A\u043E\u0440\u0440\u0435\u0441\u043F\u043E\u043D\u0434\u0435\u043D\u0446\u0438\u0439 \u0441\u0447\u0435\u0442\u043E\u0432 \u0432 \u0443\u0447\u0451\u0442\u043D\u044B\u0445 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430\u0445.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"F17\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043E\u0441\u0442\u0430\u0432 \u0433\u0440\u0443\u043F\u043F \u0440\u0430\u0437\u0440\u0435\u0448\u0451\u043D\u043D\u044B\u0445 \u043A\u043E\u0440\u0440\u0435\u0441\u043F\u043E\u043D\u0434\u0435\u043D\u0446\u0438\u0439 \u0441\u0447\u0435\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"F20\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0435\u0440\u0435\u0447\u0435\u043D\u044C \u0442\u0438\u043F\u043E\u0432 \u0435\u0434\u0438\u043D\u0438\u0446 \u0438\u0437\u043C\u0435\u0440\u0435\u043D\u0438\u044F \u043E\u0441\u0442\u0430\u0442\u043A\u043E\u0432 \u043D\u0430 \u0441\u0447\u0435\u0442\u0430\u0445, \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0435\u043C\u044B\u0445 \u0432 \u043F\u043B\u0430\u043D\u0435 \u0441\u0447\u0435\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"F28\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0435\u0440\u0432\u0438\u0447\u043D\u044B\u0439 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\" Ownership=\"0\"/>\n      <ObjectRef ID=\"F29\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0443\u0447\u0435\u0442\u043D\u044B\u0445 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"F30\" ObjectType=\"TABLE\" BriefText=\"\u0421\u0432\u044F\u0437\u044C \u0443\u0447\u0451\u0442\u043D\u043E\u0433\u043E \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430 \u0441 \u0433\u0440\u0443\u043F\u043F\u043E\u0432\u044B\u043C\u0438 \u0441\u0447\u0435\u0442\u0430\u043C\u0438 \u043F\u043B\u0430\u043D\u0430 \u0441\u0447\u0435\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"F31\" ObjectType=\"TABLE\" BriefText=\"\u0410\u043D\u0430\u043B\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0435 \u041F\u0440\u0438\u0437\u043D\u0430\u043A\u0438 \u0423\u0447\u0435\u0442\u043D\u044B\u0445 \u0414\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432 \u0438 \u0421\u0447\u0435\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"F34\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0430\u043A\u0435\u0442\u044B \u0423\u0447\u0435\u0442\u043D\u044B\u0445 \u0414\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432 \u0438 \u0421\u0447\u0435\u0442\u043E\u0432.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"F40\" ObjectType=\"TABLE\" BriefText=\"\u041E\u043A\u0440\u0443\u0433\u043B\u0435\u043D\u043D\u0430\u044F \u0444\u043E\u0440\u043C\u0430.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"F41\" ObjectType=\"TABLE\" BriefText=\"\u0414\u0430\u043D\u043D\u044B\u0435 \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u043D\u044B\u0445 \u043E\u0442\u0447\u0435\u0442\u043D\u044B\u0445 \u0444\u043E\u0440\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"F51\" ObjectType=\"TABLE\" BriefText=\"\u041E\u0441\u0442\u0430\u0442\u043A\u0438/\u043E\u0431\u043E\u0440\u043E\u0442\u044B \u043F\u043E \u0443\u0437\u043B\u0430\u043C \u043F\u043B\u0430\u043D\u0430 \u0441\u0447\u0435\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"F52\" ObjectType=\"TABLE\" BriefText=\"\u041E\u0441\u0442\u0430\u0442\u043A\u0438/\u043E\u0431\u043E\u0440\u043E\u0442\u044B \u043F\u043E \u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u043C \u0443\u0447\u0451\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"F91\" ObjectType=\"TABLE\" BriefText=\"\u0413\u0440\u0443\u043F\u043F\u044B \u0410\u043D\u0430\u043B\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u041F\u0440\u0438\u0437\u043D\u0430\u043A\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"F92\" ObjectType=\"TABLE\" BriefText=\"\u041E\u043F\u0438\u0441\u0430\u043D\u0438\u0435 \u0442\u0438\u043F\u043E\u0432\u044B\u0445 \u0430\u043D\u0430\u043B\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u043F\u0440\u0438\u0437\u043D\u0430\u043A\u043E\u0432 \u0443\u0447\u0451\u0442\u043D\u043E\u0433\u043E \u044F\u0434\u0440\u0430.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"F93\" ObjectType=\"TABLE\" BriefText=\"\u0417\u0430\u043F\u0440\u043E\u0441\u044B \u0434\u043B\u044F \u043E\u043F\u0440\u0435\u0434\u0435\u043B\u0435\u043D\u0438\u044F \u0441\u043F\u0438\u0441\u043A\u0430 \u0434\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u044B\u0445 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0439 \u0430\u043D\u0430\u043B\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u043E\u0433\u043E \u043F\u0440\u0438\u0437\u043D\u0430\u043A\u0430.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"G15\" ObjectType=\"TABLE\" Ownership=\"0\"/>\n      <ObjectRef ID=\"H01\" ObjectType=\"TABLE\" BriefText=\"StopListDictionary\" Ownership=\"0\"/>\n      <ObjectRef ID=\"H02\" ObjectType=\"TABLE\" BriefText=\"StopListEntryMain\" Ownership=\"0\"/>\n      <ObjectRef ID=\"H03\" ObjectType=\"TABLE\" BriefText=\"StopListEntryName\" Ownership=\"0\"/>\n      <ObjectRef ID=\"H04\" ObjectType=\"TABLE\" BriefText=\"StopListEntityPassport\" Ownership=\"0\"/>\n      <ObjectRef ID=\"H05\" ObjectType=\"TABLE\" BriefText=\"StopListEntityAddress\" Ownership=\"0\"/>\n      <ObjectRef ID=\"H06\" ObjectType=\"TABLE\" BriefText=\"StopListEntityBirthday\" Ownership=\"0\"/>\n      <ObjectRef ID=\"H07\" ObjectType=\"TABLE\" BriefText=\"ClientSubjectLink\" Ownership=\"0\"/>\n      <ObjectRef ID=\"H08\" ObjectType=\"TABLE\" BriefText=\"TransactionSystems\" Ownership=\"0\"/>\n      <ObjectRef ID=\"H09\" ObjectType=\"TABLE\" BriefText=\"\u0418\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u044F \u043E\u0431 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"H10\" ObjectType=\"TABLE\" BriefText=\"SuspectOperationSubcodes\" Ownership=\"0\"/>\n      <ObjectRef ID=\"H11\" ObjectType=\"TABLE\" BriefText=\"MemberDictionary\" Ownership=\"0\"/>\n      <ObjectRef ID=\"H12\" ObjectType=\"TABLE\" BriefText=\"OperationMember\" Ownership=\"0\"/>\n      <ObjectRef ID=\"H13\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u043E\u0432 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D\u0430 \u0441\u0435\u0440\u0438\u0439/\u043D\u043E\u043C\u0435\u0440\u043E\u0432 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432, \u0443\u0434\u043E\u0441\u0442\u043E\u0432\u0435\u0440\u044F\u044E\u0449\u0438\u0445 \u043B\u0438\u0447\u043D\u043E\u0441\u0442\u044C \u0441\u0443\u0431\u044A\u0435\u043A\u0442\u0430 \u0438\u0437 \u0441\u0442\u043E\u043F-\u043B\u0438\u0441\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"H14\" ObjectType=\"TABLE\" BriefText=\"\u041C\u0430\u0441\u043A\u0438 \u043F\u043E\u0438\u0441\u043A\u0430 \u043F\u043E \u0441\u0442\u043E\u043F-\u043B\u0438\u0441\u0442\u0430\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"H15\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0438\u0441\u043E\u043A \u0440\u043E\u043B\u0435\u0439 \u0437\u0430\u043F\u0438\u0441\u0438 \u0441\u0442\u043E\u043F-\u043B\u0438\u0441\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"H16\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0438\u0441\u043E\u043A \u0441\u0430\u043D\u043A\u0446\u0438\u0439, \u043F\u0440\u0438\u043C\u0435\u043D\u044F\u0435\u043C\u044B\u0445 \u0434\u043B\u044F \u0437\u0430\u043F\u0438\u0441\u0438 \u0441\u0442\u043E\u043F-\u043B\u0438\u0441\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"H20\" ObjectType=\"TABLE\" BriefText=\"\u0417\u0430\u0433\u043E\u043B\u043E\u0432\u043E\u0447\u043D\u0430\u044F \u0447\u0430\u0441\u0442\u044C \u041E\u042D\u0421\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I01\" ObjectType=\"TABLE\" BriefText=\"\u0417\u0430\u043F\u0440\u043E\u0441\u044B RRAM\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I02\" ObjectType=\"TABLE\" BriefText=\"\u041E\u0442\u0432\u0435\u0442\u044B RRAM\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I03\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u043F\u0440\u043E\u0446\u0435\u0434\u0443\u0440 \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u043A\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I04\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u0430\u0443\u0442\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0446\u0438\u043E\u043D\u043D\u043E\u0439 \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I05\" ObjectType=\"TABLE\" BriefText=\"\u041E\u043F\u0438\u0441\u0430\u043D\u0438\u044F \u0430\u0443\u0442\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0445 \u0430\u043B\u0433\u043E\u0440\u0438\u0442\u043C\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I06\" ObjectType=\"TABLE\" BriefText=\"\u0410\u0443\u0442\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0446\u0438\u043E\u043D\u043D\u0430\u044F \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u044F\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I07\" ObjectType=\"TABLE\" BriefText=\"\u0423\u0447\u0435\u0442\u043D\u044B\u0435 \u0437\u0430\u043F\u0438\u0441\u0438 \u043E\u0431\u044A\u0435\u043A\u0442\u043E\u0432 \u0434\u043B\u044F \u0441\u0438\u0441\u0442\u0435\u043C \u0443\u0434\u0430\u043B\u0435\u043D\u043D\u043E\u0433\u043E \u0434\u043E\u0441\u0442\u0443\u043F\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I08\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0438\u0441\u043E\u043A \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u043C\u044B\u0445 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I09\" ObjectType=\"TABLE\" BriefText=\"\u0418\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u044F \u043E \u043A\u043E\u043C\u043C\u0443\u043D\u0430\u043B\u044C\u043D\u044B\u0445 \u043F\u043B\u0430\u0442\u0435\u0436\u0430\u0445\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I10\" ObjectType=\"TABLE\" BriefText=\"\u0423\u0432\u0435\u0434\u043E\u043C\u043B\u0435\u043D\u0438\u044F \u043E\u0431 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u044F\u0445, \u043F\u0440\u043E\u0432\u0435\u0434\u0435\u043D\u043D\u044B\u0445 \u0432 3CardF\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I11\" ObjectType=\"TABLE\" BriefText=\"\u041D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0430 \u043A\u043B\u0438\u0435\u043D\u0442\u0441\u043A\u0438\u0445 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0439 (CSERV)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I12\" ObjectType=\"TABLE\" BriefText=\"\u0417\u0430\u044F\u0432\u043A\u0438 \u0441\u0438\u0441\u0442\u0435\u043C\u044B \u0443\u0434\u0430\u043B\u0435\u043D\u043D\u043E\u0433\u043E \u0434\u043E\u0441\u0442\u0443\u043F\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I13\" ObjectType=\"TABLE\" BriefText=\"\u041A\u043B\u0435\u043D\u0442\u0441\u043A\u0438\u0435 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I15\" ObjectType=\"TABLE\" BriefText=\"\u0410\u0443\u0442\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0435 \u043F\u0430\u043A\u0435\u0442\u044B\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I16\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0440\u0430\u0432\u0430 \u043D\u0430 \u043E\u0442\u043A\u0440\u044B\u0442\u0438\u0435 \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u043E\u0432 \u0434\u043B\u044F \u0433\u0440\u0443\u043F\u043F \u043A\u043B\u0438\u0435\u043D\u0442\u043E\u0432 \u0421\u0423\u0414\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I17\" ObjectType=\"TABLE\" BriefText=\"\u041E\u0442\u043A\u0440\u044B\u0442\u044B\u0435 \u043A\u043B\u044E\u0447\u0438 \u043A\u043B\u0438\u0435\u043D\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I18\" ObjectType=\"TABLE\" BriefText=\"\u041D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0430 \u0442\u0438\u043F\u043E\u0432\u044B\u0445 \u0443\u0432\u0435\u0434\u043E\u043C\u043B\u0435\u043D\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I19\" ObjectType=\"TABLE\" BriefText=\"\u041F\u043E\u0434\u043F\u0438\u0441\u043A\u0438 \u043A\u043B\u0438\u0435\u043D\u0442\u043E\u0432 \u043D\u0430 \u0443\u0432\u0435\u0434\u043E\u043C\u043B\u0435\u043D\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I20\" ObjectType=\"TABLE\" BriefText=\"\u0420\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u044F \u043E\u0442\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u043D\u044B\u0445 \u0443\u0432\u0435\u0434\u043E\u043C\u043B\u0435\u043D\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I21\" ObjectType=\"TABLE\" BriefText=\"\u0420\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u044F \u043A\u043B\u0438\u0435\u043D\u0442\u0430 \u0432 \u0441\u0438\u0441\u0442\u0435\u043C\u0435 \u0440\u0430\u0441\u0441\u044B\u043B\u043A\u0438 \u0443\u0432\u0435\u0434\u043E\u043C\u043B\u0435\u043D\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I22\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u0438  \u0441\u0438\u0441\u0442\u0435\u043C\u044B \u0443\u0434\u0430\u043B\u0435\u043D\u043D\u043E\u0433\u043E \u0434\u043E\u0441\u0442\u0443\u043F\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I23\" ObjectType=\"TABLE\" BriefText=\"CLOB\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I24\" ObjectType=\"TABLE\" BriefText=\"\u0417\u0430\u043F\u0440\u043E\u0441\u044B \u043E\u0442 \u0432\u043D\u0435\u0448\u043D\u0438\u0445 \u0441\u0438\u0441\u0442\u0435\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I25\" ObjectType=\"TABLE\" BriefText=\"\u041E\u0442\u0432\u0435\u0442\u044B \u0432\u043D\u0435\u0448\u043D\u0438\u043C \u0441\u0438\u0441\u0442\u0435\u043C\u0430\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I26\" ObjectType=\"TABLE\" BriefText=\"\u0414\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B, \u0441\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0435 \u043F\u043E \u043E\u0431\u044A\u0435\u043A\u0442\u0443\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I27\" ObjectType=\"TABLE\" BriefText=\"\u041E\u0431\u0440\u0430\u0431\u043E\u0442\u0447\u0438\u043A \u0437\u0430\u043F\u0440\u043E\u0441\u043E\u0432 \u0432\u043D\u0435\u0448\u043D\u0438\u0445 \u0441\u0438\u0441\u0442\u0435\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I30\" ObjectType=\"TABLE\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I31\" ObjectType=\"TABLE\" BriefText=\"\u0428\u043B\u044E\u0437 \u0441 \u0432\u043D\u0435\u0448\u043D\u0435\u0439 \u0441\u0438\u0441\u0442\u0435\u043C\u043E\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I32\" ObjectType=\"TABLE\" BriefText=\"\u041F\u043E\u0434\u043F\u0438\u0441\u043A\u0430 \u0432\u043D\u0435\u0448\u043D\u0438\u0445 \u0441\u0438\u0441\u0442\u0435\u043C \u043D\u0430 \u0441\u043E\u0431\u044B\u0442\u0438\u044F\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I33\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043E\u0431\u044B\u0442\u0438\u044F \u0441\u0438\u0441\u0442\u0435\u043C\u044B 3CardR\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I34\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0440\u043E\u0442\u043E\u043A\u043E\u043B \u0432\u0437\u0430\u0438\u043C\u043E\u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F \u0441 \u0432\u043D\u0435\u0448\u043D\u0435\u0439 \u0441\u0438\u0441\u0442\u0435\u043C\u043E\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I35\" ObjectType=\"TABLE\" BriefText=\"\u0412\u0437\u0430\u0438\u043C\u043E\u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F \u0432 \u0440\u0430\u043C\u043A\u0430\u0445 \u043F\u0440\u043E\u0442\u043E\u043A\u043E\u043B\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I36\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0440\u043E\u0442\u043E\u043A\u043E\u043B\u044B, \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u043C\u044B\u0435 \u0432\u043D\u0435\u0448\u043D\u0435\u0439 \u0441\u0438\u0441\u0442\u0435\u043C\u043E\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I38\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0438\u043F\u043E\u0432\u043E\u0435 \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u043E\u043D\u043D\u043E\u0435 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0435\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I39\" ObjectType=\"TABLE\" BriefText=\"\u0418\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0435 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u044F\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I40\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0437\u0430\u043F\u043B\u0430\u043D\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0445 \u0440\u0435\u0433\u043B\u0430\u043C\u0435\u043D\u0442\u043D\u044B\u0445 \u0437\u0430\u0434\u0430\u043D\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I99\" ObjectType=\"TABLE\" BriefText=\"LDSTransport Table\" Ownership=\"0\"/>\n      <ObjectRef ID=\"J01\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A \u043D\u0430\u0438\u043C\u0435\u043D\u043E\u0432\u0430\u043D\u0438\u0439 \u043D\u0430\u0441\u0435\u043B\u0435\u043D\u043D\u044B\u0445 \u043F\u0443\u043D\u043A\u0442\u043E\u0432.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"J02\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0438\u0441\u043E\u043A \u0441\u0438\u0441\u0442\u0435\u043C \u043F\u0435\u0440\u0435\u0432\u043E\u0434\u043E\u0432.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"J03\" ObjectType=\"TABLE\" BriefText=\"\u0412\u0430\u0440\u0438\u0430\u043D\u0442\u044B \u043D\u0430\u043F\u0438\u0441\u0430\u043D\u0438\u044F \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u044F \u043D\u0430\u0441\u0435\u043B\u0435\u043D\u043D\u043E\u0433\u043E \u043F\u0443\u043D\u043A\u0442\u0430.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"J07\" ObjectType=\"TABLE\" BriefText=\"\u0422\u043E\u043F\u043E\u043B\u043E\u0433\u0438\u044F \u0441\u0435\u0442\u0435\u0439 \u043E\u0431\u0441\u043B\u0443\u0436\u0438\u0432\u0430\u043D\u0438\u044F.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"J08\" ObjectType=\"TABLE\" BriefText=\"\u0423\u0441\u043B\u0443\u0433\u0438 \u0432 \u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0435 \u0441\u0435\u0442\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"J09\" ObjectType=\"TABLE\" BriefText=\"\u0423\u0441\u043B\u0443\u0433\u0438 \u043F\u0440\u043E\u0432\u0430\u0439\u0434\u0435\u0440\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"J10\" ObjectType=\"TABLE\" BriefText=\"\u0421\u0435\u0440\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u044B \u0438\u0441\u043F\u043E\u043B\u043D\u0438\u0442\u0435\u043B\u0435\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"J11\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0441\u0438\u043D\u043E\u043D\u0438\u043C\u043E\u0432 \u0430\u0434\u0440\u0435\u0441\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"J12\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0445\u0440\u0430\u043D\u0435\u043D\u0438\u044F \u0441\u0435\u0442\u0435\u0432\u044B\u0445 \u0430\u0434\u0440\u0435\u0441\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"J15\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0442\u0438\u043F\u043E\u0432 \u0430\u043D\u0430\u043B\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u043F\u0440\u0438\u0437\u043D\u0430\u043A\u043E\u0432 \u0443\u0441\u043B\u0443\u0433 \u043F\u0440\u043E\u0432\u0430\u0439\u0434\u0435\u0440\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"J16\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0439 \u0430\u043D\u0430\u043B\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u043F\u0440\u0438\u0437\u043D\u0430\u043A\u043E\u0432 \u0443\u0441\u043B\u0443\u0433 \u043F\u0440\u043E\u0432\u0430\u0439\u0434\u0435\u0440\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"J17\" ObjectType=\"TABLE\" BriefText=\"\u0420\u0430\u0437\u0440\u0435\u0448\u0435\u043D\u043D\u044B\u0435 \u0434\u043B\u044F \u0443\u0441\u043B\u0443\u0433\u0438 \u043F\u0440\u043E\u0432\u0430\u0439\u0434\u0435\u0440\u0430 \u0430\u043D\u0430\u043B\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0435 \u043F\u0440\u0438\u0437\u043D\u0430\u043A\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"J18\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0440\u0438\u043D\u044F\u0442\u044B\u0435 \u043F\u043B\u0430\u0442\u0435\u0436\u0438 \u0432 \u043F\u043E\u043B\u044C\u0437\u0443 \u044E\u0440. \u043B\u0438\u0446\" Ownership=\"0\"/>\n      <ObjectRef ID=\"J19\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u043F\u0440\u0438\u043D\u044F\u0442\u043E\u0433\u043E \u043F\u043B\u0430\u0442\u0435\u0436\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"J20\" ObjectType=\"TABLE\" BriefText=\"\u041A\u043B\u0438\u0440\u0438\u043D\u0433\u043E\u0432\u044B\u0435 \u043F\u043B\u0430\u0442\u0435\u0436\u0438 \u043F\u043E \u0443\u0441\u043B\u0443\u0433\u0430\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"J21\" ObjectType=\"TABLE\" BriefText=\"\u041A\u043B\u0438\u0440\u0438\u043D\u0433\u043E\u0432\u044B\u0435 \u0440\u0430\u0441\u0447\u0435\u0442\u044B \u043F\u043E \u0443\u0441\u043B\u0443\u0433\u0430\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"J99\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043E\u043F\u0438\u0441\u0430\u043D\u0438\u044F \u043E\u0448\u0438\u0431\u043E\u043A \u043F\u0440\u043E\u0432\u0430\u0439\u0434\u0435\u0440\u043E\u0432 \u0443\u0441\u043B\u0443\u0433\" Ownership=\"0\"/>\n      <ObjectRef ID=\"K06\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 POS-\u043A\u043E\u0434\u043E\u0432 \u0442\u0435\u0440\u043C\u0438\u043D\u0430\u043B\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"L00\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0441\u0438\u0441\u0442\u0435\u043C\u043D\u044B\u0445 \u0438 \u0442\u0435\u0445\u043D\u043E\u043B\u043E\u0433\u0438\u0447\u0435\u043A\u0438\u0445 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u043E\u0432 \u043F\u043E\u0434\u0441\u0438\u0441\u0442\u0435\u043C\u044B  \u0430\u0432\u0442\u043E\u0440\u0438\u0437\u0430\u0446\u0438\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"L03\" ObjectType=\"TABLE\" BriefText=\"\u0414\u0438\u0430\u043F\u0430\u0437\u043E\u043D\u044B \u0411\u0418\u041D\u043E\u0432 \u0434\u043B\u044F \u043C\u0430\u0440\u0448\u0440\u0443\u0442\u0438\u0437\u0430\u0446\u0438\u0438 \u0430\u0432\u0442\u043E\u0440\u0438\u0437\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0445 \u0438 \u0444\u0438\u043D\u0430\u043D\u0441\u043E\u0432\u044B\u0445 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"L91\" ObjectType=\"TABLE\" BriefText=\"\u041E\u0440\u0438\u0433\u0438\u043D\u0430\u043B\u044C\u043D\u0430\u044F \u0442\u0430\u0431\u043B\u0438\u0446\u0430 BIN\" Ownership=\"0\"/>\n      <ObjectRef ID=\"L92\" ObjectType=\"TABLE\" BriefText=\"\u0418\u0441\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u044F \u0438\u0437 \u0442\u0430\u0431\u043B\u0438\u0446\u044B BIN\" Ownership=\"0\"/>\n      <ObjectRef ID=\"L93\" ObjectType=\"TABLE\" BriefText=\"\u0412\u0440\u0435\u043C\u0435\u043D\u043D\u0430\u044F \u0442\u0430\u0431\u043B\u0438\u0446\u0430 \u0434\u043B\u044F \u0437\u0430\u0433\u0440\u0443\u0437\u043A\u0438 BT (TRANSACTION)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"M01\" ObjectType=\"TABLE\" BriefText=\"\u0411\u043B\u043E\u043A\u0438\u0440\u043E\u0432\u043A\u0430 \u043E\u0431\u044A\u0435\u043A\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"M02\" ObjectType=\"TABLE\" BriefText=\"\u041E\u043F\u0435\u0440\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0435 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u043E\u0439 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438, \u0438\u0441\u043A\u043B\u044E\u0447\u0435\u043D\u043D\u044B\u0435 \u0438\u0437 \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u043A\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"M03\" ObjectType=\"TABLE\" BriefText=\"\u041C\u0430\u0440\u0448\u0440\u0443\u0442\u044B \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"M04\" ObjectType=\"TABLE\" BriefText=\"\u042D\u0442\u0430\u043F\u044B \u0437\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u044B\u0445 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"M06\" ObjectType=\"TABLE\" BriefText=\"\u041E\u043F\u0435\u0440\u0430\u0442\u0438\u0432\u043D\u0430\u044F \u0442\u0430\u0431\u043B\u0438\u0446\u0430 \u0434\u0430\u043D\u043D\u044B\u0445 \u043F\u043E \u043D\u0430\u0447\u0438\u0441\u043B\u0435\u043D\u0438\u044E \u043F\u0440\u043E\u0446\u0435\u043D\u0442\u043E\u0432.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"M10\" ObjectType=\"TABLE\" BriefText=\"\u0418\u0441\u0442\u043E\u0440\u0438\u044F\" Ownership=\"0\"/>\n      <ObjectRef ID=\"M40\" ObjectType=\"TABLE\" BriefText=\"\u041E\u0441\u043D\u043E\u0432\u043D\u044B\u0435 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u043D\u0430\u0431\u043E\u0440\u0430 \u043F\u043E\u043F\u0440\u0430\u0432\u043E\u043A \u043A \u0441\u0442\u0430\u0432\u043A\u0430\u043C \u043F\u043E \u0441\u0447\u0435\u0442\u0430\u043C \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u043E\u0433\u043E \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"M42\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u043E\u043F\u0440\u0430\u0432\u043E\u043A \u043A \u0441\u0442\u0430\u0432\u043A\u0430\u043C \u043F\u043E \u0441\u0447\u0435\u0442\u0430\u043C \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u043E\u0433\u043E \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"M55\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0440\u043E\u0442\u043E\u043A\u043E\u043B\u044B \u0440\u0430\u0441\u0447\u0451\u0442\u0430 \u043F\u0440\u043E\u0446\u0435\u043D\u0442\u043E\u0432 \u043F\u043E \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u044F\u043C \u043F\u0440\u0435\u0434\u0448\u0435\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u043C \u043F\u043E\u0441\u043B\u0435\u0434\u043D\u0435\u0439 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438 \u0440\u0430\u0441\u0447\u0451\u0442\u0430 \u043F\u0440\u043E\u0446\u0435\u043D\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"M56\" ObjectType=\"TABLE\" BriefText=\"\u041E\u043F\u0435\u0440\u0430\u0442\u0438\u0432\u043D\u044B\u0439 \u043F\u0440\u043E\u0442\u043E\u043A\u043E\u043B \u0434\u043B\u044F \u0440\u0435\u0433\u043B\u0430\u043C\u0435\u043D\u0442\u043D\u043E\u0433\u043E \u044D\u0442\u0430\u043F\u0430 \u0440\u0430\u0441\u0447\u0435\u0442\u0430 \u043F\u0440\u043E\u0446\u0435\u043D\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"M57\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0434\u043B\u044F \u0445\u0440\u0430\u043D\u0435\u043D\u0438\u044F \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u044B\u0445 \u0441\u0443\u043C\u043C \u043F\u0440\u043E\u0446\u0435\u043D\u0442\u043E\u0432 \u0438 \u0442\u0430\u0440\u0438\u0444\u043E\u0432 \u043F\u043E \u0441\u0447\u0435\u0442\u0430\u043C \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u043E\u0432.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"M58\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043E\u0441\u0442\u0430\u0432 \u0432\u044B\u0433\u0440\u0443\u0437\u043A\u0438 \u0432 \u0411\u041A\u0418\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N01\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u0438\u0445 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0439 (\u0432 \u043C\u043E\u043C\u0435\u043D\u0442 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u044F \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u0438\u0445 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0439) \u0438 \u0442\u0430\u0431\u043B\u0438\u0446\u0430 \u0441\u0432\u044F\u0437\u0435\u0439 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0445,\u0443\u0447\u0435\u0442\u043D\u044B\u0445 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432 \u0438 \u043E\u0431\u044A\u0435\u043A\u0442\u043E\u0432 \u0437\u0430\u0434\u0435\u0439\u0441\u0442\u0432\u043E\u0432\u0430\u043D\u043D\u044B\u0445 \u0432 \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u043E\u0439 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438 (\u043F\u043E \u043E\u043A\u043E\u043D\u0447\u0430\u043D\u0438\u044E \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u043E\u0439 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N02\" ObjectType=\"TABLE\" BriefText=\"\u041E\u0431\u0449\u0438\u0435 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0445 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432 \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u043E\u0439 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438\" Ownership=\"1\"/>\n      <ObjectRef ID=\"N03\" ObjectType=\"TABLE\" BriefText=\"\u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0435 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B \u0434\u043B\u044F \u043E\u0431\u0441\u043B\u0443\u0436\u0438\u0432\u0430\u043D\u0438\u044F \u043A\u043B\u0438\u0435\u043D\u0442\u043E\u0432.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N04\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u044D\u0442\u0430\u043F\u043E\u0432 \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u0438\u0445 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N05\" ObjectType=\"TABLE\" BriefText=\"\u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0435 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B \u0434\u043B\u044F \u043E\u0442\u043A\u0440\u044B\u0442\u0438\u044F \u043A\u0440\u0435\u0434\u0438\u0442\u043D\u044B\u0445 \u043B\u0438\u043D\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N06\" ObjectType=\"TABLE\" BriefText=\"\u041E\u043F\u0435\u0440\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0435 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B \u0434\u043B\u044F \u043D\u0430\u0447\u0438\u0441\u043B\u0435\u043D\u0438\u044F \u043F\u0440\u043E\u0446\u0435\u043D\u0442\u043E\u0432 \u043F\u043E \u0441\u0447\u0451\u0442\u0443\" Ownership=\"1\"/>\n      <ObjectRef ID=\"N07\" ObjectType=\"TABLE\" BriefText=\"\u0410\u043D\u0430\u043B\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0435 \u043F\u0440\u0438\u0437\u043D\u0430\u043A\u0438 \u0434\u043E\u043F\u043E\u043B\u043D\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0439 \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N08\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u044F \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0445 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432 \u0434\u043B\u044F \u0443\u0447\u0451\u0442\u0430 \u0446\u0435\u043D\u043D\u043E\u0441\u0442\u0435\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N09\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043D\u043E\u043C\u0438\u043D\u0430\u043B\u043E\u0432 \u0438 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D\u043E\u0432 \u043D\u043E\u043C\u0435\u0440\u043E\u0432 \u0446\u0435\u043D\u043D\u043E\u0441\u0442\u0435\u0439, \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u043D\u043D\u044B\u0445 \u0432 \u0441\u0435\u0430\u043D\u0441\u0435 \u0440\u0430\u0431\u043E\u0442\u044B.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N10\" ObjectType=\"TABLE\" BriefText=\"\u0420\u0435\u0435\u0441\u0442\u0440\u044B \u0432\u0430\u043B\u044E\u0442\u043D\u044B\u0445 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N11\" ObjectType=\"TABLE\" BriefText=\"\u0412\u0430\u043B\u044E\u0442\u043D\u044B\u0435 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N12\" ObjectType=\"TABLE\" BriefText=\"\u0420\u0435\u0435\u0441\u0442\u0440\u044B \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0445 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N13\" ObjectType=\"TABLE\" BriefText=\"\u0421\u0442\u0440\u0443\u043A\u0442\u0443\u0440\u0430 \u043C\u0435\u043D\u044E\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N14\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430  \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u043E\u0432 \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u0438\u0445 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0439\" Ownership=\"1\"/>\n      <ObjectRef ID=\"N15\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0440\u043E\u0442\u043E\u043A\u043E\u043B \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u043E\u0432 \u0434\u043B\u044F \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u0438\u0445 \u0440\u0430\u0441\u043F\u043E\u0440\u044F\u0436\u0435\u043D\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N16\" ObjectType=\"TABLE\" BriefText=\"ProfileLaunchHistory\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N17\" ObjectType=\"TABLE\" BriefText=\"\u0411\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u043E\u0435 \u0440\u0430\u0441\u043F\u043E\u0440\u044F\u0436\u0435\u043D\u0438\u0435\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N18\" ObjectType=\"TABLE\" BriefText=\"\u0418\u0441\u0442\u043E\u0440\u0438\u044F \u043F\u0440\u043E\u043B\u043E\u043D\u0433\u0430\u0446\u0438\u0438 \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u043E\u0432\" Ownership=\"1\"/>\n      <ObjectRef ID=\"N19\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u043E\u0432 \u043F\u043E\u0441\u043B\u0435\u0434\u043D\u0435\u0433\u043E \u043D\u0430\u0447\u0438\u0441\u043B\u0435\u043D\u0438\u044F/\u0443\u043F\u043B\u0430\u0442\u044B \u043F\u0440\u043E\u0446\u0435\u043D\u0442\u043E\u0432/\u0442\u0430\u0440\u0438\u0444\u043E\u0432 \u043F\u043E \u0441\u0447\u0451\u0442\u0443.\" Ownership=\"1\"/>\n      <ObjectRef ID=\"N20\" ObjectType=\"TABLE\" BriefText=\"\u0421\u0432\u044F\u0437\u0438 \u043C\u0435\u0436\u0434\u0443 \u043E\u0431\u044A\u0435\u043A\u0442\u0430\u043C\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N21\" ObjectType=\"TABLE\" BriefText=\"\u0414\u043E\u043F\u043E\u043B\u043D\u0438\u0442\u0435\u043B\u044C\u043D\u0430\u044F \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u044F \u043F\u043E \u0438\u0441\u0445\u043E\u0434\u043D\u043E\u043C\u0443 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0443 \u0434\u043B\u044F \u0434\u0435\u0440\u0436\u0430\u0442\u0435\u043B\u0435\u0439 \u043A\u0430\u0440\u0442.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N22\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0445 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432 \u043F\u043E \u043A\u0430\u0440\u0442\u0430\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N23\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u044F \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0445 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432 \u0441 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u0430\u043C\u0438 \u043A\u0430\u0440\u0442\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N24\" ObjectType=\"TABLE\" BriefText=\"\u0420\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u0438\u0441\u0445\u043E\u0434\u043D\u043E\u0433\u043E \u043A\u0430\u0440\u0442\u043E\u0447\u043D\u043E\u0433\u043E \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430 \u0441 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u0430\u043C\u0438 \u0438\u043D\u0434\u0438\u0432\u0438\u0434\u0443\u0430\u043B\u044C\u043D\u044B\u0445 \u043B\u0438\u043C\u0438\u0442\u043E\u0432 \u0430\u043A\u0442\u0438\u0432\u043D\u043E\u0441\u0442\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N25\" ObjectType=\"TABLE\" BriefText=\"\u0420\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u0438\u0441\u0445\u043E\u0434\u043D\u043E\u0433\u043E \u043A\u0430\u0440\u0442\u043E\u0447\u043D\u043E\u0433\u043E \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430 \u0441 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u0430\u043C\u0438 \u0431\u043B\u043E\u043A\u0438\u0440\u043E\u0432\u043E\u043A\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N26\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u043F\u0435\u0440\u0435\u043F\u0440\u0438\u0432\u044F\u0437\u043A\u0438 \u0441\u0447\u0435\u0442\u043E\u0432 \u0441\u0432\u043E\u0434\u043D\u043E\u0433\u043E \u0443\u0447\u0435\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N27\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u044F \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u0438\u0437\u0430\u0446\u0438\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N28\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439 \u043F\u043E \u043F\u0440\u0438\u043D\u0443\u0434\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0439 \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0435 \u0430\u0431\u0441\u043E\u043B\u044E\u0442\u043D\u043E\u0439 \u0432\u0435\u043B\u0438\u0447\u0438\u043D\u044B \u043B\u0438\u043C\u0438\u0442\u043E\u0432 \u043A\u0430\u0440\u0442\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N29\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0443\u0447\u0435\u0442\u043D\u044B\u0445 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N30\" ObjectType=\"TABLE\" BriefText=\"\u0414\u043E\u0433\u043E\u0432\u043E\u0440\u044B \u0444\u0438\u0437\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u0438 \u044E\u0440\u0438\u0434\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u043B\u0438\u0446\" Ownership=\"1\"/>\n      <ObjectRef ID=\"N31\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u043E\u0432 \u043A\u043B\u0438\u0435\u043D\u0442\u043E\u0432 - \u0444\u0438\u0437\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u043B\u0438\u0446\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N32\" ObjectType=\"TABLE\" BriefText=\"\u0421\u0447\u0435\u0442\u0430 \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u043E\u0432\" Ownership=\"1\"/>\n      <ObjectRef ID=\"N33\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0445\u0440\u0430\u043D\u0435\u043D\u0438\u044F \u0431\u0438\u043D\u0430\u0440\u043D\u044B\u0445 \u0434\u0430\u043D\u043D\u044B\u0445\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N34\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u0438 \u043F\u043E\u0441\u043B\u0435\u0434\u043D\u0435\u0439 \u0434\u0430\u0442\u044B \u0441\u043E\u0432\u0435\u0440\u0448\u0435\u043D\u0438\u044F \u0440\u0435\u0433\u043B\u0430\u043C\u0435\u043D\u0442\u043D\u044B\u0445 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0439 \u043F\u043E \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u0443.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N35\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0441\u0443\u043C\u043C, \u0440\u0430\u0441\u0441\u0447\u0438\u0442\u0430\u043D\u043D\u044B\u0445 \u043F\u043E \u0441\u0445\u0435\u043C\u0435 \u0440\u0430\u0437\u043B\u043E\u0436\u0435\u043D\u0438\u044F.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N36\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0441\u0447\u0435\u0442\u043E\u0432, \u0441\u0432\u044F\u0437\u0430\u043D\u044B\u0445 \u0441 \u043B\u0438\u043C\u0438\u0442\u0430\u043C\u0438 \u043A\u0430\u0440\u0442, \u0434\u043B\u044F \u043A\u0430\u0440\u0442\u043E\u0447\u043D\u044B\u0445 \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u043E\u0432.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N37\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0438\u0441\u043E\u043A \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432, \u0443\u0434\u043E\u0441\u0442\u043E\u0432\u0435\u0440\u044F\u044E\u0449\u0438\u0445 \u043B\u0438\u0447\u043D\u043E\u0441\u0442\u044C \u043A\u043B\u0438\u0435\u043D\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N38\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u0440\u0438\u0432\u044F\u0437\u043A\u0438 \u0441\u0445\u0435\u043C \u0440\u0430\u0441\u0447\u0451\u0442\u0430 \u043F\u0440\u043E\u0446\u0435\u043D\u0442\u043E\u0432/\u0442\u0430\u0440\u0438\u0444\u043E\u0432 \u043A \u0441\u0447\u0435\u0442\u0430\u043C \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u043E\u0432.\" Ownership=\"1\"/>\n      <ObjectRef ID=\"N39\" ObjectType=\"TABLE\" BriefText=\"\u0423\u0447\u0451\u0442 \u0444\u0430\u043A\u0442\u043E\u0432 \u043F\u0435\u0447\u0430\u0442\u0438 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432 \u043F\u043E \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u0443\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N40\" ObjectType=\"TABLE\" BriefText=\"\u0420\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u044F \u0430\u0434\u0440\u0435\u0441\u043E\u0432 \u043E\u0431\u044A\u0435\u043A\u0442\u043E\u0432.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N41\" ObjectType=\"TABLE\" BriefText=\"\u041D\u043E\u0440\u043C\u0430\u0442\u0438\u0432\u043D\u044B\u0435 \u043F\u0440\u043E\u0446\u0435\u043D\u0442\u043D\u044B\u0435 \u0441\u0442\u0430\u0432\u043A\u0438\" Ownership=\"1\"/>\n      <ObjectRef ID=\"N42\" ObjectType=\"TABLE\" BriefText=\"\u0414\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B (\u0434\u043E\u0432\u0435\u0440\u0435\u043D\u043D\u043E\u0441\u0442\u0438, \u0430\u0440\u0435\u0441\u0442\u044B \u0438 \u0434\u0440.)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N43\" ObjectType=\"TABLE\" BriefText=\"\u041E\u0441\u043E\u0431\u044B\u0435 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u043E\u0432 \u044E\u0440\u0438\u0434\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u043B\u0438\u0446\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N44\" ObjectType=\"TABLE\" BriefText=\"\u0414\u043E\u0433\u043E\u0432\u043E\u0440\u0430 \u0438 \u043F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u044F \u043A\u043B\u0438\u0435\u043D\u0442\u0441\u043A\u0438\u0445 \u043E\u0440\u0433\u0430\u043D\u0438\u0437\u0430\u0446\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N45\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u043E\u0431\u0435\u0441\u043F\u0435\u0447\u0435\u043D\u0438\u0439 \u043A\u0440\u0435\u0434\u0438\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N46\" ObjectType=\"TABLE\" BriefText=\"\u0424\u0438\u043D\u0430\u043D\u0441\u043E\u0432\u044B\u0435 \u043F\u043E\u0442\u043E\u043A\u0438 \u043F\u043E \u043A\u0440\u0435\u0434\u0438\u0442\u043D\u043E\u043C\u0443 \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u0443\" Ownership=\"1\"/>\n      <ObjectRef ID=\"N47\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u043F\u043E\u0433\u0430\u0448\u0435\u043D\u0438\u044F \u0437\u0430\u0434\u043E\u043B\u0436\u0435\u043D\u043D\u043E\u0441\u0442\u0435\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N49\" ObjectType=\"TABLE\" BriefText=\"\u0421\u0442\u043E\u0440\u043D\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0435 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N50\" ObjectType=\"TABLE\" BriefText=\"\u041F\u043B\u0430\u0442\u0435\u0436\u043D\u044B\u0435 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B, \u0432\u044B\u0433\u0440\u0443\u0436\u0430\u0435\u043C\u044B\u0435 \u0432 \u0411\u0421 \u043F\u043E \u0441\u0447\u0435\u0442\u0430\u043C \u0441\u0432\u043E\u0434\u043D\u043E\u0433\u043E \u0443\u0447\u0435\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N51\" ObjectType=\"TABLE\" BriefText=\"\u041E\u0441\u0442\u0430\u0442\u043A\u0438/\u043E\u0431\u043E\u0440\u043E\u0442\u044B \u043F\u043E \u0441\u0447\u0435\u0442\u0430\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N52\" ObjectType=\"TABLE\" BriefText=\"\u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0435 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B - \u043F\u043B\u0430\u0442\u0435\u0436\u043D\u044B\u0435 \u043F\u043E\u0440\u0443\u0447\u0435\u043D\u0438\u044F (\u0432\u0445\u043E\u0434\u044F\u0449\u0438\u0435 \u0438 \u0438\u0441\u0445\u043E\u0434\u044F\u0449\u0438\u0435)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N53\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043E\u0434\u0435\u0440\u0436\u0438\u0442 \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u044E \u043E\u0431 \u0438\u0441\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0438 \u043F\u043B\u0430\u0442\u0435\u0436\u0430 \u043F\u043E \u043F\u0435\u0440\u0435\u0432\u043E\u0434\u0430\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N54\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u043E\u0432 \u0448\u0430\u0431\u043B\u043E\u043D\u043E\u0432 \u0434\u043B\u044F \u0432\u043D\u0435\u0448\u043D\u0438\u0445 \u043F\u043B\u0430\u0442\u0435\u0436\u0435\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N55\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0440\u043E\u0442\u043E\u043A\u043E\u043B \u0440\u0430\u0441\u0447\u0435\u0442\u0430 \u043F\u0440\u043E\u0446\u0435\u043D\u0442\u043E\u0432\" Ownership=\"1\"/>\n      <ObjectRef ID=\"N56\" ObjectType=\"TABLE\" BriefText=\"\u043E\u0431\u043E\u0440\u043E\u0442\u044B \u043F\u043E \u043D\u0435\u0437\u0430\u0432\u0435\u0448\u0435\u043D\u043D\u044B\u043C \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u044F\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N57\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438 \u043F\u043B\u0430\u0442\u0435\u0436\u0435\u0439 \u044E\u0440\u043B\u0438\u0446\u0430\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N58\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u0440\u0438\u0432\u044F\u0437\u043A\u0438 \u043F\u043E\u0434\u0447\u0438\u043D\u0451\u043D\u043D\u044B\u0445 \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u043E\u0432. \" Ownership=\"0\"/>\n      <ObjectRef ID=\"N59\" ObjectType=\"TABLE\" BriefText=\"\u0420\u0435\u0435\u0441\u0442\u0440 \u0434\u043B\u044F \u043E\u043F\u043B\u0430\u0442\u044B \u044E\u0440\u043B\u0438\u0446\u0430\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N60\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0435\u0445\u043D\u043E\u043B\u043E\u0433\u0438\u0447\u0435\u0441\u043A\u043E\u0435 \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u0434\u043B\u044F \u0430\u0432\u0442\u043E\u0440\u0438\u0437\u0430\u0446\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N61\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043E\u0441\u0442\u0430\u0432 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u043E\u0432 \u0432 \u0448\u0430\u0431\u043B\u043E\u043D\u0435 \u043A\u043E\u043C\u043C\u0443\u043D\u0430\u043B\u044C\u043D\u044B\u0445 \u043F\u043B\u0430\u0442\u0435\u0436\u0435\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N62\" ObjectType=\"TABLE\" BriefText=\"\u0412\u0438\u0434\u044B \u043F\u043B\u0430\u0442\u0435\u0436\u0435\u0439 \u043F\u043E \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u0430\u043C \u044E\u0440\u043B\u0438\u0446\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N63\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u044F \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u0438 \u043E \u0441\u043F\u0435\u0446\u0438\u0430\u043B\u0438\u0437\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0445 \u043F\u043B\u0430\u0442\u0435\u0436\u0430\u0445\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N64\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0443\u0441\u043B\u043E\u0432\u0438\u0439 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u044F \u0434\u043B\u044F \u0434\u043B\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0445 \u043F\u043E\u0440\u0443\u0447\u0435\u043D\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N65\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043E\u0441\u0442\u0430\u0432\u043D\u044B\u0435 \u0441\u0443\u043C\u043C\u044B \u0434\u043B\u044F \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0445 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N66\" ObjectType=\"TABLE\" BriefText=\"\u0413\u0440\u0443\u043F\u043F\u043E\u0432\u044B\u0435 \u0438\u043C\u0435\u043D\u0430 \u0441\u0447\u0435\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N67\" ObjectType=\"TABLE\" BriefText=\"\u0410\u043D\u0430\u043B\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0435 \u0438 \u0441\u0432\u043E\u0434\u043D\u044B\u0435 \u0441\u0447\u0435\u0442\u0430\" Ownership=\"1\"/>\n      <ObjectRef ID=\"N68\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u0438 \u043F\u043E\u0441\u043B\u0435\u0434\u043D\u0435\u0439 \u0434\u0430\u0442\u044B \u0441\u043E\u0432\u0435\u0440\u0448\u0435\u043D\u0438\u044F \u0440\u0435\u0433\u043B\u0430\u043C\u0435\u043D\u0442\u043D\u044B\u0445 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0439 \u043F\u043E \u0441\u0447\u0435\u0442\u0443.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N69\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u0430, \u0441\u0432\u044F\u0437\u0430\u043D\u043D\u044B\u0435 \u0441 \u043A\u0440\u0435\u0434\u0438\u0442\u0430\u043C\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N70\" ObjectType=\"TABLE\" BriefText=\"\u0418\u0441\u0442\u043E\u0440\u0438\u044F \u0441\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u044F \u043F\u043E\u0440\u0442\u0444\u0435\u043B\u0435\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N71\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u0438 \u043A\u043E\u043D\u0442\u0430\u043A\u0442\u043D\u043E\u0439 \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u0438 \u0437\u0430 \u043E\u0431\u044A\u0435\u043A\u0442\u0430\u043C\u0438:\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N73\" ObjectType=\"TABLE\" BriefText=\"\u0414\u043B\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0435 \u043F\u043E\u0440\u0443\u0447\u0435\u043D\u0438\u044F \u043A\u043B\u0438\u0435\u043D\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N74\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0435\u0440\u0435\u043E\u043F\u0440\u0435\u0434\u0435\u043B\u0435\u043D\u0438\u0435 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u043E\u0432 \u0434\u043B\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0445 \u043F\u043E\u0440\u0443\u0447\u0435\u043D\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N75\" ObjectType=\"TABLE\" BriefText=\"\u0421\u0442\u043E\u0438\u043C\u043E\u0441\u0442\u044C \u0446\u0435\u043D\u043D\u043E\u0441\u0442\u0435\u0439 \u043F\u043E \u0441\u0434\u0435\u043B\u043A\u0435\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N77\" ObjectType=\"TABLE\" BriefText=\"\u0421\u0432\u043E\u0434\u043D\u044B\u0435 \u043C\u0435\u043C\u043E\u0440\u0438\u0430\u043B\u044C\u043D\u044B\u0435 \u043E\u0440\u0434\u0435\u0440\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N78\" ObjectType=\"TABLE\" BriefText=\"\u0417\u0430\u044F\u0432\u043A\u0438 \u043D\u0430 \u043E\u0442\u043A\u0440\u044B\u0442\u0438\u0435 \u043A\u0440\u0435\u0434\u0438\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N79\" ObjectType=\"TABLE\" BriefText=\"\u0410\u043A\u0446\u0435\u043F\u0442\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N80\" ObjectType=\"TABLE\" BriefText=\"\u0410\u0440\u0435\u0441\u0442\u044B\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N85\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0440\u043E\u0442\u043E\u043A\u043E\u043B \u0440\u0430\u0441\u0447\u0435\u0442\u0430 \u0442\u0430\u0440\u0438\u0444\u043E\u0432 \u043F\u043E \u0441\u0447\u0451\u0442\u0443.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N86\" ObjectType=\"TABLE\" BriefText=\"\u041E\u043F\u0435\u0440\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0435 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B \u0434\u043B\u044F \u0440\u0430\u0441\u0447\u0451\u0442\u0430 \u0442\u0430\u0440\u0438\u0444\u043E\u0432 \u043F\u043E \u0441\u0447\u0451\u0442\u0443.\" Ownership=\"1\"/>\n      <ObjectRef ID=\"N89\" ObjectType=\"TABLE\" BriefText=\"\u0410\u043D\u0430\u043B\u0438\u0442\u0438\u043A\u0430 \u043F\u043E \u0443\u0447\u0435\u0442\u043D\u043E\u043C\u0443 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0443\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N90\" ObjectType=\"TABLE\" BriefText=\"\u041D\u0430\u043B\u043E\u0433\u043E\u0432\u0430\u044F \u0431\u0430\u0437\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N91\" ObjectType=\"TABLE\" BriefText=\"\u0418\u0441\u0442\u043E\u0440\u0438\u044F \u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u043D\u0430\u043B\u043E\u0433\u043E\u0432\u044B\u0445 \u0432\u044B\u0447\u0435\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"O66\" ObjectType=\"TABLE\" BriefText=\"\u041A\u043E\u043F\u0438\u044F T66\" Ownership=\"0\"/>\n      <ObjectRef ID=\"P01\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0438\u043F \u043E\u0431\u044A\u0435\u043A\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"P02\" ObjectType=\"TABLE\" BriefText=\"\u0410\u0442\u0440\u0438\u0431\u0443\u0442 \u0442\u0438\u043F\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"P04\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u044F \u043E\u0431\u044A\u0435\u043A\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"P05\" ObjectType=\"TABLE\" BriefText=\"\u0421\u0432\u044F\u0437\u044C \u043D\u0430 \u0434\u0438\u0430\u0433\u0440\u0430\u043C\u043C\u0435\" Ownership=\"0\"/>\n      <ObjectRef ID=\"P06\" ObjectType=\"TABLE\" BriefText=\"\u0423\u0437\u0435\u043B \u0434\u0438\u0430\u0433\u0440\u0430\u043C\u043C\u044B\" Ownership=\"0\"/>\n      <ObjectRef ID=\"P07\" ObjectType=\"TABLE\" BriefText=\"\u0414\u043E\u043C\u0435\u043D\u044B\" Ownership=\"0\"/>\n      <ObjectRef ID=\"P08\" ObjectType=\"TABLE\" BriefText=\"\u041C\u0435\u0442\u043E\u0434\u044B \u0442\u0438\u043F\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"P09\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0435\u0440\u0435\u0445\u043E\u0434\u044B \u0442\u0438\u043F\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"P10\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0438\u043F\u043E\u0432\u044B\u0435 \u043C\u0435\u043D\u044E\" Ownership=\"0\"/>\n      <ObjectRef ID=\"P11\" ObjectType=\"TABLE\" BriefText=\"\u041C\u0435\u043D\u044E \u0442\u0438\u043F\u043E\u0432\u044B\u0445 \u043E\u0431\u044A\u0435\u043A\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"P12\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0438\u043F\u043E\u0432\u044B\u0435 \u043C\u0435\u043D\u044E \u0434\u043B\u044F \u0441\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u044F \u043E\u0431\u044A\u0435\u043A\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"P13\" ObjectType=\"TABLE\" BriefText=\"\u041E\u043F\u0438\u0441\u0430\u043D\u0438\u0435 \u0442\u0430\u0431\u043B\u0438\u0446 \u0411\u0414\" Ownership=\"0\"/>\n      <ObjectRef ID=\"P14\" ObjectType=\"TABLE\" BriefText=\"\u041E\u043F\u0438\u0441\u0430\u043D\u0438\u0435 \u043F\u043E\u043B\u0435\u0439 \u0442\u0430\u0431\u043B\u0438\u0446\u044B \u0431\u0430\u0437\u044B \u0434\u0430\u043D\u043D\u044B\u0445\" Ownership=\"0\"/>\n      <ObjectRef ID=\"P15\" ObjectType=\"TABLE\" BriefText=\"\u041E\u0431\u044A\u0435\u043A\u0442\u044B \u0441 XML \u043F\u0440\u0435\u0434\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u0438\u0435\u043C \u0430\u0442\u0442\u0440\u0438\u0431\u0443\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"P16\" ObjectType=\"TABLE\" BriefText=\"\u0423\u0437\u043B\u044B \u0434\u0435\u0440\u0435\u0432\u0430 \u0434\u0435\u0440\u0435\u0432\u0430 \u0432\u044B\u0431\u043E\u0440\u0430 \u043E\u0431\u044A\u0435\u043A\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"P17\" ObjectType=\"TABLE\" BriefText=\"TypicalPhaseBody\" Ownership=\"0\"/>\n      <ObjectRef ID=\"P18\" ObjectType=\"TABLE\" BriefText=\"Components\" Ownership=\"0\"/>\n      <ObjectRef ID=\"P19\" ObjectType=\"TABLE\" BriefText=\"\u0421\u0432\u044F\u0437\u0438 \u0434\u043B\u044F \u0442\u0438\u043F\u043E\u0432\u044B\u0445 \u043E\u0431\u044A\u0435\u043A\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"P20\" ObjectType=\"TABLE\" BriefText=\"\u041F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u0441\u043A\u0438\u0435 \u043D\u0430\u0441\u0442\u043E\u0439\u043A\u0438 \u0434\u043B\u044F \u044D\u0442\u0430\u043F\u043E\u0432 \u043D\u0430 Xaml\" Ownership=\"0\"/>\n      <ObjectRef ID=\"P22\" ObjectType=\"TABLE\" BriefText=\"\u041F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u0441\u043A\u0438\u0435 WPF \u0442\u0435\u043C\u044B\" Ownership=\"0\"/>\n      <ObjectRef ID=\"P23\" ObjectType=\"TABLE\" BriefText=\"\u041F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u0441\u043A\u0438\u0435 \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438 WPF\" Ownership=\"0\"/>\n      <ObjectRef ID=\"P24\" ObjectType=\"TABLE\" BriefText=\"WPF \u0421\u0442\u0438\u043B\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"P25\" ObjectType=\"TABLE\" BriefText=\"\u041D\u0430\u0431\u043E\u0440 \u043F\u0440\u0435\u0434\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u0438\u0439 \u0434\u043B\u044F \u043E\u0431\u044A\u0435\u043A\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Q03\" ObjectType=\"TABLE\" BriefText=\"StopListEntryName Parsed\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Q04\" ObjectType=\"TABLE\" BriefText=\"StoplistEntryName Parsed\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Q06\" ObjectType=\"TABLE\" BriefText=\"StoplistEntityBirthdate Secondary\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Q13\" ObjectType=\"TABLE\" BriefText=\"StoplistEntityPassportRange Secondary\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Q31\" ObjectType=\"TABLE\" BriefText=\"N31 Secondary\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Q69\" ObjectType=\"TABLE\" Ownership=\"0\"/>\n      <ObjectRef ID=\"R02\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440 \u043E\u0442\u0447\u0435\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"R03\" ObjectType=\"TABLE\" BriefText=\"ReportParameterRelation\" Ownership=\"0\"/>\n      <ObjectRef ID=\"R04\" ObjectType=\"TABLE\" BriefText=\"Report\" Ownership=\"0\"/>\n      <ObjectRef ID=\"R05\" ObjectType=\"TABLE\" BriefText=\"\u0424\u043E\u0440\u043C\u0430 \u043E\u0442\u0447\u0435\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"R06\" ObjectType=\"TABLE\" BriefText=\"ReportBankProperties\" Ownership=\"0\"/>\n      <ObjectRef ID=\"R07\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0440\u0438\u0432\u044F\u0437\u043A\u0430 \u043E\u0431\u0449\u0435\u0433\u043E \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u0430 \u043A \u043E\u0442\u0447\u0435\u0442\u0443\" Ownership=\"0\"/>\n      <ObjectRef ID=\"R08\" ObjectType=\"TABLE\" BriefText=\"\u041A\u043E\u043B\u043E\u043D\u043A\u0438 \u043E\u0442\u0447\u0435\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"R09\" ObjectType=\"TABLE\" BriefText=\"\u0412\u044B\u043F\u0438\u0441\u043A\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"R11\" ObjectType=\"TABLE\" BriefText=\"\u041E\u043F\u0438\u0441\u0430\u043D\u0438\u0435 \u043F\u0435\u0440\u0435\u0445\u043E\u0434\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"R12\" ObjectType=\"TABLE\" BriefText=\"SaveUserSetting\" Ownership=\"0\"/>\n      <ObjectRef ID=\"R13\" ObjectType=\"TABLE\" BriefText=\"MappingHeader\" Ownership=\"0\"/>\n      <ObjectRef ID=\"R14\" ObjectType=\"TABLE\" BriefText=\"Mapping\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S00\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0441\u0438\u0441\u0442\u0435\u043C\u043D\u044B\u0445 \u0438 \u0442\u0435\u0445\u043D\u043E\u043B\u043E\u0433\u0438\u0447\u0435\u043A\u0438\u0445 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S01\" ObjectType=\"TABLE\" BriefText=\"\u041E\u0441\u043D\u043E\u0432\u043D\u044B\u0435 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u0444\u0438\u043D\u0430\u043D\u0441\u043E\u0432\u044B\u0445 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S03\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0435\u0446\u0438\u0444\u0438\u0447\u0435\u0441\u043A\u0438\u0435 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u0444\u0438\u043D\u0430\u043D\u0441\u043E\u0432\u044B\u0445 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S04\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u0444\u0430\u0439\u043B\u043E\u0432 \u043F\u043E \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0435\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S05\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0441\u0432\u044F\u0437\u0438 \u0432\u043E\u0437\u0432\u0440\u0430\u0442\u043E\u0432 \u043F\u043E\u043A\u0443\u043F\u043E\u043A \u0441 \u043E\u0440\u0438\u0433\u0438\u043D\u0430\u043B\u044C\u043D\u044B\u043C\u0438 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u044F\u043C\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S07\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u043F\u0430\u043A\u0435\u0442\u0430 \u043F\u043E \u043F\u0440\u0438\u0435\u043C\u0443\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S09\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u0444\u0430\u0439\u043B\u043E\u0432 \u043F\u043E \u043F\u0440\u0438\u0435\u043C\u0443\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S10\" ObjectType=\"TABLE\" BriefText=\"\u0421\u0432\u044F\u0437\u043A\u0430 \u043C\u0435\u0436\u0434\u0443 \u0442\u0440\u0430\u043D\u0437\u0430\u043A\u0446\u0438\u044F\u043C\u0438 \u043F\u043E \u043A\u043E\u043C\u0438\u0441\u0441\u0438\u044F\u043C (FeeCollection) \u0438 \u0444\u0438\u043D\u0430\u043D\u0441\u043E\u0432\u044B\u043C\u0438 \u043B\u0438\u0431\u043E \u0430\u0432\u0442\u043E\u0440\u0438\u0437\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u043C\u0438 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u044F\u043C\u0438 \u0443\u0447\u0442\u0435\u043D\u043D\u044B\u043C\u0438 \u0432 \u0441\u0443\u043C\u043C\u0430\u0445 \u043A\u043E\u043C\u0438\u0441\u0441\u0438\u0439.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S16\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u044F \u0438\u0441\u0445\u043E\u0434\u043D\u043E\u0433\u043E \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430 \u043F\u043E \u043A\u0430\u0440\u0442\u043E\u0447\u043D\u043E\u0439 \u0442\u0440\u0430\u043D\u0437\u0430\u043A\u0446\u0438\u0438 \u0434\u043B\u044F \u043F\u0440\u043E\u0432\u0435\u0434\u0435\u043D\u0438\u044F \u0443\u0447\u0435\u0442\u0430 \u0432 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0443\u044E\u0449\u0435\u043C \u0440\u0430\u0441\u0447\u0435\u0442\u043D\u043E\u043C \u0430\u0433\u0435\u043D\u0442\u0435.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S17\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0441\u0432\u044F\u0437\u0435\u0439 \u043A\u0430\u0440\u0442\u043E\u0447\u043D\u044B\u0445 \u0442\u0440\u0430\u043D\u0437\u0430\u043A\u0446\u0438\u0439 \u0441 \u043A\u043B\u0438\u0440\u0438\u043D\u0433\u043E\u0432\u044B\u043C\u0438 \u043F\u0430\u043A\u0435\u0442\u0430\u043C\u0438 \u0441\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u043C\u0438 \u043F\u0440\u043E\u0446\u0435\u0441\u0441\u043E\u0440\u043E\u043C.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S18\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0441\u0432\u044F\u0437\u0438 \u043A\u0430\u0440\u0442\u043E\u0447\u043D\u044B\u0445 \u0442\u0440\u0430\u043D\u0437\u0430\u043A\u0446\u0438\u0439 \u0441 \u0441\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u043C\u0438 \u043F\u0440\u043E\u0446\u0435\u0441\u0441\u043E\u0440\u043E\u043C c\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u044F\u043C\u0438 Detailed Positions.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S19\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0441\u0432\u044F\u0437\u0438 \u0442\u0440\u0430\u043D\u0437\u0430\u043A\u0446\u0438\u0439 \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u043D\u044B\u0445 \u0432 \u0441\u043E\u0441\u0442\u0430\u0432\u0435 \u0432\u0445\u043E\u0434\u044F\u0449\u0438\u0445 \u0444\u0430\u0439\u043B\u043E\u0432 \u0438\u0437 \u0432\u043D\u0435\u0448\u043D\u0435\u0433\u043E \u0420\u0410\u0426 \u0441 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u044F\u043C\u0438 Detailed Positions.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S38\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u0440\u0438\u0435\u043C\u0430 \u0442\u0435\u043A\u0441\u0442\u043E\u0432\u044B\u0445 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S39\" ObjectType=\"TABLE\" BriefText=\"\u041E\u0431\u0449\u0438\u0435 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439 \u0432 \u043F\u0430\u043A\u0435\u0442\u0435 \u043F\u043E \u0432\u044B\u0445\u043E\u0434\u0443\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S42\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u0440\u0438\u0435\u043C\u0430 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u043E\u0432 Reject-\u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S43\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u043E\u0432 \u043F\u0440\u0438\u043D\u044F\u0442\u044B\u0445 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439 Detailed Positions Details\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S44\" ObjectType=\"TABLE\" BriefText=\"T\u0430\u0431\u043B\u0438\u0446\u0430 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439 \u0430\u0432\u0442\u043E\u0440\u0438\u0437\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0445 \u0432\u043E\u0437\u0432\u0440\u0430\u0442\u043E\u0432 AuthReversalMessData\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S45\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0438 Reject-\u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S47\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u043E\u0432 \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0438 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439 Detailed Position Details\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S51\" ObjectType=\"TABLE\" BriefText=\"\u0410\u0432\u0442\u043E\u0440\u0438\u0437\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0435 \u043E\u0442\u043A\u0430\u0437\u044B\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S52\" ObjectType=\"TABLE\" BriefText=\"\u041E\u0441\u043D\u043E\u0432\u043D\u044B\u0435 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u0430\u0432\u0442\u043E\u0440\u0438\u0437\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0445 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439 Issuer\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S53\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0434\u043E\u043F\u043E\u043B\u043D\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0445 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u043E\u0432 \u0430\u0432\u0442\u043E\u0440\u0438\u0437\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0445 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439 \u043F\u043E \u0441\u043C\u0430\u0440\u0442-\u043A\u0430\u0440\u0442\u0430\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S54\" ObjectType=\"TABLE\" BriefText=\"\u0420\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u043E\u043F\u0435\u0440\u0430\u0442\u0438\u0432\u043D\u043E\u0439 \u0442\u0430\u0431\u043B\u0438\u0446\u044B \u0430\u0432\u0442\u043E\u0440\u0438\u0437\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0445 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439  \u0434\u043B\u044F \u0441\u043C\u0430\u0440\u0442-\u043A\u0430\u0440\u0442 (\u0418\u0441\u0443\u0435\u0440)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S55\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B  \u0430\u0432\u0442\u043E\u0440\u0438\u0437\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0445 \u0438\u043D\u043A\u0440\u0435\u043C\u0435\u043D\u0442\u0430\u043B\u044C\u043D\u044B\u0445 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S69\" ObjectType=\"TABLE\" BriefText=\"\u0421\u0432\u044F\u0437\u044C \u0430\u0432\u0442\u043E\u0440\u0438\u0437\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0445 \u0438 \u0444\u0438\u043D\u0430\u043D\u0441\u043E\u0432\u044B\u0445 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S80\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u0430\u0434\u043C\u0438\u043D\u0438\u0441\u0442\u0440\u0430\u0442\u0438\u0432\u043D\u044B\u0445 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439 \u043F\u043E \u043F\u0440\u0438\u0435\u043C\u0443 ( CopyRequest )\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S82\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0438 \u0430\u0434\u043C\u0438\u043D\u0438\u0441\u0442\u0440\u0430\u0442\u0438\u0432\u043D\u044B\u0445 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439  ( CopyRequestResponse )\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S96\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0435\u0440\u0435\u043A\u043E\u0434\u0438\u0440\u043E\u0432\u043A\u0430 \u0442\u0435\u0440\u043C\u0438\u043D\u0430\u043B\u043E\u0432 \u0432\u043E \u0432\u043D\u0435\u0448\u043D\u0438\u0435 \u0441\u0435\u0442\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S98\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043A\u043E\u0434\u043E\u0432 \u043E\u0431\u0441\u043B\u0443\u0436\u0438\u0432\u0430\u0435\u043C\u044B\u0445 \u0432\u043D\u0435\u0448\u043D\u0438\u0445 \u0441\u0435\u0442\u0435\u0439 \u0442\u0435\u0440\u043C\u0438\u043D\u0430\u043B\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S99\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u0435\u0440\u0435\u043A\u043E\u0434\u0438\u0440\u043E\u0432\u043A\u0438 \u043A\u043E\u0434\u043E\u0432 \u0442\u0435\u0440\u043C\u0438\u043D\u0430\u043B\u043E\u0432 \u0432\u043D\u0435\u0448\u043D\u0438\u0445 \u0441\u0435\u0442\u0435\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T01\" ObjectType=\"TABLE\" BriefText=\"\u041D\u0430\u0441\u0442\u0440\u043E\u0435\u0447\u043D\u0430\u044F \u0442\u0430\u0431\u043B\u0438\u0446\u0430 \u0432\u0435\u0434\u0435\u043D\u0438\u044F \u043F\u0440\u043E\u0442\u043E\u043A\u043E\u043B\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T02\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0432\u0435\u0434\u0435\u043D\u0438\u044F \u043F\u0440\u043E\u0442\u043E\u043A\u043E\u043B\u0430.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T03\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0432\u043B\u043E\u0436\u0435\u043D\u043D\u043E\u0441\u0442\u0438 \u0440\u043E\u043B\u0435\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T04\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0440\u0430\u0432\u0430 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u043E\u043D\u0438\u0441\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T05\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043E\u043F\u0435\u0440\u0430\u0442\u043E\u0440\u043E\u0432 \u0441\u0438\u0441\u0442\u0435\u043C\u044B\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T06\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A \u0442\u0438\u043F\u043E\u0432 \u0443\u0447\u0435\u0442\u043D\u044B\u0445 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T07\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u0442\u0438\u043F\u043E\u0432\u043E\u0439 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T08\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u0443\u0441\u043B\u043E\u0432\u0438\u0439 \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u0438\u0445 \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u043E\u0432 \u0434\u043B\u044F \u0444\u0438\u0437\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u043B\u0438\u0446.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T09\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0445\u0440\u0430\u043D\u0435\u043D\u0438\u044F \u0434\u043E\u043F\u043E\u043B\u043D\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0445 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u043E\u0432 \u0446\u0435\u043D\u043D\u043E\u0441\u0442\u0435\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T10\" ObjectType=\"TABLE\" BriefText=\"\u041D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438 \u0434\u043B\u044F \u043F\u0440\u043E\u0446\u0435\u0434\u0443\u0440\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T11\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0438\u043F\u043E\u0432\u044B\u0435 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T12\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0438\u043F\u043E\u0432\u044B\u0435 \u044D\u0442\u0430\u043F\u044B \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T13\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043E\u0441\u0442\u0430\u0432 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438. \u041E\u043F\u0438\u0441\u044B\u0432\u0430\u0435\u0442 \u043A\u0430\u043A\u0438\u0435 \u0442\u0438\u043F\u043E\u0432\u044B\u0435 \u044D\u0442\u0430\u043F\u044B \u0432\u0445\u043E\u0434\u044F\u0442 \u0432 \u0441\u043E\u0441\u0442\u0430\u0432 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T14\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0440\u0438\u0432\u044F\u0437\u043A\u0430 \u0442\u0438\u043F\u043E\u0432\u044B\u0445 \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u0438\u0445 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0439 \u043A \u043A\u043E\u043D\u0441\u0442\u0430\u043D\u0442\u043D\u044B\u043C \u0438\u043C\u0435\u043D\u0430\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T15\" ObjectType=\"TABLE\" BriefText=\"\u0421\u0432\u044F\u0437\u043A\u0430 \u0442\u0438\u043F\u043E\u0432\u044B\u0445 \u044D\u0442\u0430\u043F\u043E\u0432 \u0441 \u043A\u043E\u043D\u0441\u0442\u0430\u043D\u0442\u043D\u044B\u043C\u0438 \u0433\u0440\u0443\u043F\u043F\u043E\u0432\u044B\u043C\u0438 \u0438\u043C\u0435\u043D\u0430\u043C\u0438 \u0441\u0447\u0435\u0442\u043E\u0432.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T16\" ObjectType=\"TABLE\" BriefText=\"ProfileSetting\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T17\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043E\u0441\u0442\u0430\u0432 \u0444\u0443\u043D\u043A\u0446\u0438\u043E\u043D\u0430\u043B\u044C\u043D\u043E\u0441\u0442\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T18\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0432\u0438\u0434\u043E\u0432 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0439 \u043F\u043E \u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u0438 117-\u0418.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T19\" ObjectType=\"TABLE\" BriefText=\"\u041A\u0430\u043B\u0435\u043D\u0434\u0430\u0440\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T20\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430  \u043E\u043F\u0438\u0441\u0430\u043D\u0438\u044F \u0440\u0430\u0431\u043E\u0447\u0438\u0445 \u043C\u0435\u0441\u0442\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T21\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0440\u0435\u0433\u0438\u0441\u0442\u0440\u043E\u0432 \u0434\u043B\u044F \u0445\u0440\u0430\u043D\u0435\u043D\u0438\u044F \u0446\u0435\u043D\u043D\u043E\u0441\u0442\u0435\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T22\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430  \u0440\u0430\u0437\u0440\u0435\u0448\u0435\u043D\u043D\u044B\u0445 \u0432\u043E\u0437\u043C\u043E\u0436\u043D\u043E\u0441\u0442\u0435\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T23\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0438\u0441\u043E\u043A \u0434\u043E\u043B\u0436\u043D\u043E\u0441\u0442\u0435\u0439 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T24\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043D\u0430\u0441\u0442\u0440\u043E\u0435\u043A \u0440\u0435\u0433\u0438\u0441\u0442\u0440\u043E\u0432 \u0434\u043B\u044F \u0441\u0440\u0435\u0434\u0441\u0442\u0432 \u0445\u0440\u0430\u043D\u0435\u043D\u0438\u044F \u0446\u0435\u043D\u043D\u043E\u0441\u0442\u0435\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T25\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430  \u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u0438 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T26\" ObjectType=\"TABLE\" BriefText=\"\u0414\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u044B\u0435 \u043F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u044F \u0440\u0430\u0431\u043E\u0442\u044B\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T27\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0445\u0440\u0430\u043D\u0435\u043D\u0438\u044F \u0442\u0438\u043F\u043E\u0432 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432 \u043A\u043B\u0438\u0435\u043D\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T28\" ObjectType=\"TABLE\" BriefText=\"\u0412\u043D\u0443\u0442\u0440\u0435\u043D\u043D\u044F\u044F \u0441\u0442\u0440\u0443\u043A\u0442\u0443\u0440\u0430 \u0431\u0430\u043D\u043A\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T29\" ObjectType=\"TABLE\" BriefText=\"\u041E\u043F\u0438\u0441\u0430\u043D\u0438\u0435 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u043E\u0432 \u043A\u043E\u043C\u043C\u0443\u043D\u0430\u043B\u044C\u043D\u044B\u0445 \u043F\u043B\u0430\u0442\u0435\u0436\u0435\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T30\" ObjectType=\"TABLE\" BriefText=\"\u0413\u0440\u0443\u043F\u043F\u044B \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u0438\u0445 \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u043E\u0432.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T31\" ObjectType=\"TABLE\" BriefText=\"\u041E\u0431\u0449\u0438\u0435 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u0438\u0445 \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u043E\u0432 (\u0442\u0438\u043F\u043E\u0432\u044B\u0445 \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u043E\u0432).\" Ownership=\"1\"/>\n      <ObjectRef ID=\"T32\" ObjectType=\"TABLE\" BriefText=\"\u0414\u043E\u043F\u043E\u043B\u043D\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0435 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u0438\u0445 \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u043E\u0432 (\u0442\u0438\u043F\u043E\u0432\u044B\u0445 \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u043E\u0432) \u043F\u043E \u0443\u0441\u043B\u0443\u0433\u0430\u043C, \u0441\u0432\u044F\u0437\u0430\u043D\u043D\u044B\u043C \u0441 \u0434\u0435\u043F\u043E\u0437\u0438\u0442\u0430\u043C\u0438.\" Ownership=\"1\"/>\n      <ObjectRef ID=\"T33\" ObjectType=\"TABLE\" BriefText=\"\u0414\u043E\u043F\u043E\u043B\u043D\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0435 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u0438\u0445 \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u043E\u0432 (\u0442\u0438\u043F\u043E\u0432\u044B\u0445 \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u043E\u0432) \u043F\u043E \u0443\u0441\u043B\u0443\u0433\u0430\u043C, \u0441\u0432\u044F\u0437\u0430\u043D\u043D\u044B\u043C \u0441 \u043A\u0440\u0435\u0434\u0438\u0442\u0430\u043C\u0438.\" Ownership=\"1\"/>\n      <ObjectRef ID=\"T34\" ObjectType=\"TABLE\" BriefText=\"\u0424\u043E\u0440\u043C\u044B \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432, \u043F\u0435\u0447\u0430\u0442\u0430\u044E\u0449\u0438\u0445\u0441\u044F \u043F\u0440\u0438 \u043E\u0442\u043A\u0440\u044B\u0442\u0438\u0438 \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u0430 \u0432 \u0440\u0430\u043C\u043A\u0430\u0445 \u0434\u0430\u043D\u043D\u043E\u0433\u043E \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u043E\u0433\u043E \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u0430.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T35\" ObjectType=\"TABLE\" BriefText=\"\u0411\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u0438\u0435 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438, \u0440\u0430\u0437\u0440\u0435\u0448\u0435\u043D\u043D\u044B\u0435 \u0434\u043B\u044F \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u0438\u0445 \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u043E\u0432.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T36\" ObjectType=\"TABLE\" BriefText=\"\u0413\u0440\u0443\u043F\u043F\u043E\u0432\u044B\u0435 \u0438\u043C\u0435\u043D\u0430 \u0441\u0447\u0435\u0442\u043E\u0432, \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0435\u043C\u044B\u0435 \u0432 \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u0438\u0445 \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u0430\u0445.\" Ownership=\"1\"/>\n      <ObjectRef ID=\"T37\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043E\u0441\u043D\u043E\u0432\u043D\u044B\u0445 \u0441\u0445\u0435\u043C \u043D\u0430\u0447\u0438\u0441\u043B\u0435\u043D\u0438\u044F \u043F\u043E \u0441\u0447\u0435\u0442\u0430\u043C \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u043E\u0433\u043E \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u0430.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T38\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0443\u0441\u043B\u043E\u0432\u0438\u0439 \u0440\u0430\u0441\u0447\u0451\u0442\u0430 \u0441\u0443\u043C\u043C\u044B \u043F\u0435\u0440\u0438\u043E\u0434\u0438\u0447\u0435\u0441\u043A\u043E\u0433\u043E \u043F\u043B\u0430\u0442\u0435\u0436\u0430 \u0434\u043B\u044F \u043F\u043E\u0433\u0430\u0448\u0435\u043D\u0438\u044F \u0441\u0441\u0443\u0434\u043D\u043E\u0439 \u0437\u0430\u0434\u043E\u043B\u0436\u0435\u043D\u043D\u043E\u0441\u0442\u0438 \u0432 \u043A\u0440\u0435\u0434\u0438\u0442\u043D\u044B\u0445 \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u0430\u0445.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T39\" ObjectType=\"TABLE\" BriefText=\"\u0420\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u044F \u0442\u0438\u043F\u043E\u0432 \u0430\u0434\u0440\u0435\u0441\u043E\u0432 \u043E\u0431\u044A\u0435\u043A\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T40\" ObjectType=\"TABLE\" BriefText=\"\u0421\u0445\u0435\u043C\u044B \u043D\u0430\u0447\u0438\u0441\u043B\u0435\u043D\u0438\u0439.\" Ownership=\"1\"/>\n      <ObjectRef ID=\"T41\" ObjectType=\"TABLE\" BriefText=\"\u041C\u0435\u0442\u043E\u0434\u044B \u043D\u0430\u0447\u0438\u0441\u043B\u0435\u043D\u0438\u0439 \u043F\u0440\u043E\u0446\u0435\u043D\u0442\u043E\u0432.\" Ownership=\"1\"/>\n      <ObjectRef ID=\"T42\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0441\u0442\u0430\u0432\u043E\u043A \u0434\u043B\u044F \u0441\u0445\u0435\u043C \u043D\u0430\u0447\u0438\u0441\u043B\u0435\u043D\u0438\u044F \u043F\u0440\u043E\u0446\u0435\u043D\u0442\u043E\u0432.\" Ownership=\"1\"/>\n      <ObjectRef ID=\"T43\" ObjectType=\"TABLE\" BriefText=\"\u041D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438 \u0442\u0438\u043F\u043E\u0432\u044B\u0445 \u0433\u0440\u0443\u043F\u043F \u043A\u0443\u0440\u0441\u043E\u0432\u044B\u0445 \u0441\u0442\u0430\u0432\u043E\u043A\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T44\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u0440\u0438\u0432\u044F\u0437\u043A\u0438 \u0441\u0445\u0435\u043C \u0440\u0430\u0441\u0447\u0451\u0442\u0430 \u0442\u0430\u0440\u0438\u0444\u043E\u0432 \u043A \u0441\u0447\u0435\u0442\u0430\u043C \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u043E\u0433\u043E \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u0430.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T45\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u0430\u0440 \u0432\u0430\u043B\u044E\u0442 \u0434\u043B\u044F \u0437\u0430\u0432\u0435\u0434\u0435\u043D\u0438\u044F \u043A\u0443\u0440\u0441\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T46\" ObjectType=\"TABLE\" BriefText=\"\u041D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438 \u0433\u0440\u0443\u043F\u043F \u043A\u0443\u0440\u0441\u043E\u0432\u044B\u0445 \u0441\u0442\u0430\u0432\u043E\u043A\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T47\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u0435\u0440\u0438\u043E\u0434\u043E\u0432 \u043F\u043E\u0433\u0430\u0448\u0435\u043D\u0438\u044F \u043E\u0441\u043D\u043E\u0432\u043D\u043E\u0439 \u0437\u0430\u0434\u043E\u043B\u0436\u0435\u043D\u043D\u043E\u0441\u0442\u0438 \u043F\u043E \u043A\u0440\u0435\u0434\u0438\u0442\u043D\u044B\u043C \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u0438\u043C \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u0430\u043C.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T48\" ObjectType=\"TABLE\" BriefText=\"\u041D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0430 \u043F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u0438 \u043F\u043E\u0433\u0430\u0448\u0435\u043D\u0438\u0439 \u043F\u043E \u0441\u0447\u0435\u0442\u0430\u043C \u043A\u0440\u0435\u0434\u0438\u0442\u043D\u043E\u0433\u043E \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u043E\u0433\u043E \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u0430.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T49\" ObjectType=\"TABLE\" BriefText=\"\u0428\u0430\u0431\u043B\u043E\u043D\u044B \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u043E\u0432 \u043A\u043E\u043C\u043C\u0443\u043D\u0430\u043B\u044C\u043D\u044B\u0445 \u043F\u043B\u0430\u0442\u0435\u0436\u0435\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T50\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0442\u0438\u043F\u043E\u0432\u044B\u0445 \u0434\u043B\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0445 \u043F\u043E\u0440\u0443\u0447\u0435\u043D\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T51\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A \u0430\u043D\u0430\u043B\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u043F\u0440\u0438\u0437\u043D\u0430\u043A\u043E\u0432 \u0441\u0447\u0435\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T52\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u0440\u0438\u0432\u044F\u0437\u043A\u0438 \u0441\u0445\u0435\u043C \u0440\u0430\u0441\u0447\u0451\u0442\u0430 \u043F\u0440\u043E\u0446\u0435\u043D\u0442\u043E\u0432/\u0442\u0430\u0440\u0438\u0444\u043E\u0432 \u043A \u0442\u0438\u043F\u0430\u043C \u0442\u0430\u0440\u0438\u0444\u043E\u0432 \u043F\u043E \u0441\u0447\u0451\u0442\u0443.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T53\" ObjectType=\"TABLE\" BriefText=\"\u0413\u0440\u0443\u043F\u043F\u044B \u0441\u0447\u0435\u0442\u043E\u0432 \u0441\u0432\u043E\u0434\u043D\u043E\u0433\u043E \u0443\u0447\u0435\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T54\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0441\u0447\u0435\u0442\u0447\u0438\u043A\u043E\u0432 (SEQUENCE)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T55\" ObjectType=\"TABLE\" BriefText=\"\u041A\u0440\u0438\u0442\u0435\u0440\u0438\u0438 \u043F\u0440\u0438\u0432\u044F\u0437\u043A\u0438 \u0430\u043D\u0430\u043B\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u0441\u0447\u0435\u0442\u043E\u0432 \u043A \u0441\u0447\u0435\u0442\u0430\u043C \u0441\u0432\u043E\u0434\u043D\u043E\u0433\u043E \u0443\u0447\u0435\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T56\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u0434\u043B\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0445 \u043F\u043E\u0440\u0443\u0447\u0435\u043D\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T57\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u0440\u0438\u0432\u044F\u0437\u043A\u0438 \u0433\u0440\u0443\u043F\u043F \u0441\u0447\u0435\u0442\u043E\u0432 \u0441\u0432\u043E\u0434\u043D\u043E\u0433\u043E \u0443\u0447\u0435\u0442\u0430 \u043A \u0442\u0438\u043F\u0430\u043C \u043E\u0431\u044A\u0435\u043A\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T58\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0441\u0432\u044F\u0437\u0435\u0439 \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u0438\u0445 \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u043E\u0432 \u0441 \u043E\u0442\u043D\u043E\u0448\u0435\u043D\u0438\u0435\u043C \u043E\u0441\u043D\u043E\u0432\u043D\u043E\u0439 \u043F\u043E\u0434\u0447\u0438\u043D\u0451\u043D\u043D\u044B\u0439.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T59\" ObjectType=\"TABLE\" BriefText=\"\u0421\u0445\u0435\u043C\u0430 \u0440\u0430\u0437\u043B\u043E\u0436\u0435\u043D\u0438\u044F \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u043E\u0439 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438 \u043D\u0430 \u0443\u0447\u0435\u0442\u043D\u044B\u0435 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T60\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0438\u043F\u043E\u0432\u043E\u0435 \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u043E\u0435 \u0440\u0430\u0441\u043F\u043E\u0440\u044F\u0436\u0435\u043D\u0438\u0435\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T61\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A \u0442\u0438\u043F\u043E\u0432 \u0444\u0438\u043D\u0430\u043D\u0441\u043E\u0432\u044B\u0445 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T62\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0433\u0440\u0443\u043F\u043F \u0442\u0438\u043F\u043E\u0432\u044B\u0445 \u0444\u0438\u043D\u0430\u043D\u0441\u043E\u0432\u044B\u0445 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T63\" ObjectType=\"TABLE\" BriefText=\"\u041A\u0440\u0438\u0442\u0435\u0440\u0438\u0438 \u0434\u043B\u044F \u0433\u0440\u0443\u043F\u043F \u043A\u0443\u0440\u0441\u043E\u0432\u044B\u0445 \u0441\u0442\u0430\u0432\u043E\u043A\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T64\" ObjectType=\"TABLE\" BriefText=\"\u0428\u0430\u0431\u043B\u043E\u043D\u044B \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0439 \u0444\u0438\u043D\u0430\u043D\u0441\u043E\u0432\u044B\u0445 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T65\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A \u0418\u0414 \u0441\u0443\u043C\u043C \u0441\u0445\u0435\u043C\u044B \u0440\u0430\u0437\u043B\u043E\u0436\u0435\u043D\u0438\u044F\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T67\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A \u0418\u0414 \u0441\u0447\u0435\u0442\u043E\u0432 \u0441\u0445\u0435\u043C\u044B \u0440\u0430\u0437\u043B\u043E\u0436\u0435\u043D\u0438\u044F\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T68\" ObjectType=\"TABLE\" BriefText=\"\u041D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0430 \u0441\u043F\u0435\u0446\u0438\u0430\u043B\u044C\u043D\u044B\u0445 \u0440\u0435\u0435\u0441\u0442\u0440\u043E\u0432(\u0432\u044B\u043F\u0438\u0441\u043A\u0430, \u0432\u0430\u043B\u044E\u0442\u043D\u044B\u0435 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T69\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432 \u043D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u043E\u0441\u0442\u0438 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u043E\u043D\u043D\u043E\u0433\u043E \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T70\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u043E\u0432 \u0431\u0430\u043D\u043A\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T71\" ObjectType=\"TABLE\" BriefText=\"\u0420\u0435\u043A\u0432\u0438\u0437\u0438\u0442\u044B \u0431\u0430\u043D\u043A\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T72\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438 \u0442\u0438\u043F\u043E\u0432 \u043A\u043E\u043D\u0442\u0430\u043A\u0442\u043D\u043E\u0439 \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u0438 \u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u0443\u0435\u043C\u044B\u0445 \u0437\u0430 \u043E\u0431\u044A\u0435\u043A\u0442\u043E\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T73\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0448\u0430\u0431\u043B\u043E\u043D\u043E\u0432 \u0432\u044B\u0432\u043E\u0434\u0430 \u0430\u0434\u0440\u0435\u0441\u043E\u0432 \u043E\u0431\u044A\u0435\u043A\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T74\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A \u0441\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0439 \u0434\u043B\u044F \u043A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u0439 \u0446\u0435\u043D\u043D\u043E\u0441\u0442\u0435\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T75\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0432\u0438\u0434\u043E\u0432 \u0446\u0435\u043D\u043D\u043E\u0441\u0442\u0435\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T76\" ObjectType=\"TABLE\" BriefText=\"\u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u0435 \u043D\u043E\u043C\u0438\u043D\u0430\u043B\u043E\u0432 \u0446\u0435\u043D\u043D\u043E\u0441\u0442\u0435\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T77\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0438\u043F\u043E\u0432\u044B\u0435 \u0441\u0432\u043E\u0434\u043D\u044B\u0435 \u043C\u0435\u043C\u043E\u0440\u0438\u0430\u043B\u044C\u043D\u044B\u0435 \u043E\u0440\u0434\u0435\u0440\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T78\" ObjectType=\"TABLE\" BriefText=\"\u041A\u043E\u0434\u044B \u0434\u043B\u044F \u0432\u0435\u0434\u0435\u043D\u0438\u044F \u0440\u0443\u0431\u043B\u0435\u0432\u044B\u0445 \u0441\u0447\u0435\u0442\u043E\u0432 \u043D\u0435\u0440\u0435\u0437\u0438\u0434\u0435\u043D\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T79\" ObjectType=\"TABLE\" BriefText=\"\u041A\u043E\u0434\u044B \u0442\u0435\u0440\u0440\u0438\u0442\u043E\u0440\u0438\u0439 \u043F\u043E \u0421\u041E\u0410\u0422\u041E\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T80\" ObjectType=\"TABLE\" BriefText=\"\u0420\u0430\u0441\u0448\u0438\u0444\u0440\u043E\u0432\u043A\u0430 \u043A\u043E\u043D\u0441\u0442\u0430\u043D\u0442\u043D\u044B\u0445 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T81\" ObjectType=\"TABLE\" BriefText=\"\u0420\u0430\u0441\u0448\u0438\u0444\u0440\u043E\u0432\u043A\u0430 \u043A\u043E\u043D\u0441\u0442\u0430\u043D\u0442\u043D\u044B\u0445 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0439 \u043A\u043E\u043D\u043A\u0440\u0435\u0442\u043D\u043E\u0433\u043E \u0431\u0430\u043D\u043A\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T82\" ObjectType=\"TABLE\" BriefText=\"\u041A\u0430\u043B\u0435\u043D\u0434\u0430\u0440\u044C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T83\" ObjectType=\"TABLE\" BriefText=\"Holidays\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T84\" ObjectType=\"TABLE\" BriefText=\"\u0420\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u044F \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u043E\u0432 \u044E\u0440\u0438\u0434\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u043B\u0438\u0446\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T85\" ObjectType=\"TABLE\" BriefText=\"\u0420\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u0443\u0435\u043C\u044B\u0435 \u043E\u0431\u044A\u0435\u043A\u0442\u044B\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T86\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u0432\u0438\u0434\u043E\u0432 \u0446\u0435\u043D\u043D\u043E\u0441\u0442\u0435\u0439, \u0437\u0430\u0432\u0438\u0441\u044F\u0449\u0438\u0435 \u043E\u0442 \u0438\u0445 \u0441\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u044F\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T87\" ObjectType=\"TABLE\" BriefText=\"\u0420\u0430\u0437\u0440\u0435\u0448\u0435\u043D\u043D\u044B\u0435 \u043A\u0430\u0440\u0442\u043E\u0447\u043D\u044B\u0435 \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B \u0444\u0443\u043D\u043A\u0446\u0438\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0445 \u043E\u0431\u044A\u0435\u043A\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T88\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0438\u0441\u043E\u043A \u043F\u0440\u0438\u0437\u043D\u0430\u043A\u043E\u0432 \u0434\u043B\u044F \u0443\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u044F \u0440\u0430\u0437\u043B\u043E\u0436\u0435\u043D\u0438\u0435\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T89\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0440\u0438\u0432\u044F\u0437\u043A\u0430 \u043F\u0440\u0438\u0437\u043D\u0430\u043A\u043E\u0432 \u0434\u043B\u044F \u0443\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u044F \u0440\u0430\u0437\u043B\u043E\u0436\u0435\u043D\u0438\u0435\u043C \u043A \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u043C \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430\u043C.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T90\" ObjectType=\"TABLE\" BriefText=\"\u0417\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u0430\u043D\u0430\u043B\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u043F\u0440\u0438\u0437\u043D\u0430\u043A\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T91\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0445\u0430\u0440\u0430\u043A\u0442\u0435\u0440\u0438\u0441\u0442\u0438\u043A \u0444\u043E\u0440\u043C\u0430\u0442\u0430 \u043E\u0431\u043C\u0435\u043D\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T92\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0438\u043F\u044B \u0430\u043D\u0430\u043B\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u043F\u0440\u0438\u0437\u043D\u0430\u043A\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T93\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u043E\u0441\u043E\u0431\u044B \u043E\u043F\u0440\u0435\u0434\u0435\u043B\u0435\u043D\u0438\u044F \u0441\u043F\u0438\u0441\u043A\u0430 \u0434\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u044B\u0445 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0439 \u0430\u043D\u0430\u043B\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u043F\u0440\u0438\u0437\u043D\u0430\u043A\u043E\u0432.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T94\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u0440\u0438\u0432\u044F\u0437\u043A\u0438 \u0442\u0438\u043F\u0430 \u0444\u0430\u0439\u043B\u0430 \u043A \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0435 \u043A\u043E\u043D\u0432\u0435\u0440\u0442\u043E\u0440\u0443\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T95\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u0440\u0438\u0432\u044F\u0437\u043A\u0438 \u0434\u043E\u043B\u0436\u043D\u043E\u0441\u0442\u043D\u044B\u0445 \u043B\u0438\u0446 \u0441 \u043F\u0440\u0430\u0432\u043E\u043C \u043F\u043E\u0434\u043F\u0438\u0441\u0438 \u043A \u044E\u0440. \u043B\u0438\u0446\u0443\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T96\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0440\u0438\u0432\u044F\u0437\u043A\u0430 \u043F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u0439 \u043A \u0433\u0440\u0443\u043F\u043F\u0435 \u043A\u0443\u0440\u0441\u043E\u0432\u044B\u0445 \u0441\u0442\u0430\u0432\u043E\u043A\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T97\" ObjectType=\"TABLE\" BriefText=\"\u0434\u043E\u043F\u043E\u043B\u043D\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0435 \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438 \u0434\u043B\u044F \u0437\u0430\u0434\u0430\u043D\u0438\u044F \u043A\u043E\u043D\u0444\u0438\u0433\u0443\u0440\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0445 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T98\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0438\u0441\u043E\u043A \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0439 \u0434\u043B\u044F \u0437\u0430\u0434\u0430\u043D\u0438\u044F \u043A\u043E\u043D\u0444\u0438\u0433\u0443\u0440\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0445 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T99\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0441\u0438\u0441\u0442\u0435\u043C\u043D\u044B\u0445 \u043E\u0448\u0438\u0431\u043E\u043A 3CARD-R\" Ownership=\"0\"/>\n      <ObjectRef ID=\"U01\" ObjectType=\"TABLE\" BriefText=\"CartotekaDocuments\" Ownership=\"0\"/>\n      <ObjectRef ID=\"U98\" ObjectType=\"TABLE\" BriefText=\"UFEBMPaymentDocuments\" Ownership=\"0\"/>\n      <ObjectRef ID=\"W00\" ObjectType=\"TABLE\" BriefText=\"\u041A\u043E\u043D\u0444\u0438\u0433\u0443\u0440\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0435 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u0441\u0435\u0430\u043D\u0441\u0430 \u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"W01\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u043E\u0432 \u0444\u0430\u0439\u043B\u043E\u0432 \u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F\" Ownership=\"0\"/>\n      <ObjectRef ID=\"W02\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u043E\u0432 \u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0445 \u043A\u043B\u0438\u0435\u043D\u0442\u043E\u0432 \u0431\u0430\u043D\u043A\u0430.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"W03\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u043E\u0432 \u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0445 \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u043E\u0432 \u0444\u0438\u0437\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u043B\u0438\u0446.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"W04\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u043E\u0432 \u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0445 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0445 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432 \u043F\u043E \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u0430\u043C \u0444\u0438\u0437\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u043B\u0438\u0446.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"W05\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043D\u043E\u043C\u0435\u0440\u043E\u0432 \u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0445 \u043F\u0440\u0438\u043B\u0438\u043D\u043A\u043E\u0432\u0430\u043D\u043D\u044B\u0445 \u043A\u0430\u0440\u0442.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"W06\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u043E\u0432 \u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0445 \u0430\u0432\u0442\u043E\u0440\u0438\u0437\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0445 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"W07\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0445 \u043E\u0431\u043E\u0440\u043E\u0442\u043E\u0432 \u043F\u043E \u0441\u0447\u0435\u0442\u0430\u043C.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"W08\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u043E\u0432 (\u043D\u043E\u043C\u0435\u0440\u043E\u0432) \u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0445 \u0441\u0447\u0435\u0442\u043E\u0432 \u043F\u043E \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u0430\u043C \u0444\u0438\u0437\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u043B\u0438\u0446.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"W09\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u043E\u0432 \u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0445 \u0444\u0438\u0440\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"W10\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u043E\u0432 \u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0445 \u0442\u0435\u0440\u043C\u0438\u043D\u0430\u043B\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"W11\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430  \u0437\u0430\u0433\u0440\u0443\u0437\u043A\u0438 \u0431\u0438\u043D\u0430\u0440\u043D\u044B\u0445 \u0444\u0430\u0439\u043B\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"W12\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0445 \u0433\u0440\u0430\u0444\u0438\u043A\u043E\u0432 \u043F\u043E\u0433\u0430\u0448\u0435\u043D\u0438\u044F\" Ownership=\"0\"/>\n      <ObjectRef ID=\"W13\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u043E\u0432 \u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0445 \u044E\u0440. \u043B\u0438\u0446\" Ownership=\"0\"/>\n      <ObjectRef ID=\"W14\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u043E\u0432 \u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0445 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u043E\u0432 \u043A\u043E\u043C\u043C\u0443\u043D\u0430\u043B\u044C\u043D\u044B\u0445 \u043F\u043B\u0430\u0442\u0435\u0436\u0435\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"W15\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u043E\u0432 \u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0445 \u0448\u0430\u0431\u043B\u043E\u043D\u043E\u0432 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u043E\u0432 \u043A\u043E\u043C\u043C\u0443\u043D\u0430\u043B\u044C\u043D\u044B\u0445 \u043F\u043B\u0430\u0442\u0435\u0436\u0435\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"W16\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u043E\u0432 \u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0445 \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u043E\u0432 \u044E\u0440. \u043B\u0438\u0446\" Ownership=\"0\"/>\n      <ObjectRef ID=\"W17\" ObjectType=\"TABLE\" BriefText=\"\u041E\u0441\u0442\u0430\u0442\u043A\u0438 \u043F\u043E \u043A\u0430\u0440\u0442\u0430\u043C \u0432 \u0441\u0438\u0441\u0442\u0435\u043C\u0435 BankSoft\" Ownership=\"0\"/>\n      <ObjectRef ID=\"W18\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u043E\u0432 \u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0445 \u043E\u0431\u044A\u0435\u043A\u0442\u043E\u0432 \u0431\u0430\u043D\u043A\u0430.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"X00\" ObjectType=\"TABLE\" BriefText=\"\u041E\u043F\u0438\u0441\u0430\u043D\u0438\u0435 \u043F\u043E\u043B\u0435\u0439 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"X01\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u043E\u0438\u0441\u043A\u0430 \u0437\u0430\u043F\u0440\u043E\u0441\u043E\u0432 \u043F\u0440\u0438 \u043F\u0440\u0438\u0435\u043C\u0435\" Ownership=\"0\"/>\n      <ObjectRef ID=\"X03\" ObjectType=\"TABLE\" BriefText=\"\u041E\u043F\u0438\u0441\u0430\u043D\u0438\u0435 \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0435\u043C\u044B\u0445 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"X04\" ObjectType=\"TABLE\" BriefText=\"\u041E\u043F\u0438\u0441\u0430\u043D\u0438\u0435 SQL-\u0437\u0430\u043F\u0440\u043E\u0441\u043E\u0432 \u043F\u043E \u043F\u0440\u0438\u0435\u043C\u0443\" Ownership=\"0\"/>\n      <ObjectRef ID=\"X05\" ObjectType=\"TABLE\" BriefText=\"\u041E\u043F\u0438\u0441\u0430\u043D\u0438\u0435 \u0434\u043E\u043F\u043E\u043B\u043D\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0445 \u043F\u043E\u043B\u0435\u0439 \u043F\u043E \u043F\u0440\u0438\u0435\u043C\u0443 \u0434\u043B\u044F UnionCard\" Ownership=\"0\"/>\n      <ObjectRef ID=\"X06\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0432\u044B\u0431\u043E\u0440\u043A\u0438 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439 \u043F\u0440\u0438 \u043F\u0435\u0440\u0435\u0434\u0430\u0447\u0435\" Ownership=\"0\"/>\n      <ObjectRef ID=\"X07\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0444\u043E\u0440\u043C\u0430\u0442\u043E\u0432 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439 \u043F\u0440\u0438 \u043F\u0435\u0440\u0435\u0434\u0430\u0447\u0435\" Ownership=\"0\"/>\n      <ObjectRef ID=\"X08\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0441\u043A\u0440\u0438\u043F\u0442\u043E\u0432 \u0437\u0430\u0433\u0440\u0443\u0437\u043A\u0438 dbf \u0444\u0430\u0439\u043B\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"X10\" ObjectType=\"TABLE\" BriefText=\"\u0414\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B \u0434\u043B\u044F \u043E\u043F\u0438\u0441\u0430\u043D\u0438\u044F \u0438 \u043F\u0440\u0435\u043E\u0431\u0440\u0430\u0437\u043E\u0432\u0430\u043D\u0438\u044F XML-\u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Y01\" ObjectType=\"TABLE\" BriefText=\"\u041E\u043F\u0438\u0441\u0430\u043D\u0438\u0435 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0445 \u0444\u0430\u0439\u043B\u043E\u0432 \u043E\u0442 \u043E\u0440\u0433\u0430\u043D\u0438\u0437\u0430\u0446\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Y02\" ObjectType=\"TABLE\" BriefText=\"\u041E\u043F\u0438\u0441\u0430\u043D\u0438\u0435 \u0442\u0438\u043F\u043E\u0432 \u0432\u0445\u043E\u0434\u043D\u044B\u0445 \u0444\u0430\u0439\u043B\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Y03\" ObjectType=\"TABLE\" BriefText=\"\u041E\u043F\u0438\u0441\u0430\u043D\u0438\u044F \u0430\u043B\u0433\u043E\u0440\u0438\u0442\u043C\u043E\u0432 \u043F\u0440\u0435\u043E\u0431\u0440\u0430\u0437\u043E\u0432\u0430\u043D\u0438\u044F \u0438 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438 \u0434\u0430\u043D\u043D\u044B\u0445\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Y04\" ObjectType=\"TABLE\" BriefText=\"\u041E\u043F\u0438\u0441\u0430\u043D\u0438\u0439 \u043F\u0440\u043E\u0446\u0435\u0434\u0443\u0440 \u0438 \u0444\u0443\u043D\u043A\u0446\u0438\u0439 \u043D\u0430 PL/SQL, \u0430 \u0442\u0430\u043A\u0436\u0435 \u043F\u0440\u043E\u0441\u0442\u044B\u0445 SQL \u0437\u0430\u043F\u0440\u043E\u0441\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Y05\" ObjectType=\"TABLE\" BriefText=\"\u041E\u043F\u0438\u0441\u0430\u043D\u0438\u0435 \u043F\u043E\u043B\u0435\u0439 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0445 \u0444\u0430\u0439\u043B\u043E\u0432 \u043E\u0442 \u043E\u0440\u0433\u0430\u043D\u0438\u0437\u0430\u0446\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Y06\" ObjectType=\"TABLE\" BriefText=\"\u0412\u043E\u0437\u043C\u043E\u0436\u043D\u044B\u0435 \u0442\u0438\u043F\u043E\u0432\u044B\u0435 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438 \u0434\u043B\u044F \u043A\u0430\u0436\u0434\u043E\u0433\u043E \u0448\u043B\u044E\u0437\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Y07\" ObjectType=\"TABLE\" BriefText=\"\u0417\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u043F\u043E\u043B\u0435\u0439 \u043F\u043E \u043F\u043E-\u0443\u043C\u043E\u043B\u0447\u0430\u043D\u0438\u044E\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Y08\" ObjectType=\"TABLE\" BriefText=\"\u041E\u043F\u0438\u0441\u0430\u043D\u0438\u0435 \u0444\u043E\u0440\u043C\u0430\u0442\u043E\u0432 \u043E\u0442\u0432\u0435\u0442\u043D\u043E\u0433\u043E \u0444\u0430\u0439\u043B\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Y10\" ObjectType=\"TABLE\" BriefText=\"\u041F\u043E\u0440\u044F\u0434\u043A\u043E\u0432\u044B\u0439 \u043D\u043E\u043C\u0435\u0440 \u0441 \u043D\u0430\u0447\u0430\u043B\u0430 \u0434\u043D\u044F\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Y11\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u044B \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0438\u044F \u0434\u0430\u043D\u043D\u044B\u0445 \u0434\u043B\u044F \u0432\u0437\u0430\u0438\u043C\u043E\u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F \u0441 \u0432\u043D\u0435\u0448\u043D\u0438\u043C\u0438 \u0441\u0438\u0441\u0442\u0435\u043C\u0430\u043C\u0438.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Y12\" ObjectType=\"TABLE\" BriefText=\"\u0414\u0430\u043D\u043D\u044B\u0435 \u0442\u0430\u0431\u043B\u0438\u0446\u044B \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0438\u044F.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Z01\" ObjectType=\"TABLE\" BriefText=\"\u0415\u0436\u0435\u0434\u043D\u0432\u043D\u044B\u0439 \u0431\u0430\u043B\u0430\u043D\u0441 (TRANSACTION).\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Z02\" ObjectType=\"TABLE\" BriefText=\"\u0412\u0440\u0435\u043C\u0435\u043D\u043D\u0430\u044F \u0442\u0430\u0431\u043B\u0438\u0446\u0430 \u0434\u043B\u044F \u0444\u043E\u0440\u043C\u044B 0409125 (TRANSACTION).\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Z03\" ObjectType=\"TABLE\" BriefText=\"\u041E\u0442\u0447\u0435\u0442\u0430 \u043E \u043F\u0440\u0438\u0431\u044B\u043B\u044F\u0445 \u0438 \u0443\u0431\u044B\u0442\u043A\u0430\u0445 (SESSION)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Z04\" ObjectType=\"TABLE\" BriefText=\"\u0412\u0440\u0435\u043C\u0435\u043D\u043D\u0430\u044F \u0442\u0430\u0431\u043B\u0438\u0446\u0430 \u0434\u043B\u044F \u0441\u043E\u0437\u0434\u0430\u043D\u0438\u044F \u043E\u0442\u0447\u0451\u0442\u0430 \u043E \u0435\u0436\u0451\u0434\u043D\u0435\u0432\u043D\u043E\u043C \u043D\u0430\u0447\u0438\u0441\u043B\u0435\u043D\u0438\u0438 \u043F\u0440\u043E\u0446\u0435\u043D\u0442\u043E\u0432 (TRANSACTION).\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Z05\" ObjectType=\"TABLE\" BriefText=\"\u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0435 \u0434\u0430\u043D\u043D\u044B\u0435 \u043E \u0434\u043E\u0445\u043E\u0434\u0430\u0445, \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u043D\u044B\u0445 \u043A\u043B\u0438\u0435\u043D\u0442\u043E\u043C \u0434\u043B\u044F \u0444\u043E\u0440\u043C\u044B 2-\u041D\u0414\u0424\u041B (TRANSACTION)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Z06\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u0434\u043B\u044F \u0444\u0443\u043D\u043A\u0446\u0438\u0439, \u043E\u0442\u0447\u0435\u0442\u043E\u0432 (TRANSACTION)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Z07\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430, \u0445\u0440\u0430\u043D\u044F\u0449\u0430\u044F \u0441\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0435 \u0441\u043F\u0440\u0430\u0432\u043A\u0438 \u043F\u043E \u0444\u043E\u0440\u043C\u0435 2-\u041D\u0414\u0424\u041B \u0432 XML \u0444\u043E\u0440\u043C\u0430\u0442\u0435 \n(SESSION)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Z08\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0438\u0441\u043E\u043A \u043E\u0431\u044A\u0435\u043A\u0442\u043E\u0432 (SESSION)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Z09\" ObjectType=\"TABLE\" BriefText=\"\u0412\u0440\u0435\u043C\u0435\u043D\u043D\u0430\u044F \u0442\u0430\u0431\u043B\u0438\u0446\u0430 \u0434\u043B\u044F \u0444\u043E\u0440\u043C\u044B 0409118 (TRANSACTION)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Z10\" ObjectType=\"TABLE\" BriefText=\"Changed List (TRANSACTION).\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Z12\" ObjectType=\"TABLE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0441\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0430\u0446\u0438\u0438 (SESSION).\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Z13\" ObjectType=\"TABLE\" BriefText=\"\u041A\u0440\u0430\u0442\u043A\u0430\u044F \u0441\u0442\u0440\u0443\u043A\u0442\u0443\u0440\u0430 \u043C\u0435\u043D\u044E (TRANSACTION)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Z21\" ObjectType=\"TABLE\" BriefText=\"\u0424\u0438\u043D\u0430\u043D\u0441\u043E\u0432\u044B\u0435 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u044F \u043F\u043E \u043A\u0430\u0440\u0442\u0430\u043C \u043D\u0430 \u043C\u043E\u043C\u0435\u043D\u0442 \u0432\u044B\u0433\u0440\u0443\u0437\u043A\u0438 \u043F\u043E\u0447\u0442\u044B (TRANSACTION)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Z22\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u0440\u0430\u0432 \u0434\u043E\u0441\u0442\u0443\u043F\u0430 \u0441\u0435\u0430\u043D\u0441\u0430 (SESSION).\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Z24\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0435\u0445\u043D\u043E\u043B\u043E\u0433\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u0442\u0430\u0431\u043B\u0438\u0446\u0430 \u0443\u0441\u043A\u043E\u0440\u0435\u043D\u0438\u044F \u043E\u0431\u043D\u043E\u0432\u043B\u0435\u043D\u0438\u044F \u043F\u0440\u0430\u0432 (TRANSACTION).\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Z25\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0434\u043B\u044F \u0445\u0440\u0430\u043D\u0435\u043D\u0438\u044F \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442\u043E\u0432 \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u043A\u0438 \u0430\u043D\u0430\u043B\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u043F\u0440\u0438\u0437\u043D\u0430\u043A\u043E\u0432 \u0423\u0414 \u043F\u0440\u0438 \u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0438 \u0441\u0432\u043E\u0434\u043D\u044B\u0445 \u043E\u0440\u0434\u0435\u0440\u043E\u0432. (TRANSACTION)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Z27\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0435\u0445\u043D\u043E\u043B\u043E\u0433\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u0442\u0430\u0431\u043B\u0438\u0446\u0430 \u0434\u043B\u044F \u0440\u0430\u0431\u043E\u0442\u044B \u0441 \u0430\u0434\u0440\u0435\u0441\u0430\u043C\u0438 \u043E\u0431\u044A\u0435\u043A\u0442\u043E\u0432 (TRANSACTION)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Z28\" ObjectType=\"TABLE\" BriefText=\"\u0424\u0438\u043D\u0430\u043D\u0441\u043E\u0432\u044B\u0435 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u044F \u043F\u043E \u043F\u0440\u0438\u043D\u0443\u0434\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0439 \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0435 \u043B\u0438\u043C\u0438\u0442\u043E\u0432 \u043A\u0430\u0440\u0442 \u0432 \u043C\u043E\u043C\u0435\u043D\u0442 \n\u0432\u044B\u0433\u0440\u0443\u0437\u043A\u0438 \u043F\u043E\u0447\u0442\u044B (TRANSACTION)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Z34\" ObjectType=\"TABLE\" BriefText=\"\u0425\u0440\u0430\u043D\u0435\u043D\u0438\u0435 \u043B\u0438\u043C\u0438\u0442\u043E\u0432 \u0438 \u0434\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u044B\u0445 \u043E\u0432\u0435\u0440\u0434\u0440\u0430\u0444\u0442\u043E\u0432 \u043A\u0430\u0440\u0442 \u0432 \u043C\u043E\u043C\u0435\u043D\u0442 \u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F \u043F\u043E\u0447\u0442\u044B (TRANSACTION)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Z44\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0434\u043B\u044F \u0445\u0440\u0430\u043D\u0435\u043D\u0438\u044F \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442\u043E\u0432 \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u043A\u0438 \u0437\u0430\u043F\u0440\u043E\u0441\u043E\u0432 \u043E\u0442 \u0432\u043D\u0435\u0448\u043D\u0438\u0445 \u0441\u0438\u0441\u0442\u0435\u043C. (SESSION)\" Ownership=\"0\"/>\n    </ObjectRefs>\n    <ObjectRefs ObjectsType=\"VIEW\">\n      <ObjectRef ID=\"P02_RATING\" ObjectType=\"VIEW\" BriefText=\"\u0410\u0442\u0440\u0438\u0431\u0443\u0442\u044B, \u0432\u043B\u0438\u044F\u044E\u0449\u0438\u0435 \u043D\u0430 \u0440\u0435\u0439\u0442\u0438\u043D\u0433 \u043E\u0431\u044A\u0435\u043A\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"P02_RATING_VALUE\" ObjectType=\"VIEW\" BriefText=\"\u0417\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u0430\u0442\u0440\u0438\u0431\u0443\u0442\u043E\u0432 \u0440\u0435\u0439\u0442\u0438\u043D\u0433\u0430 \u043A\u043E\u0440\u0440. \u0441\u0447\u0435\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T66\" ObjectType=\"VIEW\" BriefText=\"\u041F\u0440\u0435\u0434\u0441\u0442\u0430\u0432\u043B\u044F\u0435\u0442 \u0434\u0430\u043D\u043D\u044B\u0435 \u0438\u0437 F13 \u043A\u0430\u043A T66\" Ownership=\"0\"/>\n      <ObjectRef ID=\"V_N14DIST\" ObjectType=\"VIEW\" BriefText=\"\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"VP01\" ObjectType=\"VIEW\" BriefText=\"\u0412\u0438\u0440\u0442\u0443\u0430\u043B\u044C\u043D\u044B\u0435 \u0442\u0438\u043F\u044B \u043C\u0435\u0442\u0430\u0434\u0430\u043D\u043D\u044B\u0445, \u0441\u043E\u0437\u0434\u0430\u043D\u043D\u044B\u0435 \u0438\u0437 \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u0438\u0445 \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"VP02\" ObjectType=\"VIEW\" BriefText=\"\u0410\u0442\u0440\u0438\u0431\u0443\u0442\u044B \u0432\u0438\u0440\u0442\u0443\u0430\u043B\u044C\u043D\u044B\u0445 \u0442\u0438\u043F\u043E\u0432 \u043C\u0435\u0442\u0430\u0434\u0430\u043D\u043D\u044B\u0445\" Ownership=\"0\"/>\n      <ObjectRef ID=\"VP04\" ObjectType=\"VIEW\" BriefText=\"\u0421\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u044F \u0432\u0438\u0440\u0442\u0443\u0430\u043B\u044C\u043D\u044B\u0445 \u0442\u0438\u043F\u043E\u0432 \u043C\u0435\u0442\u0430\u0434\u0430\u043D\u043D\u044B\u0445\" Ownership=\"0\"/>\n      <ObjectRef ID=\"VP08\" ObjectType=\"VIEW\" BriefText=\"\u041C\u0435\u0442\u043E\u0434\u044B \u0432\u0438\u0440\u0442\u0443\u0430\u043B\u044C\u043D\u044B\u0445 \u0442\u0438\u043F\u043E\u0432 \u043C\u0435\u0442\u0430\u0434\u0430\u043D\u043D\u044B\u0445\" Ownership=\"0\"/>\n      <ObjectRef ID=\"VP09\" ObjectType=\"VIEW\" BriefText=\"\u041F\u0435\u0440\u0435\u0445\u043E\u0434\u044B \u0432\u0438\u0440\u0442\u0443\u0430\u043B\u044C\u043D\u044B\u0445 \u0442\u0438\u043F\u043E\u0432 \u043C\u0435\u0442\u0430\u0434\u0430\u043D\u043D\u044B\u0445\" Ownership=\"0\"/>\n      <ObjectRef ID=\"VP09FULL\" ObjectType=\"VIEW\" BriefText=\"\u041F\u043E\u043B\u043D\u044B\u0439 \u043D\u0430\u0431\u043E\u0440 \u043F\u0435\u0440\u0435\u0445\u043E\u0434\u043E\u0432, \u0441 \u0443\u0447\u0435\u0442\u043E\u043C \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"VP13\" ObjectType=\"VIEW\" BriefText=\"\u0420\u0435\u0430\u043B\u0438\u0437\u0430\u0446\u0438\u0438 \u0432\u0438\u0440\u0442\u0443\u0430\u043B\u044C\u043D\u044B\u0445 \u0442\u0438\u043F\u043E\u0432 \u043C\u0435\u0442\u0430\u0434\u0430\u043D\u043D\u044B\u0445\" Ownership=\"0\"/>\n      <ObjectRef ID=\"VP14\" ObjectType=\"VIEW\" BriefText=\"\u0420\u0435\u0430\u043B\u0438\u0437\u0430\u0446\u0438\u0438 \u0430\u0442\u0440\u0438\u0431\u0443\u0442\u043E\u0432 \u0432\u0438\u0440\u0442\u0443\u0430\u043B\u044C\u043D\u044B\u0445 \u0442\u0438\u043F\u043E\u0432 \u043C\u0435\u0442\u0430\u0434\u0430\u043D\u043D\u044B\u0445\" Ownership=\"0\"/>\n      <ObjectRef ID=\"VP15_XML\" ObjectType=\"VIEW\" BriefText=\"XML-\u043F\u0440\u0435\u0434\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u0438\u0435 \u0434\u0435\u0440\u0435\u0432\u0430 \u0434\u043B\u044F \u0432\u044B\u0433\u0440\u0443\u0437\u043A\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"VP17\" ObjectType=\"VIEW\" BriefText=\"\u0420\u0435\u0430\u043B\u0438\u0437\u0430\u0446\u0438\u0438 \u0442\u0438\u043F\u043E\u0432\u043E\u0433\u043E \u044D\u0442\u0430\u043F\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"VT11_XML\" ObjectType=\"VIEW\" BriefText=\"\u0412\u044C\u044E \u0434\u043B\u044F \u0432\u044B\u0433\u0440\u0443\u0437\u043A\u0438 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"VT12_XML\" ObjectType=\"VIEW\" BriefText=\"XML-\u043F\u0440\u0435\u0434\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u0438\u0435 \u0442\u0438\u043F\u043E\u0432\u043E\u0433\u043E \u044D\u0442\u0430\u043F\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"VT50_XML\" ObjectType=\"VIEW\" BriefText=\"XML-\u043F\u0440\u0435\u0434\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u0438\u0435 \u0430\u043A\u0446\u0438\u0438(\u0431\u043E\u043D\u0443\u0441\u043D\u043E\u0439 \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u044B \u0431\u0430\u043D\u043A\u0430) \u0434\u043B\u044F \u0432\u044B\u0433\u0440\u0443\u0437\u043A\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"V09\" ObjectType=\"VIEW\" BriefText=\"\u041F\u0440\u0435\u0434\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u0438\u0435, \u043E\u043F\u0438\u0441\u044B\u0432\u0430\u044E\u0449\u0435\u0435 \u043F\u043E\u043B\u044F \u0442\u0430\u0431\u043B\u0438\u0446 \u043B\u0438\u043D\u043A\u043E\u0432\u0430\u043D\u043D\u043E\u0439 \u0441\u0445\u0435\u043C\u044B \u043D\u0430\u043A\u043E\u043F\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0433\u043E \u0430\u0440\u0445\u0438\u0432\u0430.\" Ownership=\"0\"/>\n    </ObjectRefs>\n    <ObjectRefs ObjectsType=\"QUERY\">\n      <ObjectRef ID=\"TAD_R04\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 \u0434\u043B\u044F R04 (\u043F\u043E\u0441\u043B\u0435 \u0443\u0434\u0430\u043B\u0435\u043D\u0438\u044F)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TAU_N30OVEX_OPER\" ObjectType=\"QUERY\" BriefText=\"\u041E\u043F\u0435\u0440\u0430\u0442\u043E\u0440\u043D\u044B\u0439 \u0442\u0440\u0438\u0433\u0433\u0435\u0440, \u0432\u044B\u0437\u044B\u0432\u0430\u044E\u0449\u0438\u0439 \u043F\u0440\u043E\u0446\u0435\u0434\u0443\u0440\u0443 \u043C\u043E\u0434\u0438\u0444\u0438\u043A\u0430\u0446\u0438\u0438 \u0433\u0440\u0430\u0444\u0438\u043A\u0430 \u043F\u043E\u0433\u0430\u0448\u0435\u043D\u0438\u044F \u043F\u0440\u0438 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0438 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0439 \u043F\u043E\u043B\u044F N30OVEX \u0440\u0430\u0431\u043E\u0442\u0430\u0435\u0442 \u0432 \u043F\u0430\u0440\u0435 \u0441 \u0442\u0440\u0438\u0433\u0433\u0435\u0440\u043E\u043C TBU_N30OVEX (\u043F\u043E\u0441\u043B\u0435 \u043D\u0435\u0433\u043E)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TBI_B31\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 \u043D\u0430 \u0437\u0430\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0435 B31OBID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TBI_B54\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 \u043D\u0430 \u0437\u0430\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0435 B54OBID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TBI_C51\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 \u0434\u043B\u044F \u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F \u0443\u043D\u0438\u043A\u0430\u043B\u044C\u043D\u043E\u0433\u043E \u043A\u043B\u044E\u0447\u0430 \u0437\u0430\u043F\u0438\u0441\u0438 (C51CPCI) \u0432 \u0442\u0430\u0431\u043B\u0438\u0446\u0435 C51.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TBI_C53\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 \u0434\u043B\u044F \u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F \u0443\u043D\u0438\u043A\u0430\u043B\u044C\u043D\u043E\u0433\u043E \u043A\u043B\u044E\u0447\u0430 \u0437\u0430\u043F\u0438\u0441\u0438 (C53BRRI) \u0432 \u0442\u0430\u0431\u043B\u0438\u0446\u0435 C53.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TBI_I07\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0435\u0440 \u043D\u0430 \u043F\u043E\u043B\u0435 i07obid\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TBI_I27\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0435\u0440 \u043D\u0430 \u043F\u043E\u043B\u0435 i27obid\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TBI_N11\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 \u043D\u0430 \u0437\u0430\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0435 N11OBID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TBI_N32\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 \u043D\u0430 \u0437\u0430\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0435 \u043F\u043E\u043B\u044F N32OBID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TBI_N37\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 \u043D\u0430 \u0437\u0430\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0435 \u043F\u043E\u043B\u044F N37OBID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TBI_N40\" ObjectType=\"QUERY\" BriefText=\"\u0417\u0430\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0435 N40OBID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TBI_N45\" ObjectType=\"QUERY\" BriefText=\"\u0410\u0432\u0442\u043E\u0437\u0430\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0435 \u043F\u043E\u043B\u044F N45OBID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TBI_N52\" ObjectType=\"QUERY\" BriefText=\"\u0423\u0441\u0442\u0430\u043D\u043E\u0432\u043A\u0430 N52OBTP:=200 \u043F\u043E \u0443\u043C\u043E\u043B\u0447\u0430\u043D\u0438\u044E\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TBI_N71\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0435\u0440 \u043D\u0430 \u043F\u043E\u043B\u0435 n71obid\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TBI_R02\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 \u0434\u043B\u044F R02\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TBI_R03\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 \u0434\u043B\u044F R03\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TBI_R04\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 \u0434\u043B\u044F R04 (\u043F\u0435\u0440\u0435\u0434 \u0434\u043E\u0431\u0430\u0432\u043B\u0435\u043D\u0438\u0435\u043C)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TBI_R05\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 \u0434\u043B\u044F R05\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TBI_R08\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 \u0434\u043B\u044F R08\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TBI_S38\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 \u043D\u0430 \u0437\u0430\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0435 \u043F\u043E\u043B\u044F S38OBID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TBIU_N40KLAD\" ObjectType=\"QUERY\" BriefText=\"\u0424\u0438\u043A\u0441\u0430\u0446\u0438\u044F \u0432\u0435\u0440\u0441\u0438\u0438 \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u0430 \u041A\u041B\u0410\u0414\u0420 \u0437\u0430 \u0430\u0434\u0440\u0435\u0441\u043E\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TBU_N30OVEX\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 \u0434\u043B\u044F \u043F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u043A\u0438 \u0434\u0430\u043D\u043D\u044B\u0445 \u0434\u043B\u044F \u043F\u0440\u043E\u0446\u0435\u0434\u0443\u0440\u044B \u0438\u0437 \u043F\u0430\u043A\u0435\u0442\u0430 CREDIT.PKG \u043F\u043E \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u0430\u043C \u0441 \u0438\u0437\u043C\u0435\u043D\u0451\u043D\u043D\u044B \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435\u043C \u043F\u043E\u043B\u044F OVEX\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TB31_CHNB\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 \u043F\u043E \u0437\u0430\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u044E \u0432 B31 \u043F\u043E\u043B\u044F B31CHNB (tb31_chnb)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TB31_DATE\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 \u043F\u043E B31. \u0410\u0432\u0442\u043E\u043C\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u0438 \u0443\u0441\u0442\u0430\u043D\u0430\u0432\u043B\u0438\u0432\u0430\u0435\u0442 EXDT \u0432 \u043A\u043E\u043D\u0435\u0446 \u043C\u0435\u0441\u044F\u0446\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TB88_P002_OBID\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 \u043D\u0430 \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u043A\u0443 \u0447\u0438\u0441\u043B\u043E\u0432\u043E\u0433\u043E \u0418\u0414 \u0432 \u0434\u043E\u043F. \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u0438 \u043F\u043E \u043A\u0430\u0440\u0442\u0430\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TB98_0\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 \u043F\u043E B98. \u041E\u043F\u0440\u0435\u0434\u0435\u043B\u044F\u0435\u0442 P011, P012 \u0438 OPRI\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TN22_CREATE\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 N22, \u043E\u043F\u0440\u0435\u0434\u0435\u043B\u044F\u044E\u0449\u0438\u0439 P011 \u0438 P012\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TN23_DATE\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 \u043F\u043E N23 (tn23_date). \u041A\u043E\u0440\u0440\u0435\u043A\u0442\u0438\u0440\u043E\u0432\u043A\u0430 \u0434\u0430\u0442\u044B \u043E\u043A\u043E\u043D\u0447\u0430\u043D\u0438\u044F \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F \u043A\u0430\u0440\u0442\u044B\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TN28_OVDR\" ObjectType=\"QUERY\" BriefText=\"\u0417\u0430\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0435 \u043E\u0432\u0435\u0440\u0434\u0440\u0430\u0444\u0442\u0430 \u0432 N28\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TN31_SYNC\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 \u043F\u043E n31 \u0434\u043B\u044F \u0441\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0430\u0446\u0438\u0438 \u0432\u0441\u043F\u043E\u043C\u043E\u0433\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0439 \u0442\u0430\u0431\u043B\u0438\u0446\u044B \u043F\u043E\u0438\u0441\u043A\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TR02_BDA\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 TR02_BDA\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TR02_BUA\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 TR02_BUA\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TR03_BDA\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 TR03_BDA\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TR03_BUA\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 TR03_BUA\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TR04_BDA\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 TR04_BDA\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TR04_BUA\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 TR04_BUA\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TR05_BDA\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 TR05_BDA\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TR05_BUA\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 TR05_BUA\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TR06_BDA\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 TR06_BDA\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TR06_BUA\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 TR06_BUA\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TR07_BDA\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 TR07_BDA\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TR07_BUA\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 TR07_BUA\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TR08_BDA\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 TR08_BDA\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TR08_BUA\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 TR08_BUA\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TS04_0\" ObjectType=\"QUERY\" BriefText=\"TS04_0\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TT05_0\" ObjectType=\"QUERY\" BriefText=\"\u041F\u0440\u0438\u0441\u0432\u043E\u0435\u043D\u0438\u0435 ID \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u043E\u043D\u0438\u0441\u0442\u0443 T05\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TT20_0\" ObjectType=\"QUERY\" BriefText=\"\u041F\u0440\u0438\u0441\u0432\u043E\u0435\u043D\u0438\u0435 ID \u043D\u043E\u0432\u043E\u043C\u0443 \u0440\u0430\u0431\u043E\u0447\u0435\u043C\u0443 \u043C\u0435\u0441\u0442\u0443\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TT25_0\" ObjectType=\"QUERY\" BriefText=\"\u041F\u0440\u0438\u0441\u0432\u043E\u0435\u043D\u0438\u0435 ID \u043D\u043E\u0432\u043E\u043C\u0443 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0443\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TT31_0\" ObjectType=\"QUERY\" BriefText=\"\u0423\u0434\u0430\u043B\u0435\u043D\u0438\u0435 \u043F\u0440\u0430\u0432 \u043D\u0430 \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u0438\u0435 \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u044B \u043F\u0440\u0438 \u0438\u0445 \u0443\u0434\u0430\u043B\u0435\u043D\u0438\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"UNDEFINE\" ObjectType=\"QUERY\" BriefText=\"rthrehtr44\" Ownership=\"0\"/>\n    </ObjectRefs>\n    <ObjectRefs ObjectsType=\"SEQUENCE\">\n      <ObjectRef ID=\"CARDLIMIT_SEQ\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439 \u043F\u043E \u043A\u0430\u0440\u0442\u043E\u0447\u043D\u043E\u043C\u0443 \u043B\u0438\u043C\u0438\u0442\u0443 &apos;B8&apos;, &apos;B9&apos;\" Ownership=\"0\"/>\n      <ObjectRef ID=\"INVOICE_SEQ\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C  INVOICE_SEQ\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEC_I23STRF\" ObjectType=\"SEQUENCE\" BriefText=\"\u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440 clob\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_ACNC\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F N67ACNC\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_AGRC\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u0433\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u0438 \u043A\u043E\u0434\u043E\u0432 \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u0438\u0445 \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u043E\u0432 T31AGRC\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_AGRID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_A01\" ObjectType=\"SEQUENCE\" BriefText=\"\u041D\u043E\u043C\u0435\u0440 \u0437\u0430\u043F\u0438\u0441\u0438 \u043F\u0440\u043E\u0442\u043E\u043A\u043E\u043B\u0430 \u0430\u0440\u0445\u0438\u0432\u0430\u0446\u0438\u0438 A01 (A01IDEN)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_A12STID\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u0437\u0430\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u044F \u043F\u043E\u043B\u044F A12STID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_A19AUID\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u0434\u043B\u044F \u0441\u043E\u0437\u0434\u0430\u043D\u0438\u044F \u043D\u043E\u0432\u043E\u0433\u043E \u0444\u0430\u043A\u0442\u0430 \u0430\u0443\u0434\u0438\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_BACP\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u0433\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u0438 \u043A\u043E\u0434\u043E\u0432 \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u0438\u0445 \u0443\u0441\u043B\u0443\u0433 T30BACP\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_BTCH\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u043F\u0430\u043A\u0435\u0442\u043E\u0432 \u0442\u0440\u0430\u043D\u0437\u0430\u043A\u0446\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_BTST\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C  SEQ_BTST\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_B31CHNB\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0451\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F \u043F\u043E\u043B\u044F B31CHNB\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_B31OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0418\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440 \u043A\u0430\u0440\u0442\u044B. \u0418\u0441\u043F\u043E\u043B\u0437\u0443\u0435\u0442\u0441\u044F \u0432 B31 (B31OBID)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_B54OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0418\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440 \u0442\u0435\u0440\u043C\u0438\u043D\u0430\u043B\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_B81OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u043E\u0432 \u0437\u0430\u043F\u0438\u0441\u0435\u0439 \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u0430 \u041A\u041B\u0410\u0414\u0420\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_B98P011\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u043F\u043E B98P011\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_B98TAXNUMBER\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0451\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u0441\u043A\u0432\u043E\u0437\u043D\u043E\u0439 \u043D\u0443\u043C\u0435\u0440\u0430\u0446\u0438\u0438 \u0444\u0430\u0439\u043B\u043E\u0432 \u0434\u043B\u044F \u0432\u044B\u0433\u0440\u0443\u0437\u043A\u0438 \u0432 \u0424\u041D\u0421(\u0410\u0411\u0421 \u0438 Retail - \u0435\u0434\u0438\u043D\u0430\u044F \u043D\u0443\u043C\u0435\u0440\u0430\u0446\u0438\u044F)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_CGCD\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u0443\u043D\u0438\u043A\u0430\u043B\u044C\u043D\u043E\u0433\u043E \u043A\u043E\u0434\u0430 B30CGCD\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_CLNTID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u043E\u0432 \u043A\u043B\u0438\u0435\u043D\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_C08PERM\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A  C08PERM\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_C30OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0423\u043D\u0438\u043A\u0430\u043B\u044C\u043D\u044B\u0439 \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440 \u044F\u0447\u0435\u0439\u043A\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_C31OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0418\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440 \u043A\u043B\u044E\u0447\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_C32OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u0434\u043B\u044F \u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F C32OBID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_C50CPSI\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0451\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u0433\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u0438 \u0443\u043D\u0438\u043A\u0430\u043B\u044C\u043D\u043E\u0433\u043E \u043A\u043B\u044E\u0447\u0430 \u0432 \u0442\u0430\u0431\u043B\u0438\u0446\u0435 C50CPSI.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_C51CPCI\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0451\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u0433\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u0438 \u0443\u043D\u0438\u043A\u0430\u043B\u044C\u043D\u043E\u0433\u043E \u043A\u043B\u044E\u0447\u0430 \u0432 \u0442\u0430\u0431\u043B\u0438\u0446\u0435 C51CP\u0421I.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_C52RPSI\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0451\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u0433\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u0438 \u0443\u043D\u0438\u043A\u0430\u043B\u044C\u043D\u043E\u0433\u043E \u043A\u043B\u044E\u0447\u0430 \u0432 \u0442\u0430\u0431\u043B\u0438\u0446\u0435 C52RPSI.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_C53BRRI\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0451\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u0433\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u0438 \u0443\u043D\u0438\u043A\u0430\u043B\u044C\u043D\u043E\u0433\u043E \u043A\u043B\u044E\u0447\u0430 \u0432 \u0442\u0430\u0431\u043B\u0438\u0446\u0435 C53BRRI.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_C60CTID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0451\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u0433\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u0438 \u0443\u043D\u0438\u043A\u0430\u043B\u044C\u043D\u043E\u0433\u043E \u043A\u043B\u044E\u0447\u0430 \u0432 \u0442\u0430\u0431\u043B\u0438\u0446\u0435 C60CTID.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_DP\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0451\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u0441\u0438\u0441\u0442\u0435\u043C\u044B \u0434\u043B\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0445 \u043F\u043E\u0440\u0443\u0447\u0435\u043D\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_D03\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u0433\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u0438 ID \u043F\u0440\u043E\u0446\u0435\u0441\u0441\u0430 D03STID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_EOW\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C  SEQ_EOW\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_FDID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F N03\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_FILEID\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u0434\u043B\u044F \u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F \u043F\u043E\u043B\u0435\u0439 S04FSID \u0438 S09FRID - \u0443\u043D\u0438\u043A\u0430\u043B\u044C\u043D\u044B\u0435 \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u044B \u0444\u0430\u0439\u043B\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_F02RGID\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u0434\u043B\u044F \u0442\u0430\u0431\u043B\u0438\u0446\u044B F02\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_F03RFID\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u0434\u043B\u044F \u0442\u0430\u0431\u043B\u0438\u0446\u044B F03\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_F04RCID\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u0434\u043B\u044F \u0442\u0430\u0431\u043B\u0438\u0446\u044B F04\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_F13ANID\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u0434\u043B\u044F \u0442\u0430\u0431\u043B\u0438\u0446\u044B F13\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_F16LAGI\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u0433\u0435\u043D\u0435\u0440\u0438\u0442 \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440 F16LAGI\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_F40FMID\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C ID \u043E\u0431\u044A\u0435\u043A\u0442\u043E\u0432 \u0442\u0430\u0431\u043B\u0438\u0446\u044B F40\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_F41FVID\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u0434\u043B\u044F \u0433\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u0438 ID \u043F\u043E\u043B\u044F F41FVID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_HPID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0435 \u0443\u043D\u0438\u043A\u0430\u043B\u044C\u043D\u043E\u0433\u043E \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u0430 \u0434\u043B\u044F \u0438\u0441\u0442\u043E\u0440\u0438\u0438 \u043F\u043B\u0430\u0442\u0435\u0436\u0435\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_H02OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u0437\u0430\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u044F \u043F\u043E\u043B\u044F H02OBID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_H07OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u043F\u043E\u043B\u044F H07OBID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_H07TMP_N\" ObjectType=\"SEQUENCE\" BriefText=\"\u0418\u043C\u0435\u043D\u043E\u0432\u0430\u043D\u0438\u0435 \u0432\u0440\u0435\u043C\u0435\u043D\u043D\u044B\u0445 \u0442\u0430\u0431\u043B\u0438\u0446 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438 \u043D\u0430 \u043F\u0440\u0438\u0447\u0430\u0441\u0442\u043D\u043E\u0441\u0442\u044C \u043A \u0441\u0442\u043E\u043F-\u043B\u0438\u0441\u0442\u0430\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_H11MBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u043A\u0432\u043E\u0437\u043D\u043E\u0435 \u0418\u0414 \u0443\u0447\u0430\u0441\u0442\u043D\u0438\u043A\u043E\u0432 \u043F\u043E\u0434\u043E\u0437\u0440\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0445 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_H14MSID\" ObjectType=\"SEQUENCE\" BriefText=\"\u042F\u0432\u043B\u044F\u0435\u0442\u0441\u044F \u0438\u0441\u0442\u043E\u0447\u043D\u0438\u043A\u043E\u043C \u0437\u0430\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u044F \u043F\u043E\u043B\u044F H14MSID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_H20OEID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F H20OEID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_IMPEX\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0437\u0430\u044F\u0432\u043E\u043A \u041F\u0426 \u0418\u043C\u043F\u0435\u043A\u0441\u0431\u0430\u043D\u043A\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_I07OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0422\u0440\u0438\u0433\u0435\u0440 \u043D\u0430 \u043F\u043E\u043B\u0435 i07obid\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_I18OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u043E\u0432 \u0442\u0438\u043F\u043E\u0432\u044B\u0445 \u0443\u0432\u0435\u0434\u043E\u043C\u043B\u0435\u043D\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_I19OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u0437\u0430\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u044F \u043F\u043E\u043B\u044F I19OBID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_I24OBID\" ObjectType=\"SEQUENCE\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_I26STRF\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0451\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u0433\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u0438 \u0443\u043D\u0438\u043A\u0430\u043B\u044C\u043D\u043E\u0433\u043E \u043A\u043B\u044E\u0447\u0430 \u0432 \u0442\u0430\u0431\u043B\u0438\u0446\u0435 I26STRF.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_I27OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u0437\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0445 \u0437\u0430 \u0432\u043D\u0435\u0448\u043D\u0435\u0439 \u0441\u0438\u0441\u0442\u0435\u043C\u043E\u0439 \u0437\u0430\u043F\u0440\u043E\u0441\u043E\u0432/\u043E\u0442\u0432\u0435\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_I33EVID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0418\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440 \u0441\u043E\u0431\u044B\u0442\u0438\u044F. \u0418\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0435\u0442\u0441\u044F \u0434\u043B\u044F \u0437\u0430\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u044F \u043F\u043E\u043B\u044F I33EVID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_I35ITID\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u0434\u043B\u044F \u0437\u0430\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u044F i35itid\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_JPID\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u0444\u043E\u0440\u043C\u0438\u0440\u0443\u0435\u0442 \u043F\u043E\u043B\u0435 T84JPID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_J09OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0451\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F J09OBID - \u0423\u043D\u0438\u043A\u0430\u043B\u044C\u043D\u044B\u0439 \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440 \u0443\u0441\u043B\u0443\u0433\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_J11OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A j11obid\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_J12OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C, \u0434\u043B\u044F \u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F j12obid\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_MCOD\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u0438\u044F \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u0430 \u0437\u0430\u043F\u0438\u0441\u0438 \u0432 \u0442\u0430\u0431\u043B\u0438\u0446\u0435 N33\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_MFGR\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0435\u0442\u0441\u044F \u0432 \u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u0438 \u0433\u0440\u0443\u043F\u043F \u043A\u043E\u043C\u0438\u0441\u0441\u0438\u043E\u043D\u043D\u044B\u0445 \u0441\u0442\u0430\u0432\u043E\u043A\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_M03OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u0434\u043B\u044F \u044D\u043B\u0435\u043C\u0435\u043D\u0442\u043E\u0432 \u043C\u0430\u0440\u0448\u0440\u0443\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_M10HTID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0418\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440 \u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430 \u0438\u0441\u0442\u043E\u0440\u0438\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_M40CSID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0418\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440 \u043D\u0430\u0431\u043E\u0440\u0430 \u043F\u043E\u043F\u0440\u0430\u0432\u043E\u043A \u043A \u0441\u0442\u0430\u0432\u043A\u0430\u043C \u043F\u043E \u0441\u0447\u0435\u0442\u0430\u043C \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u043E\u0433\u043E \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_M58OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u0434\u043B\u044F \u043F\u043E\u043B\u044F M58OBID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_N01OPID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A N01OPID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_N04_M04POID\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u0434\u043B\u044F \u0433\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u0438 \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u0430 \u043E\u0431\u044A\u0435\u043A\u0442\u0430 \u0411\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u0438\u0439 \u044D\u0442\u0430\u043F (\u043E\u0431\u044A\u0435\u043A\u0442\u044B \u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u044B \u043C\u0435\u0436\u0434\u0443 \u0442\u0430\u0431\u043B\u0438\u0446\u0430\u043C\u0438 N04 M04 )\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_N04TECH\" ObjectType=\"SEQUENCE\" BriefText=\"\u0441\u0447\u0435\u0442\u0447\u0438\u043A SEQ_N04TECH\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_N08N09ID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0451\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0445 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432 \u043F\u043E \u0446\u0435\u043D\u043D\u043E\u0441\u0442\u044F\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_N10LOID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0423\u043D\u0438\u043A\u0430\u043B\u044C\u043D\u044B\u0439 \u043A\u043E\u0434 \u0440\u0435\u0435\u0441\u0442\u0440\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_N12REID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0451\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u0433\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u0438 \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u0430 \u0440\u0435\u0435\u0441\u0442\u0440\u0430 \u043F\u043B\u0430\u0442\u0451\u0436\u043D\u044B\u0445 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_N22OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u0434\u043B\u044F \u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F \u0443\u043D\u0438\u043A\u0430\u043B\u044C\u043D\u043E\u0433\u043E \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u0430 \u0438\u0441\u0445\u043E\u0434\u043D\u043E\u0433\u043E \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430 \u043F\u043E \u0440\u0430\u0431\u043E\u0442\u0435 \u0441 \u043A\u0430\u0440\u0442\u043E\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_N28MNUM\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439 \u043F\u043E \u043F\u0440\u0438\u043D\u0443\u0434\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0439 \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0435 \u043B\u0438\u043C\u0438\u0442\u043E\u0432 \u043A\u0430\u0440\u0442 SEQ_N28MNUM\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_N29FDID\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C  SEQ_N29FDID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_N29PAID\" ObjectType=\"SEQUENCE\" BriefText=\"Sequence Seq_N29PAID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_N32OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0418\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440 \u043F\u0440\u0438\u0432\u044F\u0437\u043A\u0438 \u0441\u0447\u0435\u0442\u0430 \u043A \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u0443\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_N37OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0418\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430 \u043A\u043B\u0438\u0435\u043D\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_N38OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u0430 \u0433\u0440\u0430\u0444\u0438\u043A\u0430 \u0441\u0445\u0435\u043C \u0442\u0430\u0440\u0438\u0444\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_N40OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A N40OBID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_N41OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u0442\u0430\u0431\u043B\u0438\u0446\u044B N41OBID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_N42DOID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043E\u0432\u0435\u0440\u0435\u043D\u043D\u043E\u0441\u0442\u0435\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_N50PMID\" ObjectType=\"SEQUENCE\" BriefText=\"SEQUENCE SEQ_N50PMID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_N52POID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A SEQ_N52POID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_N54CLID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0418\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440 \u043E\u0431\u044A\u0435\u043A\u0442\u0430 \u0438\u0437 n54clid \u0432 \u0441\u043B\u0443\u0447\u0430\u0435 \u0435\u0441\u043B\u0438 \u0442\u0438\u043F \u043E\u0431\u044A\u0435\u043A\u0442\u0430 n54cltp = 10 (\u043F\u043E\u043B\u0443\u0447\u0430\u0442\u0435\u043B\u044C \u0432\u043D\u0435\u0448\u043D\u0435\u0433\u043E \u043F\u043B\u0430\u0442\u0435\u0436\u0430)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_N59OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0418\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440 \u043A\u043E\u043C\u043C\u0443\u043D\u0430\u043B\u044C\u043D\u043E\u0433\u043E \u043F\u043B\u0430\u0442\u0435\u0436\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_N63OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u0430 \u0438\u0437\u0432\u0435\u0449\u0435\u043D\u0438\u044F \u043E \u043F\u043B\u0430\u0442\u0435\u0436\u0435\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_N65OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u0434\u043B\u044F \u0442\u0430\u0431\u043B\u0438\u0446\u044B N65\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_N71OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u043A\u043E\u043D\u0442\u0430\u043A\u0442\u043D\u043E\u0439 \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_N75OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0414\u041B\u042F \u044275\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_N77SVID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0418\u0414 \u0441\u0432\u043E\u0434\u043D\u043E\u0433\u043E \u043C\u0435\u043C\u043E\u0440\u0438\u0430\u043B\u044C\u043D\u043E\u0433\u043E \u043E\u0440\u0434\u0435\u0440\u0430.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_N78OBID\" ObjectType=\"SEQUENCE\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_N79ACID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0424\u043E\u0440\u043C\u0438\u0440\u0443\u0435\u0442 \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440 \u0430\u043A\u0446\u0435\u043F\u0442\u0430 (N79)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u0430 \u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430 \u0441\u0435\u0442\u0438.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_OBJLINK\" ObjectType=\"SEQUENCE\" BriefText=\"\u0418\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440 \u0441\u0432\u044F\u0437\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_OUTDOC\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u043D\u043E\u043C\u0435\u0440\u043E\u0432 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432 \u0441\u0432\u043E\u0434\u043D\u043E\u0433\u043E \u0443\u0447\u0435\u0442\u0430 (\u0432\u044B\u0433\u0440\u0443\u0436\u0430\u0435\u043C\u044B\u0445 \u0432 \u0411\u0421)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_PFID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0424\u043E\u0440\u043C\u0438\u0440\u0443\u0435\u0442 \u0443\u043D\u0438\u043A\u0430\u043B\u044C\u043D\u044B\u0439 \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440 \u0444\u0430\u0439\u043B\u0430 \u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F (W01PFID)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_PREGID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u043E\u0432 \u0440\u0435\u0435\u0441\u0442\u0440\u043E\u0432 \u043F\u043B\u0430\u0442\u0435\u0436\u0435\u0439, \u0444\u043E\u0440\u043C\u0438\u0440\u0443\u0435\u043C\u044B\u0445, \u0434\u043B\u044F \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0438 \u0432 \u043F\u0440\u043E\u0432\u0430\u0439\u0434\u0435\u0440 online-\u043F\u043B\u0430\u0442\u0435\u0436\u0435\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_PSID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0424\u043E\u0440\u043C\u0438\u0440\u0443\u0435\u0442 \u0443\u043D\u0438\u043A\u0430\u043B\u044C\u043D\u044B\u0439 \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440 \u0441\u0435\u0430\u043D\u0441\u0430 \u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F (W01PSID)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_PTID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F J- \u0442\u0430\u0431\u043B\u0438\u0446\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_P011\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0438\u043D\u0438\u0446\u0438\u0430\u0442\u043E\u0440\u043E\u0432 \u0442\u0440\u0430\u043D\u0437\u0430\u043A\u0446\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_P029\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u043D\u043E\u043C\u0435\u0440\u043E\u0432 \u043F\u0430\u043A\u0435\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_P24\" ObjectType=\"SEQUENCE\" BriefText=\"\u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440 \u0441\u0442\u0438\u043B\u044F \u0434\u043B\u044F WPF\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_RECID\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u044B\u0439 \u043D\u043E\u043C\u0435\u0440 \u0437\u0430\u043F\u0438\u0441\u0438 \u0432 \u0444\u0430\u0439\u043B\u0435\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_REID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0440\u0435\u0435\u0441\u0442\u0440\u043E\u0432 \u043F\u043B\u0430\u0442\u0435\u0436\u043D\u044B\u0445 \u043F\u043E\u0440\u0443\u0447\u0435\u043D\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_REPORT\" ObjectType=\"SEQUENCE\" BriefText=\"\u0415\u0434\u0438\u043D\u044B\u0439 \u0441\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u0442\u0430\u0431\u043B\u0438\u0446 \u043E\u0442\u0447\u0435\u0442\u043D\u043E\u0441\u0442\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_RQID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0437\u0430\u044F\u0432\u043E\u043A \u0441\u0438\u0441\u0442\u0435\u043C \u0443\u0434\u0430\u043B\u0435\u043D\u043D\u043E\u0433\u043E \u0434\u043E\u0441\u0442\u0443\u043F\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_R04\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C  SEQ_R04\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_SCHED\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u0440\u0430\u0441\u043F\u0438\u0441\u0430\u043D\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_STAN\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F STAN\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_STAN_GCS\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F \u0443\u043D\u0438\u043A\u0430\u043B\u044C\u043D\u043E\u0433\u043E \u043F\u043E\u043B\u044F STAN \u0432 \u0444\u0430\u0439\u043B\u0435 \u0434\u043B\u044F \u0413\u041A\u0421 \u0432\u0435\u0440\u0441\u0438\u0438 3\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_STBLIM\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u043E\u0432 \u043B\u0438\u043C\u0438\u0442\u043E\u0432 \u0432 \u043A\u043E\u0434\u0438\u0440\u043E\u0432\u043A\u0435 \u0421\u0422\u0411\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_STRF\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u0442\u0440\u0430\u043D\u0437\u0430\u043A\u0446\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_SYNC\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0437\u0430\u043F\u0438\u0441\u0435\u0439 \u0411\u0414\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_S1\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C  SEQ_S1\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_S38OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u043F\u043E\u043B\u044F S38OBID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_TAGIT\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C  SEQ_TAGIT\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_TAXBASE\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u043F\u043E\u043B\u0435\u0439 N90OBID, N91OBID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_TMP_PAN\" ObjectType=\"SEQUENCE\" BriefText=\"\u0413\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u044F \u0432\u0440\u0435\u043C\u0435\u043D\u043D\u043E\u0433\u043E \u043D\u043E\u043C\u0435\u0440\u0430 \u043A\u0430\u0440\u0442\u044B\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_T13POID\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u0434\u043B\u044F \u0433\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u0438 \u0443\u043D\u0438\u043A\u0430\u043B\u044C\u043D\u044B\u0445 \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u043E\u0432 \u0434\u043B\u044F \u043E\u0431\u044A\u0435\u043A\u0442\u0430 \u041E\u043F\u0438\u0441\u0430\u043D\u0438\u0435 \u0422\u0438\u043F\u043E\u0432\u043E\u0433\u043E \u042D\u0442\u0430\u043F\u0430 \u0432 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_T34PKEY\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u0434\u043B\u044F \u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F \u0443\u043D\u0438\u043A\u0430\u043B\u044C\u043D\u043E\u0433\u043E \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u043F\u043E\u043B\u044F t34pkey\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_T40INSC\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0451\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u043D\u0443\u043C\u0435\u0440\u0430\u0446\u0438\u0438 \u0441\u0445\u0435\u043C \u043D\u0430\u0447\u0438\u0441\u043B\u0435\u043D\u0438\u044F \u043F\u0440\u043E\u0446\u0435\u043D\u0442\u043E\u0432.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_T57ASID\" ObjectType=\"SEQUENCE\" BriefText=\"Sequence SEQ_T57ASID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_T65SMTP\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u043E\u0432 \u0432\u044B\u0447\u0438\u0441\u043B\u044F\u0435\u043C\u044B\u0445 \u0441\u0443\u043C\u043C \u0432 \u0442\u0438\u043F\u043E\u0432\u044B\u0445 \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u0438\u0445 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u044F\u0445\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_T75TRID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u0432\u0438\u0434\u0430 \u0446\u0435\u043D\u043D\u043E\u0441\u0442\u0435\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_T88\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C  SEQ_T88\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_T95OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u043A\u043E\u0434 \u043E\u0431\u044A\u0435\u043A\u0442\u0430 \u043B\u0438\u0446\u043E \u0441 \u043F\u0440\u0430\u0432\u043E\u043C \u043F\u043E\u0434\u043F\u0438\u0441\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_Y11OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u0444\u043E\u0440\u043C\u0438\u0440\u0443\u0435\u0442 \u043F\u043E\u043B\u0435  Y11OBID\" Ownership=\"0\"/>\n    </ObjectRefs>\n  </Schema>\n</UCMsg>"
    },
    {
        key: "\n<UCMsg ID=\"3\">\n  <DataTypes></DataTypes>\n  <Context ID=\"555\">\n    <UserName>SOMEONE</UserName>\n    <UserPassword>ABSENT</UserPassword>\n    <UserStatus></UserStatus>\n    <IPAddress></IPAddress>\n    <VerMask>\u0412</VerMask>\n    <SubMask>\u0412</SubMask>\n  </Context>\n</UCMsg>",
        val: "\n<UCMsg ID=\"3\">\n  <Status/>\n  <Context ID=\"355\">\n    <UserName>SOMEONE</UserName>\n    <UserPassword>ABSENT</UserPassword>\n    <UserStatus>0</UserStatus>\n    <IPAddress/>\n    <VerMask>\u0412</VerMask>\n    <SubMask>\u0412</SubMask>\n  </Context>\n  <DataTypes>\n    <DataType ID=\"account\" BaseType=\"string\" OracleType=\"70\" Size=\"VARCHAR2\" BriefText=\"\u043D\u043E\u043C\u0435p \u0441\u0447\u0435\u0442\u0430\"/>\n    <DataType ID=\"accountid\" BaseType=\"number\" OracleType=\"10\" Size=\"NUMBER\" BriefText=\"\u043A\u043E\u0434 \u0441\u0447\u0435\u0442\u0430\"/>\n    <DataType ID=\"accountreal\" BaseType=\"string\" OracleType=\"35\" Size=\"VARCHAR2\" BriefText=\"\u0440\u0435\u0430\u043B\u044C\u043D\u044B\u0439 \u043D\u043E\u043C\u0435p \u0441\u0447\u0435\u0442\u0430\"/>\n    <DataType ID=\"actioncode\" BaseType=\"number\" OracleType=\"3\" Size=\"NUMBER\" BriefText=\"\u0441\u0442\u0430\u0442\u0443\u0441 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u044F\"/>\n    <DataType ID=\"analyticalsign\" BaseType=\"string\" OracleType=\"40\" Size=\"VARCHAR2\" BriefText=\"\u0430\u043D\u0430\u043B\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0439 \u043F\u0440\u0438\u0437\u043D\u0430\u043A\"/>\n    <DataType ID=\"apprcode\" BaseType=\"string\" OracleType=\"6\" Size=\"VARCHAR2\" BriefText=\"\u043A\u043E\u0434 \u0430\u0432\u0442\u043E\u0440\u0438\u0437\u0430\u0446\u0438\u0438\"/>\n    <DataType ID=\"blob\" BaseType=\"blob\" OracleType=\"\" Size=\"BLOB\" BriefText=\"\u0434\u0432\u043E\u0438\u0447\u043D\u0430\u044F \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u044F\"/>\n    <DataType ID=\"buscode\" BaseType=\"number\" OracleType=\"4\" Size=\"NUMBER\" BriefText=\"CardAccBusinessCode\"/>\n    <DataType ID=\"char\" BaseType=\"char\" OracleType=\"1\" Size=\"CHAR\" BriefText=\"\u043E\u0434\u0438\u043D \u0431\u0430\u0439\u0442\"/>\n    <DataType ID=\"clob\" BaseType=\"clob\" OracleType=\"\" Size=\"CLOB\" BriefText=\"\u0447\u0430\u0440\u043D\u0430\u044F \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u044F\"/>\n    <DataType ID=\"countrycode\" BaseType=\"number\" OracleType=\"3\" Size=\"NUMBER\" BriefText=\"\u043A\u043E\u0434 \u0441\u0442\u0440\u0430\u043D\u044B\"/>\n    <DataType ID=\"currcode\" BaseType=\"number\" OracleType=\"3\" Size=\"NUMBER\" BriefText=\"\u043A\u043E\u0434 \u0432\u0430\u043B\u044E\u0442\u044B\"/>\n    <DataType ID=\"currency\" BaseType=\"intmax\" OracleType=\"\" Size=\"NUMBER\" BriefText=\"\u0434\u0435\u043D\u044C\u0433\u0438\"/>\n    <DataType ID=\"date\" BaseType=\"date\" OracleType=\"\" Size=\"DATE\" BriefText=\"\u0434\u0430\u0442\u0430 \u0438 \u0432p\u0435\u043C\u044F\"/>\n    <DataType ID=\"datenum\" BaseType=\"number\" OracleType=\"4\" Size=\"NUMBER\" BriefText=\"YYMM \u0432 \u0432\u0438\u0434\u0435 \u0447\u0438\u0441\u043B\u0430\"/>\n    <DataType ID=\"datetime\" BaseType=\"date\" OracleType=\"\" Size=\"DATE\" BriefText=\"\u0434\u0430\u0442\u0430 \u0438 \u0432\u0440\u0435\u043C\u044F\"/>\n    <DataType ID=\"dateYYMM\" BaseType=\"date\" OracleType=\"\" Size=\"DATE\" BriefText=\"\u0433\u043E\u0434/\u043C\u0435\u0441\u044F\u0446\"/>\n    <DataType ID=\"dateYYMMDD\" BaseType=\"date\" OracleType=\"\" Size=\"DATE\" BriefText=\"\u0433\u043E\u0434/\u043C\u0435\u0441\u044F\u0446/\u0434\u0435\u043D\u044C\"/>\n    <DataType ID=\"eftp\" BaseType=\"number\" OracleType=\"2\" Size=\"NUMBER\" BriefText=\"\u043A\u043E\u0434 \u0444\u043E\u0440\u043C\u0430\u0442\u0430 \u0444\u0430\u0439\u043B\u0430\"/>\n    <DataType ID=\"feecode\" BaseType=\"number\" OracleType=\"2\" Size=\"NUMBER\" BriefText=\"\u043A\u043E\u0434 \u043A\u043E\u043C\u0438\u0441\u0441\u0438\u0438\"/>\n    <DataType ID=\"float\" BaseType=\"float\" OracleType=\"\" Size=\"NUMBER\" BriefText=\"\u0441 \u043F\u043B\u0430\u0432. \u0437\u0430\u043F\u044F\u0442\u043E\u0439 \u043C\u0430\u043A\u0441\u0438\u043C\u0430\u043B\u044C\u043D\u043E\u0439 \u0434\u043B\u0438\u043D\u044B\"/>\n    <DataType ID=\"flsn\" BaseType=\"number\" OracleType=\"3\" Size=\"NUMBER\" BriefText=\"\u043D\u043E\u043C\u0435\u0440 \u0444\u0430\u0439\u043B\u0430\"/>\n    <DataType ID=\"fltp\" BaseType=\"char\" OracleType=\"\" Size=\"CHAR\" BriefText=\"\u043A\u043E\u0434 \u0442\u0438\u043F\u0430 \u0444\u0430\u0439\u043B\u0430\"/>\n    <DataType ID=\"formatcode\" BaseType=\"string\" OracleType=\"2\" Size=\"VARCHAR2\" BriefText=\"\u0442\u0438\u043F \u043F\u043E\u0447\u0442\u043E\u0432\u043E\u0433\u043E \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u044F\"/>\n    <DataType ID=\"funcode\" BaseType=\"number\" OracleType=\"3\" Size=\"NUMBER\" BriefText=\"\u0444\u0443\u043D\u043A\u0446\u0438\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0439 \u043A\u043E\u0434\"/>\n    <DataType ID=\"integer\" BaseType=\"number\" OracleType=\"5\" Size=\"NUMBER\" BriefText=\"5 \u0437\u043D\u0430\u043A\u043E\u0432\"/>\n    <DataType ID=\"intmax\" BaseType=\"intmax\" OracleType=\"38\" Size=\"NUMBER\" BriefText=\"\u0446\u0435\u043B\u043E\u0435 \u043C\u0430\u043A\u0441\u0438\u043C\u0430\u043B\u044C\u043D\u043E\u0439 \u0434\u043B\u0438\u043D\u044B\"/>\n    <DataType ID=\"int16\" BaseType=\"int16\" OracleType=\"4\" Size=\"NUMBER\" BriefText=\"\u0446\u0435\u043B\u043E\u0435, \u0440\u0430\u0437\u043C\u0435\u0449\u0435\u043D\u043D\u043E\u0435 \u0432 16-\u0438 \u0431\u0438\u0442\u0430\u0445\"/>\n    <DataType ID=\"limitnum\" BaseType=\"number\" OracleType=\"2\" Size=\"NUMBER\" BriefText=\"\u043D\u043E\u043C\u0435\u0440 \u043B\u0438\u043C\u0438\u0442\u0430 \u0434\u0435\u0440\u0436\u0430\u0442\u0435\u043B\u044F\"/>\n    <DataType ID=\"long\" BaseType=\"number\" OracleType=\"10\" Size=\"NUMBER\" BriefText=\"10 \u0437\u043D\u0430\u043A\u043E\u0432\"/>\n    <DataType ID=\"maid_id\" BaseType=\"string\" OracleType=\"20\" Size=\"VARCHAR2\" BriefText=\"\u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440 \u043B\u0438\u043C\u0438\u0442\u0430\"/>\n    <DataType ID=\"memberid\" BaseType=\"number\" OracleType=\"11\" Size=\"NUMBER\" BriefText=\"\u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440 \u043E\u0431\u044A\u0435\u043A\u0442\u0430\"/>\n    <DataType ID=\"memberst\" BaseType=\"number\" OracleType=\"3\" Size=\"NUMBER\" BriefText=\"\u0441\u0442\u0430\u0442\u0443\u0441 \u043E\u0431\u044A\u0435\u043A\u0442\u0430\"/>\n    <DataType ID=\"memo\" BaseType=\"memo\" OracleType=\"\" Size=\"LONG\" BriefText=\"\u0441\u0438\u043C\u0432\u043E\u043B\u044C\u043D\u0430\u044F \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u044F\"/>\n    <DataType ID=\"msps\" BaseType=\"number\" OracleType=\"2\" Size=\"NUMBER\" BriefText=\"\u0442\u0438\u043F \u0440\u0430\u0441\u0447\u0435\u0442\u0430\"/>\n    <DataType ID=\"nacgn\" BaseType=\"number\" OracleType=\"5\" Size=\"NUMBER\" BriefText=\"\u043A\u043E\u0434 \u0433\u0440\u0443\u043F\u043F\u043E\u0432\u043E\u0433\u043E \u0438\u043C\u0435\u043D\u0438\"/>\n    <DataType ID=\"nameloc\" BaseType=\"string\" OracleType=\"99\" Size=\"VARCHAR2\" BriefText=\"\u043C\u0435\u0441\u0442\u043E \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438\"/>\n    <DataType ID=\"nerror\" BaseType=\"number\" OracleType=\"5\" Size=\"NUMBER\" BriefText=\"\u043A\u043E\u0434 \u043E\u0448\u0438\u0431\u043A\u0438\"/>\n    <DataType ID=\"nmfgr\" BaseType=\"number\" OracleType=\"11\" Size=\"NUMBER\" BriefText=\"\u043A\u043E\u0434 \u0433\u0440\u0443\u043F\u043F\u044B \u043A\u043E\u043C\u0438\u0441\u0441\u0438\u043E\u043D\u043D\u044B\u0445 \u0441\u0442\u0430\u0432\u043E\u043A\"/>\n    <DataType ID=\"nmtid\" BaseType=\"number\" OracleType=\"4\" Size=\"NUMBER\" BriefText=\"Message ID\"/>\n    <DataType ID=\"nstan\" BaseType=\"number\" OracleType=\"6\" Size=\"NUMBER\" BriefText=\"\u043A\u043B\u044E\u0447 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u044F\"/>\n    <DataType ID=\"nstat\" BaseType=\"number\" OracleType=\"2\" Size=\"NUMBER\" BriefText=\"\u0441\u0442\u0430\u0442\u0443\u0441 \u0437\u0430\u043F\u0438\u0441\u0438\"/>\n    <DataType ID=\"nstrf\" BaseType=\"number\" OracleType=\"11\" Size=\"NUMBER\" BriefText=\"\u043A\u043B\u044E\u0447 \u0437\u0430\u043F\u0438\u0441\u0438\"/>\n    <DataType ID=\"ntrnp\" BaseType=\"number\" OracleType=\"3\" Size=\"NUMBER\" BriefText=\"\u043A\u043E\u0434 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F\"/>\n    <DataType ID=\"number\" BaseType=\"number\" OracleType=\"\" Size=\"NUMBER\" BriefText=\"\u0447\u0438\u0441\u043B\u043E \u043F\u0435\u0440\u0435\u043C\u0435\u043D\u043D\u043E\u0439 \u0434\u043B\u0438\u043D\u044B,i=(p,s)\"/>\n    <DataType ID=\"operid\" BaseType=\"number\" OracleType=\"11\" Size=\"NUMBER\" BriefText=\"\u043A\u043E\u0434 \u043E\u043F\u0435p\u0430\u0442\u043Ep\u0430\"/>\n    <DataType ID=\"pan\" BaseType=\"string\" OracleType=\"19\" Size=\"VARCHAR2\" BriefText=\"\u043D\u043E\u043C\u0435\u0440 \u043A\u0430\u0440\u0442\u044B\"/>\n    <DataType ID=\"pmgr\" BaseType=\"number\" OracleType=\"4\" Size=\"NUMBER\" BriefText=\"\u0433\u0440\u0443\u043F\u043F\u0430 \u0440\u0430\u0441\u0447\u0435\u0442\u0430\"/>\n    <DataType ID=\"poscode\" BaseType=\"string\" OracleType=\"12\" Size=\"VARCHAR2\" BriefText=\"posdatacode\"/>\n    <DataType ID=\"proccode\" BaseType=\"number\" OracleType=\"6\" Size=\"NUMBER\" BriefText=\"\u043A\u043E\u0434 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438\"/>\n    <DataType ID=\"processid\" BaseType=\"number\" OracleType=\"4\" Size=\"NUMBER\" BriefText=\"\u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440 \u043F\u0440\u043E\u0446\u0435\u0441\u0441\u0430\"/>\n    <DataType ID=\"progid\" BaseType=\"string\" OracleType=\"4\" Size=\"VARCHAR2\" BriefText=\"\u043A\u043E\u0434 \u043A\u0430\u0440\u0442\u043E\u0447\u043D\u043E\u0439 \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B\"/>\n    <DataType ID=\"projectcode\" BaseType=\"string\" OracleType=\"4\" Size=\"VARCHAR2\" BriefText=\"\u043A\u043E\u0434 \u043F\u0440\u043E\u0435\u043A\u0442\u0430 \u043E\u0431\u043C\u0435\u043D\u0430\"/>\n    <DataType ID=\"psfl\" BaseType=\"string\" OracleType=\"4\" Size=\"VARCHAR2\" BriefText=\"\u043A\u043E\u0434 \u043F\u043B\u0430\u0442\u0435\u0436\u043D\u043E\u0439 \u0441\u0438\u0441\u0442\u0435\u043C\u044B\"/>\n    <DataType ID=\"rate\" BaseType=\"float\" OracleType=\"\" Size=\"NUMBER\" BriefText=\"\u043A\u0443\u0440\u0441 \u043A\u043E\u043D\u0432\u0435\u0440\u0442\u0430\u0446\u0438\u0438\"/>\n    <DataType ID=\"raw\" BaseType=\"raw\" OracleType=\"\" Size=\"RAW\" BriefText=\"\u0434\u0432\u043E\u0438\u0447\u043D\u0430\u044F \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u044F\"/>\n    <DataType ID=\"reason\" BaseType=\"number\" OracleType=\"4\" Size=\"NUMBER\" BriefText=\"\u043A\u043E\u0434 \u043Fp\u0438\u0447\u0438\u043D\u0430 \u0441\u043E\u0431\u044B\u0442\u0438\u044F\"/>\n    <DataType ID=\"reccount\" BaseType=\"number\" OracleType=\"3\" Size=\"NUMBER\" BriefText=\"\u043D\u043E\u043C\u0435\u0440 \u043F\u0430\u043A\u0435\u0442\u0430\"/>\n    <DataType ID=\"rowid\" BaseType=\"rowid\" OracleType=\"\" Size=\"ROWID\" BriefText=\"\u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440 \u0441\u0442\u0440\u043E\u043A\u0438 \u0432 \u0442\u0430\u0431\u043B\u0438\u0446\u0435\"/>\n    <DataType ID=\"smallint\" BaseType=\"number\" OracleType=\"1\" Size=\"NUMBER\" BriefText=\"\u0434\u043B\u044F \u0443\u0434\u043E\u0431\u0441\u0442\u0432\u0430\"/>\n    <DataType ID=\"smtid\" BaseType=\"string\" OracleType=\"4\" Size=\"VARCHAR2\" BriefText=\"MTID \u0432 \u0441\u0442\u0440\u043E\u043A\u043E\u0432\u043E\u043C \u043F\u0440\u0435\u0434\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u0438\u0438\"/>\n    <DataType ID=\"string\" BaseType=\"string\" OracleType=\"\" Size=\"VARCHAR2\" BriefText=\"\u0441\u0442\u0440\u043E\u043A\u0430 \u0441\u0438\u043C\u0432\u043E\u043B\u043E\u0432\"/>\n    <DataType ID=\"termid\" BaseType=\"string\" OracleType=\"8\" Size=\"VARCHAR2\" BriefText=\"\u043A\u043E\u0434 \u0442\u0435\u0440\u043C\u0438\u043D\u0430\u043B\u0430\"/>\n    <DataType ID=\"timestamp\" BaseType=\"timestamp\" OracleType=\"\" Size=\"TIMESTAMP\" BriefText=\"TIMESTAMP\"/>\n    <DataType ID=\"timestamp3\" BaseType=\"timestamp\" OracleType=\"3\" Size=\"TIMESTAMP\" BriefText=\"timestamp 3\"/>\n    <DataType ID=\"trseqnum\" BaseType=\"number\" OracleType=\"18\" Size=\"NUMBER\" BriefText=\"\u043F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u044B\u0439 \u043D\u043E\u043C\u0435\u0440 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u044F\"/>\n    <DataType ID=\"xmltype\" BaseType=\"xmltype\" OracleType=\"\" Size=\"XMLTYPE\" BriefText=\"xml \u0434\u0430\u043D\u043D\u044B\u0435\"/>\n  </DataTypes>\n</UCMsg>"
    },
    {
        key: "\n<UCMsg ID=\"13\">\n  <Schema>\n    <ObjectRefs ObjectsType=\"CONSTRAINT\"/>\n  </Schema>\n  <Context ID=\"555\">\n    <UserName>SOMEONE</UserName>\n    <UserPassword>ABSENT</UserPassword>\n    <UserStatus></UserStatus>\n    <IPAddress></IPAddress>\n    <VerMask>\u0412</VerMask>\n    <SubMask>\u0412</SubMask>\n  </Context>\n</UCMsg>",
        val: "\n<UCMsg ID=\"13\">\n  <Status/>\n  <Context ID=\"355\">\n    <UserName>SOMEONE</UserName>\n    <UserPassword>ABSENT</UserPassword>\n    <UserStatus>0</UserStatus>\n    <IPAddress/>\n    <VerMask>\u0412</VerMask>\n    <SubMask>\u0412</SubMask>\n  </Context>\n  <Schema>\n    <ObjectRefs ObjectsType=\"CONSTRAINT\">\n      <ObjectRef ID=\"CA12_0\" ObjectType=\"C\" BriefText=\"A12TBRW !=0\"/>\n      <ObjectRef ID=\"CHK_T95CLID\" ObjectType=\"C\" BriefText=\"T95CLID IS NOT NULL\"/>\n      <ObjectRef ID=\"CHK_T95POID\" ObjectType=\"C\" BriefText=\"T95POID IS NOT NULL\"/>\n      <ObjectRef ID=\"CL03_0\" ObjectType=\"C\" BriefText=\"L03DCRB&lt;=L03UCRB\"/>\n      <ObjectRef ID=\"CN21UNUM_NN\" ObjectType=\"C\" BriefText=\"N21UNUM IS NOT NULL\"/>\n      <ObjectRef ID=\"CN29_DIFF\" ObjectType=\"C\" BriefText=\" N29DIFF IS NOT NULL\"/>\n      <ObjectRef ID=\"CN29_PAYC\" ObjectType=\"C\" BriefText=\" N29PAYC IS NOT NULL\"/>\n      <ObjectRef ID=\"CN29_PAYD\" ObjectType=\"C\" BriefText=\" N29PAYD IS NOT NULL\"/>\n      <ObjectRef ID=\"CN51_ACSL\" ObjectType=\"C\" BriefText=\" N51ACSL IS NOT NULL\"/>\n      <ObjectRef ID=\"CN51_CRTR\" ObjectType=\"C\" BriefText=\" N51CRTR IS NOT NULL\"/>\n      <ObjectRef ID=\"CN51_DTRV\" ObjectType=\"C\" BriefText=\" N51DTRV IS NOT NULL\"/>\n      <ObjectRef ID=\"CA19AUID_PK\" ObjectType=\"P\" BriefText=\"A19AUID\"/>\n      <ObjectRef ID=\"CB31P002\" ObjectType=\"P\" BriefText=\"B31P002\"/>\n      <ObjectRef ID=\"CB54P041\" ObjectType=\"P\" BriefText=\"B54P041\"/>\n      <ObjectRef ID=\"CB72TRTC\" ObjectType=\"P\" BriefText=\"B72TRTC\"/>\n      <ObjectRef ID=\"CB74CURC\" ObjectType=\"P\" BriefText=\"B74CURC\"/>\n      <ObjectRef ID=\"CH01SLID_PK\" ObjectType=\"P\" BriefText=\"H01SLID\"/>\n      <ObjectRef ID=\"CH08_PK\" ObjectType=\"P\" BriefText=\"H08TSID\"/>\n      <ObjectRef ID=\"CH11_PK\" ObjectType=\"P\" BriefText=\"H11MBID\"/>\n      <ObjectRef ID=\"CH12_PK\" ObjectType=\"P\" BriefText=\"H12TSID,H12SEID,H12MBTP\"/>\n      <ObjectRef ID=\"CI08PK\" ObjectType=\"P\" BriefText=\"I08OPTP,I08OPCL\"/>\n      <ObjectRef ID=\"CI09RUID_P\" ObjectType=\"P\" BriefText=\"I09RUID\"/>\n      <ObjectRef ID=\"CK06POSI\" ObjectType=\"P\" BriefText=\"K06POSI\"/>\n      <ObjectRef ID=\"CN01OPID\" ObjectType=\"P\" BriefText=\"N01OPID\"/>\n      <ObjectRef ID=\"CN04_0\" ObjectType=\"P\" BriefText=\"N04OPID,N04PHID\"/>\n      <ObjectRef ID=\"CN29_0\" ObjectType=\"P\" BriefText=\"N29FDID\"/>\n      <ObjectRef ID=\"CN51_0\" ObjectType=\"P\" BriefText=\"N51ACNC,N51VALD\"/>\n      <ObjectRef ID=\"CT11_0\" ObjectType=\"P\" BriefText=\"T11OPTP\"/>\n      <ObjectRef ID=\"CT12_0\" ObjectType=\"P\" BriefText=\"T12PHTP\"/>\n      <ObjectRef ID=\"IC51_0\" ObjectType=\"P\" BriefText=\"C51CPCI\"/>\n      <ObjectRef ID=\"IC62_0\" ObjectType=\"P\" BriefText=\"C62CTID,C62LNID\"/>\n      <ObjectRef ID=\"IL91_PK\" ObjectType=\"P\" BriefText=\"L91LPAN,L91HPAN,L91PSFL,L91ESH9,L91RDAT,L91ORDR\"/>\n      <ObjectRef ID=\"IL92_PK\" ObjectType=\"P\" BriefText=\"L92LPAN,L92HPAN,L92PSFL,L92ESH9,L92ORDR\"/>\n      <ObjectRef ID=\"IL93_PK\" ObjectType=\"P\" BriefText=\"L93LPAN,L93HPAN,L93PSFL,L93ESH9,L93RDAT\"/>\n      <ObjectRef ID=\"CA20AUID_FK\" ObjectType=\"R\" BriefText=\"CA19AUID_PK\"/>\n    </ObjectRefs>\n  </Schema>\n</UCMsg>"
    },
    {
        key: "\n<UCMsg ID=\"7\">\n  <RequestHead ID=\"0\">\n    <Action>info</Action>\n    <Requests>\n      <Request ID=\"0\">\n        <Action>info</Action>\n        <Subject>\n          <Action>info</Action>\n          <Object Type=\"TABLE\">\n            <Table ID=\"A01\"></Table>\n          </Object>\n        </Subject>\n      </Request>\n    </Requests>\n  </RequestHead>\n  <Context ID=\"555\">\n    <UserName>SOMEONE</UserName>\n    <UserPassword>ABSENT</UserPassword>\n    <UserStatus></UserStatus>\n    <IPAddress></IPAddress>\n    <VerMask>\u0412</VerMask>\n    <SubMask>\u0412</SubMask>\n  </Context>\n</UCMsg>",
        val: "\n<UCMsg ID=\"7\">\n  <RequestHead ID=\"0\">\n    <Action>info</Action>\n    <Requests>\n      <Request ID=\"0\">\n        <Action>info</Action>\n        <Subject>\n          <Action>info</Action>\n          <Object Type=\"TABLE\">\n            <Table ID=\"A01\">\n              <Fields>\n                <Field ID=\"A01DATE\">\n                  <TableID>A01</TableID>\n                  <Type>date</Type>\n                  <Position>2</Position>\n                  <Nullable>N</Nullable>\n                  <BriefText>MessageDate</BriefText>\n                  <FullText>\u0414\u0430\u0442\u0430 \u0438 \u0432\u0440\u0435\u043C\u044F \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u044F</FullText>\n                </Field>\n                <Field ID=\"A01MESS\">\n                  <TableID>A01</TableID>\n                  <Type>string(2000)</Type>\n                  <Size>2000</Size>\n                  <Position>3</Position>\n                  <Nullable>N</Nullable>\n                  <BriefText>Message</BriefText>\n                  <FullText>\u0418\u043C\u044F \u043F\u0440\u043E\u0446\u0435\u0441\u0441\u0430 \u0438\u043B\u0438 \u043F\u0440\u043E\u0446\u0435\u0434\u0443\u0440\u044B, \u0441\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u0432\u0448\u0435\u0439 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0435</FullText>\n                </Field>\n                <Field ID=\"A01ERRM\">\n                  <TableID>A01</TableID>\n                  <Type>string(2000)</Type>\n                  <Size>2000</Size>\n                  <Position>4</Position>\n                  <Nullable>Y</Nullable>\n                  <BriefText>ErrorString</BriefText>\n                  <FullText>\u0421\u043E\u0434\u0435\u0440\u0436\u0430\u043D\u0438\u0435 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u044F</FullText>\n                </Field>\n                <Field ID=\"A01AMOD\">\n                  <TableID>A01</TableID>\n                  <Type>string(8)</Type>\n                  <Size>8</Size>\n                  <Position>5</Position>\n                  <Nullable>Y</Nullable>\n                  <BriefText>ArchiveMode</BriefText>\n                  <FullText>\u0422\u0438\u043F \u043F\u0440\u043E\u0446\u0435\u0441\u0441\u0430, \u0441\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u0432\u0448\u0435\u0433\u043E \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0435 (\u041D\u0430\u0438\u043C\u0435\u043D\u043E\u0432\u0430\u043D\u0438\u0435 \u0432 T80 \u0441typ=167)</FullText>\n                </Field>\n                <Field ID=\"A01LEVL\">\n                  <TableID>A01</TableID>\n                  <Type>string(1)</Type>\n                  <Size>1</Size>\n                  <Position>13102</Position>\n                  <Nullable>Y</Nullable>\n                  <BriefText>ErrorLevel</BriefText>\n                  <FullText>\u0423\u0440\u043E\u0432\u0435\u043D\u044C \u043E\u0448\u0438\u0431\u043A\u0438(I-\u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u044F,W-\u043F\u0440\u0435\u0434\u0443\u043F\u0440\u0435\u0436\u0434\u0435\u043D\u0438\u0435,E-\u043E\u0448\u0438\u0431\u043A\u0430)</FullText>\n                </Field>\n                <Field ID=\"A01OPID\">\n                  <TableID>A01</TableID>\n                  <Type>memberid</Type>\n                  <Position>13103</Position>\n                  <Nullable>Y</Nullable>\n                  <FullText>\u041A\u043E\u0434 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438, \u0437\u0430\u043F\u0443\u0441\u0442\u0438\u0432\u0448\u0438\u0439 \u043F\u0440\u043E\u0446\u0435\u0441\u0441</FullText>\n                </Field>\n                <Field ID=\"A01CPTR\">\n                  <TableID>A01</TableID>\n                  <Type>intmax</Type>\n                  <Position>13104</Position>\n                  <Nullable>Y</Nullable>\n                  <FullText>\u0421\u0441\u044B\u043B\u043A\u0430 \u043D\u0430 I23STRF(\u043F\u043E\u0434\u0440\u043E\u0431\u043D\u044B\u0439 \u043F\u0440\u043E\u0442\u043E\u043A\u043E\u043B \u043F\u0440\u043E\u0446\u0435\u0441\u0441\u0430)</FullText>\n                </Field>\n                <Field ID=\"A01OBID\">\n                  <TableID>A01</TableID>\n                  <Type>number(11)</Type>\n                  <Size>11</Size>\n                  <Position>14220</Position>\n                  <Nullable>Y</Nullable>\n                  <BriefText>ObjectID</BriefText>\n                  <FullText>\u0418\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440 \u043E\u0431\u044A\u0435\u043A\u0442\u0430</FullText>\n                </Field>\n                <Field ID=\"A01MBST\">\n                  <TableID>A01</TableID>\n                  <Type>number(11)</Type>\n                  <Size>11</Size>\n                  <Position>14221</Position>\n                  <Nullable>Y</Nullable>\n                  <BriefText>ObjectType</BriefText>\n                  <FullText>\u0422\u0438\u043F \u043E\u0431\u044A\u0435\u043A\u0442\u0430</FullText>\n                </Field>\n                <Field ID=\"A01IDEN\">\n                  <TableID>A01</TableID>\n                  <Type>long</Type>\n                  <Nullable>N</Nullable>\n                  <BriefText>ID</BriefText>\n                  <FullText>\u041D\u043E\u043C\u0435\u0440 \u043F\u043E \u043F\u043E\u0440\u044F\u0434\u043A\u0443 \u0441\u0447\u0451\u0442\u0447\u0438\u043A SEQ_A01 \u0442\u0440\u0438\u0433\u0433\u0435\u0440 TA01_0 </FullText>\n                </Field>\n              </Fields>\n              <Indexes>\n                <Index ID=\"IA01IDEN\">\n                  <TableID>A01</TableID>\n                  <Type/>\n                  <Uniqueness>1</Uniqueness>\n                  <Fields>\n                    <Field ID=\"A01IDEN\">\n                      <TableID>A01</TableID>\n                      <Position>1</Position>\n                    </Field>\n                  </Fields>\n                </Index>\n                <Index ID=\"IA01OPID\">\n                  <TableID>A01</TableID>\n                  <Type/>\n                  <Uniqueness>0</Uniqueness>\n                  <Fields>\n                    <Field ID=\"A01OPID\">\n                      <TableID>A01</TableID>\n                      <Position>1</Position>\n                    </Field>\n                  </Fields>\n                </Index>\n                <Index ID=\"IA01_1\">\n                  <TableID>A01</TableID>\n                  <Type>0</Type>\n                  <Uniqueness>0</Uniqueness>\n                  <Fields>\n                    <Field ID=\"A01MBST\">\n                      <TableID>A01</TableID>\n                      <Position>1</Position>\n                    </Field>\n                    <Field ID=\"A01OBID\">\n                      <TableID>A01</TableID>\n                      <Position>2</Position>\n                    </Field>\n                  </Fields>\n                </Index>\n              </Indexes>\n              <BriefText>\u041F\u0440\u043E\u0442\u043E\u043A\u043E\u043B \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u044F \u043F\u0440\u043E\u0446\u0435\u0441\u0441\u043E\u0432</BriefText>\n              <FullText>\u0421\u043E\u0434\u0435\u0440\u0436\u0438\u0442 \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0443\u044E \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u044E \u0438 \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u044E \u043E\u0431 \u043E\u0448\u0438\u0431\u043A\u0430\u0445</FullText>\n            </Table>\n          </Object>\n          <ObjectContext>\n            <Users>EVGENIY,GMG,KHATAEV,KOT,LEONID,MARAT,NERVIWKI,OLEG,OSA,ROSTICK,SELIV,SHESTAKOV,VLAD76,VLASENKO,WOWA</Users>\n            <RequestHeads>\n              <ObjectRef ID=\"3176\" ObjectType=\"REQUESTHEAD\" BriefText=\"\u0420\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u0444\u0443\u043D\u043A\u0446\u0438\u043E\u043D\u0430\u043B\u044C\u043D\u043E\u0441\u0442\u0438 \u043F\u0440\u043E\u0442\u043E\u043A\u043E\u043B\u0430\" Author=\"WOWA\" Done=\"2006.12.25\"/>\n              <ObjectRef ID=\"3347\" ObjectType=\"REQUESTHEAD\" BriefText=\"\u0423\u0441\u043A\u043E\u0440\u0435\u043D\u0438\u0435 \u0434\u043E\u0441\u0442\u0443\u043F\u0430 \u043A \u043F\u0440\u043E\u0442\u043E\u043A\u043E\u043B\u0443\" Author=\"SELIV\" Done=\"2007.11.27\"/>\n              <ObjectRef ID=\"3483\" ObjectType=\"REQUESTHEAD\" BriefText=\"\u0420\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u0432\u043E\u0437\u043C\u043E\u0436\u043D\u043E\u0441\u0442\u0435\u0439 \u043F\u0440\u043E\u0442\u043E\u043A\u043E\u043B\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F\" Author=\"SELIV\" Done=\"2008.10.13\"/>\n              <ObjectRef ID=\"4750\" ObjectType=\"REQUESTHEAD\" BriefText=\"\u0420\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u0432\u043E\u0437\u043C\u043E\u0436\u043D\u043E\u0441\u0442\u0435\u0439 \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438 \u0440\u0435\u0433\u043B\u0430\u043C\u0435\u043D\u0442\u043D\u044B\u0445 \u0437\u0430\u0434\u0430\u043D\u0438\u0439. \u0412 \u0440\u0430\u043C\u043A\u0430\u0445 \u0437\u0430\u044F\u0432\u043A\u0438 \nbas00021963\" Author=\"ROSTICK\" Done=\"2014.04.21\"/>\n            </RequestHeads>\n          </ObjectContext>\n        </Subject>\n      </Request>\n    </Requests>\n  </RequestHead>\n  <Status/>\n  <Context ID=\"355\">\n    <UserName>SOMEONE</UserName>\n    <UserPassword>ABSENT</UserPassword>\n    <UserStatus>0</UserStatus>\n    <IPAddress/>\n    <VerMask>\u0412</VerMask>\n    <SubMask>\u0412</SubMask>\n  </Context>\n</UCMsg>"
    },
    {
        key: "\n<UCMsg ID=\"9\">\n  <RequestHead ID=\"3176\">\n    <Action>info</Action>\n  </RequestHead>\n  <Context ID=\"555\">\n    <UserName>SOMEONE</UserName>\n    <UserPassword>ABSENT</UserPassword>\n    <UserStatus></UserStatus>\n    <IPAddress></IPAddress>\n    <VerMask>\u0412</VerMask>\n    <SubMask>\u0412</SubMask>\n  </Context>\n</UCMsg>",
        val: "\n<UCMsg ID=\"9\">\n  <RequestHead ID=\"3176\">\n    <Action>info</Action>\n    <Requests>\n      <Request ID=\"13102\">\n        <Action>info</Action>\n        <Subject>\n          <Action>add</Action>\n          <Object Type=\"FIELD\">\n            <Field ID=\"A01LEVL\">\n              <TableID>A01</TableID>\n              <Type>string(1)</Type>\n              <Size>1</Size>\n              <Nullable>Y</Nullable>\n              <BriefText>ErrorLevel</BriefText>\n              <FullText>\u0423\u0440\u043E\u0432\u0435\u043D\u044C \u043E\u0448\u0438\u0431\u043A\u0438(I-\u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u044F,W-\u043F\u0440\u0435\u0434\u0443\u043F\u0440\u0435\u0436\u0434\u0435\u043D\u0438\u0435,E-\u043E\u0448\u0438\u0431\u043A\u0430)</FullText>\n            </Field>\n          </Object>\n        </Subject>\n      </Request>\n      <Request ID=\"13103\">\n        <Action>info</Action>\n        <Subject>\n          <Action>add</Action>\n          <Object Type=\"FIELD\">\n            <Field ID=\"A01OPID\">\n              <TableID>A01</TableID>\n              <Type>memberid</Type>\n              <Nullable>Y</Nullable>\n              <FullText>\u041A\u043E\u0434 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438, \u0437\u0430\u043F\u0443\u0441\u0442\u0438\u0432\u0448\u0438\u0439 \u043F\u0440\u043E\u0446\u0435\u0441\u0441</FullText>\n            </Field>\n          </Object>\n        </Subject>\n      </Request>\n      <Request ID=\"13104\">\n        <Action>info</Action>\n        <Subject>\n          <Action>add</Action>\n          <Object Type=\"FIELD\">\n            <Field ID=\"A01CPTR\">\n              <TableID>A01</TableID>\n              <Type>intmax</Type>\n              <Nullable>Y</Nullable>\n              <FullText>\u0421\u0441\u044B\u043B\u043A\u0430 \u043D\u0430 I23STRF(\u043F\u043E\u0434\u0440\u043E\u0431\u043D\u044B\u0439 \u043F\u0440\u043E\u0442\u043E\u043A\u043E\u043B \u043F\u0440\u043E\u0446\u0435\u0441\u0441\u0430)</FullText>\n            </Field>\n          </Object>\n        </Subject>\n      </Request>\n    </Requests>\n    <BriefText>\u0420\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u0444\u0443\u043D\u043A\u0446\u0438\u043E\u043D\u0430\u043B\u044C\u043D\u043E\u0441\u0442\u0438 \u043F\u0440\u043E\u0442\u043E\u043A\u043E\u043B\u0430</BriefText>\n    <Author>WOWA</Author>\n    <Created>21.12.2006 11:23:54</Created>\n    <Done>25.12.2006 12:31:22</Done>\n  </RequestHead>\n  <Status/>\n  <Context ID=\"355\">\n    <UserName>SOMEONE</UserName>\n    <UserPassword>ABSENT</UserPassword>\n    <UserStatus>0</UserStatus>\n    <IPAddress/>\n    <VerMask>\u0412</VerMask>\n    <SubMask>\u0412</SubMask>\n  </Context>\n</UCMsg>"
    },
    {
        key: "\n<UCMsg ID=\"11\">\n  <Confirms>\n    <Filter>\n      <Status>notapproved</Status>\n      <DateFrom>" + ATools.getdate(-6) + "</DateFrom>\n      <DateTo>" + ATools.getdate(0) + "</DateTo>\n    </Filter>\n  </Confirms>\n  <Context ID=\"555\">\n    <UserName>SOMEONE</UserName>\n    <UserPassword>ABSENT</UserPassword>\n    <UserStatus></UserStatus>\n    <IPAddress></IPAddress>\n    <VerMask>\u0412</VerMask>\n    <SubMask>\u0412</SubMask>\n  </Context>\n</UCMsg>",
        val: "\n<UCMsg ID=\"11\">\n  <Status/>\n  <Context ID=\"355\">\n    <UserName>SOMEONE</UserName>\n    <UserPassword>ABSENT</UserPassword>\n    <UserStatus>0</UserStatus>\n    <IPAddress/>\n    <VerMask>\u0412</VerMask>\n    <SubMask>\u0412</SubMask>\n  </Context>\n  <Confirms>\n    <Confirm>\n      <RequestHead ID=\"5257\">\n        <Action>info</Action>\n        <BriefText>\u043B\u0434\u043B\u0434</BriefText>\n        <Author>LEONID</Author>\n        <Created>31.03 13:08:28</Created>\n      </RequestHead>\n      <Decision/>\n      <UsersConfirm>\n        <UserConfirm ID=\"EVGENIY\" Decision=\"Y\"/>\n        <UserConfirm ID=\"GMG\" Decision=\"\"/>\n        <UserConfirm ID=\"KHATAEV\" Decision=\"\"/>\n        <UserConfirm ID=\"KOT\" Decision=\"\"/>\n        <UserConfirm ID=\"LEONID\" Decision=\"\"/>\n        <UserConfirm ID=\"MARAT\" Decision=\"\"/>\n        <UserConfirm ID=\"NERVIWKI\" Decision=\"\"/>\n        <UserConfirm ID=\"OLEG\" Decision=\"\"/>\n        <UserConfirm ID=\"OSA\" Decision=\"\"/>\n        <UserConfirm ID=\"ROSTICK\" Decision=\"\"/>\n        <UserConfirm ID=\"SELIV\" Decision=\"\"/>\n        <UserConfirm ID=\"SHESTAKOV\" Decision=\"\"/>\n        <UserConfirm ID=\"VLAD76\" Decision=\"Y\"/>\n        <UserConfirm ID=\"VLASENKO\" Decision=\"\"/>\n        <UserConfirm ID=\"WOWA\" Decision=\"Y\"/>\n      </UsersConfirm>\n    </Confirm>\n    <Confirm>\n      <RequestHead ID=\"5255\">\n        <Action>info</Action>\n        <BriefText>\u043F\u043E\u0434\u0434\u0435\u0440\u0436\u043A\u0430 \u043C\u043E\u0434\u0435\u043B\u0438 \u0441\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0439 \u0434\u043B\u044F \u043F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u0439 \u043A\u043B\u0438\u0435\u043D\u0442\u0441\u043A\u0438\u0445 \u043E\u0440\u0433\u0430\u043D\u0438\u0437\u0430\u0446\u0438\u0439</BriefText>\n        <Author>WOWA</Author>\n        <Created>31.03 15:47:43</Created>\n      </RequestHead>\n      <Decision/>\n      <UsersConfirm>\n        <UserConfirm ID=\"EVGENIY\" Decision=\"Y\"/>\n        <UserConfirm ID=\"GMG\" Decision=\"\"/>\n        <UserConfirm ID=\"KHATAEV\" Decision=\"\"/>\n        <UserConfirm ID=\"KOT\" Decision=\"\"/>\n        <UserConfirm ID=\"LEONID\" Decision=\"\"/>\n        <UserConfirm ID=\"MARAT\" Decision=\"\"/>\n        <UserConfirm ID=\"NERVIWKI\" Decision=\"\"/>\n        <UserConfirm ID=\"OLEG\" Decision=\"\"/>\n        <UserConfirm ID=\"OSA\" Decision=\"\"/>\n        <UserConfirm ID=\"ROSTICK\" Decision=\"\"/>\n        <UserConfirm ID=\"SELIV\" Decision=\"\"/>\n        <UserConfirm ID=\"SHESTAKOV\" Decision=\"\"/>\n        <UserConfirm ID=\"VLAD76\" Decision=\"\"/>\n        <UserConfirm ID=\"VLASENKO\" Decision=\"\"/>\n        <UserConfirm ID=\"WOWA\" Decision=\"Y\"/>\n      </UsersConfirm>\n    </Confirm>\n    <Confirm>\n      <RequestHead ID=\"5248\">\n        <Action>info</Action>\n        <BriefText>\u041D\u0435\u043E\u0431\u0445\u043E\u0434\u0438\u043C\u043E\u0441\u0442\u044C \u0438\u043D\u0434\u0435\u043A\u0441\u043E\u0432 \u043F\u043E \u043F\u043E\u043B\u044F\u043C F13PKID \u0438 F29PKID \u0434\u043B\u044F \u043A\u043E\u043D\u0442\u0440\u043E\u043B\u044F \u0430\u043A\u0442\u0443\u0430\u043B\u0438\u0437\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u043E\u0441\u0442\u0438 \u0432\u0441\u0435\u0445 \u043E\u0431\u044A\u0435\u043A\u0442\u043E\u0432 \u043F\u0430\u043A\u0435\u0442\u0430</BriefText>\n        <Author>OSA</Author>\n        <Created>15.03 18:26:56</Created>\n      </RequestHead>\n      <Decision/>\n      <UsersConfirm>\n        <UserConfirm ID=\"EVGENIY\" Decision=\"Y\"/>\n        <UserConfirm ID=\"GMG\" Decision=\"\"/>\n        <UserConfirm ID=\"KHATAEV\" Decision=\"\"/>\n        <UserConfirm ID=\"KOT\" Decision=\"\"/>\n        <UserConfirm ID=\"LEONID\" Decision=\"\"/>\n        <UserConfirm ID=\"MARAT\" Decision=\"\"/>\n        <UserConfirm ID=\"NERVIWKI\" Decision=\"\"/>\n        <UserConfirm ID=\"OLEG\" Decision=\"\"/>\n        <UserConfirm ID=\"OSA\" Decision=\"Y\"/>\n        <UserConfirm ID=\"ROSTICK\" Decision=\"\"/>\n        <UserConfirm ID=\"SELIV\" Decision=\"\"/>\n        <UserConfirm ID=\"SHESTAKOV\" Decision=\"\"/>\n        <UserConfirm ID=\"VLAD76\" Decision=\"\"/>\n        <UserConfirm ID=\"VLASENKO\" Decision=\"\"/>\n        <UserConfirm ID=\"WOWA\" Decision=\"Y\"/>\n      </UsersConfirm>\n    </Confirm>\n    <Confirm>\n      <RequestHead ID=\"5244\">\n        <Action>info</Action>\n        <BriefText>\u041E\u0436\u0438\u0434\u0430\u0435\u043C\u044B\u0435 \u043F\u0440\u0438\u0445\u043E\u0434\u043D\u044B\u0435 \u043F\u043B\u0430\u0442\u0451\u0436\u043D\u044B\u0435 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B \u0423\u0424\u042D\u0411\u0421</BriefText>\n        <Author>OSA</Author>\n        <Created>11.03 10:33:56</Created>\n      </RequestHead>\n      <Decision/>\n      <UsersConfirm>\n        <UserConfirm ID=\"EVGENIY\" Decision=\"Y\"/>\n        <UserConfirm ID=\"GMG\" Decision=\"\"/>\n        <UserConfirm ID=\"KHATAEV\" Decision=\"\"/>\n        <UserConfirm ID=\"KOT\" Decision=\"\"/>\n        <UserConfirm ID=\"LEONID\" Decision=\"\"/>\n        <UserConfirm ID=\"MARAT\" Decision=\"\"/>\n        <UserConfirm ID=\"NERVIWKI\" Decision=\"\"/>\n        <UserConfirm ID=\"OLEG\" Decision=\"\"/>\n        <UserConfirm ID=\"OSA\" Decision=\"Y\"/>\n        <UserConfirm ID=\"ROSTICK\" Decision=\"\"/>\n        <UserConfirm ID=\"SELIV\" Decision=\"\"/>\n        <UserConfirm ID=\"SHESTAKOV\" Decision=\"\"/>\n        <UserConfirm ID=\"VLAD76\" Decision=\"\"/>\n        <UserConfirm ID=\"VLASENKO\" Decision=\"\"/>\n        <UserConfirm ID=\"WOWA\" Decision=\"Y\"/>\n      </UsersConfirm>\n    </Confirm>\n    <Filter>\n      <Status>notapproved</Status>\n      <DateFrom>08.07.2015</DateFrom>\n      <DateTo>15.02.2017</DateTo>\n    </Filter>\n  </Confirms>\n</UCMsg>"
    },
    {
        key: "\n<UCMsg ID=\"9\">\n  <RequestHead ID=\"5257\">\n    <Action>info</Action>\n  </RequestHead>\n  <Context ID=\"555\">\n    <UserName>SOMEONE</UserName>\n    <UserPassword>ABSENT</UserPassword>\n    <UserStatus></UserStatus>\n    <IPAddress></IPAddress>\n    <VerMask>\u0412</VerMask>\n    <SubMask>\u0412</SubMask>\n  </Context>\n</UCMsg>",
        val: "\n<UCMsg ID=\"9\">\n  <RequestHead ID=\"5257\">\n    <Action>info</Action>\n    <Requests>\n      <Request ID=\"37771\">\n        <Action>info</Action>\n        <Subject>\n          <Action>add</Action>\n          <Object Type=\"FIELD\">\n            <Field ID=\"B62CHEN\">\n              <TableID>B62</TableID>\n              <Type>string(26)</Type>\n              <Size>26</Size>\n              <Position>37771</Position>\n              <Nullable>Y</Nullable>\n              <BriefText>CardholdEmbossName</BriefText>\n              <FullText>\u0418\u043C\u044F \u043A\u043B\u0438\u0435\u043D\u0442\u0430 \u044D\u043C\u0431\u043E\u0441\u0441\u0438\u0440\u0443\u0435\u043C\u043E\u0435 \u043D\u0430 \u043A\u0430\u0440\u0442\u0435 - \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0435\u0442\u0441\u044F \u043F\u0440\u0438 \u0432\u044B\u0433\u0440\u0443\u0437\u043A\u0435 \u0444\u0430\u0439\u043B\u0430 \u043D\u0430 \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u0438\u0437\u0430\u0446\u0438\u044E, \u0435\u0441\u043B\u0438 \u043D\u0435 \u0437\u0430\u0434\u0430\u043D\u043E \u0437\u0430 \u043A\u0430\u0440\u0442\u043E\u0439</FullText>\n            </Field>\n          </Object>\n        </Subject>\n      </Request>\n      <Request ID=\"37772\">\n        <Action>info</Action>\n        <Subject>\n          <Action>add</Action>\n          <Object Type=\"FIELD\">\n            <Field ID=\"B62CMEN\">\n              <TableID>B62</TableID>\n              <Type>string(30)</Type>\n              <Size>30</Size>\n              <Position>37772</Position>\n              <Nullable>Y</Nullable>\n              <BriefText>CompanyEmbossName</BriefText>\n              <FullText>\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435 \u043E\u0440\u0433\u0430\u043D\u0438\u0437\u0430\u0446\u0438\u0438 \u043F\u0440\u0438 \u044D\u043C\u0431\u043E\u0441\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0438 - \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0435\u0442\u0441\u044F \u043F\u0440\u0438 \u0432\u044B\u0433\u0440\u0443\u0437\u043A\u0435 \u0444\u0430\u0439\u043B\u0430 \u043D\u0430 \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u0438\u0437\u0430\u0446\u0438\u044E, \u0435\u0441\u043B\u0438 \u043D\u0435 \u0437\u0430\u0434\u0430\u043D\u043E \u0437\u0430 \u043A\u0430\u0440\u0442\u043E\u0439</FullText>\n            </Field>\n          </Object>\n        </Subject>\n      </Request>\n    </Requests>\n    <BriefText>\u043B\u0434\u043B\u0434</BriefText>\n    <Author>VLAD76</Author>\n    <Created>31.03.2016 01:08:28</Created>\n  </RequestHead>\n  <Status/>\n  <Context ID=\"355\">\n    <UserName>SOMEONE</UserName>\n    <UserPassword>ABSENT</UserPassword>\n    <UserStatus>0</UserStatus>\n    <IPAddress/>\n    <VerMask>\u0412</VerMask>\n    <SubMask>\u0412</SubMask>\n  </Context>\n</UCMsg>"
    },
    {
        key: "\n<UCMsg ID=\"11\">\n  <Confirms>\n    <Filter>\n      <Status>approved</Status>\n      <DateFrom>" + ATools.getdate(-6) + "</DateFrom>\n      <DateTo>" + ATools.getdate(0) + "</DateTo>\n    </Filter>\n  </Confirms>\n  <Context ID=\"555\">\n    <UserName>SOMEONE</UserName>\n    <UserPassword>ABSENT</UserPassword>\n    <UserStatus></UserStatus>\n    <IPAddress></IPAddress>\n    <VerMask>\u0412</VerMask>\n    <SubMask>\u0412</SubMask>\n  </Context>\n</UCMsg>",
        val: "\n<UCMsg ID=\"11\">\n  <Status/>\n  <Context ID=\"355\">\n    <UserName>SOMEONE</UserName>\n    <UserPassword>ABSENT</UserPassword>\n    <UserStatus>0</UserStatus>\n    <IPAddress/>\n    <VerMask>\u0412</VerMask>\n    <SubMask>\u0412</SubMask>\n  </Context>\n  <Confirms>\n    <Confirm>\n      <RequestHead ID=\"5239\">\n        <Action>info</Action>\n        <BriefText>\u0420\u0430\u0441\u0447\u0435\u0442 \u0440\u0435\u0439\u0442\u0438\u043D\u0433\u0430 \u043A\u043E\u0440\u0440. \u0441\u0447\u0435\u0442\u043E\u0432 (\u0434\u043B\u044F \u0437\u0430\u044F\u0432\u043A\u0438 20685)</BriefText>\n        <Author>EVGENIY</Author>\n        <Created>03.03 17:21:11</Created>\n        <Done>04.03 11:42:06</Done>\n      </RequestHead>\n      <Decision/>\n      <UsersConfirm>\n        <UserConfirm ID=\"ALEXB\" Decision=\"Y\"/>\n        <UserConfirm ID=\"EVGENIY\" Decision=\"Y\"/>\n        <UserConfirm ID=\"GMG\" Decision=\"Y\"/>\n        <UserConfirm ID=\"KHATAEV\" Decision=\"Y\"/>\n        <UserConfirm ID=\"KOT\" Decision=\"Y\"/>\n        <UserConfirm ID=\"LEONID\" Decision=\"Y\"/>\n        <UserConfirm ID=\"MARAT\" Decision=\"Y\"/>\n        <UserConfirm ID=\"NERVIWKI\" Decision=\"Y\"/>\n        <UserConfirm ID=\"OLEG\" Decision=\"Y\"/>\n        <UserConfirm ID=\"OSA\" Decision=\"Y\"/>\n        <UserConfirm ID=\"ROSTICK\" Decision=\"Y\"/>\n        <UserConfirm ID=\"SELIV\" Decision=\"Y\"/>\n        <UserConfirm ID=\"SHESTAKOV\" Decision=\"Y\"/>\n        <UserConfirm ID=\"VLAD76\" Decision=\"Y\"/>\n        <UserConfirm ID=\"VLASENKO\" Decision=\"Y\"/>\n        <UserConfirm ID=\"WOWA\" Decision=\"Y\"/>\n        <UserConfirm ID=\"ALEXB\" Decision=\"\"/>\n      </UsersConfirm>\n    </Confirm>\n    <Confirm>\n      <RequestHead ID=\"5237\">\n        <Action>info</Action>\n        <BriefText>\u0423\u0434\u0430\u043B\u0435\u043D\u0438\u0435 \u043E\u0433\u0440\u0430\u043D\u0438\u0447\u0435\u043D\u0438\u0439 \u0442\u0430\u0431\u043B\u0438\u0446\u044B T06</BriefText>\n        <Author>OSA</Author>\n        <Created>03.03 15:52:26</Created>\n        <Done>04.03 11:42:07</Done>\n      </RequestHead>\n      <Decision/>\n      <UsersConfirm>\n        <UserConfirm ID=\"ALEXB\" Decision=\"Y\"/>\n        <UserConfirm ID=\"EVGENIY\" Decision=\"Y\"/>\n        <UserConfirm ID=\"GMG\" Decision=\"Y\"/>\n        <UserConfirm ID=\"KHATAEV\" Decision=\"Y\"/>\n        <UserConfirm ID=\"KOT\" Decision=\"Y\"/>\n        <UserConfirm ID=\"LEONID\" Decision=\"Y\"/>\n        <UserConfirm ID=\"MARAT\" Decision=\"Y\"/>\n        <UserConfirm ID=\"NERVIWKI\" Decision=\"Y\"/>\n        <UserConfirm ID=\"OLEG\" Decision=\"Y\"/>\n        <UserConfirm ID=\"OSA\" Decision=\"Y\"/>\n        <UserConfirm ID=\"ROSTICK\" Decision=\"Y\"/>\n        <UserConfirm ID=\"SELIV\" Decision=\"Y\"/>\n        <UserConfirm ID=\"SHESTAKOV\" Decision=\"Y\"/>\n        <UserConfirm ID=\"VLAD76\" Decision=\"Y\"/>\n        <UserConfirm ID=\"VLASENKO\" Decision=\"Y\"/>\n        <UserConfirm ID=\"WOWA\" Decision=\"Y\"/>\n        <UserConfirm ID=\"ALEXB\" Decision=\"\"/>\n      </UsersConfirm>\n    </Confirm>\n    <Confirm>\n      <RequestHead ID=\"5236\">\n        <Action>info</Action>\n        <BriefText>\u0423\u0434\u0430\u043B\u0435\u043D\u0438\u0435 \u043F\u043E\u043B\u044F N67ACCT</BriefText>\n        <Author>VLASENKO</Author>\n        <Created>03.03 15:34:01</Created>\n        <Done>04.03 11:42:09</Done>\n      </RequestHead>\n      <Decision/>\n      <UsersConfirm>\n        <UserConfirm ID=\"ALEXB\" Decision=\"Y\"/>\n        <UserConfirm ID=\"EVGENIY\" Decision=\"Y\"/>\n        <UserConfirm ID=\"GMG\" Decision=\"Y\"/>\n        <UserConfirm ID=\"KHATAEV\" Decision=\"Y\"/>\n        <UserConfirm ID=\"KOT\" Decision=\"Y\"/>\n        <UserConfirm ID=\"LEONID\" Decision=\"Y\"/>\n        <UserConfirm ID=\"MARAT\" Decision=\"Y\"/>\n        <UserConfirm ID=\"NERVIWKI\" Decision=\"Y\"/>\n        <UserConfirm ID=\"OLEG\" Decision=\"Y\"/>\n        <UserConfirm ID=\"OSA\" Decision=\"Y\"/>\n        <UserConfirm ID=\"ROSTICK\" Decision=\"Y\"/>\n        <UserConfirm ID=\"SELIV\" Decision=\"Y\"/>\n        <UserConfirm ID=\"SHESTAKOV\" Decision=\"Y\"/>\n        <UserConfirm ID=\"VLAD76\" Decision=\"Y\"/>\n        <UserConfirm ID=\"VLASENKO\" Decision=\"Y\"/>\n        <UserConfirm ID=\"WOWA\" Decision=\"Y\"/>\n        <UserConfirm ID=\"ALEXB\" Decision=\"\"/>\n      </UsersConfirm>\n    </Confirm>\n    <Confirm>\n      <RequestHead ID=\"5235\">\n        <Action>info</Action>\n        <BriefText>\u0417\u0430\u0434\u0430\u043D\u0438\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u043F\u043E \u0443\u043C\u043E\u043B\u0447\u0430\u043D\u0438\u044E \u0434\u043B\u044F N67ACCT - \u0432\u0438\u0434 \u0441\u0447\u0451\u0442\u0430</BriefText>\n        <Author>VLASENKO</Author>\n        <Created>03.03 14:18:38</Created>\n        <Done>03.03 14:36:29</Done>\n      </RequestHead>\n      <Decision/>\n      <UsersConfirm>\n        <UserConfirm ID=\"ALEXB\" Decision=\"Y\"/>\n        <UserConfirm ID=\"EVGENIY\" Decision=\"Y\"/>\n        <UserConfirm ID=\"GMG\" Decision=\"Y\"/>\n        <UserConfirm ID=\"KHATAEV\" Decision=\"Y\"/>\n        <UserConfirm ID=\"KOT\" Decision=\"Y\"/>\n        <UserConfirm ID=\"LEONID\" Decision=\"Y\"/>\n        <UserConfirm ID=\"MARAT\" Decision=\"Y\"/>\n        <UserConfirm ID=\"NERVIWKI\" Decision=\"Y\"/>\n        <UserConfirm ID=\"OLEG\" Decision=\"Y\"/>\n        <UserConfirm ID=\"OSA\" Decision=\"Y\"/>\n        <UserConfirm ID=\"ROSTICK\" Decision=\"Y\"/>\n        <UserConfirm ID=\"SELIV\" Decision=\"Y\"/>\n        <UserConfirm ID=\"SHESTAKOV\" Decision=\"Y\"/>\n        <UserConfirm ID=\"VLAD76\" Decision=\"Y\"/>\n        <UserConfirm ID=\"VLASENKO\" Decision=\"Y\"/>\n        <UserConfirm ID=\"WOWA\" Decision=\"Y\"/>\n        <UserConfirm ID=\"ALEXB\" Decision=\"\"/>\n      </UsersConfirm>\n    </Confirm>\n    <Confirm>\n      <RequestHead ID=\"5230\">\n        <Action>info</Action>\n        <BriefText>\u041F\u043E \u0437\u0430\u044F\u0432\u043A\u0435 bas00024396. \u0420\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u0440\u0430\u0437\u043C\u0435\u0440\u043D\u043E\u0441\u0442\u0438 \u043F\u043E\u043B\u044F N37PORG.</BriefText>\n        <Author>VLAD76</Author>\n        <Created>26.02 09:51:01</Created>\n        <Done>03.03 14:36:30</Done>\n      </RequestHead>\n      <Decision/>\n      <UsersConfirm>\n        <UserConfirm ID=\"ALEXB\" Decision=\"Y\"/>\n        <UserConfirm ID=\"EVGENIY\" Decision=\"Y\"/>\n        <UserConfirm ID=\"GMG\" Decision=\"Y\"/>\n        <UserConfirm ID=\"KHATAEV\" Decision=\"Y\"/>\n        <UserConfirm ID=\"KOT\" Decision=\"Y\"/>\n        <UserConfirm ID=\"LEONID\" Decision=\"Y\"/>\n        <UserConfirm ID=\"MARAT\" Decision=\"Y\"/>\n        <UserConfirm ID=\"NERVIWKI\" Decision=\"Y\"/>\n        <UserConfirm ID=\"OLEG\" Decision=\"Y\"/>\n        <UserConfirm ID=\"OSA\" Decision=\"Y\"/>\n        <UserConfirm ID=\"ROSTICK\" Decision=\"Y\"/>\n        <UserConfirm ID=\"SELIV\" Decision=\"Y\"/>\n        <UserConfirm ID=\"SHESTAKOV\" Decision=\"Y\"/>\n        <UserConfirm ID=\"VLAD76\" Decision=\"Y\"/>\n        <UserConfirm ID=\"VLASENKO\" Decision=\"Y\"/>\n        <UserConfirm ID=\"WOWA\" Decision=\"Y\"/>\n        <UserConfirm ID=\"ALEXB\" Decision=\"\"/>\n      </UsersConfirm>\n    </Confirm>\n    <Confirm>\n      <RequestHead ID=\"5229\">\n        <Action>info</Action>\n        <BriefText>\u041E\u043F\u0442\u0438\u043C\u0438\u0437\u0430\u0446\u0438\u044F \u0432\u044B\u0433\u0440\u0443\u0437\u043A\u0438 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439 \u0432 oa-\u0444\u0430\u0439\u043B\u0435</BriefText>\n        <Author>VLAD76</Author>\n        <Created>03.03 15:10:38</Created>\n        <Done>04.03 11:42:10</Done>\n      </RequestHead>\n      <Decision/>\n      <UsersConfirm>\n        <UserConfirm ID=\"ALEXB\" Decision=\"Y\"/>\n        <UserConfirm ID=\"EVGENIY\" Decision=\"Y\"/>\n        <UserConfirm ID=\"GMG\" Decision=\"Y\"/>\n        <UserConfirm ID=\"KHATAEV\" Decision=\"Y\"/>\n        <UserConfirm ID=\"KOT\" Decision=\"Y\"/>\n        <UserConfirm ID=\"LEONID\" Decision=\"Y\"/>\n        <UserConfirm ID=\"MARAT\" Decision=\"Y\"/>\n        <UserConfirm ID=\"NERVIWKI\" Decision=\"Y\"/>\n        <UserConfirm ID=\"OLEG\" Decision=\"Y\"/>\n        <UserConfirm ID=\"OSA\" Decision=\"Y\"/>\n        <UserConfirm ID=\"ROSTICK\" Decision=\"Y\"/>\n        <UserConfirm ID=\"SELIV\" Decision=\"Y\"/>\n        <UserConfirm ID=\"SHESTAKOV\" Decision=\"Y\"/>\n        <UserConfirm ID=\"VLAD76\" Decision=\"Y\"/>\n        <UserConfirm ID=\"VLASENKO\" Decision=\"Y\"/>\n        <UserConfirm ID=\"WOWA\" Decision=\"Y\"/>\n        <UserConfirm ID=\"ALEXB\" Decision=\"\"/>\n      </UsersConfirm>\n    </Confirm>\n    <Confirm>\n      <RequestHead ID=\"5228\">\n        <Action>info</Action>\n        <BriefText>\u0434\u043E\u0440\u0430\u0431\u043E\u0442\u043A\u0430 \u043C\u0435\u043D\u0435\u0434\u0436\u0435\u0440\u0430 \u043E\u0442\u0447\u0435\u0442\u043E\u0432</BriefText>\n        <Author>SHESTAKOV</Author>\n        <Created>20.02 11:46:51</Created>\n        <Done>03.03 14:36:30</Done>\n      </RequestHead>\n      <Decision/>\n      <UsersConfirm>\n        <UserConfirm ID=\"ALEXB\" Decision=\"Y\"/>\n        <UserConfirm ID=\"EVGENIY\" Decision=\"Y\"/>\n        <UserConfirm ID=\"GMG\" Decision=\"Y\"/>\n        <UserConfirm ID=\"KHATAEV\" Decision=\"Y\"/>\n        <UserConfirm ID=\"KOT\" Decision=\"Y\"/>\n        <UserConfirm ID=\"LEONID\" Decision=\"Y\"/>\n        <UserConfirm ID=\"MARAT\" Decision=\"Y\"/>\n        <UserConfirm ID=\"NERVIWKI\" Decision=\"Y\"/>\n        <UserConfirm ID=\"OLEG\" Decision=\"Y\"/>\n        <UserConfirm ID=\"OSA\" Decision=\"Y\"/>\n        <UserConfirm ID=\"ROSTICK\" Decision=\"Y\"/>\n        <UserConfirm ID=\"SELIV\" Decision=\"Y\"/>\n        <UserConfirm ID=\"SHESTAKOV\" Decision=\"Y\"/>\n        <UserConfirm ID=\"VLAD76\" Decision=\"Y\"/>\n        <UserConfirm ID=\"VLASENKO\" Decision=\"Y\"/>\n        <UserConfirm ID=\"WOWA\" Decision=\"Y\"/>\n        <UserConfirm ID=\"ALEXB\" Decision=\"\"/>\n      </UsersConfirm>\n    </Confirm>\n    <Confirm>\n      <RequestHead ID=\"5157\">\n        <Action>info</Action>\n        <BriefText>\u041D\u0435\u043E\u0431\u0445\u043E\u0434\u0438\u043C\u043E\u0441\u0442\u044C \u043F\u043E\u0438\u0441\u043A\u0430 \u0440\u0430\u043D\u0435\u0435 \u043E\u0442\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u043D\u043E\u0433\u043E \u0444\u0430\u0439\u043B\u0430 \u043F\u043E \u0438\u043C\u0435\u043D\u0438</BriefText>\n        <Author>VLAD76</Author>\n        <Created>03.03 15:11:12</Created>\n        <Done>04.03 11:42:11</Done>\n      </RequestHead>\n      <Decision/>\n      <UsersConfirm>\n        <UserConfirm ID=\"ALEXB\" Decision=\"Y\"/>\n        <UserConfirm ID=\"KHATAEV\" Decision=\"Y\"/>\n        <UserConfirm ID=\"LEONID\" Decision=\"Y\"/>\n        <UserConfirm ID=\"MARAT\" Decision=\"Y\"/>\n        <UserConfirm ID=\"NERVIWKI\" Decision=\"Y\"/>\n        <UserConfirm ID=\"OLEG\" Decision=\"Y\"/>\n        <UserConfirm ID=\"OSA\" Decision=\"Y\"/>\n        <UserConfirm ID=\"ROSTICK\" Decision=\"Y\"/>\n        <UserConfirm ID=\"SELIV\" Decision=\"Y\"/>\n        <UserConfirm ID=\"SHESTAKOV\" Decision=\"Y\"/>\n        <UserConfirm ID=\"VLAD76\" Decision=\"Y\"/>\n        <UserConfirm ID=\"VLASENKO\" Decision=\"Y\"/>\n        <UserConfirm ID=\"WOWA\" Decision=\"Y\"/>\n        <UserConfirm ID=\"ALEXB\" Decision=\"\"/>\n      </UsersConfirm>\n    </Confirm>\n    <Filter>\n      <Status>approved</Status>\n      <DateFrom>20.02.2016</DateFrom>\n      <DateTo>15.02.2017</DateTo>\n    </Filter>\n  </Confirms>\n</UCMsg>"
    },
    {
        key: "\n<UCMsg ID=\"2\">\n  <Schema></Schema>\n  <Context ID=\"555\">\n    <UserName>leonid</UserName>\n    <UserPassword>o</UserPassword>\n    <UserStatus></UserStatus>\n    <IPAddress></IPAddress>\n    <VerMask>\u0412</VerMask>\n    <SubMask>\u0412</SubMask>\n  </Context>\n</UCMsg>",
        val: "\n<UCMsg ID=\"2\">\n  <Status/>\n  <Context ID=\"355\">\n    <UserName>leonid</UserName>\n    <UserPassword>o</UserPassword>\n    <UserStatus></UserStatus>\n    <IPAddress/>\n    <VerMask>\u0412</VerMask>\n    <SubMask>\u0412</SubMask>\n  </Context>\n  <Schema>\n    <ObjectRefs ObjectsType=\"TABLE\">\n      <ObjectRef ID=\"A01\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0440\u043E\u0442\u043E\u043A\u043E\u043B \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u044F \u043F\u0440\u043E\u0446\u0435\u0441\u0441\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"A02\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 ROWID-\u043E\u0432. \u0412 \u043D\u0435\u0435 \u043D\u0430\u043A\u0430\u043F\u043B\u0438\u0432\u0430\u044E\u0442\u0441\u044F ROWID-\u044B \u0441\u0442\u0440\u043E\u043A  \n\u0442\u0430\u0431\u043B\u0438\u0446, \u043F\u043E\u0434\u043B\u0435\u0436\u0430\u0449\u0438\u0445 \u0430\u0440\u0445\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044E\" Ownership=\"1\"/>\n      <ObjectRef ID=\"A03\" ObjectType=\"TABLE\" BriefText=\"\u0412\u0445\u043E\u0434\u044F\u0449\u0438\u0435 \u0442\u0430\u0431\u043B\u0438\u0446\u044B. \u0421 \u043D\u0438\u0445 \u043D\u0430\u0447\u0438\u043D\u0430\u0435\u0442\u0441\u044F \u0440\u0435\u043A\u0443\u0440\u0441\u0438\u0432\u043D\u044B\u0439  \u0430\u043B\u0433\u043E\u0440\u0438\u0442\u043C \u0430\u0440\u0445\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F\" Ownership=\"0\"/>\n      <ObjectRef ID=\"A04\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u044B \u0434\u043B\u044F \u043E\u0447\u0438\u0441\u0442\u043A\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"A05\" ObjectType=\"TABLE\" BriefText=\"\u0421\u0432\u044F\u0437\u0438 \u0442\u0430\u0431\u043B\u0438\u0446\" Ownership=\"0\"/>\n      <ObjectRef ID=\"A06\" ObjectType=\"TABLE\" BriefText=\"\u041A\u0440\u0438\u0442\u0435\u0440\u0438\u0438 \u0430\u0440\u0445\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F\" Ownership=\"0\"/>\n      <ObjectRef ID=\"A07\" ObjectType=\"TABLE\" BriefText=\"\u041C\u0430\u043A\u0440\u043E\u0441\u044B\" Ownership=\"0\"/>\n      <ObjectRef ID=\"A08\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0434\u043B\u044F \u043A\u043E\u043D\u0442\u0440\u043E\u043B\u044F \u043F\u0440\u043E\u0446\u0435\u0441\u0441\u0430 \u0430\u0440\u0445\u0438\u0432\u0430\u0446\u0438\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"A09\" ObjectType=\"TABLE\" BriefText=\"\u0418\u0441\u0442\u043E\u0440\u0438\u044F \u043E\u0447\u0438\u0441\u0442\u043A\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"A12\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0443\u0434\u0430\u043B\u044F\u0435\u043C\u044B\u0445 \u0437\u0430\u043F\u0438\u0441\u0435\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"A13\" ObjectType=\"TABLE\" BriefText=\"\u0418\u0441\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u044F \u0438\u0437 \u0441\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0430\u0446\u0438\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"A14\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0438\u0441\u043E\u043A \u043C\u043E\u0434\u0438\u0444\u0438\u0446\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0445 \u0437\u0430\u043F\u0438\u0441\u0435\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"A15\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0438\u0441\u043A\u0438 \u0442\u0430\u0431\u043B\u0438\u0446 \u0434\u043B\u044F CRM-\u0441\u0438\u0441\u0442\u0435\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"A16\" ObjectType=\"TABLE\" BriefText=\"\u041E\u0431\u044A\u0435\u043A\u0442\u044B \u0430\u0443\u0434\u0438\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"A17\" ObjectType=\"TABLE\" BriefText=\"\u0420\u0430\u0441\u043F\u043E\u043B\u043E\u0436\u0435\u043D\u0438\u0435 \u0430\u0443\u0434\u0438\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"A19\" ObjectType=\"TABLE\" BriefText=\"\u0424\u0430\u043A\u0442\u044B \u0432\u043E\u0437\u043D\u0438\u043A\u043D\u043E\u0432\u0435\u043D\u0438\u044F \u0430\u0443\u0434\u0438\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"A20\" ObjectType=\"TABLE\" BriefText=\"\u041E\u0431\u044A\u0435\u043A\u0442\u044B \u0444\u0430\u043A\u0442\u0430 \u0432\u043E\u0437\u043D\u0438\u043A\u043D\u043E\u0432\u0435\u043D\u0438\u044F \u0430\u0443\u0434\u0438\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B13\" ObjectType=\"TABLE\" BriefText=\"\u0420\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u0442\u0430\u0431\u043B\u0438\u0446\u044B S01 \u0434\u043B\u044F \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0439 \u043F\u043E \u0441\u043C\u0430\u0440\u0442-\u043A\u0430\u0440\u0442\u0430\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B16\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B. \u0441 \u0434\u0430\u0442\u0430\u043C\u0438 \u0438 \u0432\u0440\u0435\u043C\u0435\u043D\u0430\u043C\u0438 \u0438\u043D\u043A\u0430\u0441\u0441\u0430\u0446\u0438\u0439 \u0434\u043B\u044F \u0431\u0430\u043D\u043A\u043E\u043C\u0430\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B19\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0441 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u0430\u043C\u0438 \u0434\u0438\u0437\u0430\u0439\u043D\u043E\u0432 \u043A\u0430\u0440\u0442\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B20\" ObjectType=\"TABLE\" BriefText=\"\u041E\u0433\u0440\u0430\u043D\u0438\u0447\u0435\u043D\u0438\u044F \u043F\u043E \u043E\u0431\u044A\u0435\u043A\u0442\u0430\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B21\" ObjectType=\"TABLE\" BriefText=\"\u0418\u043D\u0434\u0438\u0432\u0438\u0434\u0443\u0430\u043B\u044C\u043D\u044B\u0435 \u043B\u0438\u043C\u0438\u0442\u044B \u0430\u043A\u0442\u0438\u0432\u043D\u043E\u0441\u0442\u0438 \u043F\u043E \u043A\u0430\u0440\u0442\u0430\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B22\" ObjectType=\"TABLE\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B25\" ObjectType=\"TABLE\" BriefText=\"\u042D\u0442\u0430\u043F\u044B \u043A\u043B\u0438p\u0438\u043D\u0433\u043E\u0432\u043E\u0433\u043E \u0446\u0438\u043A\u043B\u0430 \u0444\u0438\u043D\u0430\u043D\u0441\u043E\u0432\u044B\u0445 \u043E\u043F\u0435p\u0430\u0446\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B29\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0438\u043F\u043E\u0432\u044B\u0435 \u043B\u0438\u043C\u0438\u0442\u044B \u0430\u043A\u0442\u0438\u0432\u043D\u043E\u0441\u0442\u0438 \u043F\u043E \u043A\u0430\u0440\u0442\u043E\u0447\u043D\u044B\u043C \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u0438\u043C \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u0430\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B30\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0438\u043F\u043E\u0432\u044B\u0435 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u043A\u0430\u0440\u0442 \u043A\u0430\u0440\u0442\u043E\u0447\u043D\u043E\u0433\u043E \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u043E\u0433\u043E \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B31\" ObjectType=\"TABLE\" BriefText=\"\u041E\u0441\u043D\u043E\u0432\u043D\u044B\u0435 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u043A\u0430\u0440\u0442\u043E\u0447\u043A\u0438 CardDetailes (Issuer, IssuerCenter)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B32\" ObjectType=\"TABLE\" BriefText=\"\u0412\u0437\u0430\u0438\u043C\u043E\u0441\u0432\u044F\u0437\u044C \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u0438\u0445 \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u043E\u0432 \u0438 \u0442\u0438\u043F\u043E\u0432\u044B\u0445 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0439 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u043E\u0432 \u043A\u0430\u0440\u0442\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B33\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0434\u043B\u044F \u043F\u0440\u043E\u0432\u0435\u0434\u0435\u043D\u0438\u044F \u0441\u0432\u0435\u0440\u043A\u0438 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u043E\u0432 \u0438 \u043B\u0438\u043C\u0438\u0442\u043E\u0432 \u043A\u0430\u0440\u0442\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B34\" ObjectType=\"TABLE\" BriefText=\"\u041E\u0441\u0442\u0430\u0442\u043A\u0438 \u043F\u043E \u043A\u0430\u0440\u0442\u0430\u043C, \u0432\u044B\u0433\u0440\u0443\u0436\u0435\u043D\u043D\u044B\u0435 \u0432 \u0444\u0430\u0439\u043B\u0430\u0445\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B35\" ObjectType=\"TABLE\" BriefText=\"\u041D\u043E\u043C\u0435\u0440\u0430 \u043A\u0430\u0440\u0442, \u0441\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0445 \u0432 \u0441\u0438\u0441\u0442\u0435\u043C\u0435\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B37\" ObjectType=\"TABLE\" BriefText=\"\u041E\u0441\u043D\u043E\u0432\u043D\u044B\u0435 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u0434\u0435\u0431\u0435\u0442\u043D\u043E\u0433\u043E \u043F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u044F \u0441\u043C\u0430\u0440\u0442 - \u043A\u0430\u0440\u0442\u044B\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B39\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0441 \u043A\u0430\u0440\u0442\u0430\u043C\u0438 (\u043C\u0430\u0441\u043A\u0430\u043C\u0438 \u043A\u0430\u0440\u0442) \u0434\u043B\u044F \u0441\u0442\u043E\u043F - \u043B\u0438\u0441\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B40\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 K\u0443\u0440\u0441\u043E\u0432\u044B\u0445 \u0441\u0442\u0430\u0432\u043E\u043A \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0435\u043C\u044B\u0445 \u0432\u0430\u043B\u044E\u0442\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B47\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0448\u0430\u0431\u043B\u043E\u043D\u043E\u0432 \u0438 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D\u043E\u0432 \u043D\u043E\u043C\u0435\u0440\u043E\u0432 \u043A\u0430\u0440\u0442 \u043F\u043E \u043E\u0440\u0433\u0430\u043D\u0438\u0437\u0430\u0446\u0438\u044F\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B54\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u044B\u0435 \u0434\u0430\u043D\u043D\u044B\u0435 \u043F\u043E \u0422\u0435\u0440\u043C\u0438\u043D\u0430\u043B\u0430\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B55\" ObjectType=\"TABLE\" BriefText=\"\u041E\u0441\u043D\u043E\u0432\u043D\u044B\u0435 \u0434\u0430\u043D\u043D\u044B\u0435 \u043F\u043E \u0444\u0438\u0440\u043C\u0430\u043C \u0438 \u0444\u0438\u043B\u0438\u0430\u043B\u0430\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B56\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0435\u0446\u0438\u0430\u043B\u044C\u043D\u044B\u0435 \u043B\u0438\u043C\u0438\u0442\u044B \u0431\u0435\u0437\u0430\u0432\u0442\u043E\u0440\u0438\u0437\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0445 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0439 \u0444\u0438\u0440\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B60\" ObjectType=\"TABLE\" BriefText=\"\u041B\u0438\u043C\u0438\u0442\u044B \u0430\u043A\u0442\u0438\u0432\u043D\u043E\u0441\u0442\u0438 \u043F\u043E \u043E\u0440\u0433\u0430\u043D\u0438\u0437\u0430\u0446\u0438\u044F\u043C (\u043F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u044F\u043C)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B61\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u043E\u0432 \u043F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u0439 (\u0433\u0440\u0443\u043F\u043F \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u043E\u0432) \u0432 \u0440\u0430\u043C\u043A\u0430\u0445 \u043A\u043B\u0438\u0435\u043D\u0442\u0441\u043A\u0438\u0445 \u043E\u0440\u0433\u0430\u043D\u0438\u0437\u0430\u0446\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B62\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0434\u0438\u0430\u043F\u043E\u0437\u043E\u043D\u043E\u0432 \u043D\u043E\u043C\u0435\u0440\u043E\u0432 \u043A\u0430\u0440\u0442, \u0440\u0430\u0437\u0440\u0435\u0448\u0435\u043D\u043D\u044B\u0445 \u0434\u043B\u044F \u044D\u043C\u0438\u0441\u0441\u0438\u0438 \u042D\u043C\u0438\u0442\u0435\u043D\u0442\u043E\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B63\" ObjectType=\"TABLE\" BriefText=\"\u041F\u043B\u0430\u0442\u0435\u0436\u043D\u044B\u0435 \u0441\u0438\u0441\u0442\u0435\u043C\u044B \u0434\u043B\u044F \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D\u0430 \u043D\u043E\u043C\u0435\u0440\u043E\u0432 \u043A\u0430\u0440\u0442\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B67\" ObjectType=\"TABLE\" BriefText=\"\u0412\u0430\u043B\u044E\u0442\u044B \u043E\u0431\u0441\u043B\u0443\u0436\u0438\u0432\u0430\u0435\u043C\u044B\u0435 \u0442\u0435\u0440\u043C\u0438\u043D\u0430\u043B\u0430\u043C\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B69\" ObjectType=\"TABLE\" BriefText=\"ReasonCodes\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B71\" ObjectType=\"TABLE\" BriefText=\"\u042D\u043A\u0441\u043F\u043E\u043D\u0435\u043D\u0442\u044B \u0432\u0430\u043B\u044E\u0442 \u0432 \u043A\u043E\u0442\u043E\u0440\u044B\u0445 \u0442\u0435\u0440\u043C\u0438\u043D\u0430\u043B\u044B \u0443\u043A\u0430\u0437\u044B\u0432\u0430\u044E\u0442 \u0441\u0443\u043C\u043C\u0443 \u0442\u0440\u0430\u043D\u0437\u0430\u043A\u0446\u0438\u0438.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B72\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u044B\u0435 \u0434\u0430\u043D\u043D\u044B\u0435 \u043F\u043E \u0442\u0438\u043F\u0430\u043C \u0442\u0435\u0440\u043C\u0438\u043D\u0430\u043B\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B73\" ObjectType=\"TABLE\" BriefText=\"K\u0430\u0440\u0442\u043E\u0447\u043D\u044B\u0435 \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B, \u043E\u0431\u0441\u043B\u0443\u0436\u0438\u0432\u0430\u0435\u043C\u044B\u0435 \u0443\u0447\u0430\u0441\u0442\u043D\u0438\u043A\u043E\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B74\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0438\u0441\u043E\u043A \u043A\u043E\u0434\u043E\u0432 \u0432\u0430\u043B\u044E\u0442\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B77\" ObjectType=\"TABLE\" BriefText=\"K\u043E\u0434\u044B \u0441\u0442\u0430\u0442\u0443\u0441\u043E\u0432 \u043A\u0430\u0440\u0442\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B78\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0438\u0441\u043E\u043A \u043A\u043E\u0434\u043E\u0432 \u0441\u0442\u0440\u0430\u043D\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B79\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 Processing Codes\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B80\" ObjectType=\"TABLE\" BriefText=\"(\u041D\u0415 \u0418\u0421\u041F\u041E\u041B\u042C\u0417\u0423\u0415\u0422\u0421\u042F) \u041A\u043E\u0434\u044B \u043A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u0439 \u0444\u0438\u0440\u043C (\u043A\u043E\u0434\u0438\u0440\u043E\u0432\u043A\u0430 \u042E\u043D\u0438\u043E\u043D \u041A\u0430\u0440\u0434)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B81\" ObjectType=\"TABLE\" BriefText=\"(\u041D\u0415 \u0418\u0421\u041F\u041E\u041B\u042C\u0417\u0423\u0415\u0422\u0421\u042F) \u041A\u043E\u0434\u044B \u043A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u0439 \u0444\u0438\u0440\u043C (\u043A\u043E\u0434\u0438\u0440\u043E\u0432\u043A\u0430 ISO 8583)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B82\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u0435\u0440\u0435\u043F\u043E\u0434\u0447\u0438\u043D\u0435\u043D\u043D\u044B\u0445 \u043E\u0431\u044A\u0435\u043A\u0442\u043E\u0432 \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u0430 \u041A\u041B\u0410\u0414\u0420\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B83\" ObjectType=\"TABLE\" BriefText=\"\u041E\u043F\u0438\u0441\u0430\u043D\u0438\u0435 \u043D\u0430\u0431\u043E\u0440\u043E\u0432 \u043E\u0446\u0435\u043D\u043E\u043A \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432 \u0441\u043A\u043E\u0440\u0438\u043D\u0433\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B84\" ObjectType=\"TABLE\" BriefText=\"\u041A\u0440\u0438\u0442\u0435\u0440\u0438\u0438, \u0444\u043E\u0440\u043C\u0443\u043B\u044B, \u0441\u0432\u044F\u0437\u044C \u0441 \u0442\u0430\u0431\u043B\u0438\u0446\u0435\u0439 B87 (\u0434\u043E\u043F. \u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B85\" ObjectType=\"TABLE\" BriefText=\"\u0425\u0430\u0440\u0430\u043A\u0442\u0435\u0440\u0438\u0441\u0442\u0438\u043A\u0438 \u0438 \u0438\u0445 \u043E\u0446\u0435\u043D\u043A\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B86\" ObjectType=\"TABLE\" BriefText=\"\u041E\u0447\u0435\u0440\u0435\u0434\u043D\u043E\u0441\u0442\u044C \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432 \u0432 \u043E\u0442\u0447\u0435\u0442\u043D\u043E\u0439 \u0444\u043E\u0440\u043C\u0435\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B87\" ObjectType=\"TABLE\" BriefText=\"\u041A\u0430\u0442\u0435\u0433\u043Ep\u0438\u0438 \u0434\u043E\u043F\u043E\u043B\u043D\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0439 \u0438\u043D\u0444\u043Ep\u043C\u0430\u0446\u0438\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B88\" ObjectType=\"TABLE\" BriefText=\"\u0414\u043E\u043F\u043E\u043B\u043D\u0438\u0442\u0435\u043B\u044C\u043D\u0430\u044F \u0438\u043D\u0444\u043Ep\u043C\u0430\u0446\u0438\u044F\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B89\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 BIN&apos;\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B90\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0435\u043A\u0441\u0442\u043E\u0432\u044B\u0435 \u043A\u043E\u043C\u043C\u0435\u043D\u0442\u0430\u0440\u0438\u0438 \u043A\u043E\u0434\u043E\u0432 \u043E\u0442\u0432\u0435\u0442\u043E\u0432 \u043F\u0440\u0438 \u0430\u0432\u0442\u043E\u0440\u0438\u0437\u0430\u0446\u0438\u0438 (\u0440\u0430\u0441\u0448\u0438\u0444\u0440\u043E\u0432\u043A\u0430 \u043A\u043E\u0434\u043E\u0432 \u043E\u0448\u0438\u0431\u043E\u043A)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B91\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u0440\u0438\u0432\u044F\u0437\u043A\u0438 \u043A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u0439 \u0434\u043E\u043F. \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u0438 \u043A \u043E\u0441\u043E\u0431\u0435\u043D\u043D\u043E\u0441\u0442\u044F\u043C \u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u0443\u0435\u043C\u044B\u0445 \u043E\u0431\u044A\u0435\u043A\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B94\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0438\u0441\u043A\u0438 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0439 \u0434\u043E\u043F\u043E\u043B\u043D\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0439 \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B95\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0440\u0430\u0441\u0448\u0438\u0444\u0440\u043E\u0432\u043E\u043A \u0441\u043E\u043A\u0440\u0430\u0449\u0435\u043D\u0438\u0439 \u043D\u0430\u0438\u043C\u0435\u043D\u043E\u0432\u0430\u043D\u0438\u0439 \u043E\u0431\u044A\u0435\u043A\u0442\u043E\u0432 \u043F\u043E \u041A\u041B\u0410\u0414\u0420\" Ownership=\"0\"/>\n      <ObjectRef ID=\"B98\" ObjectType=\"TABLE\" BriefText=\"\u0421\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0430\u0446\u0438\u044F Online \u0438 BackOffice\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C01\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0438\u043F\u043E\u0432\u0430\u044F \u0441\u0432\u044F\u0437\u044C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C02\" ObjectType=\"TABLE\" BriefText=\"\u0423\u0447\u0430\u0441\u0442\u043D\u0438\u043A\u0438 \u0442\u0438\u043F\u043E\u0432\u043E\u0439 \u0441\u0432\u044F\u0437\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C03\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0438\u043F\u043E\u0432\u043E\u0439 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442 \u0441\u043E\u043F\u0440\u043E\u0432\u043E\u0436\u0434\u0430\u044E\u0449\u0438\u0439 \u0434\u043E\u0433\u043E\u0432\u043E\u0440.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C04\" ObjectType=\"TABLE\" BriefText=\"\u0412\u043E\u0437\u043C\u043E\u0436\u043D\u044B\u0435 \u0442\u0438\u043F\u044B \u0432\u043B\u0430\u0434\u0435\u043B\u044C\u0446\u0435\u0432 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C05\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0438\u043F\u043E\u0432\u043E\u0435 \u043E\u0433\u0440\u0430\u043D\u0438\u0447\u0435\u043D\u0438\u0435\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C06\" ObjectType=\"TABLE\" BriefText=\"\u0412\u043E\u0437\u043C\u043E\u0436\u043D\u044B\u0435 \u0441\u0442\u0430\u0442\u0443\u0441\u044B \u0432\u043B\u0430\u0434\u0435\u043B\u044C\u0446\u0435\u0432 \u043E\u0433\u0440\u0430\u043D\u0438\u0447\u0435\u043D\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C07\" ObjectType=\"TABLE\" BriefText=\"\u0420\u043E\u043B\u044C \u0432 \u0442\u0438\u043F\u043E\u0432\u044B\u0445 \u0441\u0432\u044F\u0437\u044F\u0445\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C08\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0438\u0441\u043E\u043A \u0440\u0430\u0437\u0440\u0435\u0448\u0435\u043D\u043D\u044B\u0445/\u0437\u0430\u043F\u0440\u0435\u0449\u0435\u043D\u043D\u044B\u0445 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0439 \u043F\u043E \u043E\u0431\u044A\u0435\u043A\u0442\u0443\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C09\" ObjectType=\"TABLE\" BriefText=\"\u0414\u0435\u0439\u0441\u0442\u0432\u0438\u0439 \u043F\u043E \u0443\u0441\u0442\u0430\u043D\u043E\u0432\u043A\u0435 \u0440\u0430\u0437\u0440\u0435\u0448\u0435\u043D\u043D\u0438\u0439 \u043D\u0430 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438 \u043E\u0431\u044A\u0435\u043A\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C14\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B. \u0444\u0430\u043A\u0442\u0438\u0447. \u043F\u0430\u0440\u0430\u043C. \u043F\u0430\u043A\u0435\u0442\u043E\u0432 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439 (\u0441\u043B\u0438\u043F\u044B, \u0437\u0430\u043F\u0438\u0441\u0438 \u044D\u043B.\u0436\u0443\u0440\u043D.)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C15\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0438\u0441\u043E\u043A \u0442\u0438\u043F\u043E\u0432 \u0440\u0430\u0441\u043F\u0438\u0441\u0430\u043D\u0438\u0439/\u0448\u0430\u0431\u043B\u043E\u043D\u043E\u0432 \u0440\u0430\u0441\u043F\u0438\u0441\u0430\u043D\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C16\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0440\u0438\u0432\u044F\u0437\u043A\u0430 \u0442\u0438\u043F\u043E\u0432 \u0440\u0430\u0441\u043F\u0438\u0441\u0430\u043D\u0438\u0439 \u043A \u0442\u0438\u043F\u0430\u043C \u043E\u0431\u044A\u0435\u043A\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C17\" ObjectType=\"TABLE\" BriefText=\"\u0420\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u044F \u0437\u0430\u043F\u0438\u0441\u0435\u0439 \u0440\u0430\u0441\u043F\u0438\u0441\u0430\u043D\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C18\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0440\u0438\u0432\u044F\u0437\u043A\u0430 \u0440\u0430\u0441\u043F\u0438\u0441\u0430\u043D\u0438\u044F \u043A \u043E\u0431\u044A\u0435\u043A\u0442\u0443\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C23\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0440\u0438\u0432\u044F\u0437\u043A\u0430 STGI \u043A \u044E\u0440\u0438\u0434\u0438\u0447\u0435\u0441\u043A\u0438\u043C \u043B\u0438\u0446\u0430\u043C \u043F\u0440\u043E\u0432\u043E\u0434\u044F\u0449\u0438\u0445 \u0440\u0430\u0441\u0447\u0435\u0442\u044B \u0443\u0447\u0430\u0441\u0442\u043D\u0438\u043A\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C24\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D\u043E\u0432 \u043D\u043E\u043C\u0435\u0440\u043E\u0432 \u043A\u0430\u0440\u0442 \u043F\u043E \u0441\u043F\u043E\u043D\u0441\u0438\u0440\u0443\u0435\u043C\u044B\u043C \u044D\u043C\u0438\u0442\u0435\u043D\u0442\u0430\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C25\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u043F\u0430\u0440\u0442\u0438\u0439 \u043A\u0430\u0440\u0442 \u0434\u0435\u0431\u0435\u0442\u043D\u043E\u0433\u043E-\u0441\u043C\u0430\u0440\u0442 \u043F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u044F\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C30\" ObjectType=\"TABLE\" BriefText=\"\u0421\u0435\u0439\u0444\u043E\u0432\u044B\u0435 \u044F\u0447\u0435\u0439\u043A\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C31\" ObjectType=\"TABLE\" BriefText=\"\u041A\u043B\u044E\u0447\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C32\" ObjectType=\"TABLE\" BriefText=\"\u0420\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u044F \u043F\u043E\u0441\u0435\u0449\u0435\u043D\u0438\u0439 \u044F\u0447\u0435\u0435\u043A\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C33\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043B\u0438\u0442\u043A\u0438 \u0434\u0440\u0430\u0433\u043E\u0446\u0435\u043D\u043D\u044B\u0445 \u043C\u0435\u0442\u0430\u043B\u043B\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C39\" ObjectType=\"TABLE\" BriefText=\"\u0413\u0440\u0443\u043F\u043F\u044B \u043A\u043E\u043C\u0438\u0441\u0441\u0438\u043E\u043D\u043D\u044B\u0445 \u0441\u0442\u0430\u0432\u043E\u043A \u0434\u043B\u044F \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0445 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C40\" ObjectType=\"TABLE\" BriefText=\"\u041E\u043F\u0438\u0441\u0430\u043D\u0438\u044F \u0434\u0435\u0440\u0435\u0432\u044C\u0435\u0432 \u0433\u0440\u0443\u043F\u043F \u043A\u043E\u043C\u0438\u0441\u0441\u0438\u043E\u043D\u043D\u044B\u0445 \u0441\u0442\u0430\u0432\u043E\u043A\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C41\" ObjectType=\"TABLE\" BriefText=\"\u041F\u043E\u0440\u043E\u0433\u0438 \u0434\u043B\u044F \u0433\u0440\u0443\u043F\u043F \u043A\u043E\u043C\u0438\u0441\u0441\u0438\u043E\u043D\u043D\u044B\u0445 \u0441\u0442\u0430\u0432\u043E\u043A\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C42\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0440\u0438\u0432\u044F\u0437\u043A\u0430 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0445 \u0442\u0430\u0440\u0438\u0444\u043E\u0432 \u043A \u043E\u0431\u044A\u0435\u043A\u0442\u0430\u043C \u0441\u0438\u0441\u0442\u0435\u043C\u044B\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C43\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u0438 \u0434\u0435\u0440\u0435\u0432\u0430 \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C44\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0440\u0438\u0432\u044F\u0437\u043A\u0430 \u0434\u0435\u0440\u0435\u0432\u0430 \u043A \u044E\u0440. \u043B\u0438\u0446\u0430\u043C, \u0443\u0447\u0430\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u043C \u0432 \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u0430\u0445\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C45\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u0438 \u0434\u0435\u0440\u0435\u0432\u0430 \u0432\u044B\u0431\u043E\u0440\u0430 \u043F\u043E\u0440\u0442\u0444\u0435\u043B\u044F\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C46\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u0440\u0438\u0432\u044F\u0437\u043A\u0438 \u0434\u0435\u0440\u0435\u0432\u044C\u0435\u0432 \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432 \u043F\u0440\u0438\u0432\u044F\u0437\u043A\u0438 \u0430\u043D\u0430\u043B\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u0441\u0447\u0435\u0442\u043E\u0432 \u043A \u0441\u0447\u0435\u0442\u0430\u043C \u0441\u0432\u043E\u0434\u043D\u043E\u0433\u043E \u0443\u0447\u0435\u0442\u0430 \u043A \u0440\u0430\u0441\u0447\u0435\u0442\u043D\u043E\u043C\u0443 \u0430\u0433\u0435\u043D\u0442\u0443, \u0442\u0438\u043F\u0443 \u043E\u0431\u044A\u0435\u043A\u0442\u0430 \u0438 \u0432\u0430\u043B\u044E\u0442\u044B\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C47\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0434\u0435\u0440\u0435\u0432\u044C\u0435\u0432 \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432 \u043F\u0440\u0438\u0432\u044F\u0437\u043A\u0438 \u0430\u043D\u0430\u043B\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u0441\u0447\u0435\u0442\u043E\u0432 \u043A \u0441\u0447\u0435\u0442\u0430\u043C \u0441\u0432\u043E\u0434\u043D\u043E\u0433\u043E \u0443\u0447\u0435\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C48\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u0440\u0438\u0432\u044F\u0437\u043A\u0438 \u0434\u0435\u0440\u0435\u0432\u044C\u0435\u0432 \u0434\u043B\u044F \u0430\u0432\u0442\u043E\u043C\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u043E\u0433\u043E \u0437\u0430\u043F\u0443\u0441\u043A\u0430 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0439 \u043F\u043E \u043A\u0440\u0435\u0434\u0438\u0442\u043D\u043E\u0439 \u0437\u0430\u044F\u0432\u043A\u0435 \u043A \u0431\u0430\u043D\u043A\u0443 \u0440\u0430\u0441\u0447\u0435\u0442\u043D\u043E\u043C\u0443 \u0430\u0433\u0435\u043D\u0442\u0443\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C49\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0434\u0435\u0440\u0435\u0432\u044C\u0435\u0432 \u0430\u0432\u0442\u043E\u043C\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u043E\u0433\u043E \u0437\u0430\u043F\u0443\u0441\u043A\u0430 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0439 \u043F\u043E \u043A\u0440\u0435\u0434\u0438\u0442\u043D\u043E\u0439 \u0437\u0430\u044F\u0432\u043A\u0435\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C50\" ObjectType=\"TABLE\" BriefText=\"\u0421\u0445\u0435\u043C\u044B \u0440\u0430\u0441\u0447\u0451\u0442\u0430 \u043C\u0438\u043D\u0438\u043C\u0430\u043B\u044C\u043D\u043E\u0433\u043E \u043E\u0431\u044F\u0437\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0433\u043E \u043F\u043B\u0430\u0442\u0435\u0436\u0430 (\u041C\u041E\u041F) \u0434\u043B\u044F \u043A\u0440\u0435\u0434\u0438\u0442\u043D\u044B\u0445 \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u0438\u0445 \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u043E\u0432 \u0438 \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u043E\u0432.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C51\" ObjectType=\"TABLE\" BriefText=\"\u0423\u0441\u043B\u043E\u0432\u0438\u044F \u0441\u0445\u0435\u043C\u044B \u0440\u0430\u0441\u0447\u0451\u0442\u0430 \u0441\u0443\u043C\u043C\u044B \u043C\u0438\u043D\u0438\u043C\u0430\u043B\u044C\u043D\u043E\u0433\u043E \u043E\u0431\u044F\u0437\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0433\u043E \u043F\u043B\u0430\u0442\u0435\u0436\u0430 (\u041C\u041E\u041F).\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C52\" ObjectType=\"TABLE\" BriefText=\"\u0423\u0441\u043B\u043E\u0432\u0438\u044F \u0441\u0445\u0435\u043C\u044B \u0440\u0430\u0441\u0447\u0451\u0442\u0430 \u0434\u0430\u0442 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u044F \u0440\u0435\u0433\u043B\u0430\u043C\u0435\u043D\u0442\u043D\u044B\u0445 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0439.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C53\" ObjectType=\"TABLE\" BriefText=\"\u0420\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u0441\u0445\u0435\u043C\u044B \u0440\u0430\u0441\u0447\u0451\u0442\u0430 \u0434\u0430\u0442 \u0440\u0435\u0433\u043B\u0430\u043C\u0435\u043D\u0442\u043D\u044B\u0445 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0439 \u0434\u043B\u044F \u0437\u0430\u0434\u0430\u043D\u0438\u044F \u0434\u0430\u0442\u044B \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u044F \u043F\u043E\u0441\u043B\u0435\u0434\u0443\u044E\u0449\u0435\u0433\u043E \u0441\u0432\u044F\u0437\u0430\u043D\u043D\u043E\u0433\u043E \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C54\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0440\u0430\u0432\u0438\u043B\u0430 \u043E\u043F\u0440\u0435\u0434\u0435\u043B\u0435\u043D\u0438\u044F \u0441\u043E\u0431\u044B\u0442\u0438\u0439 \u0441\u0438\u0441\u0442\u0435\u043C\u044B\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C60\" ObjectType=\"TABLE\" BriefText=\"\u0418\u043C\u0435\u043D\u043E\u0432\u0430\u043D\u043D\u044B\u0435 \u0441\u043F\u0438\u0441\u043A\u0438 \u043E\u0431\u044A\u0435\u043A\u0442\u043E\u0432 \u0441 \u0434\u0435\u0440\u0435\u0432\u044C\u044F\u043C\u0438 \u0432\u044B\u0431\u043E\u0440\u0430 \u043E\u0431\u044A\u0435\u043A\u0442\u0430 \u043F\u043E \u0443\u043C\u043E\u043B\u0447\u0430\u043D\u0438\u044E.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C61\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u0434\u0435\u0440\u0435\u0432\u044C\u0435\u0432 \u0432\u044B\u0431\u043E\u0440\u0430 \u0438\u0437 \u0441\u043F\u0438\u0441\u043A\u0430 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u043F\u043E \u0443\u043C\u043E\u043B\u0447\u0430\u043D\u0438\u044E.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C62\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043E\u0441\u0442\u0430\u0432 \u0438\u043C\u0435\u043D\u043E\u0432\u0430\u043D\u043D\u043E\u0433\u043E \u0441\u043F\u0438\u0441\u043A\u0430.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C63\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043E\u0441\u0442\u0430\u0432 \u043A\u043E\u043D\u0435\u0447\u043D\u043E\u0433\u043E \u043B\u0438\u0441\u0442\u0430 \u0434\u0435\u0440\u0435\u0432\u0430 \u0438\u043C\u0435\u043D\u043E\u0432\u0430\u043D\u043D\u043E\u0433\u043E \u0441\u043F\u0438\u0441\u043A\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C66\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0430\u0440\u043D\u044B\u0435 \u0441\u0447\u0435\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C70\" ObjectType=\"TABLE\" BriefText=\"\u041A\u043E\u0434\u044B \u043A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u0439 \u0444\u0438\u0440\u043C (\u043A\u043E\u0434\u0438\u0440\u043E\u0432\u043A\u0430 ISO 8583)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C71\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u0433\u0440\u0443\u043F\u043F \u043B\u0438\u043C\u0438\u0442\u043E\u0432 \u0431\u0435\u0437\u0430\u0432\u0442\u043E\u0440\u0438\u0437\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0445 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C72\" ObjectType=\"TABLE\" BriefText=\"\u0412\u0435\u0434\u0435\u043D\u0438\u0435 \u0441\u0447\u0435\u0442\u0447\u0438\u043A\u043E\u0432 \u043F\u043E \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u043C \u0434\u043D\u044F\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C73\" ObjectType=\"TABLE\" BriefText=\"\u0412\u0435\u0434\u0435\u043D\u0438\u0435 \u0441\u0447\u0435\u0442\u0447\u0438\u043A\u043E\u0432 \u043F\u043E \u043E\u0431\u044A\u0435\u043A\u0442\u0430\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C81\" ObjectType=\"TABLE\" BriefText=\"\u041E\u0441\u0442\u0430\u0442\u043A\u0438 \u043D\u0430 \u0441\u0447\u0435\u0442\u0430\u0445 \u0431\u0430\u043D\u043A\u043E\u0432-\u0443\u0447\u0430\u0441\u0442\u043D\u0438\u043A\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C84\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0441\u0432\u044F\u0437\u0438 \u0443\u0447\u0430\u0441\u0442\u043D\u0438\u043A\u043E\u0432(\u044D\u043C\u0438\u0442\u0435\u043D\u0442\u043E\u0432, \u044D\u043A\u0432\u0430\u0439\u0435\u0440\u043E\u0432) \u0441 \u0440\u0435\u0433\u0438\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u043C\u0438 \u0420\u0410\u0426\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C85\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043C\u0430\u0440\u0448\u0440\u0443\u0442\u0438\u0437\u0430\u0446\u0438\u0438 \u043A\u043B\u0438\u0440\u0438\u043D\u0433\u043E\u0432\u044B\u0445 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439, \u0432\u0445\u043E\u0434\u044F\u0449\u0438\u0445 \u0432 \u0441\u043E\u0441\u0442\u0430\u0432 \u0438\u0441\u0445\u043E\u0434\u044F\u0449\u0438\u0445 \u0444\u0430\u0439\u043B\u043E\u0432 (oc)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C89\" ObjectType=\"TABLE\" BriefText=\"\u0428\u0430\u0431\u043B\u043E\u043D\u044B \u043F\u0440\u0438\u0437\u043D\u0430\u043A\u043E\u0432 \u0434\u043B\u044F \u0443\u0447\u0435\u0442\u043D\u044B\u0445 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"C90\" ObjectType=\"TABLE\" BriefText=\"\u0421\u0442\u0430\u043D\u0434\u0430\u0440\u0442\u043D\u044B\u0435 \u043A\u043E\u0434\u044B \u043F\u0440\u0438\u0437\u043D\u0430\u043A\u043E\u0432 \u043F\u043E\u0434\u043E\u0437\u0440\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0445 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"D00\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0435\u0445\u043D\u043E\u043B\u043E\u0433\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u0442\u0430\u0431\u043B\u0438\u0446\u0430 \u0434\u043B\u044F \u0445\u0440\u0430\u043D\u0435\u043D\u0438\u044F \u0431\u043B\u043E\u043A\u0430 \u0441 \u043B\u0438\u0446\u0435\u043D\u0437\u0438\u043E\u043D\u043D\u043E\u0439 \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u0435\u0439 \u0438 \u0434\u043B\u044F \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u0438\u044F \u0442\u0435\u043A\u0443\u0449\u0438\u0445 \u0434\u0430\u0442\u044B \u0438 \u0432\u0440\u0435\u043C\u0435\u043D\u0438 \u0441 \u0441\u0435\u0440\u0432\u0435\u0440\u0430 \u0411\u0414\" Ownership=\"0\"/>\n      <ObjectRef ID=\"D01\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0438\u0441\u043E\u043A \u043B\u0438\u0446\u0435\u043D\u0437\u0438\u0439 \u043F\u043E \u0443\u0447\u0430\u0441\u0442\u043D\u0438\u043A\u0430\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"D03\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u0438 \u0434\u043B\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0445 \u043F\u0440\u043E\u0446\u0435\u0434\u0443\u0440\" Ownership=\"0\"/>\n      <ObjectRef ID=\"D04\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043A\u043B\u0438\u0435\u043D\u0442\u043E\u0432 \u0441\u0435\u0440\u0432\u0435\u0440\u0430 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"D05\" ObjectType=\"TABLE\" BriefText=\"SQL-\u0437\u0430\u043F\u0440\u043E\u0441\u044B \u0430\u043F\u0433\u0440\u0435\u0439\u0434\u0430 \u0431\u0430\u0437\u044B\" Ownership=\"0\"/>\n      <ObjectRef ID=\"D06\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0434\u043E\u043F\u043E\u043B\u043D\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0445 \u043E\u0431\u044A\u0435\u043A\u0442\u043E\u0432 \u0441\u0445\u0435\u043C\u044B\" Ownership=\"0\"/>\n      <ObjectRef ID=\"D08\" ObjectType=\"TABLE\" BriefText=\"CacheRegistrationTable\" Ownership=\"0\"/>\n      <ObjectRef ID=\"D48\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u0442\u0435\u0440\u043C\u0438\u043D\u0430\u043B\u0430, \u0441\u0432\u044F\u0437\u0430\u043D\u043D\u044B\u0435 \u0441 \u043E\u0431\u0441\u043B\u0443\u0436\u0438\u0432\u0430\u043D\u0438\u0435\u043C \u0434\u0435\u0431\u0435\u0442\u043D\u043E\u0433\u043E \u043F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u044F \u0441\u043C\u0430\u0440\u0442 - \u043A\u0430\u0440\u0442.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"E01\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B. \u043A\u0443\u0440\u0441\u043E\u0432 \u0432\u0430\u043B\u044E\u0442 Europay\" Ownership=\"0\"/>\n      <ObjectRef ID=\"E02\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B. \u043F\u0440\u0438\u0435\u043C\u0430 Detail Position Europay\" Ownership=\"0\"/>\n      <ObjectRef ID=\"E06\" ObjectType=\"TABLE\" BriefText=\"Passenger Transpor\" Ownership=\"0\"/>\n      <ObjectRef ID=\"E07\" ObjectType=\"TABLE\" BriefText=\"Vehicle Rental\" Ownership=\"0\"/>\n      <ObjectRef ID=\"E08\" ObjectType=\"TABLE\" BriefText=\"LODGING\" Ownership=\"0\"/>\n      <ObjectRef ID=\"E98\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0434\u043B\u044F \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0438\u044F \u043A\u0432\u0430\u0440\u0442\u0430\u043B\u044C\u043D\u044B\u0445 \u043E\u0442\u0447\u0435\u0442\u043E\u0432 \u0434\u043B\u044F EPI\" Ownership=\"0\"/>\n      <ObjectRef ID=\"E99\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 BIN-\u043D\u043E\u0432 \u0434\u043B\u044F EUPOPAY\" Ownership=\"0\"/>\n      <ObjectRef ID=\"F01\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0438 \u043C\u043E\u0448\u0435\u043D\u043D\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u0442\u0440\u0430\u043D\u0437\u0430\u043A\u0446\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"F02\" ObjectType=\"TABLE\" BriefText=\"ReportFormGroup\" Ownership=\"0\"/>\n      <ObjectRef ID=\"F03\" ObjectType=\"TABLE\" BriefText=\"ReportForm\" Ownership=\"0\"/>\n      <ObjectRef ID=\"F04\" ObjectType=\"TABLE\" BriefText=\"ReportFormContent\" Ownership=\"0\"/>\n      <ObjectRef ID=\"F11\" ObjectType=\"TABLE\" BriefText=\"\u041C\u0435\u0442\u0440\u0438\u043A\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"F12\" ObjectType=\"TABLE\" BriefText=\"\u041F\u043B\u0430\u043D \u0441\u0447\u0435\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"F13\" ObjectType=\"TABLE\" BriefText=\"\u0421\u0447\u0435\u0442\u0430 \u0438 \u0441\u0442\u0440\u0443\u043A\u0442\u0443\u0440\u0430 \u043F\u043B\u0430\u043D\u0430 \u0441\u0447\u0435\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"F14\" ObjectType=\"TABLE\" BriefText=\"\u0421\u0440\u043E\u043A\u0438 \u043E\u0442\u043A\u0440\u044B\u0442\u0438\u044F \u0441\u0447\u0435\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"F16\" ObjectType=\"TABLE\" BriefText=\"\u0413\u0440\u0443\u043F\u043F\u0430 \u0440\u0430\u0437\u0440\u0435\u0448\u0451\u043D\u043D\u044B\u0445 \u043A\u043E\u0440\u0440\u0435\u0441\u043F\u043E\u043D\u0434\u0435\u043D\u0446\u0438\u0439 \u0441\u0447\u0435\u0442\u043E\u0432 \u0432 \u0443\u0447\u0451\u0442\u043D\u044B\u0445 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430\u0445.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"F17\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043E\u0441\u0442\u0430\u0432 \u0433\u0440\u0443\u043F\u043F \u0440\u0430\u0437\u0440\u0435\u0448\u0451\u043D\u043D\u044B\u0445 \u043A\u043E\u0440\u0440\u0435\u0441\u043F\u043E\u043D\u0434\u0435\u043D\u0446\u0438\u0439 \u0441\u0447\u0435\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"F20\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0435\u0440\u0435\u0447\u0435\u043D\u044C \u0442\u0438\u043F\u043E\u0432 \u0435\u0434\u0438\u043D\u0438\u0446 \u0438\u0437\u043C\u0435\u0440\u0435\u043D\u0438\u044F \u043E\u0441\u0442\u0430\u0442\u043A\u043E\u0432 \u043D\u0430 \u0441\u0447\u0435\u0442\u0430\u0445, \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0435\u043C\u044B\u0445 \u0432 \u043F\u043B\u0430\u043D\u0435 \u0441\u0447\u0435\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"F28\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0435\u0440\u0432\u0438\u0447\u043D\u044B\u0439 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\" Ownership=\"0\"/>\n      <ObjectRef ID=\"F29\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0443\u0447\u0435\u0442\u043D\u044B\u0445 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"F30\" ObjectType=\"TABLE\" BriefText=\"\u0421\u0432\u044F\u0437\u044C \u0443\u0447\u0451\u0442\u043D\u043E\u0433\u043E \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430 \u0441 \u0433\u0440\u0443\u043F\u043F\u043E\u0432\u044B\u043C\u0438 \u0441\u0447\u0435\u0442\u0430\u043C\u0438 \u043F\u043B\u0430\u043D\u0430 \u0441\u0447\u0435\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"F31\" ObjectType=\"TABLE\" BriefText=\"\u0410\u043D\u0430\u043B\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0435 \u041F\u0440\u0438\u0437\u043D\u0430\u043A\u0438 \u0423\u0447\u0435\u0442\u043D\u044B\u0445 \u0414\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432 \u0438 \u0421\u0447\u0435\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"F34\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0430\u043A\u0435\u0442\u044B \u0423\u0447\u0435\u0442\u043D\u044B\u0445 \u0414\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432 \u0438 \u0421\u0447\u0435\u0442\u043E\u0432.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"F40\" ObjectType=\"TABLE\" BriefText=\"\u041E\u043A\u0440\u0443\u0433\u043B\u0435\u043D\u043D\u0430\u044F \u0444\u043E\u0440\u043C\u0430.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"F41\" ObjectType=\"TABLE\" BriefText=\"\u0414\u0430\u043D\u043D\u044B\u0435 \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u043D\u044B\u0445 \u043E\u0442\u0447\u0435\u0442\u043D\u044B\u0445 \u0444\u043E\u0440\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"F51\" ObjectType=\"TABLE\" BriefText=\"\u041E\u0441\u0442\u0430\u0442\u043A\u0438/\u043E\u0431\u043E\u0440\u043E\u0442\u044B \u043F\u043E \u0443\u0437\u043B\u0430\u043C \u043F\u043B\u0430\u043D\u0430 \u0441\u0447\u0435\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"F52\" ObjectType=\"TABLE\" BriefText=\"\u041E\u0441\u0442\u0430\u0442\u043A\u0438/\u043E\u0431\u043E\u0440\u043E\u0442\u044B \u043F\u043E \u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u043C \u0443\u0447\u0451\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"F91\" ObjectType=\"TABLE\" BriefText=\"\u0413\u0440\u0443\u043F\u043F\u044B \u0410\u043D\u0430\u043B\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u041F\u0440\u0438\u0437\u043D\u0430\u043A\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"F92\" ObjectType=\"TABLE\" BriefText=\"\u041E\u043F\u0438\u0441\u0430\u043D\u0438\u0435 \u0442\u0438\u043F\u043E\u0432\u044B\u0445 \u0430\u043D\u0430\u043B\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u043F\u0440\u0438\u0437\u043D\u0430\u043A\u043E\u0432 \u0443\u0447\u0451\u0442\u043D\u043E\u0433\u043E \u044F\u0434\u0440\u0430.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"F93\" ObjectType=\"TABLE\" BriefText=\"\u0417\u0430\u043F\u0440\u043E\u0441\u044B \u0434\u043B\u044F \u043E\u043F\u0440\u0435\u0434\u0435\u043B\u0435\u043D\u0438\u044F \u0441\u043F\u0438\u0441\u043A\u0430 \u0434\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u044B\u0445 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0439 \u0430\u043D\u0430\u043B\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u043E\u0433\u043E \u043F\u0440\u0438\u0437\u043D\u0430\u043A\u0430.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"G15\" ObjectType=\"TABLE\" Ownership=\"0\"/>\n      <ObjectRef ID=\"H01\" ObjectType=\"TABLE\" BriefText=\"StopListDictionary\" Ownership=\"0\"/>\n      <ObjectRef ID=\"H02\" ObjectType=\"TABLE\" BriefText=\"StopListEntryMain\" Ownership=\"0\"/>\n      <ObjectRef ID=\"H03\" ObjectType=\"TABLE\" BriefText=\"StopListEntryName\" Ownership=\"0\"/>\n      <ObjectRef ID=\"H04\" ObjectType=\"TABLE\" BriefText=\"StopListEntityPassport\" Ownership=\"0\"/>\n      <ObjectRef ID=\"H05\" ObjectType=\"TABLE\" BriefText=\"StopListEntityAddress\" Ownership=\"0\"/>\n      <ObjectRef ID=\"H06\" ObjectType=\"TABLE\" BriefText=\"StopListEntityBirthday\" Ownership=\"0\"/>\n      <ObjectRef ID=\"H07\" ObjectType=\"TABLE\" BriefText=\"ClientSubjectLink\" Ownership=\"0\"/>\n      <ObjectRef ID=\"H08\" ObjectType=\"TABLE\" BriefText=\"TransactionSystems\" Ownership=\"0\"/>\n      <ObjectRef ID=\"H09\" ObjectType=\"TABLE\" BriefText=\"\u0418\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u044F \u043E\u0431 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"H10\" ObjectType=\"TABLE\" BriefText=\"SuspectOperationSubcodes\" Ownership=\"0\"/>\n      <ObjectRef ID=\"H11\" ObjectType=\"TABLE\" BriefText=\"MemberDictionary\" Ownership=\"0\"/>\n      <ObjectRef ID=\"H12\" ObjectType=\"TABLE\" BriefText=\"OperationMember\" Ownership=\"0\"/>\n      <ObjectRef ID=\"H13\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u043E\u0432 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D\u0430 \u0441\u0435\u0440\u0438\u0439/\u043D\u043E\u043C\u0435\u0440\u043E\u0432 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432, \u0443\u0434\u043E\u0441\u0442\u043E\u0432\u0435\u0440\u044F\u044E\u0449\u0438\u0445 \u043B\u0438\u0447\u043D\u043E\u0441\u0442\u044C \u0441\u0443\u0431\u044A\u0435\u043A\u0442\u0430 \u0438\u0437 \u0441\u0442\u043E\u043F-\u043B\u0438\u0441\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"H14\" ObjectType=\"TABLE\" BriefText=\"\u041C\u0430\u0441\u043A\u0438 \u043F\u043E\u0438\u0441\u043A\u0430 \u043F\u043E \u0441\u0442\u043E\u043F-\u043B\u0438\u0441\u0442\u0430\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"H15\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0438\u0441\u043E\u043A \u0440\u043E\u043B\u0435\u0439 \u0437\u0430\u043F\u0438\u0441\u0438 \u0441\u0442\u043E\u043F-\u043B\u0438\u0441\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"H16\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0438\u0441\u043E\u043A \u0441\u0430\u043D\u043A\u0446\u0438\u0439, \u043F\u0440\u0438\u043C\u0435\u043D\u044F\u0435\u043C\u044B\u0445 \u0434\u043B\u044F \u0437\u0430\u043F\u0438\u0441\u0438 \u0441\u0442\u043E\u043F-\u043B\u0438\u0441\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"H20\" ObjectType=\"TABLE\" BriefText=\"\u0417\u0430\u0433\u043E\u043B\u043E\u0432\u043E\u0447\u043D\u0430\u044F \u0447\u0430\u0441\u0442\u044C \u041E\u042D\u0421\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I01\" ObjectType=\"TABLE\" BriefText=\"\u0417\u0430\u043F\u0440\u043E\u0441\u044B RRAM\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I02\" ObjectType=\"TABLE\" BriefText=\"\u041E\u0442\u0432\u0435\u0442\u044B RRAM\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I03\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u043F\u0440\u043E\u0446\u0435\u0434\u0443\u0440 \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u043A\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I04\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u0430\u0443\u0442\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0446\u0438\u043E\u043D\u043D\u043E\u0439 \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I05\" ObjectType=\"TABLE\" BriefText=\"\u041E\u043F\u0438\u0441\u0430\u043D\u0438\u044F \u0430\u0443\u0442\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0445 \u0430\u043B\u0433\u043E\u0440\u0438\u0442\u043C\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I06\" ObjectType=\"TABLE\" BriefText=\"\u0410\u0443\u0442\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0446\u0438\u043E\u043D\u043D\u0430\u044F \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u044F\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I07\" ObjectType=\"TABLE\" BriefText=\"\u0423\u0447\u0435\u0442\u043D\u044B\u0435 \u0437\u0430\u043F\u0438\u0441\u0438 \u043E\u0431\u044A\u0435\u043A\u0442\u043E\u0432 \u0434\u043B\u044F \u0441\u0438\u0441\u0442\u0435\u043C \u0443\u0434\u0430\u043B\u0435\u043D\u043D\u043E\u0433\u043E \u0434\u043E\u0441\u0442\u0443\u043F\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I08\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0438\u0441\u043E\u043A \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u043C\u044B\u0445 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I09\" ObjectType=\"TABLE\" BriefText=\"\u0418\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u044F \u043E \u043A\u043E\u043C\u043C\u0443\u043D\u0430\u043B\u044C\u043D\u044B\u0445 \u043F\u043B\u0430\u0442\u0435\u0436\u0430\u0445\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I10\" ObjectType=\"TABLE\" BriefText=\"\u0423\u0432\u0435\u0434\u043E\u043C\u043B\u0435\u043D\u0438\u044F \u043E\u0431 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u044F\u0445, \u043F\u0440\u043E\u0432\u0435\u0434\u0435\u043D\u043D\u044B\u0445 \u0432 3CardF\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I11\" ObjectType=\"TABLE\" BriefText=\"\u041D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0430 \u043A\u043B\u0438\u0435\u043D\u0442\u0441\u043A\u0438\u0445 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0439 (CSERV)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I12\" ObjectType=\"TABLE\" BriefText=\"\u0417\u0430\u044F\u0432\u043A\u0438 \u0441\u0438\u0441\u0442\u0435\u043C\u044B \u0443\u0434\u0430\u043B\u0435\u043D\u043D\u043E\u0433\u043E \u0434\u043E\u0441\u0442\u0443\u043F\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I13\" ObjectType=\"TABLE\" BriefText=\"\u041A\u043B\u0435\u043D\u0442\u0441\u043A\u0438\u0435 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I15\" ObjectType=\"TABLE\" BriefText=\"\u0410\u0443\u0442\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0435 \u043F\u0430\u043A\u0435\u0442\u044B\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I16\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0440\u0430\u0432\u0430 \u043D\u0430 \u043E\u0442\u043A\u0440\u044B\u0442\u0438\u0435 \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u043E\u0432 \u0434\u043B\u044F \u0433\u0440\u0443\u043F\u043F \u043A\u043B\u0438\u0435\u043D\u0442\u043E\u0432 \u0421\u0423\u0414\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I17\" ObjectType=\"TABLE\" BriefText=\"\u041E\u0442\u043A\u0440\u044B\u0442\u044B\u0435 \u043A\u043B\u044E\u0447\u0438 \u043A\u043B\u0438\u0435\u043D\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I18\" ObjectType=\"TABLE\" BriefText=\"\u041D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0430 \u0442\u0438\u043F\u043E\u0432\u044B\u0445 \u0443\u0432\u0435\u0434\u043E\u043C\u043B\u0435\u043D\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I19\" ObjectType=\"TABLE\" BriefText=\"\u041F\u043E\u0434\u043F\u0438\u0441\u043A\u0438 \u043A\u043B\u0438\u0435\u043D\u0442\u043E\u0432 \u043D\u0430 \u0443\u0432\u0435\u0434\u043E\u043C\u043B\u0435\u043D\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I20\" ObjectType=\"TABLE\" BriefText=\"\u0420\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u044F \u043E\u0442\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u043D\u044B\u0445 \u0443\u0432\u0435\u0434\u043E\u043C\u043B\u0435\u043D\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I21\" ObjectType=\"TABLE\" BriefText=\"\u0420\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u044F \u043A\u043B\u0438\u0435\u043D\u0442\u0430 \u0432 \u0441\u0438\u0441\u0442\u0435\u043C\u0435 \u0440\u0430\u0441\u0441\u044B\u043B\u043A\u0438 \u0443\u0432\u0435\u0434\u043E\u043C\u043B\u0435\u043D\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I22\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u0438  \u0441\u0438\u0441\u0442\u0435\u043C\u044B \u0443\u0434\u0430\u043B\u0435\u043D\u043D\u043E\u0433\u043E \u0434\u043E\u0441\u0442\u0443\u043F\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I23\" ObjectType=\"TABLE\" BriefText=\"CLOB\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I24\" ObjectType=\"TABLE\" BriefText=\"\u0417\u0430\u043F\u0440\u043E\u0441\u044B \u043E\u0442 \u0432\u043D\u0435\u0448\u043D\u0438\u0445 \u0441\u0438\u0441\u0442\u0435\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I25\" ObjectType=\"TABLE\" BriefText=\"\u041E\u0442\u0432\u0435\u0442\u044B \u0432\u043D\u0435\u0448\u043D\u0438\u043C \u0441\u0438\u0441\u0442\u0435\u043C\u0430\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I26\" ObjectType=\"TABLE\" BriefText=\"\u0414\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B, \u0441\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0435 \u043F\u043E \u043E\u0431\u044A\u0435\u043A\u0442\u0443\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I27\" ObjectType=\"TABLE\" BriefText=\"\u041E\u0431\u0440\u0430\u0431\u043E\u0442\u0447\u0438\u043A \u0437\u0430\u043F\u0440\u043E\u0441\u043E\u0432 \u0432\u043D\u0435\u0448\u043D\u0438\u0445 \u0441\u0438\u0441\u0442\u0435\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I30\" ObjectType=\"TABLE\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I31\" ObjectType=\"TABLE\" BriefText=\"\u0428\u043B\u044E\u0437 \u0441 \u0432\u043D\u0435\u0448\u043D\u0435\u0439 \u0441\u0438\u0441\u0442\u0435\u043C\u043E\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I32\" ObjectType=\"TABLE\" BriefText=\"\u041F\u043E\u0434\u043F\u0438\u0441\u043A\u0430 \u0432\u043D\u0435\u0448\u043D\u0438\u0445 \u0441\u0438\u0441\u0442\u0435\u043C \u043D\u0430 \u0441\u043E\u0431\u044B\u0442\u0438\u044F\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I33\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043E\u0431\u044B\u0442\u0438\u044F \u0441\u0438\u0441\u0442\u0435\u043C\u044B 3CardR\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I34\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0440\u043E\u0442\u043E\u043A\u043E\u043B \u0432\u0437\u0430\u0438\u043C\u043E\u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F \u0441 \u0432\u043D\u0435\u0448\u043D\u0435\u0439 \u0441\u0438\u0441\u0442\u0435\u043C\u043E\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I35\" ObjectType=\"TABLE\" BriefText=\"\u0412\u0437\u0430\u0438\u043C\u043E\u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F \u0432 \u0440\u0430\u043C\u043A\u0430\u0445 \u043F\u0440\u043E\u0442\u043E\u043A\u043E\u043B\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I36\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0440\u043E\u0442\u043E\u043A\u043E\u043B\u044B, \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u043C\u044B\u0435 \u0432\u043D\u0435\u0448\u043D\u0435\u0439 \u0441\u0438\u0441\u0442\u0435\u043C\u043E\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I38\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0438\u043F\u043E\u0432\u043E\u0435 \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u043E\u043D\u043D\u043E\u0435 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0435\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I39\" ObjectType=\"TABLE\" BriefText=\"\u0418\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0435 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u044F\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I40\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0437\u0430\u043F\u043B\u0430\u043D\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0445 \u0440\u0435\u0433\u043B\u0430\u043C\u0435\u043D\u0442\u043D\u044B\u0445 \u0437\u0430\u0434\u0430\u043D\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"I99\" ObjectType=\"TABLE\" BriefText=\"LDSTransport Table\" Ownership=\"0\"/>\n      <ObjectRef ID=\"J01\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A \u043D\u0430\u0438\u043C\u0435\u043D\u043E\u0432\u0430\u043D\u0438\u0439 \u043D\u0430\u0441\u0435\u043B\u0435\u043D\u043D\u044B\u0445 \u043F\u0443\u043D\u043A\u0442\u043E\u0432.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"J02\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0438\u0441\u043E\u043A \u0441\u0438\u0441\u0442\u0435\u043C \u043F\u0435\u0440\u0435\u0432\u043E\u0434\u043E\u0432.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"J03\" ObjectType=\"TABLE\" BriefText=\"\u0412\u0430\u0440\u0438\u0430\u043D\u0442\u044B \u043D\u0430\u043F\u0438\u0441\u0430\u043D\u0438\u044F \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u044F \u043D\u0430\u0441\u0435\u043B\u0435\u043D\u043D\u043E\u0433\u043E \u043F\u0443\u043D\u043A\u0442\u0430.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"J07\" ObjectType=\"TABLE\" BriefText=\"\u0422\u043E\u043F\u043E\u043B\u043E\u0433\u0438\u044F \u0441\u0435\u0442\u0435\u0439 \u043E\u0431\u0441\u043B\u0443\u0436\u0438\u0432\u0430\u043D\u0438\u044F.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"J08\" ObjectType=\"TABLE\" BriefText=\"\u0423\u0441\u043B\u0443\u0433\u0438 \u0432 \u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0435 \u0441\u0435\u0442\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"J09\" ObjectType=\"TABLE\" BriefText=\"\u0423\u0441\u043B\u0443\u0433\u0438 \u043F\u0440\u043E\u0432\u0430\u0439\u0434\u0435\u0440\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"J10\" ObjectType=\"TABLE\" BriefText=\"\u0421\u0435\u0440\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u044B \u0438\u0441\u043F\u043E\u043B\u043D\u0438\u0442\u0435\u043B\u0435\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"J11\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0441\u0438\u043D\u043E\u043D\u0438\u043C\u043E\u0432 \u0430\u0434\u0440\u0435\u0441\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"J12\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0445\u0440\u0430\u043D\u0435\u043D\u0438\u044F \u0441\u0435\u0442\u0435\u0432\u044B\u0445 \u0430\u0434\u0440\u0435\u0441\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"J15\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0442\u0438\u043F\u043E\u0432 \u0430\u043D\u0430\u043B\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u043F\u0440\u0438\u0437\u043D\u0430\u043A\u043E\u0432 \u0443\u0441\u043B\u0443\u0433 \u043F\u0440\u043E\u0432\u0430\u0439\u0434\u0435\u0440\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"J16\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0439 \u0430\u043D\u0430\u043B\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u043F\u0440\u0438\u0437\u043D\u0430\u043A\u043E\u0432 \u0443\u0441\u043B\u0443\u0433 \u043F\u0440\u043E\u0432\u0430\u0439\u0434\u0435\u0440\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"J17\" ObjectType=\"TABLE\" BriefText=\"\u0420\u0430\u0437\u0440\u0435\u0448\u0435\u043D\u043D\u044B\u0435 \u0434\u043B\u044F \u0443\u0441\u043B\u0443\u0433\u0438 \u043F\u0440\u043E\u0432\u0430\u0439\u0434\u0435\u0440\u0430 \u0430\u043D\u0430\u043B\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0435 \u043F\u0440\u0438\u0437\u043D\u0430\u043A\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"J18\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0440\u0438\u043D\u044F\u0442\u044B\u0435 \u043F\u043B\u0430\u0442\u0435\u0436\u0438 \u0432 \u043F\u043E\u043B\u044C\u0437\u0443 \u044E\u0440. \u043B\u0438\u0446\" Ownership=\"0\"/>\n      <ObjectRef ID=\"J19\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u043F\u0440\u0438\u043D\u044F\u0442\u043E\u0433\u043E \u043F\u043B\u0430\u0442\u0435\u0436\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"J20\" ObjectType=\"TABLE\" BriefText=\"\u041A\u043B\u0438\u0440\u0438\u043D\u0433\u043E\u0432\u044B\u0435 \u043F\u043B\u0430\u0442\u0435\u0436\u0438 \u043F\u043E \u0443\u0441\u043B\u0443\u0433\u0430\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"J21\" ObjectType=\"TABLE\" BriefText=\"\u041A\u043B\u0438\u0440\u0438\u043D\u0433\u043E\u0432\u044B\u0435 \u0440\u0430\u0441\u0447\u0435\u0442\u044B \u043F\u043E \u0443\u0441\u043B\u0443\u0433\u0430\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"J99\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043E\u043F\u0438\u0441\u0430\u043D\u0438\u044F \u043E\u0448\u0438\u0431\u043E\u043A \u043F\u0440\u043E\u0432\u0430\u0439\u0434\u0435\u0440\u043E\u0432 \u0443\u0441\u043B\u0443\u0433\" Ownership=\"0\"/>\n      <ObjectRef ID=\"K06\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 POS-\u043A\u043E\u0434\u043E\u0432 \u0442\u0435\u0440\u043C\u0438\u043D\u0430\u043B\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"L00\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0441\u0438\u0441\u0442\u0435\u043C\u043D\u044B\u0445 \u0438 \u0442\u0435\u0445\u043D\u043E\u043B\u043E\u0433\u0438\u0447\u0435\u043A\u0438\u0445 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u043E\u0432 \u043F\u043E\u0434\u0441\u0438\u0441\u0442\u0435\u043C\u044B  \u0430\u0432\u0442\u043E\u0440\u0438\u0437\u0430\u0446\u0438\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"L03\" ObjectType=\"TABLE\" BriefText=\"\u0414\u0438\u0430\u043F\u0430\u0437\u043E\u043D\u044B \u0411\u0418\u041D\u043E\u0432 \u0434\u043B\u044F \u043C\u0430\u0440\u0448\u0440\u0443\u0442\u0438\u0437\u0430\u0446\u0438\u0438 \u0430\u0432\u0442\u043E\u0440\u0438\u0437\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0445 \u0438 \u0444\u0438\u043D\u0430\u043D\u0441\u043E\u0432\u044B\u0445 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"L91\" ObjectType=\"TABLE\" BriefText=\"\u041E\u0440\u0438\u0433\u0438\u043D\u0430\u043B\u044C\u043D\u0430\u044F \u0442\u0430\u0431\u043B\u0438\u0446\u0430 BIN\" Ownership=\"0\"/>\n      <ObjectRef ID=\"L92\" ObjectType=\"TABLE\" BriefText=\"\u0418\u0441\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u044F \u0438\u0437 \u0442\u0430\u0431\u043B\u0438\u0446\u044B BIN\" Ownership=\"0\"/>\n      <ObjectRef ID=\"L93\" ObjectType=\"TABLE\" BriefText=\"\u0412\u0440\u0435\u043C\u0435\u043D\u043D\u0430\u044F \u0442\u0430\u0431\u043B\u0438\u0446\u0430 \u0434\u043B\u044F \u0437\u0430\u0433\u0440\u0443\u0437\u043A\u0438 BT (TRANSACTION)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"M01\" ObjectType=\"TABLE\" BriefText=\"\u0411\u043B\u043E\u043A\u0438\u0440\u043E\u0432\u043A\u0430 \u043E\u0431\u044A\u0435\u043A\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"M02\" ObjectType=\"TABLE\" BriefText=\"\u041E\u043F\u0435\u0440\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0435 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u043E\u0439 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438, \u0438\u0441\u043A\u043B\u044E\u0447\u0435\u043D\u043D\u044B\u0435 \u0438\u0437 \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u043A\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"M03\" ObjectType=\"TABLE\" BriefText=\"\u041C\u0430\u0440\u0448\u0440\u0443\u0442\u044B \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"M04\" ObjectType=\"TABLE\" BriefText=\"\u042D\u0442\u0430\u043F\u044B \u0437\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u044B\u0445 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"M06\" ObjectType=\"TABLE\" BriefText=\"\u041E\u043F\u0435\u0440\u0430\u0442\u0438\u0432\u043D\u0430\u044F \u0442\u0430\u0431\u043B\u0438\u0446\u0430 \u0434\u0430\u043D\u043D\u044B\u0445 \u043F\u043E \u043D\u0430\u0447\u0438\u0441\u043B\u0435\u043D\u0438\u044E \u043F\u0440\u043E\u0446\u0435\u043D\u0442\u043E\u0432.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"M10\" ObjectType=\"TABLE\" BriefText=\"\u0418\u0441\u0442\u043E\u0440\u0438\u044F\" Ownership=\"0\"/>\n      <ObjectRef ID=\"M40\" ObjectType=\"TABLE\" BriefText=\"\u041E\u0441\u043D\u043E\u0432\u043D\u044B\u0435 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u043D\u0430\u0431\u043E\u0440\u0430 \u043F\u043E\u043F\u0440\u0430\u0432\u043E\u043A \u043A \u0441\u0442\u0430\u0432\u043A\u0430\u043C \u043F\u043E \u0441\u0447\u0435\u0442\u0430\u043C \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u043E\u0433\u043E \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"M42\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u043E\u043F\u0440\u0430\u0432\u043E\u043A \u043A \u0441\u0442\u0430\u0432\u043A\u0430\u043C \u043F\u043E \u0441\u0447\u0435\u0442\u0430\u043C \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u043E\u0433\u043E \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"M55\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0440\u043E\u0442\u043E\u043A\u043E\u043B\u044B \u0440\u0430\u0441\u0447\u0451\u0442\u0430 \u043F\u0440\u043E\u0446\u0435\u043D\u0442\u043E\u0432 \u043F\u043E \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u044F\u043C \u043F\u0440\u0435\u0434\u0448\u0435\u0441\u0442\u0432\u0443\u044E\u0449\u0438\u043C \u043F\u043E\u0441\u043B\u0435\u0434\u043D\u0435\u0439 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438 \u0440\u0430\u0441\u0447\u0451\u0442\u0430 \u043F\u0440\u043E\u0446\u0435\u043D\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"M56\" ObjectType=\"TABLE\" BriefText=\"\u041E\u043F\u0435\u0440\u0430\u0442\u0438\u0432\u043D\u044B\u0439 \u043F\u0440\u043E\u0442\u043E\u043A\u043E\u043B \u0434\u043B\u044F \u0440\u0435\u0433\u043B\u0430\u043C\u0435\u043D\u0442\u043D\u043E\u0433\u043E \u044D\u0442\u0430\u043F\u0430 \u0440\u0430\u0441\u0447\u0435\u0442\u0430 \u043F\u0440\u043E\u0446\u0435\u043D\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"M57\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0434\u043B\u044F \u0445\u0440\u0430\u043D\u0435\u043D\u0438\u044F \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u044B\u0445 \u0441\u0443\u043C\u043C \u043F\u0440\u043E\u0446\u0435\u043D\u0442\u043E\u0432 \u0438 \u0442\u0430\u0440\u0438\u0444\u043E\u0432 \u043F\u043E \u0441\u0447\u0435\u0442\u0430\u043C \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u043E\u0432.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"M58\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043E\u0441\u0442\u0430\u0432 \u0432\u044B\u0433\u0440\u0443\u0437\u043A\u0438 \u0432 \u0411\u041A\u0418\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N01\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u0438\u0445 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0439 (\u0432 \u043C\u043E\u043C\u0435\u043D\u0442 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u044F \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u0438\u0445 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0439) \u0438 \u0442\u0430\u0431\u043B\u0438\u0446\u0430 \u0441\u0432\u044F\u0437\u0435\u0439 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0445,\u0443\u0447\u0435\u0442\u043D\u044B\u0445 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432 \u0438 \u043E\u0431\u044A\u0435\u043A\u0442\u043E\u0432 \u0437\u0430\u0434\u0435\u0439\u0441\u0442\u0432\u043E\u0432\u0430\u043D\u043D\u044B\u0445 \u0432 \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u043E\u0439 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438 (\u043F\u043E \u043E\u043A\u043E\u043D\u0447\u0430\u043D\u0438\u044E \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u043E\u0439 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N02\" ObjectType=\"TABLE\" BriefText=\"\u041E\u0431\u0449\u0438\u0435 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0445 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432 \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u043E\u0439 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438\" Ownership=\"1\"/>\n      <ObjectRef ID=\"N03\" ObjectType=\"TABLE\" BriefText=\"\u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0435 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B \u0434\u043B\u044F \u043E\u0431\u0441\u043B\u0443\u0436\u0438\u0432\u0430\u043D\u0438\u044F \u043A\u043B\u0438\u0435\u043D\u0442\u043E\u0432.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N04\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u044D\u0442\u0430\u043F\u043E\u0432 \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u0438\u0445 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N05\" ObjectType=\"TABLE\" BriefText=\"\u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0435 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B \u0434\u043B\u044F \u043E\u0442\u043A\u0440\u044B\u0442\u0438\u044F \u043A\u0440\u0435\u0434\u0438\u0442\u043D\u044B\u0445 \u043B\u0438\u043D\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N06\" ObjectType=\"TABLE\" BriefText=\"\u041E\u043F\u0435\u0440\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0435 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B \u0434\u043B\u044F \u043D\u0430\u0447\u0438\u0441\u043B\u0435\u043D\u0438\u044F \u043F\u0440\u043E\u0446\u0435\u043D\u0442\u043E\u0432 \u043F\u043E \u0441\u0447\u0451\u0442\u0443\" Ownership=\"1\"/>\n      <ObjectRef ID=\"N07\" ObjectType=\"TABLE\" BriefText=\"\u0410\u043D\u0430\u043B\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0435 \u043F\u0440\u0438\u0437\u043D\u0430\u043A\u0438 \u0434\u043E\u043F\u043E\u043B\u043D\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0439 \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N08\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u044F \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0445 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432 \u0434\u043B\u044F \u0443\u0447\u0451\u0442\u0430 \u0446\u0435\u043D\u043D\u043E\u0441\u0442\u0435\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N09\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043D\u043E\u043C\u0438\u043D\u0430\u043B\u043E\u0432 \u0438 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D\u043E\u0432 \u043D\u043E\u043C\u0435\u0440\u043E\u0432 \u0446\u0435\u043D\u043D\u043E\u0441\u0442\u0435\u0439, \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u043D\u043D\u044B\u0445 \u0432 \u0441\u0435\u0430\u043D\u0441\u0435 \u0440\u0430\u0431\u043E\u0442\u044B.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N10\" ObjectType=\"TABLE\" BriefText=\"\u0420\u0435\u0435\u0441\u0442\u0440\u044B \u0432\u0430\u043B\u044E\u0442\u043D\u044B\u0445 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N11\" ObjectType=\"TABLE\" BriefText=\"\u0412\u0430\u043B\u044E\u0442\u043D\u044B\u0435 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N12\" ObjectType=\"TABLE\" BriefText=\"\u0420\u0435\u0435\u0441\u0442\u0440\u044B \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0445 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N13\" ObjectType=\"TABLE\" BriefText=\"\u0421\u0442\u0440\u0443\u043A\u0442\u0443\u0440\u0430 \u043C\u0435\u043D\u044E\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N14\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430  \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u043E\u0432 \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u0438\u0445 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0439\" Ownership=\"1\"/>\n      <ObjectRef ID=\"N15\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0440\u043E\u0442\u043E\u043A\u043E\u043B \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u043E\u0432 \u0434\u043B\u044F \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u0438\u0445 \u0440\u0430\u0441\u043F\u043E\u0440\u044F\u0436\u0435\u043D\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N16\" ObjectType=\"TABLE\" BriefText=\"ProfileLaunchHistory\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N17\" ObjectType=\"TABLE\" BriefText=\"\u0411\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u043E\u0435 \u0440\u0430\u0441\u043F\u043E\u0440\u044F\u0436\u0435\u043D\u0438\u0435\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N18\" ObjectType=\"TABLE\" BriefText=\"\u0418\u0441\u0442\u043E\u0440\u0438\u044F \u043F\u0440\u043E\u043B\u043E\u043D\u0433\u0430\u0446\u0438\u0438 \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u043E\u0432\" Ownership=\"1\"/>\n      <ObjectRef ID=\"N19\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u043E\u0432 \u043F\u043E\u0441\u043B\u0435\u0434\u043D\u0435\u0433\u043E \u043D\u0430\u0447\u0438\u0441\u043B\u0435\u043D\u0438\u044F/\u0443\u043F\u043B\u0430\u0442\u044B \u043F\u0440\u043E\u0446\u0435\u043D\u0442\u043E\u0432/\u0442\u0430\u0440\u0438\u0444\u043E\u0432 \u043F\u043E \u0441\u0447\u0451\u0442\u0443.\" Ownership=\"1\"/>\n      <ObjectRef ID=\"N20\" ObjectType=\"TABLE\" BriefText=\"\u0421\u0432\u044F\u0437\u0438 \u043C\u0435\u0436\u0434\u0443 \u043E\u0431\u044A\u0435\u043A\u0442\u0430\u043C\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N21\" ObjectType=\"TABLE\" BriefText=\"\u0414\u043E\u043F\u043E\u043B\u043D\u0438\u0442\u0435\u043B\u044C\u043D\u0430\u044F \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u044F \u043F\u043E \u0438\u0441\u0445\u043E\u0434\u043D\u043E\u043C\u0443 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0443 \u0434\u043B\u044F \u0434\u0435\u0440\u0436\u0430\u0442\u0435\u043B\u0435\u0439 \u043A\u0430\u0440\u0442.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N22\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0445 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432 \u043F\u043E \u043A\u0430\u0440\u0442\u0430\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N23\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u044F \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0445 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432 \u0441 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u0430\u043C\u0438 \u043A\u0430\u0440\u0442\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N24\" ObjectType=\"TABLE\" BriefText=\"\u0420\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u0438\u0441\u0445\u043E\u0434\u043D\u043E\u0433\u043E \u043A\u0430\u0440\u0442\u043E\u0447\u043D\u043E\u0433\u043E \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430 \u0441 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u0430\u043C\u0438 \u0438\u043D\u0434\u0438\u0432\u0438\u0434\u0443\u0430\u043B\u044C\u043D\u044B\u0445 \u043B\u0438\u043C\u0438\u0442\u043E\u0432 \u0430\u043A\u0442\u0438\u0432\u043D\u043E\u0441\u0442\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N25\" ObjectType=\"TABLE\" BriefText=\"\u0420\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u0438\u0441\u0445\u043E\u0434\u043D\u043E\u0433\u043E \u043A\u0430\u0440\u0442\u043E\u0447\u043D\u043E\u0433\u043E \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430 \u0441 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u0430\u043C\u0438 \u0431\u043B\u043E\u043A\u0438\u0440\u043E\u0432\u043E\u043A\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N26\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u043F\u0435\u0440\u0435\u043F\u0440\u0438\u0432\u044F\u0437\u043A\u0438 \u0441\u0447\u0435\u0442\u043E\u0432 \u0441\u0432\u043E\u0434\u043D\u043E\u0433\u043E \u0443\u0447\u0435\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N27\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u044F \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u0438\u0437\u0430\u0446\u0438\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N28\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439 \u043F\u043E \u043F\u0440\u0438\u043D\u0443\u0434\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0439 \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0435 \u0430\u0431\u0441\u043E\u043B\u044E\u0442\u043D\u043E\u0439 \u0432\u0435\u043B\u0438\u0447\u0438\u043D\u044B \u043B\u0438\u043C\u0438\u0442\u043E\u0432 \u043A\u0430\u0440\u0442\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N29\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0443\u0447\u0435\u0442\u043D\u044B\u0445 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N30\" ObjectType=\"TABLE\" BriefText=\"\u0414\u043E\u0433\u043E\u0432\u043E\u0440\u044B \u0444\u0438\u0437\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u0438 \u044E\u0440\u0438\u0434\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u043B\u0438\u0446\" Ownership=\"1\"/>\n      <ObjectRef ID=\"N31\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u043E\u0432 \u043A\u043B\u0438\u0435\u043D\u0442\u043E\u0432 - \u0444\u0438\u0437\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u043B\u0438\u0446\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N32\" ObjectType=\"TABLE\" BriefText=\"\u0421\u0447\u0435\u0442\u0430 \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u043E\u0432\" Ownership=\"1\"/>\n      <ObjectRef ID=\"N33\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0445\u0440\u0430\u043D\u0435\u043D\u0438\u044F \u0431\u0438\u043D\u0430\u0440\u043D\u044B\u0445 \u0434\u0430\u043D\u043D\u044B\u0445\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N34\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u0438 \u043F\u043E\u0441\u043B\u0435\u0434\u043D\u0435\u0439 \u0434\u0430\u0442\u044B \u0441\u043E\u0432\u0435\u0440\u0448\u0435\u043D\u0438\u044F \u0440\u0435\u0433\u043B\u0430\u043C\u0435\u043D\u0442\u043D\u044B\u0445 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0439 \u043F\u043E \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u0443.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N35\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0441\u0443\u043C\u043C, \u0440\u0430\u0441\u0441\u0447\u0438\u0442\u0430\u043D\u043D\u044B\u0445 \u043F\u043E \u0441\u0445\u0435\u043C\u0435 \u0440\u0430\u0437\u043B\u043E\u0436\u0435\u043D\u0438\u044F.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N36\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0441\u0447\u0435\u0442\u043E\u0432, \u0441\u0432\u044F\u0437\u0430\u043D\u044B\u0445 \u0441 \u043B\u0438\u043C\u0438\u0442\u0430\u043C\u0438 \u043A\u0430\u0440\u0442, \u0434\u043B\u044F \u043A\u0430\u0440\u0442\u043E\u0447\u043D\u044B\u0445 \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u043E\u0432.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N37\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0438\u0441\u043E\u043A \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432, \u0443\u0434\u043E\u0441\u0442\u043E\u0432\u0435\u0440\u044F\u044E\u0449\u0438\u0445 \u043B\u0438\u0447\u043D\u043E\u0441\u0442\u044C \u043A\u043B\u0438\u0435\u043D\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N38\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u0440\u0438\u0432\u044F\u0437\u043A\u0438 \u0441\u0445\u0435\u043C \u0440\u0430\u0441\u0447\u0451\u0442\u0430 \u043F\u0440\u043E\u0446\u0435\u043D\u0442\u043E\u0432/\u0442\u0430\u0440\u0438\u0444\u043E\u0432 \u043A \u0441\u0447\u0435\u0442\u0430\u043C \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u043E\u0432.\" Ownership=\"1\"/>\n      <ObjectRef ID=\"N39\" ObjectType=\"TABLE\" BriefText=\"\u0423\u0447\u0451\u0442 \u0444\u0430\u043A\u0442\u043E\u0432 \u043F\u0435\u0447\u0430\u0442\u0438 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432 \u043F\u043E \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u0443\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N40\" ObjectType=\"TABLE\" BriefText=\"\u0420\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u044F \u0430\u0434\u0440\u0435\u0441\u043E\u0432 \u043E\u0431\u044A\u0435\u043A\u0442\u043E\u0432.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N41\" ObjectType=\"TABLE\" BriefText=\"\u041D\u043E\u0440\u043C\u0430\u0442\u0438\u0432\u043D\u044B\u0435 \u043F\u0440\u043E\u0446\u0435\u043D\u0442\u043D\u044B\u0435 \u0441\u0442\u0430\u0432\u043A\u0438\" Ownership=\"1\"/>\n      <ObjectRef ID=\"N42\" ObjectType=\"TABLE\" BriefText=\"\u0414\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B (\u0434\u043E\u0432\u0435\u0440\u0435\u043D\u043D\u043E\u0441\u0442\u0438, \u0430\u0440\u0435\u0441\u0442\u044B \u0438 \u0434\u0440.)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N43\" ObjectType=\"TABLE\" BriefText=\"\u041E\u0441\u043E\u0431\u044B\u0435 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u043E\u0432 \u044E\u0440\u0438\u0434\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u043B\u0438\u0446\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N44\" ObjectType=\"TABLE\" BriefText=\"\u0414\u043E\u0433\u043E\u0432\u043E\u0440\u0430 \u0438 \u043F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u044F \u043A\u043B\u0438\u0435\u043D\u0442\u0441\u043A\u0438\u0445 \u043E\u0440\u0433\u0430\u043D\u0438\u0437\u0430\u0446\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N45\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u043E\u0431\u0435\u0441\u043F\u0435\u0447\u0435\u043D\u0438\u0439 \u043A\u0440\u0435\u0434\u0438\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N46\" ObjectType=\"TABLE\" BriefText=\"\u0424\u0438\u043D\u0430\u043D\u0441\u043E\u0432\u044B\u0435 \u043F\u043E\u0442\u043E\u043A\u0438 \u043F\u043E \u043A\u0440\u0435\u0434\u0438\u0442\u043D\u043E\u043C\u0443 \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u0443\" Ownership=\"1\"/>\n      <ObjectRef ID=\"N47\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u043F\u043E\u0433\u0430\u0448\u0435\u043D\u0438\u044F \u0437\u0430\u0434\u043E\u043B\u0436\u0435\u043D\u043D\u043E\u0441\u0442\u0435\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N49\" ObjectType=\"TABLE\" BriefText=\"\u0421\u0442\u043E\u0440\u043D\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0435 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N50\" ObjectType=\"TABLE\" BriefText=\"\u041F\u043B\u0430\u0442\u0435\u0436\u043D\u044B\u0435 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B, \u0432\u044B\u0433\u0440\u0443\u0436\u0430\u0435\u043C\u044B\u0435 \u0432 \u0411\u0421 \u043F\u043E \u0441\u0447\u0435\u0442\u0430\u043C \u0441\u0432\u043E\u0434\u043D\u043E\u0433\u043E \u0443\u0447\u0435\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N51\" ObjectType=\"TABLE\" BriefText=\"\u041E\u0441\u0442\u0430\u0442\u043A\u0438/\u043E\u0431\u043E\u0440\u043E\u0442\u044B \u043F\u043E \u0441\u0447\u0435\u0442\u0430\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N52\" ObjectType=\"TABLE\" BriefText=\"\u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0435 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B - \u043F\u043B\u0430\u0442\u0435\u0436\u043D\u044B\u0435 \u043F\u043E\u0440\u0443\u0447\u0435\u043D\u0438\u044F (\u0432\u0445\u043E\u0434\u044F\u0449\u0438\u0435 \u0438 \u0438\u0441\u0445\u043E\u0434\u044F\u0449\u0438\u0435)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N53\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043E\u0434\u0435\u0440\u0436\u0438\u0442 \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u044E \u043E\u0431 \u0438\u0441\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0438 \u043F\u043B\u0430\u0442\u0435\u0436\u0430 \u043F\u043E \u043F\u0435\u0440\u0435\u0432\u043E\u0434\u0430\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N54\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u043E\u0432 \u0448\u0430\u0431\u043B\u043E\u043D\u043E\u0432 \u0434\u043B\u044F \u0432\u043D\u0435\u0448\u043D\u0438\u0445 \u043F\u043B\u0430\u0442\u0435\u0436\u0435\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N55\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0440\u043E\u0442\u043E\u043A\u043E\u043B \u0440\u0430\u0441\u0447\u0435\u0442\u0430 \u043F\u0440\u043E\u0446\u0435\u043D\u0442\u043E\u0432\" Ownership=\"1\"/>\n      <ObjectRef ID=\"N56\" ObjectType=\"TABLE\" BriefText=\"\u043E\u0431\u043E\u0440\u043E\u0442\u044B \u043F\u043E \u043D\u0435\u0437\u0430\u0432\u0435\u0448\u0435\u043D\u043D\u044B\u043C \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u044F\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N57\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438 \u043F\u043B\u0430\u0442\u0435\u0436\u0435\u0439 \u044E\u0440\u043B\u0438\u0446\u0430\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N58\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u0440\u0438\u0432\u044F\u0437\u043A\u0438 \u043F\u043E\u0434\u0447\u0438\u043D\u0451\u043D\u043D\u044B\u0445 \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u043E\u0432. \" Ownership=\"0\"/>\n      <ObjectRef ID=\"N59\" ObjectType=\"TABLE\" BriefText=\"\u0420\u0435\u0435\u0441\u0442\u0440 \u0434\u043B\u044F \u043E\u043F\u043B\u0430\u0442\u044B \u044E\u0440\u043B\u0438\u0446\u0430\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N60\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0435\u0445\u043D\u043E\u043B\u043E\u0433\u0438\u0447\u0435\u0441\u043A\u043E\u0435 \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u0434\u043B\u044F \u0430\u0432\u0442\u043E\u0440\u0438\u0437\u0430\u0446\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N61\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043E\u0441\u0442\u0430\u0432 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u043E\u0432 \u0432 \u0448\u0430\u0431\u043B\u043E\u043D\u0435 \u043A\u043E\u043C\u043C\u0443\u043D\u0430\u043B\u044C\u043D\u044B\u0445 \u043F\u043B\u0430\u0442\u0435\u0436\u0435\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N62\" ObjectType=\"TABLE\" BriefText=\"\u0412\u0438\u0434\u044B \u043F\u043B\u0430\u0442\u0435\u0436\u0435\u0439 \u043F\u043E \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u0430\u043C \u044E\u0440\u043B\u0438\u0446\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N63\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u044F \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u0438 \u043E \u0441\u043F\u0435\u0446\u0438\u0430\u043B\u0438\u0437\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0445 \u043F\u043B\u0430\u0442\u0435\u0436\u0430\u0445\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N64\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0443\u0441\u043B\u043E\u0432\u0438\u0439 \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u044F \u0434\u043B\u044F \u0434\u043B\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0445 \u043F\u043E\u0440\u0443\u0447\u0435\u043D\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N65\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043E\u0441\u0442\u0430\u0432\u043D\u044B\u0435 \u0441\u0443\u043C\u043C\u044B \u0434\u043B\u044F \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0445 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N66\" ObjectType=\"TABLE\" BriefText=\"\u0413\u0440\u0443\u043F\u043F\u043E\u0432\u044B\u0435 \u0438\u043C\u0435\u043D\u0430 \u0441\u0447\u0435\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N67\" ObjectType=\"TABLE\" BriefText=\"\u0410\u043D\u0430\u043B\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0435 \u0438 \u0441\u0432\u043E\u0434\u043D\u044B\u0435 \u0441\u0447\u0435\u0442\u0430\" Ownership=\"1\"/>\n      <ObjectRef ID=\"N68\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u0438 \u043F\u043E\u0441\u043B\u0435\u0434\u043D\u0435\u0439 \u0434\u0430\u0442\u044B \u0441\u043E\u0432\u0435\u0440\u0448\u0435\u043D\u0438\u044F \u0440\u0435\u0433\u043B\u0430\u043C\u0435\u043D\u0442\u043D\u044B\u0445 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0439 \u043F\u043E \u0441\u0447\u0435\u0442\u0443.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N69\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u0430, \u0441\u0432\u044F\u0437\u0430\u043D\u043D\u044B\u0435 \u0441 \u043A\u0440\u0435\u0434\u0438\u0442\u0430\u043C\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N70\" ObjectType=\"TABLE\" BriefText=\"\u0418\u0441\u0442\u043E\u0440\u0438\u044F \u0441\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u044F \u043F\u043E\u0440\u0442\u0444\u0435\u043B\u0435\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N71\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u0438 \u043A\u043E\u043D\u0442\u0430\u043A\u0442\u043D\u043E\u0439 \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u0438 \u0437\u0430 \u043E\u0431\u044A\u0435\u043A\u0442\u0430\u043C\u0438:\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N73\" ObjectType=\"TABLE\" BriefText=\"\u0414\u043B\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0435 \u043F\u043E\u0440\u0443\u0447\u0435\u043D\u0438\u044F \u043A\u043B\u0438\u0435\u043D\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N74\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0435\u0440\u0435\u043E\u043F\u0440\u0435\u0434\u0435\u043B\u0435\u043D\u0438\u0435 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u043E\u0432 \u0434\u043B\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0445 \u043F\u043E\u0440\u0443\u0447\u0435\u043D\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N75\" ObjectType=\"TABLE\" BriefText=\"\u0421\u0442\u043E\u0438\u043C\u043E\u0441\u0442\u044C \u0446\u0435\u043D\u043D\u043E\u0441\u0442\u0435\u0439 \u043F\u043E \u0441\u0434\u0435\u043B\u043A\u0435\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N77\" ObjectType=\"TABLE\" BriefText=\"\u0421\u0432\u043E\u0434\u043D\u044B\u0435 \u043C\u0435\u043C\u043E\u0440\u0438\u0430\u043B\u044C\u043D\u044B\u0435 \u043E\u0440\u0434\u0435\u0440\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N78\" ObjectType=\"TABLE\" BriefText=\"\u0417\u0430\u044F\u0432\u043A\u0438 \u043D\u0430 \u043E\u0442\u043A\u0440\u044B\u0442\u0438\u0435 \u043A\u0440\u0435\u0434\u0438\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N79\" ObjectType=\"TABLE\" BriefText=\"\u0410\u043A\u0446\u0435\u043F\u0442\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N80\" ObjectType=\"TABLE\" BriefText=\"\u0410\u0440\u0435\u0441\u0442\u044B\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N85\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0440\u043E\u0442\u043E\u043A\u043E\u043B \u0440\u0430\u0441\u0447\u0435\u0442\u0430 \u0442\u0430\u0440\u0438\u0444\u043E\u0432 \u043F\u043E \u0441\u0447\u0451\u0442\u0443.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N86\" ObjectType=\"TABLE\" BriefText=\"\u041E\u043F\u0435\u0440\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0435 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B \u0434\u043B\u044F \u0440\u0430\u0441\u0447\u0451\u0442\u0430 \u0442\u0430\u0440\u0438\u0444\u043E\u0432 \u043F\u043E \u0441\u0447\u0451\u0442\u0443.\" Ownership=\"1\"/>\n      <ObjectRef ID=\"N89\" ObjectType=\"TABLE\" BriefText=\"\u0410\u043D\u0430\u043B\u0438\u0442\u0438\u043A\u0430 \u043F\u043E \u0443\u0447\u0435\u0442\u043D\u043E\u043C\u0443 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0443\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N90\" ObjectType=\"TABLE\" BriefText=\"\u041D\u0430\u043B\u043E\u0433\u043E\u0432\u0430\u044F \u0431\u0430\u0437\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"N91\" ObjectType=\"TABLE\" BriefText=\"\u0418\u0441\u0442\u043E\u0440\u0438\u044F \u043F\u0440\u0438\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u043D\u0430\u043B\u043E\u0433\u043E\u0432\u044B\u0445 \u0432\u044B\u0447\u0435\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"O66\" ObjectType=\"TABLE\" BriefText=\"\u041A\u043E\u043F\u0438\u044F T66\" Ownership=\"0\"/>\n      <ObjectRef ID=\"P01\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0438\u043F \u043E\u0431\u044A\u0435\u043A\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"P02\" ObjectType=\"TABLE\" BriefText=\"\u0410\u0442\u0440\u0438\u0431\u0443\u0442 \u0442\u0438\u043F\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"P04\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u044F \u043E\u0431\u044A\u0435\u043A\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"P05\" ObjectType=\"TABLE\" BriefText=\"\u0421\u0432\u044F\u0437\u044C \u043D\u0430 \u0434\u0438\u0430\u0433\u0440\u0430\u043C\u043C\u0435\" Ownership=\"0\"/>\n      <ObjectRef ID=\"P06\" ObjectType=\"TABLE\" BriefText=\"\u0423\u0437\u0435\u043B \u0434\u0438\u0430\u0433\u0440\u0430\u043C\u043C\u044B\" Ownership=\"0\"/>\n      <ObjectRef ID=\"P07\" ObjectType=\"TABLE\" BriefText=\"\u0414\u043E\u043C\u0435\u043D\u044B\" Ownership=\"0\"/>\n      <ObjectRef ID=\"P08\" ObjectType=\"TABLE\" BriefText=\"\u041C\u0435\u0442\u043E\u0434\u044B \u0442\u0438\u043F\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"P09\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0435\u0440\u0435\u0445\u043E\u0434\u044B \u0442\u0438\u043F\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"P10\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0438\u043F\u043E\u0432\u044B\u0435 \u043C\u0435\u043D\u044E\" Ownership=\"0\"/>\n      <ObjectRef ID=\"P11\" ObjectType=\"TABLE\" BriefText=\"\u041C\u0435\u043D\u044E \u0442\u0438\u043F\u043E\u0432\u044B\u0445 \u043E\u0431\u044A\u0435\u043A\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"P12\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0438\u043F\u043E\u0432\u044B\u0435 \u043C\u0435\u043D\u044E \u0434\u043B\u044F \u0441\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u044F \u043E\u0431\u044A\u0435\u043A\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"P13\" ObjectType=\"TABLE\" BriefText=\"\u041E\u043F\u0438\u0441\u0430\u043D\u0438\u0435 \u0442\u0430\u0431\u043B\u0438\u0446 \u0411\u0414\" Ownership=\"0\"/>\n      <ObjectRef ID=\"P14\" ObjectType=\"TABLE\" BriefText=\"\u041E\u043F\u0438\u0441\u0430\u043D\u0438\u0435 \u043F\u043E\u043B\u0435\u0439 \u0442\u0430\u0431\u043B\u0438\u0446\u044B \u0431\u0430\u0437\u044B \u0434\u0430\u043D\u043D\u044B\u0445\" Ownership=\"0\"/>\n      <ObjectRef ID=\"P15\" ObjectType=\"TABLE\" BriefText=\"\u041E\u0431\u044A\u0435\u043A\u0442\u044B \u0441 XML \u043F\u0440\u0435\u0434\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u0438\u0435\u043C \u0430\u0442\u0442\u0440\u0438\u0431\u0443\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"P16\" ObjectType=\"TABLE\" BriefText=\"\u0423\u0437\u043B\u044B \u0434\u0435\u0440\u0435\u0432\u0430 \u0434\u0435\u0440\u0435\u0432\u0430 \u0432\u044B\u0431\u043E\u0440\u0430 \u043E\u0431\u044A\u0435\u043A\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"P17\" ObjectType=\"TABLE\" BriefText=\"TypicalPhaseBody\" Ownership=\"0\"/>\n      <ObjectRef ID=\"P18\" ObjectType=\"TABLE\" BriefText=\"Components\" Ownership=\"0\"/>\n      <ObjectRef ID=\"P19\" ObjectType=\"TABLE\" BriefText=\"\u0421\u0432\u044F\u0437\u0438 \u0434\u043B\u044F \u0442\u0438\u043F\u043E\u0432\u044B\u0445 \u043E\u0431\u044A\u0435\u043A\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"P20\" ObjectType=\"TABLE\" BriefText=\"\u041F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u0441\u043A\u0438\u0435 \u043D\u0430\u0441\u0442\u043E\u0439\u043A\u0438 \u0434\u043B\u044F \u044D\u0442\u0430\u043F\u043E\u0432 \u043D\u0430 Xaml\" Ownership=\"0\"/>\n      <ObjectRef ID=\"P22\" ObjectType=\"TABLE\" BriefText=\"\u041F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u0441\u043A\u0438\u0435 WPF \u0442\u0435\u043C\u044B\" Ownership=\"0\"/>\n      <ObjectRef ID=\"P23\" ObjectType=\"TABLE\" BriefText=\"\u041F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u0441\u043A\u0438\u0435 \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438 WPF\" Ownership=\"0\"/>\n      <ObjectRef ID=\"P24\" ObjectType=\"TABLE\" BriefText=\"WPF \u0421\u0442\u0438\u043B\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"P25\" ObjectType=\"TABLE\" BriefText=\"\u041D\u0430\u0431\u043E\u0440 \u043F\u0440\u0435\u0434\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u0438\u0439 \u0434\u043B\u044F \u043E\u0431\u044A\u0435\u043A\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Q03\" ObjectType=\"TABLE\" BriefText=\"StopListEntryName Parsed\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Q04\" ObjectType=\"TABLE\" BriefText=\"StoplistEntryName Parsed\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Q06\" ObjectType=\"TABLE\" BriefText=\"StoplistEntityBirthdate Secondary\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Q13\" ObjectType=\"TABLE\" BriefText=\"StoplistEntityPassportRange Secondary\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Q31\" ObjectType=\"TABLE\" BriefText=\"N31 Secondary\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Q69\" ObjectType=\"TABLE\" Ownership=\"0\"/>\n      <ObjectRef ID=\"R02\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440 \u043E\u0442\u0447\u0435\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"R03\" ObjectType=\"TABLE\" BriefText=\"ReportParameterRelation\" Ownership=\"0\"/>\n      <ObjectRef ID=\"R04\" ObjectType=\"TABLE\" BriefText=\"Report\" Ownership=\"0\"/>\n      <ObjectRef ID=\"R05\" ObjectType=\"TABLE\" BriefText=\"\u0424\u043E\u0440\u043C\u0430 \u043E\u0442\u0447\u0435\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"R06\" ObjectType=\"TABLE\" BriefText=\"ReportBankProperties\" Ownership=\"0\"/>\n      <ObjectRef ID=\"R07\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0440\u0438\u0432\u044F\u0437\u043A\u0430 \u043E\u0431\u0449\u0435\u0433\u043E \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u0430 \u043A \u043E\u0442\u0447\u0435\u0442\u0443\" Ownership=\"0\"/>\n      <ObjectRef ID=\"R08\" ObjectType=\"TABLE\" BriefText=\"\u041A\u043E\u043B\u043E\u043D\u043A\u0438 \u043E\u0442\u0447\u0435\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"R09\" ObjectType=\"TABLE\" BriefText=\"\u0412\u044B\u043F\u0438\u0441\u043A\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"R11\" ObjectType=\"TABLE\" BriefText=\"\u041E\u043F\u0438\u0441\u0430\u043D\u0438\u0435 \u043F\u0435\u0440\u0435\u0445\u043E\u0434\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"R12\" ObjectType=\"TABLE\" BriefText=\"SaveUserSetting\" Ownership=\"0\"/>\n      <ObjectRef ID=\"R13\" ObjectType=\"TABLE\" BriefText=\"MappingHeader\" Ownership=\"0\"/>\n      <ObjectRef ID=\"R14\" ObjectType=\"TABLE\" BriefText=\"Mapping\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S00\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0441\u0438\u0441\u0442\u0435\u043C\u043D\u044B\u0445 \u0438 \u0442\u0435\u0445\u043D\u043E\u043B\u043E\u0433\u0438\u0447\u0435\u043A\u0438\u0445 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S01\" ObjectType=\"TABLE\" BriefText=\"\u041E\u0441\u043D\u043E\u0432\u043D\u044B\u0435 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u0444\u0438\u043D\u0430\u043D\u0441\u043E\u0432\u044B\u0445 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S03\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0435\u0446\u0438\u0444\u0438\u0447\u0435\u0441\u043A\u0438\u0435 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u0444\u0438\u043D\u0430\u043D\u0441\u043E\u0432\u044B\u0445 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S04\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u0444\u0430\u0439\u043B\u043E\u0432 \u043F\u043E \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0435\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S05\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0441\u0432\u044F\u0437\u0438 \u0432\u043E\u0437\u0432\u0440\u0430\u0442\u043E\u0432 \u043F\u043E\u043A\u0443\u043F\u043E\u043A \u0441 \u043E\u0440\u0438\u0433\u0438\u043D\u0430\u043B\u044C\u043D\u044B\u043C\u0438 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u044F\u043C\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S07\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u043F\u0430\u043A\u0435\u0442\u0430 \u043F\u043E \u043F\u0440\u0438\u0435\u043C\u0443\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S09\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u0444\u0430\u0439\u043B\u043E\u0432 \u043F\u043E \u043F\u0440\u0438\u0435\u043C\u0443\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S10\" ObjectType=\"TABLE\" BriefText=\"\u0421\u0432\u044F\u0437\u043A\u0430 \u043C\u0435\u0436\u0434\u0443 \u0442\u0440\u0430\u043D\u0437\u0430\u043A\u0446\u0438\u044F\u043C\u0438 \u043F\u043E \u043A\u043E\u043C\u0438\u0441\u0441\u0438\u044F\u043C (FeeCollection) \u0438 \u0444\u0438\u043D\u0430\u043D\u0441\u043E\u0432\u044B\u043C\u0438 \u043B\u0438\u0431\u043E \u0430\u0432\u0442\u043E\u0440\u0438\u0437\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u043C\u0438 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u044F\u043C\u0438 \u0443\u0447\u0442\u0435\u043D\u043D\u044B\u043C\u0438 \u0432 \u0441\u0443\u043C\u043C\u0430\u0445 \u043A\u043E\u043C\u0438\u0441\u0441\u0438\u0439.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S16\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u044F \u0438\u0441\u0445\u043E\u0434\u043D\u043E\u0433\u043E \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430 \u043F\u043E \u043A\u0430\u0440\u0442\u043E\u0447\u043D\u043E\u0439 \u0442\u0440\u0430\u043D\u0437\u0430\u043A\u0446\u0438\u0438 \u0434\u043B\u044F \u043F\u0440\u043E\u0432\u0435\u0434\u0435\u043D\u0438\u044F \u0443\u0447\u0435\u0442\u0430 \u0432 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0443\u044E\u0449\u0435\u043C \u0440\u0430\u0441\u0447\u0435\u0442\u043D\u043E\u043C \u0430\u0433\u0435\u043D\u0442\u0435.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S17\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0441\u0432\u044F\u0437\u0435\u0439 \u043A\u0430\u0440\u0442\u043E\u0447\u043D\u044B\u0445 \u0442\u0440\u0430\u043D\u0437\u0430\u043A\u0446\u0438\u0439 \u0441 \u043A\u043B\u0438\u0440\u0438\u043D\u0433\u043E\u0432\u044B\u043C\u0438 \u043F\u0430\u043A\u0435\u0442\u0430\u043C\u0438 \u0441\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u043C\u0438 \u043F\u0440\u043E\u0446\u0435\u0441\u0441\u043E\u0440\u043E\u043C.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S18\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0441\u0432\u044F\u0437\u0438 \u043A\u0430\u0440\u0442\u043E\u0447\u043D\u044B\u0445 \u0442\u0440\u0430\u043D\u0437\u0430\u043A\u0446\u0438\u0439 \u0441 \u0441\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u043C\u0438 \u043F\u0440\u043E\u0446\u0435\u0441\u0441\u043E\u0440\u043E\u043C c\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u044F\u043C\u0438 Detailed Positions.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S19\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0441\u0432\u044F\u0437\u0438 \u0442\u0440\u0430\u043D\u0437\u0430\u043A\u0446\u0438\u0439 \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u043D\u044B\u0445 \u0432 \u0441\u043E\u0441\u0442\u0430\u0432\u0435 \u0432\u0445\u043E\u0434\u044F\u0449\u0438\u0445 \u0444\u0430\u0439\u043B\u043E\u0432 \u0438\u0437 \u0432\u043D\u0435\u0448\u043D\u0435\u0433\u043E \u0420\u0410\u0426 \u0441 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u044F\u043C\u0438 Detailed Positions.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S38\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u0440\u0438\u0435\u043C\u0430 \u0442\u0435\u043A\u0441\u0442\u043E\u0432\u044B\u0445 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S39\" ObjectType=\"TABLE\" BriefText=\"\u041E\u0431\u0449\u0438\u0435 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439 \u0432 \u043F\u0430\u043A\u0435\u0442\u0435 \u043F\u043E \u0432\u044B\u0445\u043E\u0434\u0443\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S42\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u0440\u0438\u0435\u043C\u0430 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u043E\u0432 Reject-\u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S43\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u043E\u0432 \u043F\u0440\u0438\u043D\u044F\u0442\u044B\u0445 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439 Detailed Positions Details\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S44\" ObjectType=\"TABLE\" BriefText=\"T\u0430\u0431\u043B\u0438\u0446\u0430 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439 \u0430\u0432\u0442\u043E\u0440\u0438\u0437\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0445 \u0432\u043E\u0437\u0432\u0440\u0430\u0442\u043E\u0432 AuthReversalMessData\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S45\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0438 Reject-\u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S47\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u043E\u0432 \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0438 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439 Detailed Position Details\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S51\" ObjectType=\"TABLE\" BriefText=\"\u0410\u0432\u0442\u043E\u0440\u0438\u0437\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0435 \u043E\u0442\u043A\u0430\u0437\u044B\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S52\" ObjectType=\"TABLE\" BriefText=\"\u041E\u0441\u043D\u043E\u0432\u043D\u044B\u0435 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u0430\u0432\u0442\u043E\u0440\u0438\u0437\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0445 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439 Issuer\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S53\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0434\u043E\u043F\u043E\u043B\u043D\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0445 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u043E\u0432 \u0430\u0432\u0442\u043E\u0440\u0438\u0437\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0445 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439 \u043F\u043E \u0441\u043C\u0430\u0440\u0442-\u043A\u0430\u0440\u0442\u0430\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S54\" ObjectType=\"TABLE\" BriefText=\"\u0420\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u043E\u043F\u0435\u0440\u0430\u0442\u0438\u0432\u043D\u043E\u0439 \u0442\u0430\u0431\u043B\u0438\u0446\u044B \u0430\u0432\u0442\u043E\u0440\u0438\u0437\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0445 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439  \u0434\u043B\u044F \u0441\u043C\u0430\u0440\u0442-\u043A\u0430\u0440\u0442 (\u0418\u0441\u0443\u0435\u0440)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S55\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B  \u0430\u0432\u0442\u043E\u0440\u0438\u0437\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0445 \u0438\u043D\u043A\u0440\u0435\u043C\u0435\u043D\u0442\u0430\u043B\u044C\u043D\u044B\u0445 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S69\" ObjectType=\"TABLE\" BriefText=\"\u0421\u0432\u044F\u0437\u044C \u0430\u0432\u0442\u043E\u0440\u0438\u0437\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0445 \u0438 \u0444\u0438\u043D\u0430\u043D\u0441\u043E\u0432\u044B\u0445 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S80\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u0430\u0434\u043C\u0438\u043D\u0438\u0441\u0442\u0440\u0430\u0442\u0438\u0432\u043D\u044B\u0445 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439 \u043F\u043E \u043F\u0440\u0438\u0435\u043C\u0443 ( CopyRequest )\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S82\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0438 \u0430\u0434\u043C\u0438\u043D\u0438\u0441\u0442\u0440\u0430\u0442\u0438\u0432\u043D\u044B\u0445 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439  ( CopyRequestResponse )\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S96\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0435\u0440\u0435\u043A\u043E\u0434\u0438\u0440\u043E\u0432\u043A\u0430 \u0442\u0435\u0440\u043C\u0438\u043D\u0430\u043B\u043E\u0432 \u0432\u043E \u0432\u043D\u0435\u0448\u043D\u0438\u0435 \u0441\u0435\u0442\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S98\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043A\u043E\u0434\u043E\u0432 \u043E\u0431\u0441\u043B\u0443\u0436\u0438\u0432\u0430\u0435\u043C\u044B\u0445 \u0432\u043D\u0435\u0448\u043D\u0438\u0445 \u0441\u0435\u0442\u0435\u0439 \u0442\u0435\u0440\u043C\u0438\u043D\u0430\u043B\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"S99\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u0435\u0440\u0435\u043A\u043E\u0434\u0438\u0440\u043E\u0432\u043A\u0438 \u043A\u043E\u0434\u043E\u0432 \u0442\u0435\u0440\u043C\u0438\u043D\u0430\u043B\u043E\u0432 \u0432\u043D\u0435\u0448\u043D\u0438\u0445 \u0441\u0435\u0442\u0435\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T01\" ObjectType=\"TABLE\" BriefText=\"\u041D\u0430\u0441\u0442\u0440\u043E\u0435\u0447\u043D\u0430\u044F \u0442\u0430\u0431\u043B\u0438\u0446\u0430 \u0432\u0435\u0434\u0435\u043D\u0438\u044F \u043F\u0440\u043E\u0442\u043E\u043A\u043E\u043B\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T02\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0432\u0435\u0434\u0435\u043D\u0438\u044F \u043F\u0440\u043E\u0442\u043E\u043A\u043E\u043B\u0430.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T03\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0432\u043B\u043E\u0436\u0435\u043D\u043D\u043E\u0441\u0442\u0438 \u0440\u043E\u043B\u0435\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T04\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0440\u0430\u0432\u0430 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u043E\u043D\u0438\u0441\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T05\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043E\u043F\u0435\u0440\u0430\u0442\u043E\u0440\u043E\u0432 \u0441\u0438\u0441\u0442\u0435\u043C\u044B\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T06\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A \u0442\u0438\u043F\u043E\u0432 \u0443\u0447\u0435\u0442\u043D\u044B\u0445 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T07\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u0442\u0438\u043F\u043E\u0432\u043E\u0439 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T08\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u0443\u0441\u043B\u043E\u0432\u0438\u0439 \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u0438\u0445 \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u043E\u0432 \u0434\u043B\u044F \u0444\u0438\u0437\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u043B\u0438\u0446.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T09\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0445\u0440\u0430\u043D\u0435\u043D\u0438\u044F \u0434\u043E\u043F\u043E\u043B\u043D\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0445 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u043E\u0432 \u0446\u0435\u043D\u043D\u043E\u0441\u0442\u0435\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T10\" ObjectType=\"TABLE\" BriefText=\"\u041D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438 \u0434\u043B\u044F \u043F\u0440\u043E\u0446\u0435\u0434\u0443\u0440\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T11\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0438\u043F\u043E\u0432\u044B\u0435 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T12\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0438\u043F\u043E\u0432\u044B\u0435 \u044D\u0442\u0430\u043F\u044B \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T13\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043E\u0441\u0442\u0430\u0432 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438. \u041E\u043F\u0438\u0441\u044B\u0432\u0430\u0435\u0442 \u043A\u0430\u043A\u0438\u0435 \u0442\u0438\u043F\u043E\u0432\u044B\u0435 \u044D\u0442\u0430\u043F\u044B \u0432\u0445\u043E\u0434\u044F\u0442 \u0432 \u0441\u043E\u0441\u0442\u0430\u0432 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T14\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0440\u0438\u0432\u044F\u0437\u043A\u0430 \u0442\u0438\u043F\u043E\u0432\u044B\u0445 \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u0438\u0445 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0439 \u043A \u043A\u043E\u043D\u0441\u0442\u0430\u043D\u0442\u043D\u044B\u043C \u0438\u043C\u0435\u043D\u0430\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T15\" ObjectType=\"TABLE\" BriefText=\"\u0421\u0432\u044F\u0437\u043A\u0430 \u0442\u0438\u043F\u043E\u0432\u044B\u0445 \u044D\u0442\u0430\u043F\u043E\u0432 \u0441 \u043A\u043E\u043D\u0441\u0442\u0430\u043D\u0442\u043D\u044B\u043C\u0438 \u0433\u0440\u0443\u043F\u043F\u043E\u0432\u044B\u043C\u0438 \u0438\u043C\u0435\u043D\u0430\u043C\u0438 \u0441\u0447\u0435\u0442\u043E\u0432.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T16\" ObjectType=\"TABLE\" BriefText=\"ProfileSetting\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T17\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043E\u0441\u0442\u0430\u0432 \u0444\u0443\u043D\u043A\u0446\u0438\u043E\u043D\u0430\u043B\u044C\u043D\u043E\u0441\u0442\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T18\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0432\u0438\u0434\u043E\u0432 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0439 \u043F\u043E \u0418\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u0438 117-\u0418.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T19\" ObjectType=\"TABLE\" BriefText=\"\u041A\u0430\u043B\u0435\u043D\u0434\u0430\u0440\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T20\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430  \u043E\u043F\u0438\u0441\u0430\u043D\u0438\u044F \u0440\u0430\u0431\u043E\u0447\u0438\u0445 \u043C\u0435\u0441\u0442\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T21\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0440\u0435\u0433\u0438\u0441\u0442\u0440\u043E\u0432 \u0434\u043B\u044F \u0445\u0440\u0430\u043D\u0435\u043D\u0438\u044F \u0446\u0435\u043D\u043D\u043E\u0441\u0442\u0435\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T22\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430  \u0440\u0430\u0437\u0440\u0435\u0448\u0435\u043D\u043D\u044B\u0445 \u0432\u043E\u0437\u043C\u043E\u0436\u043D\u043E\u0441\u0442\u0435\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T23\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0438\u0441\u043E\u043A \u0434\u043E\u043B\u0436\u043D\u043E\u0441\u0442\u0435\u0439 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T24\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043D\u0430\u0441\u0442\u0440\u043E\u0435\u043A \u0440\u0435\u0433\u0438\u0441\u0442\u0440\u043E\u0432 \u0434\u043B\u044F \u0441\u0440\u0435\u0434\u0441\u0442\u0432 \u0445\u0440\u0430\u043D\u0435\u043D\u0438\u044F \u0446\u0435\u043D\u043D\u043E\u0441\u0442\u0435\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T25\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430  \u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u0438 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T26\" ObjectType=\"TABLE\" BriefText=\"\u0414\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u044B\u0435 \u043F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u044F \u0440\u0430\u0431\u043E\u0442\u044B\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T27\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0445\u0440\u0430\u043D\u0435\u043D\u0438\u044F \u0442\u0438\u043F\u043E\u0432 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432 \u043A\u043B\u0438\u0435\u043D\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T28\" ObjectType=\"TABLE\" BriefText=\"\u0412\u043D\u0443\u0442\u0440\u0435\u043D\u043D\u044F\u044F \u0441\u0442\u0440\u0443\u043A\u0442\u0443\u0440\u0430 \u0431\u0430\u043D\u043A\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T29\" ObjectType=\"TABLE\" BriefText=\"\u041E\u043F\u0438\u0441\u0430\u043D\u0438\u0435 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u043E\u0432 \u043A\u043E\u043C\u043C\u0443\u043D\u0430\u043B\u044C\u043D\u044B\u0445 \u043F\u043B\u0430\u0442\u0435\u0436\u0435\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T30\" ObjectType=\"TABLE\" BriefText=\"\u0413\u0440\u0443\u043F\u043F\u044B \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u0438\u0445 \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u043E\u0432.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T31\" ObjectType=\"TABLE\" BriefText=\"\u041E\u0431\u0449\u0438\u0435 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u0438\u0445 \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u043E\u0432 (\u0442\u0438\u043F\u043E\u0432\u044B\u0445 \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u043E\u0432).\" Ownership=\"1\"/>\n      <ObjectRef ID=\"T32\" ObjectType=\"TABLE\" BriefText=\"\u0414\u043E\u043F\u043E\u043B\u043D\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0435 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u0438\u0445 \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u043E\u0432 (\u0442\u0438\u043F\u043E\u0432\u044B\u0445 \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u043E\u0432) \u043F\u043E \u0443\u0441\u043B\u0443\u0433\u0430\u043C, \u0441\u0432\u044F\u0437\u0430\u043D\u043D\u044B\u043C \u0441 \u0434\u0435\u043F\u043E\u0437\u0438\u0442\u0430\u043C\u0438.\" Ownership=\"1\"/>\n      <ObjectRef ID=\"T33\" ObjectType=\"TABLE\" BriefText=\"\u0414\u043E\u043F\u043E\u043B\u043D\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0435 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u0438\u0445 \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u043E\u0432 (\u0442\u0438\u043F\u043E\u0432\u044B\u0445 \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u043E\u0432) \u043F\u043E \u0443\u0441\u043B\u0443\u0433\u0430\u043C, \u0441\u0432\u044F\u0437\u0430\u043D\u043D\u044B\u043C \u0441 \u043A\u0440\u0435\u0434\u0438\u0442\u0430\u043C\u0438.\" Ownership=\"1\"/>\n      <ObjectRef ID=\"T34\" ObjectType=\"TABLE\" BriefText=\"\u0424\u043E\u0440\u043C\u044B \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432, \u043F\u0435\u0447\u0430\u0442\u0430\u044E\u0449\u0438\u0445\u0441\u044F \u043F\u0440\u0438 \u043E\u0442\u043A\u0440\u044B\u0442\u0438\u0438 \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u0430 \u0432 \u0440\u0430\u043C\u043A\u0430\u0445 \u0434\u0430\u043D\u043D\u043E\u0433\u043E \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u043E\u0433\u043E \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u0430.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T35\" ObjectType=\"TABLE\" BriefText=\"\u0411\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u0438\u0435 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438, \u0440\u0430\u0437\u0440\u0435\u0448\u0435\u043D\u043D\u044B\u0435 \u0434\u043B\u044F \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u0438\u0445 \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u043E\u0432.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T36\" ObjectType=\"TABLE\" BriefText=\"\u0413\u0440\u0443\u043F\u043F\u043E\u0432\u044B\u0435 \u0438\u043C\u0435\u043D\u0430 \u0441\u0447\u0435\u0442\u043E\u0432, \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0435\u043C\u044B\u0435 \u0432 \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u0438\u0445 \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u0430\u0445.\" Ownership=\"1\"/>\n      <ObjectRef ID=\"T37\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043E\u0441\u043D\u043E\u0432\u043D\u044B\u0445 \u0441\u0445\u0435\u043C \u043D\u0430\u0447\u0438\u0441\u043B\u0435\u043D\u0438\u044F \u043F\u043E \u0441\u0447\u0435\u0442\u0430\u043C \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u043E\u0433\u043E \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u0430.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T38\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0443\u0441\u043B\u043E\u0432\u0438\u0439 \u0440\u0430\u0441\u0447\u0451\u0442\u0430 \u0441\u0443\u043C\u043C\u044B \u043F\u0435\u0440\u0438\u043E\u0434\u0438\u0447\u0435\u0441\u043A\u043E\u0433\u043E \u043F\u043B\u0430\u0442\u0435\u0436\u0430 \u0434\u043B\u044F \u043F\u043E\u0433\u0430\u0448\u0435\u043D\u0438\u044F \u0441\u0441\u0443\u0434\u043D\u043E\u0439 \u0437\u0430\u0434\u043E\u043B\u0436\u0435\u043D\u043D\u043E\u0441\u0442\u0438 \u0432 \u043A\u0440\u0435\u0434\u0438\u0442\u043D\u044B\u0445 \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u0430\u0445.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T39\" ObjectType=\"TABLE\" BriefText=\"\u0420\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u044F \u0442\u0438\u043F\u043E\u0432 \u0430\u0434\u0440\u0435\u0441\u043E\u0432 \u043E\u0431\u044A\u0435\u043A\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T40\" ObjectType=\"TABLE\" BriefText=\"\u0421\u0445\u0435\u043C\u044B \u043D\u0430\u0447\u0438\u0441\u043B\u0435\u043D\u0438\u0439.\" Ownership=\"1\"/>\n      <ObjectRef ID=\"T41\" ObjectType=\"TABLE\" BriefText=\"\u041C\u0435\u0442\u043E\u0434\u044B \u043D\u0430\u0447\u0438\u0441\u043B\u0435\u043D\u0438\u0439 \u043F\u0440\u043E\u0446\u0435\u043D\u0442\u043E\u0432.\" Ownership=\"1\"/>\n      <ObjectRef ID=\"T42\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0441\u0442\u0430\u0432\u043E\u043A \u0434\u043B\u044F \u0441\u0445\u0435\u043C \u043D\u0430\u0447\u0438\u0441\u043B\u0435\u043D\u0438\u044F \u043F\u0440\u043E\u0446\u0435\u043D\u0442\u043E\u0432.\" Ownership=\"1\"/>\n      <ObjectRef ID=\"T43\" ObjectType=\"TABLE\" BriefText=\"\u041D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438 \u0442\u0438\u043F\u043E\u0432\u044B\u0445 \u0433\u0440\u0443\u043F\u043F \u043A\u0443\u0440\u0441\u043E\u0432\u044B\u0445 \u0441\u0442\u0430\u0432\u043E\u043A\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T44\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u0440\u0438\u0432\u044F\u0437\u043A\u0438 \u0441\u0445\u0435\u043C \u0440\u0430\u0441\u0447\u0451\u0442\u0430 \u0442\u0430\u0440\u0438\u0444\u043E\u0432 \u043A \u0441\u0447\u0435\u0442\u0430\u043C \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u043E\u0433\u043E \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u0430.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T45\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u0430\u0440 \u0432\u0430\u043B\u044E\u0442 \u0434\u043B\u044F \u0437\u0430\u0432\u0435\u0434\u0435\u043D\u0438\u044F \u043A\u0443\u0440\u0441\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T46\" ObjectType=\"TABLE\" BriefText=\"\u041D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438 \u0433\u0440\u0443\u043F\u043F \u043A\u0443\u0440\u0441\u043E\u0432\u044B\u0445 \u0441\u0442\u0430\u0432\u043E\u043A\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T47\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u0435\u0440\u0438\u043E\u0434\u043E\u0432 \u043F\u043E\u0433\u0430\u0448\u0435\u043D\u0438\u044F \u043E\u0441\u043D\u043E\u0432\u043D\u043E\u0439 \u0437\u0430\u0434\u043E\u043B\u0436\u0435\u043D\u043D\u043E\u0441\u0442\u0438 \u043F\u043E \u043A\u0440\u0435\u0434\u0438\u0442\u043D\u044B\u043C \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u0438\u043C \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u0430\u043C.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T48\" ObjectType=\"TABLE\" BriefText=\"\u041D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0430 \u043F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u0438 \u043F\u043E\u0433\u0430\u0448\u0435\u043D\u0438\u0439 \u043F\u043E \u0441\u0447\u0435\u0442\u0430\u043C \u043A\u0440\u0435\u0434\u0438\u0442\u043D\u043E\u0433\u043E \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u043E\u0433\u043E \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u0430.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T49\" ObjectType=\"TABLE\" BriefText=\"\u0428\u0430\u0431\u043B\u043E\u043D\u044B \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u043E\u0432 \u043A\u043E\u043C\u043C\u0443\u043D\u0430\u043B\u044C\u043D\u044B\u0445 \u043F\u043B\u0430\u0442\u0435\u0436\u0435\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T50\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0442\u0438\u043F\u043E\u0432\u044B\u0445 \u0434\u043B\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0445 \u043F\u043E\u0440\u0443\u0447\u0435\u043D\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T51\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A \u0430\u043D\u0430\u043B\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u043F\u0440\u0438\u0437\u043D\u0430\u043A\u043E\u0432 \u0441\u0447\u0435\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T52\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u0440\u0438\u0432\u044F\u0437\u043A\u0438 \u0441\u0445\u0435\u043C \u0440\u0430\u0441\u0447\u0451\u0442\u0430 \u043F\u0440\u043E\u0446\u0435\u043D\u0442\u043E\u0432/\u0442\u0430\u0440\u0438\u0444\u043E\u0432 \u043A \u0442\u0438\u043F\u0430\u043C \u0442\u0430\u0440\u0438\u0444\u043E\u0432 \u043F\u043E \u0441\u0447\u0451\u0442\u0443.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T53\" ObjectType=\"TABLE\" BriefText=\"\u0413\u0440\u0443\u043F\u043F\u044B \u0441\u0447\u0435\u0442\u043E\u0432 \u0441\u0432\u043E\u0434\u043D\u043E\u0433\u043E \u0443\u0447\u0435\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T54\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0441\u0447\u0435\u0442\u0447\u0438\u043A\u043E\u0432 (SEQUENCE)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T55\" ObjectType=\"TABLE\" BriefText=\"\u041A\u0440\u0438\u0442\u0435\u0440\u0438\u0438 \u043F\u0440\u0438\u0432\u044F\u0437\u043A\u0438 \u0430\u043D\u0430\u043B\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u0441\u0447\u0435\u0442\u043E\u0432 \u043A \u0441\u0447\u0435\u0442\u0430\u043C \u0441\u0432\u043E\u0434\u043D\u043E\u0433\u043E \u0443\u0447\u0435\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T56\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u0434\u043B\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0445 \u043F\u043E\u0440\u0443\u0447\u0435\u043D\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T57\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u0440\u0438\u0432\u044F\u0437\u043A\u0438 \u0433\u0440\u0443\u043F\u043F \u0441\u0447\u0435\u0442\u043E\u0432 \u0441\u0432\u043E\u0434\u043D\u043E\u0433\u043E \u0443\u0447\u0435\u0442\u0430 \u043A \u0442\u0438\u043F\u0430\u043C \u043E\u0431\u044A\u0435\u043A\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T58\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0441\u0432\u044F\u0437\u0435\u0439 \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u0438\u0445 \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u043E\u0432 \u0441 \u043E\u0442\u043D\u043E\u0448\u0435\u043D\u0438\u0435\u043C \u043E\u0441\u043D\u043E\u0432\u043D\u043E\u0439 \u043F\u043E\u0434\u0447\u0438\u043D\u0451\u043D\u043D\u044B\u0439.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T59\" ObjectType=\"TABLE\" BriefText=\"\u0421\u0445\u0435\u043C\u0430 \u0440\u0430\u0437\u043B\u043E\u0436\u0435\u043D\u0438\u044F \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u043E\u0439 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438 \u043D\u0430 \u0443\u0447\u0435\u0442\u043D\u044B\u0435 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T60\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0438\u043F\u043E\u0432\u043E\u0435 \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u043E\u0435 \u0440\u0430\u0441\u043F\u043E\u0440\u044F\u0436\u0435\u043D\u0438\u0435\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T61\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A \u0442\u0438\u043F\u043E\u0432 \u0444\u0438\u043D\u0430\u043D\u0441\u043E\u0432\u044B\u0445 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T62\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0433\u0440\u0443\u043F\u043F \u0442\u0438\u043F\u043E\u0432\u044B\u0445 \u0444\u0438\u043D\u0430\u043D\u0441\u043E\u0432\u044B\u0445 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T63\" ObjectType=\"TABLE\" BriefText=\"\u041A\u0440\u0438\u0442\u0435\u0440\u0438\u0438 \u0434\u043B\u044F \u0433\u0440\u0443\u043F\u043F \u043A\u0443\u0440\u0441\u043E\u0432\u044B\u0445 \u0441\u0442\u0430\u0432\u043E\u043A\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T64\" ObjectType=\"TABLE\" BriefText=\"\u0428\u0430\u0431\u043B\u043E\u043D\u044B \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0439 \u0444\u0438\u043D\u0430\u043D\u0441\u043E\u0432\u044B\u0445 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T65\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A \u0418\u0414 \u0441\u0443\u043C\u043C \u0441\u0445\u0435\u043C\u044B \u0440\u0430\u0437\u043B\u043E\u0436\u0435\u043D\u0438\u044F\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T67\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A \u0418\u0414 \u0441\u0447\u0435\u0442\u043E\u0432 \u0441\u0445\u0435\u043C\u044B \u0440\u0430\u0437\u043B\u043E\u0436\u0435\u043D\u0438\u044F\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T68\" ObjectType=\"TABLE\" BriefText=\"\u041D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0430 \u0441\u043F\u0435\u0446\u0438\u0430\u043B\u044C\u043D\u044B\u0445 \u0440\u0435\u0435\u0441\u0442\u0440\u043E\u0432(\u0432\u044B\u043F\u0438\u0441\u043A\u0430, \u0432\u0430\u043B\u044E\u0442\u043D\u044B\u0435 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T69\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u0435\u0432 \u043D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u043E\u0441\u0442\u0438 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u043E\u043D\u043D\u043E\u0433\u043E \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T70\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u043E\u0432 \u0431\u0430\u043D\u043A\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T71\" ObjectType=\"TABLE\" BriefText=\"\u0420\u0435\u043A\u0432\u0438\u0437\u0438\u0442\u044B \u0431\u0430\u043D\u043A\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T72\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438 \u0442\u0438\u043F\u043E\u0432 \u043A\u043E\u043D\u0442\u0430\u043A\u0442\u043D\u043E\u0439 \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u0438 \u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u0443\u0435\u043C\u044B\u0445 \u0437\u0430 \u043E\u0431\u044A\u0435\u043A\u0442\u043E\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T73\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0448\u0430\u0431\u043B\u043E\u043D\u043E\u0432 \u0432\u044B\u0432\u043E\u0434\u0430 \u0430\u0434\u0440\u0435\u0441\u043E\u0432 \u043E\u0431\u044A\u0435\u043A\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T74\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A \u0441\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0439 \u0434\u043B\u044F \u043A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u0439 \u0446\u0435\u043D\u043D\u043E\u0441\u0442\u0435\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T75\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0432\u0438\u0434\u043E\u0432 \u0446\u0435\u043D\u043D\u043E\u0441\u0442\u0435\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T76\" ObjectType=\"TABLE\" BriefText=\"\u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u0435 \u043D\u043E\u043C\u0438\u043D\u0430\u043B\u043E\u0432 \u0446\u0435\u043D\u043D\u043E\u0441\u0442\u0435\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T77\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0438\u043F\u043E\u0432\u044B\u0435 \u0441\u0432\u043E\u0434\u043D\u044B\u0435 \u043C\u0435\u043C\u043E\u0440\u0438\u0430\u043B\u044C\u043D\u044B\u0435 \u043E\u0440\u0434\u0435\u0440\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T78\" ObjectType=\"TABLE\" BriefText=\"\u041A\u043E\u0434\u044B \u0434\u043B\u044F \u0432\u0435\u0434\u0435\u043D\u0438\u044F \u0440\u0443\u0431\u043B\u0435\u0432\u044B\u0445 \u0441\u0447\u0435\u0442\u043E\u0432 \u043D\u0435\u0440\u0435\u0437\u0438\u0434\u0435\u043D\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T79\" ObjectType=\"TABLE\" BriefText=\"\u041A\u043E\u0434\u044B \u0442\u0435\u0440\u0440\u0438\u0442\u043E\u0440\u0438\u0439 \u043F\u043E \u0421\u041E\u0410\u0422\u041E\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T80\" ObjectType=\"TABLE\" BriefText=\"\u0420\u0430\u0441\u0448\u0438\u0444\u0440\u043E\u0432\u043A\u0430 \u043A\u043E\u043D\u0441\u0442\u0430\u043D\u0442\u043D\u044B\u0445 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T81\" ObjectType=\"TABLE\" BriefText=\"\u0420\u0430\u0441\u0448\u0438\u0444\u0440\u043E\u0432\u043A\u0430 \u043A\u043E\u043D\u0441\u0442\u0430\u043D\u0442\u043D\u044B\u0445 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0439 \u043A\u043E\u043D\u043A\u0440\u0435\u0442\u043D\u043E\u0433\u043E \u0431\u0430\u043D\u043A\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T82\" ObjectType=\"TABLE\" BriefText=\"\u041A\u0430\u043B\u0435\u043D\u0434\u0430\u0440\u044C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T83\" ObjectType=\"TABLE\" BriefText=\"Holidays\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T84\" ObjectType=\"TABLE\" BriefText=\"\u0420\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u044F \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u043E\u0432 \u044E\u0440\u0438\u0434\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u043B\u0438\u0446\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T85\" ObjectType=\"TABLE\" BriefText=\"\u0420\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u0443\u0435\u043C\u044B\u0435 \u043E\u0431\u044A\u0435\u043A\u0442\u044B\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T86\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u0432\u0438\u0434\u043E\u0432 \u0446\u0435\u043D\u043D\u043E\u0441\u0442\u0435\u0439, \u0437\u0430\u0432\u0438\u0441\u044F\u0449\u0438\u0435 \u043E\u0442 \u0438\u0445 \u0441\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u044F\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T87\" ObjectType=\"TABLE\" BriefText=\"\u0420\u0430\u0437\u0440\u0435\u0448\u0435\u043D\u043D\u044B\u0435 \u043A\u0430\u0440\u0442\u043E\u0447\u043D\u044B\u0435 \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B \u0444\u0443\u043D\u043A\u0446\u0438\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0445 \u043E\u0431\u044A\u0435\u043A\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T88\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0438\u0441\u043E\u043A \u043F\u0440\u0438\u0437\u043D\u0430\u043A\u043E\u0432 \u0434\u043B\u044F \u0443\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u044F \u0440\u0430\u0437\u043B\u043E\u0436\u0435\u043D\u0438\u0435\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T89\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0440\u0438\u0432\u044F\u0437\u043A\u0430 \u043F\u0440\u0438\u0437\u043D\u0430\u043A\u043E\u0432 \u0434\u043B\u044F \u0443\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u044F \u0440\u0430\u0437\u043B\u043E\u0436\u0435\u043D\u0438\u0435\u043C \u043A \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u043C \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430\u043C.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T90\" ObjectType=\"TABLE\" BriefText=\"\u0417\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u0430\u043D\u0430\u043B\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u043F\u0440\u0438\u0437\u043D\u0430\u043A\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T91\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0445\u0430\u0440\u0430\u043A\u0442\u0435\u0440\u0438\u0441\u0442\u0438\u043A \u0444\u043E\u0440\u043C\u0430\u0442\u0430 \u043E\u0431\u043C\u0435\u043D\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T92\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0438\u043F\u044B \u0430\u043D\u0430\u043B\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u043F\u0440\u0438\u0437\u043D\u0430\u043A\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T93\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u043E\u0441\u043E\u0431\u044B \u043E\u043F\u0440\u0435\u0434\u0435\u043B\u0435\u043D\u0438\u044F \u0441\u043F\u0438\u0441\u043A\u0430 \u0434\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u044B\u0445 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0439 \u0430\u043D\u0430\u043B\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u043F\u0440\u0438\u0437\u043D\u0430\u043A\u043E\u0432.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T94\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u0440\u0438\u0432\u044F\u0437\u043A\u0438 \u0442\u0438\u043F\u0430 \u0444\u0430\u0439\u043B\u0430 \u043A \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0435 \u043A\u043E\u043D\u0432\u0435\u0440\u0442\u043E\u0440\u0443\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T95\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u0440\u0438\u0432\u044F\u0437\u043A\u0438 \u0434\u043E\u043B\u0436\u043D\u043E\u0441\u0442\u043D\u044B\u0445 \u043B\u0438\u0446 \u0441 \u043F\u0440\u0430\u0432\u043E\u043C \u043F\u043E\u0434\u043F\u0438\u0441\u0438 \u043A \u044E\u0440. \u043B\u0438\u0446\u0443\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T96\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0440\u0438\u0432\u044F\u0437\u043A\u0430 \u043F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u0439 \u043A \u0433\u0440\u0443\u043F\u043F\u0435 \u043A\u0443\u0440\u0441\u043E\u0432\u044B\u0445 \u0441\u0442\u0430\u0432\u043E\u043A\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T97\" ObjectType=\"TABLE\" BriefText=\"\u0434\u043E\u043F\u043E\u043B\u043D\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0435 \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438 \u0434\u043B\u044F \u0437\u0430\u0434\u0430\u043D\u0438\u044F \u043A\u043E\u043D\u0444\u0438\u0433\u0443\u0440\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0445 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T98\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0438\u0441\u043E\u043A \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0439 \u0434\u043B\u044F \u0437\u0430\u0434\u0430\u043D\u0438\u044F \u043A\u043E\u043D\u0444\u0438\u0433\u0443\u0440\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0445 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T99\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0441\u0438\u0441\u0442\u0435\u043C\u043D\u044B\u0445 \u043E\u0448\u0438\u0431\u043E\u043A 3CARD-R\" Ownership=\"0\"/>\n      <ObjectRef ID=\"U01\" ObjectType=\"TABLE\" BriefText=\"CartotekaDocuments\" Ownership=\"0\"/>\n      <ObjectRef ID=\"U98\" ObjectType=\"TABLE\" BriefText=\"UFEBMPaymentDocuments\" Ownership=\"0\"/>\n      <ObjectRef ID=\"W00\" ObjectType=\"TABLE\" BriefText=\"\u041A\u043E\u043D\u0444\u0438\u0433\u0443\u0440\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0435 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u0441\u0435\u0430\u043D\u0441\u0430 \u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"W01\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u043E\u0432 \u0444\u0430\u0439\u043B\u043E\u0432 \u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F\" Ownership=\"0\"/>\n      <ObjectRef ID=\"W02\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u043E\u0432 \u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0445 \u043A\u043B\u0438\u0435\u043D\u0442\u043E\u0432 \u0431\u0430\u043D\u043A\u0430.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"W03\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u043E\u0432 \u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0445 \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u043E\u0432 \u0444\u0438\u0437\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u043B\u0438\u0446.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"W04\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u043E\u0432 \u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0445 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0445 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432 \u043F\u043E \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u0430\u043C \u0444\u0438\u0437\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u043B\u0438\u0446.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"W05\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043D\u043E\u043C\u0435\u0440\u043E\u0432 \u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0445 \u043F\u0440\u0438\u043B\u0438\u043D\u043A\u043E\u0432\u0430\u043D\u043D\u044B\u0445 \u043A\u0430\u0440\u0442.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"W06\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u043E\u0432 \u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0445 \u0430\u0432\u0442\u043E\u0440\u0438\u0437\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0445 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"W07\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0445 \u043E\u0431\u043E\u0440\u043E\u0442\u043E\u0432 \u043F\u043E \u0441\u0447\u0435\u0442\u0430\u043C.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"W08\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u043E\u0432 (\u043D\u043E\u043C\u0435\u0440\u043E\u0432) \u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0445 \u0441\u0447\u0435\u0442\u043E\u0432 \u043F\u043E \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u0430\u043C \u0444\u0438\u0437\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u043B\u0438\u0446.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"W09\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u043E\u0432 \u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0445 \u0444\u0438\u0440\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"W10\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u043E\u0432 \u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0445 \u0442\u0435\u0440\u043C\u0438\u043D\u0430\u043B\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"W11\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430  \u0437\u0430\u0433\u0440\u0443\u0437\u043A\u0438 \u0431\u0438\u043D\u0430\u0440\u043D\u044B\u0445 \u0444\u0430\u0439\u043B\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"W12\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0445 \u0433\u0440\u0430\u0444\u0438\u043A\u043E\u0432 \u043F\u043E\u0433\u0430\u0448\u0435\u043D\u0438\u044F\" Ownership=\"0\"/>\n      <ObjectRef ID=\"W13\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u043E\u0432 \u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0445 \u044E\u0440. \u043B\u0438\u0446\" Ownership=\"0\"/>\n      <ObjectRef ID=\"W14\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u043E\u0432 \u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0445 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u043E\u0432 \u043A\u043E\u043C\u043C\u0443\u043D\u0430\u043B\u044C\u043D\u044B\u0445 \u043F\u043B\u0430\u0442\u0435\u0436\u0435\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"W15\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u043E\u0432 \u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0445 \u0448\u0430\u0431\u043B\u043E\u043D\u043E\u0432 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u043E\u0432 \u043A\u043E\u043C\u043C\u0443\u043D\u0430\u043B\u044C\u043D\u044B\u0445 \u043F\u043B\u0430\u0442\u0435\u0436\u0435\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"W16\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u043E\u0432 \u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0445 \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u043E\u0432 \u044E\u0440. \u043B\u0438\u0446\" Ownership=\"0\"/>\n      <ObjectRef ID=\"W17\" ObjectType=\"TABLE\" BriefText=\"\u041E\u0441\u0442\u0430\u0442\u043A\u0438 \u043F\u043E \u043A\u0430\u0440\u0442\u0430\u043C \u0432 \u0441\u0438\u0441\u0442\u0435\u043C\u0435 BankSoft\" Ownership=\"0\"/>\n      <ObjectRef ID=\"W18\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u043E\u0432 \u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0445 \u043E\u0431\u044A\u0435\u043A\u0442\u043E\u0432 \u0431\u0430\u043D\u043A\u0430.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"X00\" ObjectType=\"TABLE\" BriefText=\"\u041E\u043F\u0438\u0441\u0430\u043D\u0438\u0435 \u043F\u043E\u043B\u0435\u0439 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"X01\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u043E\u0438\u0441\u043A\u0430 \u0437\u0430\u043F\u0440\u043E\u0441\u043E\u0432 \u043F\u0440\u0438 \u043F\u0440\u0438\u0435\u043C\u0435\" Ownership=\"0\"/>\n      <ObjectRef ID=\"X03\" ObjectType=\"TABLE\" BriefText=\"\u041E\u043F\u0438\u0441\u0430\u043D\u0438\u0435 \u043F\u0440\u0438\u043D\u0438\u043C\u0430\u0435\u043C\u044B\u0445 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"X04\" ObjectType=\"TABLE\" BriefText=\"\u041E\u043F\u0438\u0441\u0430\u043D\u0438\u0435 SQL-\u0437\u0430\u043F\u0440\u043E\u0441\u043E\u0432 \u043F\u043E \u043F\u0440\u0438\u0435\u043C\u0443\" Ownership=\"0\"/>\n      <ObjectRef ID=\"X05\" ObjectType=\"TABLE\" BriefText=\"\u041E\u043F\u0438\u0441\u0430\u043D\u0438\u0435 \u0434\u043E\u043F\u043E\u043B\u043D\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0445 \u043F\u043E\u043B\u0435\u0439 \u043F\u043E \u043F\u0440\u0438\u0435\u043C\u0443 \u0434\u043B\u044F UnionCard\" Ownership=\"0\"/>\n      <ObjectRef ID=\"X06\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0432\u044B\u0431\u043E\u0440\u043A\u0438 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439 \u043F\u0440\u0438 \u043F\u0435\u0440\u0435\u0434\u0430\u0447\u0435\" Ownership=\"0\"/>\n      <ObjectRef ID=\"X07\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0444\u043E\u0440\u043C\u0430\u0442\u043E\u0432 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439 \u043F\u0440\u0438 \u043F\u0435\u0440\u0435\u0434\u0430\u0447\u0435\" Ownership=\"0\"/>\n      <ObjectRef ID=\"X08\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0441\u043A\u0440\u0438\u043F\u0442\u043E\u0432 \u0437\u0430\u0433\u0440\u0443\u0437\u043A\u0438 dbf \u0444\u0430\u0439\u043B\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"X10\" ObjectType=\"TABLE\" BriefText=\"\u0414\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B \u0434\u043B\u044F \u043E\u043F\u0438\u0441\u0430\u043D\u0438\u044F \u0438 \u043F\u0440\u0435\u043E\u0431\u0440\u0430\u0437\u043E\u0432\u0430\u043D\u0438\u044F XML-\u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Y01\" ObjectType=\"TABLE\" BriefText=\"\u041E\u043F\u0438\u0441\u0430\u043D\u0438\u0435 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0445 \u0444\u0430\u0439\u043B\u043E\u0432 \u043E\u0442 \u043E\u0440\u0433\u0430\u043D\u0438\u0437\u0430\u0446\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Y02\" ObjectType=\"TABLE\" BriefText=\"\u041E\u043F\u0438\u0441\u0430\u043D\u0438\u0435 \u0442\u0438\u043F\u043E\u0432 \u0432\u0445\u043E\u0434\u043D\u044B\u0445 \u0444\u0430\u0439\u043B\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Y03\" ObjectType=\"TABLE\" BriefText=\"\u041E\u043F\u0438\u0441\u0430\u043D\u0438\u044F \u0430\u043B\u0433\u043E\u0440\u0438\u0442\u043C\u043E\u0432 \u043F\u0440\u0435\u043E\u0431\u0440\u0430\u0437\u043E\u0432\u0430\u043D\u0438\u044F \u0438 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438 \u0434\u0430\u043D\u043D\u044B\u0445\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Y04\" ObjectType=\"TABLE\" BriefText=\"\u041E\u043F\u0438\u0441\u0430\u043D\u0438\u0439 \u043F\u0440\u043E\u0446\u0435\u0434\u0443\u0440 \u0438 \u0444\u0443\u043D\u043A\u0446\u0438\u0439 \u043D\u0430 PL/SQL, \u0430 \u0442\u0430\u043A\u0436\u0435 \u043F\u0440\u043E\u0441\u0442\u044B\u0445 SQL \u0437\u0430\u043F\u0440\u043E\u0441\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Y05\" ObjectType=\"TABLE\" BriefText=\"\u041E\u043F\u0438\u0441\u0430\u043D\u0438\u0435 \u043F\u043E\u043B\u0435\u0439 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0445 \u0444\u0430\u0439\u043B\u043E\u0432 \u043E\u0442 \u043E\u0440\u0433\u0430\u043D\u0438\u0437\u0430\u0446\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Y06\" ObjectType=\"TABLE\" BriefText=\"\u0412\u043E\u0437\u043C\u043E\u0436\u043D\u044B\u0435 \u0442\u0438\u043F\u043E\u0432\u044B\u0435 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438 \u0434\u043B\u044F \u043A\u0430\u0436\u0434\u043E\u0433\u043E \u0448\u043B\u044E\u0437\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Y07\" ObjectType=\"TABLE\" BriefText=\"\u0417\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u043F\u043E\u043B\u0435\u0439 \u043F\u043E \u043F\u043E-\u0443\u043C\u043E\u043B\u0447\u0430\u043D\u0438\u044E\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Y08\" ObjectType=\"TABLE\" BriefText=\"\u041E\u043F\u0438\u0441\u0430\u043D\u0438\u0435 \u0444\u043E\u0440\u043C\u0430\u0442\u043E\u0432 \u043E\u0442\u0432\u0435\u0442\u043D\u043E\u0433\u043E \u0444\u0430\u0439\u043B\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Y10\" ObjectType=\"TABLE\" BriefText=\"\u041F\u043E\u0440\u044F\u0434\u043A\u043E\u0432\u044B\u0439 \u043D\u043E\u043C\u0435\u0440 \u0441 \u043D\u0430\u0447\u0430\u043B\u0430 \u0434\u043D\u044F\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Y11\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u044B \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0438\u044F \u0434\u0430\u043D\u043D\u044B\u0445 \u0434\u043B\u044F \u0432\u0437\u0430\u0438\u043C\u043E\u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F \u0441 \u0432\u043D\u0435\u0448\u043D\u0438\u043C\u0438 \u0441\u0438\u0441\u0442\u0435\u043C\u0430\u043C\u0438.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Y12\" ObjectType=\"TABLE\" BriefText=\"\u0414\u0430\u043D\u043D\u044B\u0435 \u0442\u0430\u0431\u043B\u0438\u0446\u044B \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0438\u044F.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Z01\" ObjectType=\"TABLE\" BriefText=\"\u0415\u0436\u0435\u0434\u043D\u0432\u043D\u044B\u0439 \u0431\u0430\u043B\u0430\u043D\u0441 (TRANSACTION).\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Z02\" ObjectType=\"TABLE\" BriefText=\"\u0412\u0440\u0435\u043C\u0435\u043D\u043D\u0430\u044F \u0442\u0430\u0431\u043B\u0438\u0446\u0430 \u0434\u043B\u044F \u0444\u043E\u0440\u043C\u044B 0409125 (TRANSACTION).\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Z03\" ObjectType=\"TABLE\" BriefText=\"\u041E\u0442\u0447\u0435\u0442\u0430 \u043E \u043F\u0440\u0438\u0431\u044B\u043B\u044F\u0445 \u0438 \u0443\u0431\u044B\u0442\u043A\u0430\u0445 (SESSION)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Z04\" ObjectType=\"TABLE\" BriefText=\"\u0412\u0440\u0435\u043C\u0435\u043D\u043D\u0430\u044F \u0442\u0430\u0431\u043B\u0438\u0446\u0430 \u0434\u043B\u044F \u0441\u043E\u0437\u0434\u0430\u043D\u0438\u044F \u043E\u0442\u0447\u0451\u0442\u0430 \u043E \u0435\u0436\u0451\u0434\u043D\u0435\u0432\u043D\u043E\u043C \u043D\u0430\u0447\u0438\u0441\u043B\u0435\u043D\u0438\u0438 \u043F\u0440\u043E\u0446\u0435\u043D\u0442\u043E\u0432 (TRANSACTION).\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Z05\" ObjectType=\"TABLE\" BriefText=\"\u0418\u0441\u0445\u043E\u0434\u043D\u044B\u0435 \u0434\u0430\u043D\u043D\u044B\u0435 \u043E \u0434\u043E\u0445\u043E\u0434\u0430\u0445, \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u043D\u044B\u0445 \u043A\u043B\u0438\u0435\u043D\u0442\u043E\u043C \u0434\u043B\u044F \u0444\u043E\u0440\u043C\u044B 2-\u041D\u0414\u0424\u041B (TRANSACTION)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Z06\" ObjectType=\"TABLE\" BriefText=\"\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u0434\u043B\u044F \u0444\u0443\u043D\u043A\u0446\u0438\u0439, \u043E\u0442\u0447\u0435\u0442\u043E\u0432 (TRANSACTION)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Z07\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430, \u0445\u0440\u0430\u043D\u044F\u0449\u0430\u044F \u0441\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0435 \u0441\u043F\u0440\u0430\u0432\u043A\u0438 \u043F\u043E \u0444\u043E\u0440\u043C\u0435 2-\u041D\u0414\u0424\u041B \u0432 XML \u0444\u043E\u0440\u043C\u0430\u0442\u0435 \n(SESSION)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Z08\" ObjectType=\"TABLE\" BriefText=\"\u0421\u043F\u0438\u0441\u043E\u043A \u043E\u0431\u044A\u0435\u043A\u0442\u043E\u0432 (SESSION)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Z09\" ObjectType=\"TABLE\" BriefText=\"\u0412\u0440\u0435\u043C\u0435\u043D\u043D\u0430\u044F \u0442\u0430\u0431\u043B\u0438\u0446\u0430 \u0434\u043B\u044F \u0444\u043E\u0440\u043C\u044B 0409118 (TRANSACTION)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Z10\" ObjectType=\"TABLE\" BriefText=\"Changed List (TRANSACTION).\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Z12\" ObjectType=\"TABLE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0441\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0430\u0446\u0438\u0438 (SESSION).\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Z13\" ObjectType=\"TABLE\" BriefText=\"\u041A\u0440\u0430\u0442\u043A\u0430\u044F \u0441\u0442\u0440\u0443\u043A\u0442\u0443\u0440\u0430 \u043C\u0435\u043D\u044E (TRANSACTION)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Z21\" ObjectType=\"TABLE\" BriefText=\"\u0424\u0438\u043D\u0430\u043D\u0441\u043E\u0432\u044B\u0435 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u044F \u043F\u043E \u043A\u0430\u0440\u0442\u0430\u043C \u043D\u0430 \u043C\u043E\u043C\u0435\u043D\u0442 \u0432\u044B\u0433\u0440\u0443\u0437\u043A\u0438 \u043F\u043E\u0447\u0442\u044B (TRANSACTION)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Z22\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u0440\u0430\u0432 \u0434\u043E\u0441\u0442\u0443\u043F\u0430 \u0441\u0435\u0430\u043D\u0441\u0430 (SESSION).\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Z24\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0435\u0445\u043D\u043E\u043B\u043E\u0433\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u0442\u0430\u0431\u043B\u0438\u0446\u0430 \u0443\u0441\u043A\u043E\u0440\u0435\u043D\u0438\u044F \u043E\u0431\u043D\u043E\u0432\u043B\u0435\u043D\u0438\u044F \u043F\u0440\u0430\u0432 (TRANSACTION).\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Z25\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0434\u043B\u044F \u0445\u0440\u0430\u043D\u0435\u043D\u0438\u044F \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442\u043E\u0432 \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u043A\u0438 \u0430\u043D\u0430\u043B\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u043F\u0440\u0438\u0437\u043D\u0430\u043A\u043E\u0432 \u0423\u0414 \u043F\u0440\u0438 \u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0438 \u0441\u0432\u043E\u0434\u043D\u044B\u0445 \u043E\u0440\u0434\u0435\u0440\u043E\u0432. (TRANSACTION)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Z27\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0435\u0445\u043D\u043E\u043B\u043E\u0433\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u0442\u0430\u0431\u043B\u0438\u0446\u0430 \u0434\u043B\u044F \u0440\u0430\u0431\u043E\u0442\u044B \u0441 \u0430\u0434\u0440\u0435\u0441\u0430\u043C\u0438 \u043E\u0431\u044A\u0435\u043A\u0442\u043E\u0432 (TRANSACTION)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Z28\" ObjectType=\"TABLE\" BriefText=\"\u0424\u0438\u043D\u0430\u043D\u0441\u043E\u0432\u044B\u0435 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u044F \u043F\u043E \u043F\u0440\u0438\u043D\u0443\u0434\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0439 \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0435 \u043B\u0438\u043C\u0438\u0442\u043E\u0432 \u043A\u0430\u0440\u0442 \u0432 \u043C\u043E\u043C\u0435\u043D\u0442 \n\u0432\u044B\u0433\u0440\u0443\u0437\u043A\u0438 \u043F\u043E\u0447\u0442\u044B (TRANSACTION)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Z34\" ObjectType=\"TABLE\" BriefText=\"\u0425\u0440\u0430\u043D\u0435\u043D\u0438\u0435 \u043B\u0438\u043C\u0438\u0442\u043E\u0432 \u0438 \u0434\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u044B\u0445 \u043E\u0432\u0435\u0440\u0434\u0440\u0430\u0444\u0442\u043E\u0432 \u043A\u0430\u0440\u0442 \u0432 \u043C\u043E\u043C\u0435\u043D\u0442 \u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F \u043F\u043E\u0447\u0442\u044B (TRANSACTION)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"Z44\" ObjectType=\"TABLE\" BriefText=\"\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u0434\u043B\u044F \u0445\u0440\u0430\u043D\u0435\u043D\u0438\u044F \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442\u043E\u0432 \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u043A\u0438 \u0437\u0430\u043F\u0440\u043E\u0441\u043E\u0432 \u043E\u0442 \u0432\u043D\u0435\u0448\u043D\u0438\u0445 \u0441\u0438\u0441\u0442\u0435\u043C. (SESSION)\" Ownership=\"0\"/>\n    </ObjectRefs>\n    <ObjectRefs ObjectsType=\"VIEW\">\n      <ObjectRef ID=\"P02_RATING\" ObjectType=\"VIEW\" BriefText=\"\u0410\u0442\u0440\u0438\u0431\u0443\u0442\u044B, \u0432\u043B\u0438\u044F\u044E\u0449\u0438\u0435 \u043D\u0430 \u0440\u0435\u0439\u0442\u0438\u043D\u0433 \u043E\u0431\u044A\u0435\u043A\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"P02_RATING_VALUE\" ObjectType=\"VIEW\" BriefText=\"\u0417\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u0430\u0442\u0440\u0438\u0431\u0443\u0442\u043E\u0432 \u0440\u0435\u0439\u0442\u0438\u043D\u0433\u0430 \u043A\u043E\u0440\u0440. \u0441\u0447\u0435\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"T66\" ObjectType=\"VIEW\" BriefText=\"\u041F\u0440\u0435\u0434\u0441\u0442\u0430\u0432\u043B\u044F\u0435\u0442 \u0434\u0430\u043D\u043D\u044B\u0435 \u0438\u0437 F13 \u043A\u0430\u043A T66\" Ownership=\"0\"/>\n      <ObjectRef ID=\"V_N14DIST\" ObjectType=\"VIEW\" BriefText=\"\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"VP01\" ObjectType=\"VIEW\" BriefText=\"\u0412\u0438\u0440\u0442\u0443\u0430\u043B\u044C\u043D\u044B\u0435 \u0442\u0438\u043F\u044B \u043C\u0435\u0442\u0430\u0434\u0430\u043D\u043D\u044B\u0445, \u0441\u043E\u0437\u0434\u0430\u043D\u043D\u044B\u0435 \u0438\u0437 \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u0438\u0445 \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"VP02\" ObjectType=\"VIEW\" BriefText=\"\u0410\u0442\u0440\u0438\u0431\u0443\u0442\u044B \u0432\u0438\u0440\u0442\u0443\u0430\u043B\u044C\u043D\u044B\u0445 \u0442\u0438\u043F\u043E\u0432 \u043C\u0435\u0442\u0430\u0434\u0430\u043D\u043D\u044B\u0445\" Ownership=\"0\"/>\n      <ObjectRef ID=\"VP04\" ObjectType=\"VIEW\" BriefText=\"\u0421\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u044F \u0432\u0438\u0440\u0442\u0443\u0430\u043B\u044C\u043D\u044B\u0445 \u0442\u0438\u043F\u043E\u0432 \u043C\u0435\u0442\u0430\u0434\u0430\u043D\u043D\u044B\u0445\" Ownership=\"0\"/>\n      <ObjectRef ID=\"VP08\" ObjectType=\"VIEW\" BriefText=\"\u041C\u0435\u0442\u043E\u0434\u044B \u0432\u0438\u0440\u0442\u0443\u0430\u043B\u044C\u043D\u044B\u0445 \u0442\u0438\u043F\u043E\u0432 \u043C\u0435\u0442\u0430\u0434\u0430\u043D\u043D\u044B\u0445\" Ownership=\"0\"/>\n      <ObjectRef ID=\"VP09\" ObjectType=\"VIEW\" BriefText=\"\u041F\u0435\u0440\u0435\u0445\u043E\u0434\u044B \u0432\u0438\u0440\u0442\u0443\u0430\u043B\u044C\u043D\u044B\u0445 \u0442\u0438\u043F\u043E\u0432 \u043C\u0435\u0442\u0430\u0434\u0430\u043D\u043D\u044B\u0445\" Ownership=\"0\"/>\n      <ObjectRef ID=\"VP09FULL\" ObjectType=\"VIEW\" BriefText=\"\u041F\u043E\u043B\u043D\u044B\u0439 \u043D\u0430\u0431\u043E\u0440 \u043F\u0435\u0440\u0435\u0445\u043E\u0434\u043E\u0432, \u0441 \u0443\u0447\u0435\u0442\u043E\u043C \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"VP13\" ObjectType=\"VIEW\" BriefText=\"\u0420\u0435\u0430\u043B\u0438\u0437\u0430\u0446\u0438\u0438 \u0432\u0438\u0440\u0442\u0443\u0430\u043B\u044C\u043D\u044B\u0445 \u0442\u0438\u043F\u043E\u0432 \u043C\u0435\u0442\u0430\u0434\u0430\u043D\u043D\u044B\u0445\" Ownership=\"0\"/>\n      <ObjectRef ID=\"VP14\" ObjectType=\"VIEW\" BriefText=\"\u0420\u0435\u0430\u043B\u0438\u0437\u0430\u0446\u0438\u0438 \u0430\u0442\u0440\u0438\u0431\u0443\u0442\u043E\u0432 \u0432\u0438\u0440\u0442\u0443\u0430\u043B\u044C\u043D\u044B\u0445 \u0442\u0438\u043F\u043E\u0432 \u043C\u0435\u0442\u0430\u0434\u0430\u043D\u043D\u044B\u0445\" Ownership=\"0\"/>\n      <ObjectRef ID=\"VP15_XML\" ObjectType=\"VIEW\" BriefText=\"XML-\u043F\u0440\u0435\u0434\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u0438\u0435 \u0434\u0435\u0440\u0435\u0432\u0430 \u0434\u043B\u044F \u0432\u044B\u0433\u0440\u0443\u0437\u043A\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"VP17\" ObjectType=\"VIEW\" BriefText=\"\u0420\u0435\u0430\u043B\u0438\u0437\u0430\u0446\u0438\u0438 \u0442\u0438\u043F\u043E\u0432\u043E\u0433\u043E \u044D\u0442\u0430\u043F\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"VT11_XML\" ObjectType=\"VIEW\" BriefText=\"\u0412\u044C\u044E \u0434\u043B\u044F \u0432\u044B\u0433\u0440\u0443\u0437\u043A\u0438 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"VT12_XML\" ObjectType=\"VIEW\" BriefText=\"XML-\u043F\u0440\u0435\u0434\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u0438\u0435 \u0442\u0438\u043F\u043E\u0432\u043E\u0433\u043E \u044D\u0442\u0430\u043F\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"VT50_XML\" ObjectType=\"VIEW\" BriefText=\"XML-\u043F\u0440\u0435\u0434\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u0438\u0435 \u0430\u043A\u0446\u0438\u0438(\u0431\u043E\u043D\u0443\u0441\u043D\u043E\u0439 \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u044B \u0431\u0430\u043D\u043A\u0430) \u0434\u043B\u044F \u0432\u044B\u0433\u0440\u0443\u0437\u043A\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"V09\" ObjectType=\"VIEW\" BriefText=\"\u041F\u0440\u0435\u0434\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u0438\u0435, \u043E\u043F\u0438\u0441\u044B\u0432\u0430\u044E\u0449\u0435\u0435 \u043F\u043E\u043B\u044F \u0442\u0430\u0431\u043B\u0438\u0446 \u043B\u0438\u043D\u043A\u043E\u0432\u0430\u043D\u043D\u043E\u0439 \u0441\u0445\u0435\u043C\u044B \u043D\u0430\u043A\u043E\u043F\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0433\u043E \u0430\u0440\u0445\u0438\u0432\u0430.\" Ownership=\"0\"/>\n    </ObjectRefs>\n    <ObjectRefs ObjectsType=\"QUERY\">\n      <ObjectRef ID=\"TAD_R04\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 \u0434\u043B\u044F R04 (\u043F\u043E\u0441\u043B\u0435 \u0443\u0434\u0430\u043B\u0435\u043D\u0438\u044F)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TAU_N30OVEX_OPER\" ObjectType=\"QUERY\" BriefText=\"\u041E\u043F\u0435\u0440\u0430\u0442\u043E\u0440\u043D\u044B\u0439 \u0442\u0440\u0438\u0433\u0433\u0435\u0440, \u0432\u044B\u0437\u044B\u0432\u0430\u044E\u0449\u0438\u0439 \u043F\u0440\u043E\u0446\u0435\u0434\u0443\u0440\u0443 \u043C\u043E\u0434\u0438\u0444\u0438\u043A\u0430\u0446\u0438\u0438 \u0433\u0440\u0430\u0444\u0438\u043A\u0430 \u043F\u043E\u0433\u0430\u0448\u0435\u043D\u0438\u044F \u043F\u0440\u0438 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0438 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0439 \u043F\u043E\u043B\u044F N30OVEX \u0440\u0430\u0431\u043E\u0442\u0430\u0435\u0442 \u0432 \u043F\u0430\u0440\u0435 \u0441 \u0442\u0440\u0438\u0433\u0433\u0435\u0440\u043E\u043C TBU_N30OVEX (\u043F\u043E\u0441\u043B\u0435 \u043D\u0435\u0433\u043E)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TBI_B31\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 \u043D\u0430 \u0437\u0430\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0435 B31OBID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TBI_B54\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 \u043D\u0430 \u0437\u0430\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0435 B54OBID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TBI_C51\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 \u0434\u043B\u044F \u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F \u0443\u043D\u0438\u043A\u0430\u043B\u044C\u043D\u043E\u0433\u043E \u043A\u043B\u044E\u0447\u0430 \u0437\u0430\u043F\u0438\u0441\u0438 (C51CPCI) \u0432 \u0442\u0430\u0431\u043B\u0438\u0446\u0435 C51.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TBI_C53\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 \u0434\u043B\u044F \u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F \u0443\u043D\u0438\u043A\u0430\u043B\u044C\u043D\u043E\u0433\u043E \u043A\u043B\u044E\u0447\u0430 \u0437\u0430\u043F\u0438\u0441\u0438 (C53BRRI) \u0432 \u0442\u0430\u0431\u043B\u0438\u0446\u0435 C53.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TBI_I07\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0435\u0440 \u043D\u0430 \u043F\u043E\u043B\u0435 i07obid\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TBI_I27\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0435\u0440 \u043D\u0430 \u043F\u043E\u043B\u0435 i27obid\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TBI_N11\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 \u043D\u0430 \u0437\u0430\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0435 N11OBID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TBI_N32\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 \u043D\u0430 \u0437\u0430\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0435 \u043F\u043E\u043B\u044F N32OBID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TBI_N37\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 \u043D\u0430 \u0437\u0430\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0435 \u043F\u043E\u043B\u044F N37OBID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TBI_N40\" ObjectType=\"QUERY\" BriefText=\"\u0417\u0430\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0435 N40OBID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TBI_N45\" ObjectType=\"QUERY\" BriefText=\"\u0410\u0432\u0442\u043E\u0437\u0430\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0435 \u043F\u043E\u043B\u044F N45OBID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TBI_N52\" ObjectType=\"QUERY\" BriefText=\"\u0423\u0441\u0442\u0430\u043D\u043E\u0432\u043A\u0430 N52OBTP:=200 \u043F\u043E \u0443\u043C\u043E\u043B\u0447\u0430\u043D\u0438\u044E\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TBI_N71\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0435\u0440 \u043D\u0430 \u043F\u043E\u043B\u0435 n71obid\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TBI_R02\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 \u0434\u043B\u044F R02\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TBI_R03\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 \u0434\u043B\u044F R03\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TBI_R04\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 \u0434\u043B\u044F R04 (\u043F\u0435\u0440\u0435\u0434 \u0434\u043E\u0431\u0430\u0432\u043B\u0435\u043D\u0438\u0435\u043C)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TBI_R05\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 \u0434\u043B\u044F R05\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TBI_R08\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 \u0434\u043B\u044F R08\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TBI_S38\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 \u043D\u0430 \u0437\u0430\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0435 \u043F\u043E\u043B\u044F S38OBID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TBIU_N40KLAD\" ObjectType=\"QUERY\" BriefText=\"\u0424\u0438\u043A\u0441\u0430\u0446\u0438\u044F \u0432\u0435\u0440\u0441\u0438\u0438 \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u0430 \u041A\u041B\u0410\u0414\u0420 \u0437\u0430 \u0430\u0434\u0440\u0435\u0441\u043E\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TBU_N30OVEX\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 \u0434\u043B\u044F \u043F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u043A\u0438 \u0434\u0430\u043D\u043D\u044B\u0445 \u0434\u043B\u044F \u043F\u0440\u043E\u0446\u0435\u0434\u0443\u0440\u044B \u0438\u0437 \u043F\u0430\u043A\u0435\u0442\u0430 CREDIT.PKG \u043F\u043E \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u0430\u043C \u0441 \u0438\u0437\u043C\u0435\u043D\u0451\u043D\u043D\u044B \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435\u043C \u043F\u043E\u043B\u044F OVEX\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TB31_CHNB\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 \u043F\u043E \u0437\u0430\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u044E \u0432 B31 \u043F\u043E\u043B\u044F B31CHNB (tb31_chnb)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TB31_DATE\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 \u043F\u043E B31. \u0410\u0432\u0442\u043E\u043C\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u0438 \u0443\u0441\u0442\u0430\u043D\u0430\u0432\u043B\u0438\u0432\u0430\u0435\u0442 EXDT \u0432 \u043A\u043E\u043D\u0435\u0446 \u043C\u0435\u0441\u044F\u0446\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TB88_P002_OBID\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 \u043D\u0430 \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u043A\u0443 \u0447\u0438\u0441\u043B\u043E\u0432\u043E\u0433\u043E \u0418\u0414 \u0432 \u0434\u043E\u043F. \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u0438 \u043F\u043E \u043A\u0430\u0440\u0442\u0430\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TB98_0\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 \u043F\u043E B98. \u041E\u043F\u0440\u0435\u0434\u0435\u043B\u044F\u0435\u0442 P011, P012 \u0438 OPRI\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TN22_CREATE\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 N22, \u043E\u043F\u0440\u0435\u0434\u0435\u043B\u044F\u044E\u0449\u0438\u0439 P011 \u0438 P012\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TN23_DATE\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 \u043F\u043E N23 (tn23_date). \u041A\u043E\u0440\u0440\u0435\u043A\u0442\u0438\u0440\u043E\u0432\u043A\u0430 \u0434\u0430\u0442\u044B \u043E\u043A\u043E\u043D\u0447\u0430\u043D\u0438\u044F \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F \u043A\u0430\u0440\u0442\u044B\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TN28_OVDR\" ObjectType=\"QUERY\" BriefText=\"\u0417\u0430\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u0435 \u043E\u0432\u0435\u0440\u0434\u0440\u0430\u0444\u0442\u0430 \u0432 N28\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TN31_SYNC\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 \u043F\u043E n31 \u0434\u043B\u044F \u0441\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0430\u0446\u0438\u0438 \u0432\u0441\u043F\u043E\u043C\u043E\u0433\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0439 \u0442\u0430\u0431\u043B\u0438\u0446\u044B \u043F\u043E\u0438\u0441\u043A\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TR02_BDA\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 TR02_BDA\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TR02_BUA\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 TR02_BUA\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TR03_BDA\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 TR03_BDA\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TR03_BUA\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 TR03_BUA\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TR04_BDA\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 TR04_BDA\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TR04_BUA\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 TR04_BUA\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TR05_BDA\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 TR05_BDA\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TR05_BUA\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 TR05_BUA\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TR06_BDA\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 TR06_BDA\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TR06_BUA\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 TR06_BUA\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TR07_BDA\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 TR07_BDA\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TR07_BUA\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 TR07_BUA\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TR08_BDA\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 TR08_BDA\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TR08_BUA\" ObjectType=\"QUERY\" BriefText=\"\u0422\u0440\u0438\u0433\u0433\u0435\u0440 TR08_BUA\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TS04_0\" ObjectType=\"QUERY\" BriefText=\"TS04_0\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TT05_0\" ObjectType=\"QUERY\" BriefText=\"\u041F\u0440\u0438\u0441\u0432\u043E\u0435\u043D\u0438\u0435 ID \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u043E\u043D\u0438\u0441\u0442\u0443 T05\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TT20_0\" ObjectType=\"QUERY\" BriefText=\"\u041F\u0440\u0438\u0441\u0432\u043E\u0435\u043D\u0438\u0435 ID \u043D\u043E\u0432\u043E\u043C\u0443 \u0440\u0430\u0431\u043E\u0447\u0435\u043C\u0443 \u043C\u0435\u0441\u0442\u0443\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TT25_0\" ObjectType=\"QUERY\" BriefText=\"\u041F\u0440\u0438\u0441\u0432\u043E\u0435\u043D\u0438\u0435 ID \u043D\u043E\u0432\u043E\u043C\u0443 \u0441\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u0443\" Ownership=\"0\"/>\n      <ObjectRef ID=\"TT31_0\" ObjectType=\"QUERY\" BriefText=\"\u0423\u0434\u0430\u043B\u0435\u043D\u0438\u0435 \u043F\u0440\u0430\u0432 \u043D\u0430 \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u0438\u0435 \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u044B \u043F\u0440\u0438 \u0438\u0445 \u0443\u0434\u0430\u043B\u0435\u043D\u0438\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"UNDEFINE\" ObjectType=\"QUERY\" BriefText=\"rthrehtr44\" Ownership=\"0\"/>\n    </ObjectRefs>\n    <ObjectRefs ObjectsType=\"SEQUENCE\">\n      <ObjectRef ID=\"CARDLIMIT_SEQ\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439 \u043F\u043E \u043A\u0430\u0440\u0442\u043E\u0447\u043D\u043E\u043C\u0443 \u043B\u0438\u043C\u0438\u0442\u0443 &apos;B8&apos;, &apos;B9&apos;\" Ownership=\"0\"/>\n      <ObjectRef ID=\"INVOICE_SEQ\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C  INVOICE_SEQ\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEC_I23STRF\" ObjectType=\"SEQUENCE\" BriefText=\"\u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440 clob\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_ACNC\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F N67ACNC\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_AGRC\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u0433\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u0438 \u043A\u043E\u0434\u043E\u0432 \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u0438\u0445 \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u043E\u0432 T31AGRC\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_AGRID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_A01\" ObjectType=\"SEQUENCE\" BriefText=\"\u041D\u043E\u043C\u0435\u0440 \u0437\u0430\u043F\u0438\u0441\u0438 \u043F\u0440\u043E\u0442\u043E\u043A\u043E\u043B\u0430 \u0430\u0440\u0445\u0438\u0432\u0430\u0446\u0438\u0438 A01 (A01IDEN)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_A12STID\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u0437\u0430\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u044F \u043F\u043E\u043B\u044F A12STID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_A19AUID\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u0434\u043B\u044F \u0441\u043E\u0437\u0434\u0430\u043D\u0438\u044F \u043D\u043E\u0432\u043E\u0433\u043E \u0444\u0430\u043A\u0442\u0430 \u0430\u0443\u0434\u0438\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_BACP\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u0433\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u0438 \u043A\u043E\u0434\u043E\u0432 \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u0438\u0445 \u0443\u0441\u043B\u0443\u0433 T30BACP\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_BTCH\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u043F\u0430\u043A\u0435\u0442\u043E\u0432 \u0442\u0440\u0430\u043D\u0437\u0430\u043A\u0446\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_BTST\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C  SEQ_BTST\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_B31CHNB\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0451\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F \u043F\u043E\u043B\u044F B31CHNB\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_B31OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0418\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440 \u043A\u0430\u0440\u0442\u044B. \u0418\u0441\u043F\u043E\u043B\u0437\u0443\u0435\u0442\u0441\u044F \u0432 B31 (B31OBID)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_B54OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0418\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440 \u0442\u0435\u0440\u043C\u0438\u043D\u0430\u043B\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_B81OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u043E\u0432 \u0437\u0430\u043F\u0438\u0441\u0435\u0439 \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A\u0430 \u041A\u041B\u0410\u0414\u0420\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_B98P011\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u043F\u043E B98P011\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_B98TAXNUMBER\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0451\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u0441\u043A\u0432\u043E\u0437\u043D\u043E\u0439 \u043D\u0443\u043C\u0435\u0440\u0430\u0446\u0438\u0438 \u0444\u0430\u0439\u043B\u043E\u0432 \u0434\u043B\u044F \u0432\u044B\u0433\u0440\u0443\u0437\u043A\u0438 \u0432 \u0424\u041D\u0421(\u0410\u0411\u0421 \u0438 Retail - \u0435\u0434\u0438\u043D\u0430\u044F \u043D\u0443\u043C\u0435\u0440\u0430\u0446\u0438\u044F)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_CGCD\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u0443\u043D\u0438\u043A\u0430\u043B\u044C\u043D\u043E\u0433\u043E \u043A\u043E\u0434\u0430 B30CGCD\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_CLNTID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u043E\u0432 \u043A\u043B\u0438\u0435\u043D\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_C08PERM\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A  C08PERM\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_C30OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0423\u043D\u0438\u043A\u0430\u043B\u044C\u043D\u044B\u0439 \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440 \u044F\u0447\u0435\u0439\u043A\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_C31OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0418\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440 \u043A\u043B\u044E\u0447\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_C32OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u0434\u043B\u044F \u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F C32OBID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_C50CPSI\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0451\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u0433\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u0438 \u0443\u043D\u0438\u043A\u0430\u043B\u044C\u043D\u043E\u0433\u043E \u043A\u043B\u044E\u0447\u0430 \u0432 \u0442\u0430\u0431\u043B\u0438\u0446\u0435 C50CPSI.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_C51CPCI\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0451\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u0433\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u0438 \u0443\u043D\u0438\u043A\u0430\u043B\u044C\u043D\u043E\u0433\u043E \u043A\u043B\u044E\u0447\u0430 \u0432 \u0442\u0430\u0431\u043B\u0438\u0446\u0435 C51CP\u0421I.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_C52RPSI\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0451\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u0433\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u0438 \u0443\u043D\u0438\u043A\u0430\u043B\u044C\u043D\u043E\u0433\u043E \u043A\u043B\u044E\u0447\u0430 \u0432 \u0442\u0430\u0431\u043B\u0438\u0446\u0435 C52RPSI.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_C53BRRI\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0451\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u0433\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u0438 \u0443\u043D\u0438\u043A\u0430\u043B\u044C\u043D\u043E\u0433\u043E \u043A\u043B\u044E\u0447\u0430 \u0432 \u0442\u0430\u0431\u043B\u0438\u0446\u0435 C53BRRI.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_C60CTID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0451\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u0433\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u0438 \u0443\u043D\u0438\u043A\u0430\u043B\u044C\u043D\u043E\u0433\u043E \u043A\u043B\u044E\u0447\u0430 \u0432 \u0442\u0430\u0431\u043B\u0438\u0446\u0435 C60CTID.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_DP\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0451\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u0441\u0438\u0441\u0442\u0435\u043C\u044B \u0434\u043B\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0445 \u043F\u043E\u0440\u0443\u0447\u0435\u043D\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_D03\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u0433\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u0438 ID \u043F\u0440\u043E\u0446\u0435\u0441\u0441\u0430 D03STID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_EOW\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C  SEQ_EOW\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_FDID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F N03\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_FILEID\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u0434\u043B\u044F \u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F \u043F\u043E\u043B\u0435\u0439 S04FSID \u0438 S09FRID - \u0443\u043D\u0438\u043A\u0430\u043B\u044C\u043D\u044B\u0435 \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u044B \u0444\u0430\u0439\u043B\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_F02RGID\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u0434\u043B\u044F \u0442\u0430\u0431\u043B\u0438\u0446\u044B F02\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_F03RFID\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u0434\u043B\u044F \u0442\u0430\u0431\u043B\u0438\u0446\u044B F03\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_F04RCID\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u0434\u043B\u044F \u0442\u0430\u0431\u043B\u0438\u0446\u044B F04\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_F13ANID\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u0434\u043B\u044F \u0442\u0430\u0431\u043B\u0438\u0446\u044B F13\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_F16LAGI\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u0433\u0435\u043D\u0435\u0440\u0438\u0442 \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440 F16LAGI\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_F40FMID\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C ID \u043E\u0431\u044A\u0435\u043A\u0442\u043E\u0432 \u0442\u0430\u0431\u043B\u0438\u0446\u044B F40\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_F41FVID\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u0434\u043B\u044F \u0433\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u0438 ID \u043F\u043E\u043B\u044F F41FVID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_HPID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0435 \u0443\u043D\u0438\u043A\u0430\u043B\u044C\u043D\u043E\u0433\u043E \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u0430 \u0434\u043B\u044F \u0438\u0441\u0442\u043E\u0440\u0438\u0438 \u043F\u043B\u0430\u0442\u0435\u0436\u0435\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_H02OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u0437\u0430\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u044F \u043F\u043E\u043B\u044F H02OBID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_H07OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u043F\u043E\u043B\u044F H07OBID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_H07TMP_N\" ObjectType=\"SEQUENCE\" BriefText=\"\u0418\u043C\u0435\u043D\u043E\u0432\u0430\u043D\u0438\u0435 \u0432\u0440\u0435\u043C\u0435\u043D\u043D\u044B\u0445 \u0442\u0430\u0431\u043B\u0438\u0446 \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438 \u043D\u0430 \u043F\u0440\u0438\u0447\u0430\u0441\u0442\u043D\u043E\u0441\u0442\u044C \u043A \u0441\u0442\u043E\u043F-\u043B\u0438\u0441\u0442\u0430\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_H11MBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u043A\u0432\u043E\u0437\u043D\u043E\u0435 \u0418\u0414 \u0443\u0447\u0430\u0441\u0442\u043D\u0438\u043A\u043E\u0432 \u043F\u043E\u0434\u043E\u0437\u0440\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0445 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_H14MSID\" ObjectType=\"SEQUENCE\" BriefText=\"\u042F\u0432\u043B\u044F\u0435\u0442\u0441\u044F \u0438\u0441\u0442\u043E\u0447\u043D\u0438\u043A\u043E\u043C \u0437\u0430\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u044F \u043F\u043E\u043B\u044F H14MSID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_H20OEID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F H20OEID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_IMPEX\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0437\u0430\u044F\u0432\u043E\u043A \u041F\u0426 \u0418\u043C\u043F\u0435\u043A\u0441\u0431\u0430\u043D\u043A\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_I07OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0422\u0440\u0438\u0433\u0435\u0440 \u043D\u0430 \u043F\u043E\u043B\u0435 i07obid\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_I18OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u043E\u0432 \u0442\u0438\u043F\u043E\u0432\u044B\u0445 \u0443\u0432\u0435\u0434\u043E\u043C\u043B\u0435\u043D\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_I19OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u0437\u0430\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u044F \u043F\u043E\u043B\u044F I19OBID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_I24OBID\" ObjectType=\"SEQUENCE\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_I26STRF\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0451\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u0433\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u0438 \u0443\u043D\u0438\u043A\u0430\u043B\u044C\u043D\u043E\u0433\u043E \u043A\u043B\u044E\u0447\u0430 \u0432 \u0442\u0430\u0431\u043B\u0438\u0446\u0435 I26STRF.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_I27OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u0437\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0445 \u0437\u0430 \u0432\u043D\u0435\u0448\u043D\u0435\u0439 \u0441\u0438\u0441\u0442\u0435\u043C\u043E\u0439 \u0437\u0430\u043F\u0440\u043E\u0441\u043E\u0432/\u043E\u0442\u0432\u0435\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_I33EVID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0418\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440 \u0441\u043E\u0431\u044B\u0442\u0438\u044F. \u0418\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0435\u0442\u0441\u044F \u0434\u043B\u044F \u0437\u0430\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u044F \u043F\u043E\u043B\u044F I33EVID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_I35ITID\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u0434\u043B\u044F \u0437\u0430\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u044F i35itid\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_JPID\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u0444\u043E\u0440\u043C\u0438\u0440\u0443\u0435\u0442 \u043F\u043E\u043B\u0435 T84JPID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_J09OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0451\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F J09OBID - \u0423\u043D\u0438\u043A\u0430\u043B\u044C\u043D\u044B\u0439 \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440 \u0443\u0441\u043B\u0443\u0433\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_J11OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A j11obid\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_J12OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C, \u0434\u043B\u044F \u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F j12obid\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_MCOD\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u0438\u044F \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u0430 \u0437\u0430\u043F\u0438\u0441\u0438 \u0432 \u0442\u0430\u0431\u043B\u0438\u0446\u0435 N33\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_MFGR\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0435\u0442\u0441\u044F \u0432 \u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u0438 \u0433\u0440\u0443\u043F\u043F \u043A\u043E\u043C\u0438\u0441\u0441\u0438\u043E\u043D\u043D\u044B\u0445 \u0441\u0442\u0430\u0432\u043E\u043A\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_M03OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u0434\u043B\u044F \u044D\u043B\u0435\u043C\u0435\u043D\u0442\u043E\u0432 \u043C\u0430\u0440\u0448\u0440\u0443\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_M10HTID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0418\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440 \u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430 \u0438\u0441\u0442\u043E\u0440\u0438\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_M40CSID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0418\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440 \u043D\u0430\u0431\u043E\u0440\u0430 \u043F\u043E\u043F\u0440\u0430\u0432\u043E\u043A \u043A \u0441\u0442\u0430\u0432\u043A\u0430\u043C \u043F\u043E \u0441\u0447\u0435\u0442\u0430\u043C \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u043E\u0433\u043E \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_M58OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u0434\u043B\u044F \u043F\u043E\u043B\u044F M58OBID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_N01OPID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A N01OPID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_N04_M04POID\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u0434\u043B\u044F \u0433\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u0438 \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u0430 \u043E\u0431\u044A\u0435\u043A\u0442\u0430 \u0411\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u0438\u0439 \u044D\u0442\u0430\u043F (\u043E\u0431\u044A\u0435\u043A\u0442\u044B \u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u044B \u043C\u0435\u0436\u0434\u0443 \u0442\u0430\u0431\u043B\u0438\u0446\u0430\u043C\u0438 N04 M04 )\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_N04TECH\" ObjectType=\"SEQUENCE\" BriefText=\"\u0441\u0447\u0435\u0442\u0447\u0438\u043A SEQ_N04TECH\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_N08N09ID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0451\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0445 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432 \u043F\u043E \u0446\u0435\u043D\u043D\u043E\u0441\u0442\u044F\u043C\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_N10LOID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0423\u043D\u0438\u043A\u0430\u043B\u044C\u043D\u044B\u0439 \u043A\u043E\u0434 \u0440\u0435\u0435\u0441\u0442\u0440\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_N12REID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0451\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u0433\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u0438 \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u0430 \u0440\u0435\u0435\u0441\u0442\u0440\u0430 \u043F\u043B\u0430\u0442\u0451\u0436\u043D\u044B\u0445 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_N22OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u0434\u043B\u044F \u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F \u0443\u043D\u0438\u043A\u0430\u043B\u044C\u043D\u043E\u0433\u043E \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u0430 \u0438\u0441\u0445\u043E\u0434\u043D\u043E\u0433\u043E \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430 \u043F\u043E \u0440\u0430\u0431\u043E\u0442\u0435 \u0441 \u043A\u0430\u0440\u0442\u043E\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_N28MNUM\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439 \u043F\u043E \u043F\u0440\u0438\u043D\u0443\u0434\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0439 \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0435 \u043B\u0438\u043C\u0438\u0442\u043E\u0432 \u043A\u0430\u0440\u0442 SEQ_N28MNUM\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_N29FDID\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C  SEQ_N29FDID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_N29PAID\" ObjectType=\"SEQUENCE\" BriefText=\"Sequence Seq_N29PAID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_N32OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0418\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440 \u043F\u0440\u0438\u0432\u044F\u0437\u043A\u0438 \u0441\u0447\u0435\u0442\u0430 \u043A \u0434\u043E\u0433\u043E\u0432\u043E\u0440\u0443\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_N37OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0418\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430 \u043A\u043B\u0438\u0435\u043D\u0442\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_N38OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u0430 \u0433\u0440\u0430\u0444\u0438\u043A\u0430 \u0441\u0445\u0435\u043C \u0442\u0430\u0440\u0438\u0444\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_N40OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A N40OBID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_N41OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u0442\u0430\u0431\u043B\u0438\u0446\u044B N41OBID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_N42DOID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043E\u0432\u0435\u0440\u0435\u043D\u043D\u043E\u0441\u0442\u0435\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_N50PMID\" ObjectType=\"SEQUENCE\" BriefText=\"SEQUENCE SEQ_N50PMID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_N52POID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A SEQ_N52POID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_N54CLID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0418\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440 \u043E\u0431\u044A\u0435\u043A\u0442\u0430 \u0438\u0437 n54clid \u0432 \u0441\u043B\u0443\u0447\u0430\u0435 \u0435\u0441\u043B\u0438 \u0442\u0438\u043F \u043E\u0431\u044A\u0435\u043A\u0442\u0430 n54cltp = 10 (\u043F\u043E\u043B\u0443\u0447\u0430\u0442\u0435\u043B\u044C \u0432\u043D\u0435\u0448\u043D\u0435\u0433\u043E \u043F\u043B\u0430\u0442\u0435\u0436\u0430)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_N59OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0418\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440 \u043A\u043E\u043C\u043C\u0443\u043D\u0430\u043B\u044C\u043D\u043E\u0433\u043E \u043F\u043B\u0430\u0442\u0435\u0436\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_N63OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u0430 \u0438\u0437\u0432\u0435\u0449\u0435\u043D\u0438\u044F \u043E \u043F\u043B\u0430\u0442\u0435\u0436\u0435\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_N65OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u0434\u043B\u044F \u0442\u0430\u0431\u043B\u0438\u0446\u044B N65\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_N71OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u043A\u043E\u043D\u0442\u0430\u043A\u0442\u043D\u043E\u0439 \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_N75OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0414\u041B\u042F \u044275\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_N77SVID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0418\u0414 \u0441\u0432\u043E\u0434\u043D\u043E\u0433\u043E \u043C\u0435\u043C\u043E\u0440\u0438\u0430\u043B\u044C\u043D\u043E\u0433\u043E \u043E\u0440\u0434\u0435\u0440\u0430.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_N78OBID\" ObjectType=\"SEQUENCE\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_N79ACID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0424\u043E\u0440\u043C\u0438\u0440\u0443\u0435\u0442 \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440 \u0430\u043A\u0446\u0435\u043F\u0442\u0430 (N79)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u0430 \u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430 \u0441\u0435\u0442\u0438.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_OBJLINK\" ObjectType=\"SEQUENCE\" BriefText=\"\u0418\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440 \u0441\u0432\u044F\u0437\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_OUTDOC\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u043D\u043E\u043C\u0435\u0440\u043E\u0432 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432 \u0441\u0432\u043E\u0434\u043D\u043E\u0433\u043E \u0443\u0447\u0435\u0442\u0430 (\u0432\u044B\u0433\u0440\u0443\u0436\u0430\u0435\u043C\u044B\u0445 \u0432 \u0411\u0421)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_PFID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0424\u043E\u0440\u043C\u0438\u0440\u0443\u0435\u0442 \u0443\u043D\u0438\u043A\u0430\u043B\u044C\u043D\u044B\u0439 \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440 \u0444\u0430\u0439\u043B\u0430 \u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F (W01PFID)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_PREGID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u043E\u0432 \u0440\u0435\u0435\u0441\u0442\u0440\u043E\u0432 \u043F\u043B\u0430\u0442\u0435\u0436\u0435\u0439, \u0444\u043E\u0440\u043C\u0438\u0440\u0443\u0435\u043C\u044B\u0445, \u0434\u043B\u044F \u043E\u0442\u043F\u0440\u0430\u0432\u043A\u0438 \u0432 \u043F\u0440\u043E\u0432\u0430\u0439\u0434\u0435\u0440 online-\u043F\u043B\u0430\u0442\u0435\u0436\u0435\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_PSID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0424\u043E\u0440\u043C\u0438\u0440\u0443\u0435\u0442 \u0443\u043D\u0438\u043A\u0430\u043B\u044C\u043D\u044B\u0439 \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440 \u0441\u0435\u0430\u043D\u0441\u0430 \u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F (W01PSID)\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_PTID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F J- \u0442\u0430\u0431\u043B\u0438\u0446\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_P011\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0438\u043D\u0438\u0446\u0438\u0430\u0442\u043E\u0440\u043E\u0432 \u0442\u0440\u0430\u043D\u0437\u0430\u043A\u0446\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_P029\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u043D\u043E\u043C\u0435\u0440\u043E\u0432 \u043F\u0430\u043A\u0435\u0442\u043E\u0432\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_P24\" ObjectType=\"SEQUENCE\" BriefText=\"\u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440 \u0441\u0442\u0438\u043B\u044F \u0434\u043B\u044F WPF\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_RECID\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u044B\u0439 \u043D\u043E\u043C\u0435\u0440 \u0437\u0430\u043F\u0438\u0441\u0438 \u0432 \u0444\u0430\u0439\u043B\u0435\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_REID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0440\u0435\u0435\u0441\u0442\u0440\u043E\u0432 \u043F\u043B\u0430\u0442\u0435\u0436\u043D\u044B\u0445 \u043F\u043E\u0440\u0443\u0447\u0435\u043D\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_REPORT\" ObjectType=\"SEQUENCE\" BriefText=\"\u0415\u0434\u0438\u043D\u044B\u0439 \u0441\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u0442\u0430\u0431\u043B\u0438\u0446 \u043E\u0442\u0447\u0435\u0442\u043D\u043E\u0441\u0442\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_RQID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0437\u0430\u044F\u0432\u043E\u043A \u0441\u0438\u0441\u0442\u0435\u043C \u0443\u0434\u0430\u043B\u0435\u043D\u043D\u043E\u0433\u043E \u0434\u043E\u0441\u0442\u0443\u043F\u0430\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_R04\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C  SEQ_R04\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_SCHED\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u0440\u0430\u0441\u043F\u0438\u0441\u0430\u043D\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_STAN\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F STAN\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_STAN_GCS\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F \u0443\u043D\u0438\u043A\u0430\u043B\u044C\u043D\u043E\u0433\u043E \u043F\u043E\u043B\u044F STAN \u0432 \u0444\u0430\u0439\u043B\u0435 \u0434\u043B\u044F \u0413\u041A\u0421 \u0432\u0435\u0440\u0441\u0438\u0438 3\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_STBLIM\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u043E\u0432 \u043B\u0438\u043C\u0438\u0442\u043E\u0432 \u0432 \u043A\u043E\u0434\u0438\u0440\u043E\u0432\u043A\u0435 \u0421\u0422\u0411\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_STRF\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u0442\u0440\u0430\u043D\u0437\u0430\u043A\u0446\u0438\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_SYNC\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0437\u0430\u043F\u0438\u0441\u0435\u0439 \u0411\u0414\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_S1\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C  SEQ_S1\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_S38OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u043F\u043E\u043B\u044F S38OBID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_TAGIT\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C  SEQ_TAGIT\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_TAXBASE\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u043F\u043E\u043B\u0435\u0439 N90OBID, N91OBID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_TMP_PAN\" ObjectType=\"SEQUENCE\" BriefText=\"\u0413\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u044F \u0432\u0440\u0435\u043C\u0435\u043D\u043D\u043E\u0433\u043E \u043D\u043E\u043C\u0435\u0440\u0430 \u043A\u0430\u0440\u0442\u044B\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_T13POID\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u0434\u043B\u044F \u0433\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u0438 \u0443\u043D\u0438\u043A\u0430\u043B\u044C\u043D\u044B\u0445 \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u043E\u0432 \u0434\u043B\u044F \u043E\u0431\u044A\u0435\u043A\u0442\u0430 \u041E\u043F\u0438\u0441\u0430\u043D\u0438\u0435 \u0422\u0438\u043F\u043E\u0432\u043E\u0433\u043E \u042D\u0442\u0430\u043F\u0430 \u0432 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_T34PKEY\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u0434\u043B\u044F \u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F \u0443\u043D\u0438\u043A\u0430\u043B\u044C\u043D\u043E\u0433\u043E \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u043F\u043E\u043B\u044F t34pkey\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_T40INSC\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0451\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u043D\u0443\u043C\u0435\u0440\u0430\u0446\u0438\u0438 \u0441\u0445\u0435\u043C \u043D\u0430\u0447\u0438\u0441\u043B\u0435\u043D\u0438\u044F \u043F\u0440\u043E\u0446\u0435\u043D\u0442\u043E\u0432.\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_T57ASID\" ObjectType=\"SEQUENCE\" BriefText=\"Sequence SEQ_T57ASID\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_T65SMTP\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440\u043E\u0432 \u0432\u044B\u0447\u0438\u0441\u043B\u044F\u0435\u043C\u044B\u0445 \u0441\u0443\u043C\u043C \u0432 \u0442\u0438\u043F\u043E\u0432\u044B\u0445 \u0431\u0430\u043D\u043A\u043E\u0432\u0441\u043A\u0438\u0445 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u044F\u0445\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_T75TRID\" ObjectType=\"SEQUENCE\" BriefText=\"\u0421\u0447\u0435\u0442\u0447\u0438\u043A \u0434\u043B\u044F \u0432\u0438\u0434\u0430 \u0446\u0435\u043D\u043D\u043E\u0441\u0442\u0435\u0439\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_T88\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C  SEQ_T88\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_T95OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u043A\u043E\u0434 \u043E\u0431\u044A\u0435\u043A\u0442\u0430 \u043B\u0438\u0446\u043E \u0441 \u043F\u0440\u0430\u0432\u043E\u043C \u043F\u043E\u0434\u043F\u0438\u0441\u0438\" Ownership=\"0\"/>\n      <ObjectRef ID=\"SEQ_Y11OBID\" ObjectType=\"SEQUENCE\" BriefText=\"\u041F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u0444\u043E\u0440\u043C\u0438\u0440\u0443\u0435\u0442 \u043F\u043E\u043B\u0435  Y11OBID\" Ownership=\"0\"/>\n    </ObjectRefs>\n  </Schema>\n</UCMsg>"
    },
    {
        key: "\n<UCMsg ID=\"3\">\n  <DataTypes></DataTypes>\n  <Context ID=\"555\">\n    <UserName>leonid</UserName>\n    <UserPassword>o</UserPassword>\n    <UserStatus></UserStatus>\n    <IPAddress></IPAddress>\n    <VerMask>\u0412</VerMask>\n    <SubMask>\u0412</SubMask>\n  </Context>\n</UCMsg>",
        val: "\n<UCMsg ID=\"3\">\n  <Status/>\n  <Context ID=\"355\">\n    <UserName>leonid</UserName>\n    <UserPassword>o</UserPassword>\n    <UserStatus></UserStatus>\n    <IPAddress/>\n    <VerMask>\u0412</VerMask>\n    <SubMask>\u0412</SubMask>\n  </Context>\n  <DataTypes>\n    <DataType ID=\"account\" BaseType=\"string\" OracleType=\"70\" Size=\"VARCHAR2\" BriefText=\"\u043D\u043E\u043C\u0435p \u0441\u0447\u0435\u0442\u0430\"/>\n    <DataType ID=\"accountid\" BaseType=\"number\" OracleType=\"10\" Size=\"NUMBER\" BriefText=\"\u043A\u043E\u0434 \u0441\u0447\u0435\u0442\u0430\"/>\n    <DataType ID=\"accountreal\" BaseType=\"string\" OracleType=\"35\" Size=\"VARCHAR2\" BriefText=\"\u0440\u0435\u0430\u043B\u044C\u043D\u044B\u0439 \u043D\u043E\u043C\u0435p \u0441\u0447\u0435\u0442\u0430\"/>\n    <DataType ID=\"actioncode\" BaseType=\"number\" OracleType=\"3\" Size=\"NUMBER\" BriefText=\"\u0441\u0442\u0430\u0442\u0443\u0441 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u044F\"/>\n    <DataType ID=\"analyticalsign\" BaseType=\"string\" OracleType=\"40\" Size=\"VARCHAR2\" BriefText=\"\u0430\u043D\u0430\u043B\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0439 \u043F\u0440\u0438\u0437\u043D\u0430\u043A\"/>\n    <DataType ID=\"apprcode\" BaseType=\"string\" OracleType=\"6\" Size=\"VARCHAR2\" BriefText=\"\u043A\u043E\u0434 \u0430\u0432\u0442\u043E\u0440\u0438\u0437\u0430\u0446\u0438\u0438\"/>\n    <DataType ID=\"blob\" BaseType=\"blob\" OracleType=\"\" Size=\"BLOB\" BriefText=\"\u0434\u0432\u043E\u0438\u0447\u043D\u0430\u044F \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u044F\"/>\n    <DataType ID=\"buscode\" BaseType=\"number\" OracleType=\"4\" Size=\"NUMBER\" BriefText=\"CardAccBusinessCode\"/>\n    <DataType ID=\"char\" BaseType=\"char\" OracleType=\"1\" Size=\"CHAR\" BriefText=\"\u043E\u0434\u0438\u043D \u0431\u0430\u0439\u0442\"/>\n    <DataType ID=\"clob\" BaseType=\"clob\" OracleType=\"\" Size=\"CLOB\" BriefText=\"\u0447\u0430\u0440\u043D\u0430\u044F \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u044F\"/>\n    <DataType ID=\"countrycode\" BaseType=\"number\" OracleType=\"3\" Size=\"NUMBER\" BriefText=\"\u043A\u043E\u0434 \u0441\u0442\u0440\u0430\u043D\u044B\"/>\n    <DataType ID=\"currcode\" BaseType=\"number\" OracleType=\"3\" Size=\"NUMBER\" BriefText=\"\u043A\u043E\u0434 \u0432\u0430\u043B\u044E\u0442\u044B\"/>\n    <DataType ID=\"currency\" BaseType=\"intmax\" OracleType=\"\" Size=\"NUMBER\" BriefText=\"\u0434\u0435\u043D\u044C\u0433\u0438\"/>\n    <DataType ID=\"date\" BaseType=\"date\" OracleType=\"\" Size=\"DATE\" BriefText=\"\u0434\u0430\u0442\u0430 \u0438 \u0432p\u0435\u043C\u044F\"/>\n    <DataType ID=\"datenum\" BaseType=\"number\" OracleType=\"4\" Size=\"NUMBER\" BriefText=\"YYMM \u0432 \u0432\u0438\u0434\u0435 \u0447\u0438\u0441\u043B\u0430\"/>\n    <DataType ID=\"datetime\" BaseType=\"date\" OracleType=\"\" Size=\"DATE\" BriefText=\"\u0434\u0430\u0442\u0430 \u0438 \u0432\u0440\u0435\u043C\u044F\"/>\n    <DataType ID=\"dateYYMM\" BaseType=\"date\" OracleType=\"\" Size=\"DATE\" BriefText=\"\u0433\u043E\u0434/\u043C\u0435\u0441\u044F\u0446\"/>\n    <DataType ID=\"dateYYMMDD\" BaseType=\"date\" OracleType=\"\" Size=\"DATE\" BriefText=\"\u0433\u043E\u0434/\u043C\u0435\u0441\u044F\u0446/\u0434\u0435\u043D\u044C\"/>\n    <DataType ID=\"eftp\" BaseType=\"number\" OracleType=\"2\" Size=\"NUMBER\" BriefText=\"\u043A\u043E\u0434 \u0444\u043E\u0440\u043C\u0430\u0442\u0430 \u0444\u0430\u0439\u043B\u0430\"/>\n    <DataType ID=\"feecode\" BaseType=\"number\" OracleType=\"2\" Size=\"NUMBER\" BriefText=\"\u043A\u043E\u0434 \u043A\u043E\u043C\u0438\u0441\u0441\u0438\u0438\"/>\n    <DataType ID=\"float\" BaseType=\"float\" OracleType=\"\" Size=\"NUMBER\" BriefText=\"\u0441 \u043F\u043B\u0430\u0432. \u0437\u0430\u043F\u044F\u0442\u043E\u0439 \u043C\u0430\u043A\u0441\u0438\u043C\u0430\u043B\u044C\u043D\u043E\u0439 \u0434\u043B\u0438\u043D\u044B\"/>\n    <DataType ID=\"flsn\" BaseType=\"number\" OracleType=\"3\" Size=\"NUMBER\" BriefText=\"\u043D\u043E\u043C\u0435\u0440 \u0444\u0430\u0439\u043B\u0430\"/>\n    <DataType ID=\"fltp\" BaseType=\"char\" OracleType=\"\" Size=\"CHAR\" BriefText=\"\u043A\u043E\u0434 \u0442\u0438\u043F\u0430 \u0444\u0430\u0439\u043B\u0430\"/>\n    <DataType ID=\"formatcode\" BaseType=\"string\" OracleType=\"2\" Size=\"VARCHAR2\" BriefText=\"\u0442\u0438\u043F \u043F\u043E\u0447\u0442\u043E\u0432\u043E\u0433\u043E \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u044F\"/>\n    <DataType ID=\"funcode\" BaseType=\"number\" OracleType=\"3\" Size=\"NUMBER\" BriefText=\"\u0444\u0443\u043D\u043A\u0446\u0438\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0439 \u043A\u043E\u0434\"/>\n    <DataType ID=\"integer\" BaseType=\"number\" OracleType=\"5\" Size=\"NUMBER\" BriefText=\"5 \u0437\u043D\u0430\u043A\u043E\u0432\"/>\n    <DataType ID=\"intmax\" BaseType=\"intmax\" OracleType=\"38\" Size=\"NUMBER\" BriefText=\"\u0446\u0435\u043B\u043E\u0435 \u043C\u0430\u043A\u0441\u0438\u043C\u0430\u043B\u044C\u043D\u043E\u0439 \u0434\u043B\u0438\u043D\u044B\"/>\n    <DataType ID=\"int16\" BaseType=\"int16\" OracleType=\"4\" Size=\"NUMBER\" BriefText=\"\u0446\u0435\u043B\u043E\u0435, \u0440\u0430\u0437\u043C\u0435\u0449\u0435\u043D\u043D\u043E\u0435 \u0432 16-\u0438 \u0431\u0438\u0442\u0430\u0445\"/>\n    <DataType ID=\"limitnum\" BaseType=\"number\" OracleType=\"2\" Size=\"NUMBER\" BriefText=\"\u043D\u043E\u043C\u0435\u0440 \u043B\u0438\u043C\u0438\u0442\u0430 \u0434\u0435\u0440\u0436\u0430\u0442\u0435\u043B\u044F\"/>\n    <DataType ID=\"long\" BaseType=\"number\" OracleType=\"10\" Size=\"NUMBER\" BriefText=\"10 \u0437\u043D\u0430\u043A\u043E\u0432\"/>\n    <DataType ID=\"maid_id\" BaseType=\"string\" OracleType=\"20\" Size=\"VARCHAR2\" BriefText=\"\u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440 \u043B\u0438\u043C\u0438\u0442\u0430\"/>\n    <DataType ID=\"memberid\" BaseType=\"number\" OracleType=\"11\" Size=\"NUMBER\" BriefText=\"\u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440 \u043E\u0431\u044A\u0435\u043A\u0442\u0430\"/>\n    <DataType ID=\"memberst\" BaseType=\"number\" OracleType=\"3\" Size=\"NUMBER\" BriefText=\"\u0441\u0442\u0430\u0442\u0443\u0441 \u043E\u0431\u044A\u0435\u043A\u0442\u0430\"/>\n    <DataType ID=\"memo\" BaseType=\"memo\" OracleType=\"\" Size=\"LONG\" BriefText=\"\u0441\u0438\u043C\u0432\u043E\u043B\u044C\u043D\u0430\u044F \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u044F\"/>\n    <DataType ID=\"msps\" BaseType=\"number\" OracleType=\"2\" Size=\"NUMBER\" BriefText=\"\u0442\u0438\u043F \u0440\u0430\u0441\u0447\u0435\u0442\u0430\"/>\n    <DataType ID=\"nacgn\" BaseType=\"number\" OracleType=\"5\" Size=\"NUMBER\" BriefText=\"\u043A\u043E\u0434 \u0433\u0440\u0443\u043F\u043F\u043E\u0432\u043E\u0433\u043E \u0438\u043C\u0435\u043D\u0438\"/>\n    <DataType ID=\"nameloc\" BaseType=\"string\" OracleType=\"99\" Size=\"VARCHAR2\" BriefText=\"\u043C\u0435\u0441\u0442\u043E \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438\"/>\n    <DataType ID=\"nerror\" BaseType=\"number\" OracleType=\"5\" Size=\"NUMBER\" BriefText=\"\u043A\u043E\u0434 \u043E\u0448\u0438\u0431\u043A\u0438\"/>\n    <DataType ID=\"nmfgr\" BaseType=\"number\" OracleType=\"11\" Size=\"NUMBER\" BriefText=\"\u043A\u043E\u0434 \u0433\u0440\u0443\u043F\u043F\u044B \u043A\u043E\u043C\u0438\u0441\u0441\u0438\u043E\u043D\u043D\u044B\u0445 \u0441\u0442\u0430\u0432\u043E\u043A\"/>\n    <DataType ID=\"nmtid\" BaseType=\"number\" OracleType=\"4\" Size=\"NUMBER\" BriefText=\"Message ID\"/>\n    <DataType ID=\"nstan\" BaseType=\"number\" OracleType=\"6\" Size=\"NUMBER\" BriefText=\"\u043A\u043B\u044E\u0447 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u044F\"/>\n    <DataType ID=\"nstat\" BaseType=\"number\" OracleType=\"2\" Size=\"NUMBER\" BriefText=\"\u0441\u0442\u0430\u0442\u0443\u0441 \u0437\u0430\u043F\u0438\u0441\u0438\"/>\n    <DataType ID=\"nstrf\" BaseType=\"number\" OracleType=\"11\" Size=\"NUMBER\" BriefText=\"\u043A\u043B\u044E\u0447 \u0437\u0430\u043F\u0438\u0441\u0438\"/>\n    <DataType ID=\"ntrnp\" BaseType=\"number\" OracleType=\"3\" Size=\"NUMBER\" BriefText=\"\u043A\u043E\u0434 \u043D\u0430\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F\"/>\n    <DataType ID=\"number\" BaseType=\"number\" OracleType=\"\" Size=\"NUMBER\" BriefText=\"\u0447\u0438\u0441\u043B\u043E \u043F\u0435\u0440\u0435\u043C\u0435\u043D\u043D\u043E\u0439 \u0434\u043B\u0438\u043D\u044B,i=(p,s)\"/>\n    <DataType ID=\"operid\" BaseType=\"number\" OracleType=\"11\" Size=\"NUMBER\" BriefText=\"\u043A\u043E\u0434 \u043E\u043F\u0435p\u0430\u0442\u043Ep\u0430\"/>\n    <DataType ID=\"pan\" BaseType=\"string\" OracleType=\"19\" Size=\"VARCHAR2\" BriefText=\"\u043D\u043E\u043C\u0435\u0440 \u043A\u0430\u0440\u0442\u044B\"/>\n    <DataType ID=\"pmgr\" BaseType=\"number\" OracleType=\"4\" Size=\"NUMBER\" BriefText=\"\u0433\u0440\u0443\u043F\u043F\u0430 \u0440\u0430\u0441\u0447\u0435\u0442\u0430\"/>\n    <DataType ID=\"poscode\" BaseType=\"string\" OracleType=\"12\" Size=\"VARCHAR2\" BriefText=\"posdatacode\"/>\n    <DataType ID=\"proccode\" BaseType=\"number\" OracleType=\"6\" Size=\"NUMBER\" BriefText=\"\u043A\u043E\u0434 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438\"/>\n    <DataType ID=\"processid\" BaseType=\"number\" OracleType=\"4\" Size=\"NUMBER\" BriefText=\"\u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440 \u043F\u0440\u043E\u0446\u0435\u0441\u0441\u0430\"/>\n    <DataType ID=\"progid\" BaseType=\"string\" OracleType=\"4\" Size=\"VARCHAR2\" BriefText=\"\u043A\u043E\u0434 \u043A\u0430\u0440\u0442\u043E\u0447\u043D\u043E\u0439 \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u044B\"/>\n    <DataType ID=\"projectcode\" BaseType=\"string\" OracleType=\"4\" Size=\"VARCHAR2\" BriefText=\"\u043A\u043E\u0434 \u043F\u0440\u043E\u0435\u043A\u0442\u0430 \u043E\u0431\u043C\u0435\u043D\u0430\"/>\n    <DataType ID=\"psfl\" BaseType=\"string\" OracleType=\"4\" Size=\"VARCHAR2\" BriefText=\"\u043A\u043E\u0434 \u043F\u043B\u0430\u0442\u0435\u0436\u043D\u043E\u0439 \u0441\u0438\u0441\u0442\u0435\u043C\u044B\"/>\n    <DataType ID=\"rate\" BaseType=\"float\" OracleType=\"\" Size=\"NUMBER\" BriefText=\"\u043A\u0443\u0440\u0441 \u043A\u043E\u043D\u0432\u0435\u0440\u0442\u0430\u0446\u0438\u0438\"/>\n    <DataType ID=\"raw\" BaseType=\"raw\" OracleType=\"\" Size=\"RAW\" BriefText=\"\u0434\u0432\u043E\u0438\u0447\u043D\u0430\u044F \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u044F\"/>\n    <DataType ID=\"reason\" BaseType=\"number\" OracleType=\"4\" Size=\"NUMBER\" BriefText=\"\u043A\u043E\u0434 \u043Fp\u0438\u0447\u0438\u043D\u0430 \u0441\u043E\u0431\u044B\u0442\u0438\u044F\"/>\n    <DataType ID=\"reccount\" BaseType=\"number\" OracleType=\"3\" Size=\"NUMBER\" BriefText=\"\u043D\u043E\u043C\u0435\u0440 \u043F\u0430\u043A\u0435\u0442\u0430\"/>\n    <DataType ID=\"rowid\" BaseType=\"rowid\" OracleType=\"\" Size=\"ROWID\" BriefText=\"\u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440 \u0441\u0442\u0440\u043E\u043A\u0438 \u0432 \u0442\u0430\u0431\u043B\u0438\u0446\u0435\"/>\n    <DataType ID=\"smallint\" BaseType=\"number\" OracleType=\"1\" Size=\"NUMBER\" BriefText=\"\u0434\u043B\u044F \u0443\u0434\u043E\u0431\u0441\u0442\u0432\u0430\"/>\n    <DataType ID=\"smtid\" BaseType=\"string\" OracleType=\"4\" Size=\"VARCHAR2\" BriefText=\"MTID \u0432 \u0441\u0442\u0440\u043E\u043A\u043E\u0432\u043E\u043C \u043F\u0440\u0435\u0434\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u0438\u0438\"/>\n    <DataType ID=\"string\" BaseType=\"string\" OracleType=\"\" Size=\"VARCHAR2\" BriefText=\"\u0441\u0442\u0440\u043E\u043A\u0430 \u0441\u0438\u043C\u0432\u043E\u043B\u043E\u0432\"/>\n    <DataType ID=\"termid\" BaseType=\"string\" OracleType=\"8\" Size=\"VARCHAR2\" BriefText=\"\u043A\u043E\u0434 \u0442\u0435\u0440\u043C\u0438\u043D\u0430\u043B\u0430\"/>\n    <DataType ID=\"timestamp\" BaseType=\"timestamp\" OracleType=\"\" Size=\"TIMESTAMP\" BriefText=\"TIMESTAMP\"/>\n    <DataType ID=\"timestamp3\" BaseType=\"timestamp\" OracleType=\"3\" Size=\"TIMESTAMP\" BriefText=\"timestamp 3\"/>\n    <DataType ID=\"trseqnum\" BaseType=\"number\" OracleType=\"18\" Size=\"NUMBER\" BriefText=\"\u043F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u044B\u0439 \u043D\u043E\u043C\u0435\u0440 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u044F\"/>\n    <DataType ID=\"xmltype\" BaseType=\"xmltype\" OracleType=\"\" Size=\"XMLTYPE\" BriefText=\"xml \u0434\u0430\u043D\u043D\u044B\u0435\"/>\n  </DataTypes>\n</UCMsg>"
    },
    {
        key: "\n<UCMsg ID=\"13\">\n  <Schema>\n    <ObjectRefs ObjectsType=\"CONSTRAINT\"/>\n  </Schema>\n  <Context ID=\"555\">\n    <UserName>leonid</UserName>\n    <UserPassword>o</UserPassword>\n    <UserStatus></UserStatus>\n    <IPAddress></IPAddress>\n    <VerMask>\u0412</VerMask>\n    <SubMask>\u0412</SubMask>\n  </Context>\n</UCMsg>",
        val: "\n<UCMsg ID=\"13\">\n  <Status/>\n  <Context ID=\"355\">\n    <UserName>leonid</UserName>\n    <UserPassword>o</UserPassword>\n    <UserStatus></UserStatus>\n    <IPAddress/>\n    <VerMask>\u0412</VerMask>\n    <SubMask>\u0412</SubMask>\n  </Context>\n  <Schema>\n    <ObjectRefs ObjectsType=\"CONSTRAINT\">\n      <ObjectRef ID=\"CA12_0\" ObjectType=\"C\" BriefText=\"A12TBRW !=0\"/>\n      <ObjectRef ID=\"CHK_T95CLID\" ObjectType=\"C\" BriefText=\"T95CLID IS NOT NULL\"/>\n      <ObjectRef ID=\"CHK_T95POID\" ObjectType=\"C\" BriefText=\"T95POID IS NOT NULL\"/>\n      <ObjectRef ID=\"CL03_0\" ObjectType=\"C\" BriefText=\"L03DCRB&lt;=L03UCRB\"/>\n      <ObjectRef ID=\"CN21UNUM_NN\" ObjectType=\"C\" BriefText=\"N21UNUM IS NOT NULL\"/>\n      <ObjectRef ID=\"CN29_DIFF\" ObjectType=\"C\" BriefText=\" N29DIFF IS NOT NULL\"/>\n      <ObjectRef ID=\"CN29_PAYC\" ObjectType=\"C\" BriefText=\" N29PAYC IS NOT NULL\"/>\n      <ObjectRef ID=\"CN29_PAYD\" ObjectType=\"C\" BriefText=\" N29PAYD IS NOT NULL\"/>\n      <ObjectRef ID=\"CN51_ACSL\" ObjectType=\"C\" BriefText=\" N51ACSL IS NOT NULL\"/>\n      <ObjectRef ID=\"CN51_CRTR\" ObjectType=\"C\" BriefText=\" N51CRTR IS NOT NULL\"/>\n      <ObjectRef ID=\"CN51_DTRV\" ObjectType=\"C\" BriefText=\" N51DTRV IS NOT NULL\"/>\n      <ObjectRef ID=\"CA19AUID_PK\" ObjectType=\"P\" BriefText=\"A19AUID\"/>\n      <ObjectRef ID=\"CB31P002\" ObjectType=\"P\" BriefText=\"B31P002\"/>\n      <ObjectRef ID=\"CB54P041\" ObjectType=\"P\" BriefText=\"B54P041\"/>\n      <ObjectRef ID=\"CB72TRTC\" ObjectType=\"P\" BriefText=\"B72TRTC\"/>\n      <ObjectRef ID=\"CB74CURC\" ObjectType=\"P\" BriefText=\"B74CURC\"/>\n      <ObjectRef ID=\"CH01SLID_PK\" ObjectType=\"P\" BriefText=\"H01SLID\"/>\n      <ObjectRef ID=\"CH08_PK\" ObjectType=\"P\" BriefText=\"H08TSID\"/>\n      <ObjectRef ID=\"CH11_PK\" ObjectType=\"P\" BriefText=\"H11MBID\"/>\n      <ObjectRef ID=\"CH12_PK\" ObjectType=\"P\" BriefText=\"H12TSID,H12SEID,H12MBTP\"/>\n      <ObjectRef ID=\"CI08PK\" ObjectType=\"P\" BriefText=\"I08OPTP,I08OPCL\"/>\n      <ObjectRef ID=\"CI09RUID_P\" ObjectType=\"P\" BriefText=\"I09RUID\"/>\n      <ObjectRef ID=\"CK06POSI\" ObjectType=\"P\" BriefText=\"K06POSI\"/>\n      <ObjectRef ID=\"CN01OPID\" ObjectType=\"P\" BriefText=\"N01OPID\"/>\n      <ObjectRef ID=\"CN04_0\" ObjectType=\"P\" BriefText=\"N04OPID,N04PHID\"/>\n      <ObjectRef ID=\"CN29_0\" ObjectType=\"P\" BriefText=\"N29FDID\"/>\n      <ObjectRef ID=\"CN51_0\" ObjectType=\"P\" BriefText=\"N51ACNC,N51VALD\"/>\n      <ObjectRef ID=\"CT11_0\" ObjectType=\"P\" BriefText=\"T11OPTP\"/>\n      <ObjectRef ID=\"CT12_0\" ObjectType=\"P\" BriefText=\"T12PHTP\"/>\n      <ObjectRef ID=\"IC51_0\" ObjectType=\"P\" BriefText=\"C51CPCI\"/>\n      <ObjectRef ID=\"IC62_0\" ObjectType=\"P\" BriefText=\"C62CTID,C62LNID\"/>\n      <ObjectRef ID=\"IL91_PK\" ObjectType=\"P\" BriefText=\"L91LPAN,L91HPAN,L91PSFL,L91ESH9,L91RDAT,L91ORDR\"/>\n      <ObjectRef ID=\"IL92_PK\" ObjectType=\"P\" BriefText=\"L92LPAN,L92HPAN,L92PSFL,L92ESH9,L92ORDR\"/>\n      <ObjectRef ID=\"IL93_PK\" ObjectType=\"P\" BriefText=\"L93LPAN,L93HPAN,L93PSFL,L93ESH9,L93RDAT\"/>\n      <ObjectRef ID=\"CA20AUID_FK\" ObjectType=\"R\" BriefText=\"CA19AUID_PK\"/>\n    </ObjectRefs>\n  </Schema>\n</UCMsg>"
    },
    {
        key: "\n<UCMsg ID=\"7\">\n  <RequestHead ID=\"0\">\n    <Action>info</Action>\n    <Requests>\n      <Request ID=\"0\">\n        <Action>info</Action>\n        <Subject>\n          <Action>info</Action>\n          <Object Type=\"TABLE\">\n            <Table ID=\"A01\"></Table>\n          </Object>\n        </Subject>\n      </Request>\n    </Requests>\n  </RequestHead>\n  <Context ID=\"555\">\n    <UserName>leonid</UserName>\n    <UserPassword>o</UserPassword>\n    <UserStatus></UserStatus>\n    <IPAddress></IPAddress>\n    <VerMask>\u0412</VerMask>\n    <SubMask>\u0412</SubMask>\n  </Context>\n</UCMsg>",
        val: "\n<UCMsg ID=\"7\">\n  <RequestHead ID=\"0\">\n    <Action>info</Action>\n    <Requests>\n      <Request ID=\"0\">\n        <Action>info</Action>\n        <Subject>\n          <Action>info</Action>\n          <Object Type=\"TABLE\">\n            <Table ID=\"A01\">\n              <Fields>\n                <Field ID=\"A01DATE\">\n                  <TableID>A01</TableID>\n                  <Type>date</Type>\n                  <Position>2</Position>\n                  <Nullable>N</Nullable>\n                  <BriefText>MessageDate</BriefText>\n                  <FullText>\u0414\u0430\u0442\u0430 \u0438 \u0432\u0440\u0435\u043C\u044F \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u044F</FullText>\n                </Field>\n                <Field ID=\"A01MESS\">\n                  <TableID>A01</TableID>\n                  <Type>string(2000)</Type>\n                  <Size>2000</Size>\n                  <Position>3</Position>\n                  <Nullable>N</Nullable>\n                  <BriefText>Message</BriefText>\n                  <FullText>\u0418\u043C\u044F \u043F\u0440\u043E\u0446\u0435\u0441\u0441\u0430 \u0438\u043B\u0438 \u043F\u0440\u043E\u0446\u0435\u0434\u0443\u0440\u044B, \u0441\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u0432\u0448\u0435\u0439 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0435</FullText>\n                </Field>\n                <Field ID=\"A01ERRM\">\n                  <TableID>A01</TableID>\n                  <Type>string(2000)</Type>\n                  <Size>2000</Size>\n                  <Position>4</Position>\n                  <Nullable>Y</Nullable>\n                  <BriefText>ErrorString</BriefText>\n                  <FullText>\u0421\u043E\u0434\u0435\u0440\u0436\u0430\u043D\u0438\u0435 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u044F</FullText>\n                </Field>\n                <Field ID=\"A01AMOD\">\n                  <TableID>A01</TableID>\n                  <Type>string(8)</Type>\n                  <Size>8</Size>\n                  <Position>5</Position>\n                  <Nullable>Y</Nullable>\n                  <BriefText>ArchiveMode</BriefText>\n                  <FullText>\u0422\u0438\u043F \u043F\u0440\u043E\u0446\u0435\u0441\u0441\u0430, \u0441\u0444\u043E\u0440\u043C\u0438\u0440\u043E\u0432\u0430\u0432\u0448\u0435\u0433\u043E \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0435 (\u041D\u0430\u0438\u043C\u0435\u043D\u043E\u0432\u0430\u043D\u0438\u0435 \u0432 T80 \u0441typ=167)</FullText>\n                </Field>\n                <Field ID=\"A01LEVL\">\n                  <TableID>A01</TableID>\n                  <Type>string(1)</Type>\n                  <Size>1</Size>\n                  <Position>13102</Position>\n                  <Nullable>Y</Nullable>\n                  <BriefText>ErrorLevel</BriefText>\n                  <FullText>\u0423\u0440\u043E\u0432\u0435\u043D\u044C \u043E\u0448\u0438\u0431\u043A\u0438(I-\u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u044F,W-\u043F\u0440\u0435\u0434\u0443\u043F\u0440\u0435\u0436\u0434\u0435\u043D\u0438\u0435,E-\u043E\u0448\u0438\u0431\u043A\u0430)</FullText>\n                </Field>\n                <Field ID=\"A01OPID\">\n                  <TableID>A01</TableID>\n                  <Type>memberid</Type>\n                  <Position>13103</Position>\n                  <Nullable>Y</Nullable>\n                  <FullText>\u041A\u043E\u0434 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438, \u0437\u0430\u043F\u0443\u0441\u0442\u0438\u0432\u0448\u0438\u0439 \u043F\u0440\u043E\u0446\u0435\u0441\u0441</FullText>\n                </Field>\n                <Field ID=\"A01CPTR\">\n                  <TableID>A01</TableID>\n                  <Type>intmax</Type>\n                  <Position>13104</Position>\n                  <Nullable>Y</Nullable>\n                  <FullText>\u0421\u0441\u044B\u043B\u043A\u0430 \u043D\u0430 I23STRF(\u043F\u043E\u0434\u0440\u043E\u0431\u043D\u044B\u0439 \u043F\u0440\u043E\u0442\u043E\u043A\u043E\u043B \u043F\u0440\u043E\u0446\u0435\u0441\u0441\u0430)</FullText>\n                </Field>\n                <Field ID=\"A01OBID\">\n                  <TableID>A01</TableID>\n                  <Type>number(11)</Type>\n                  <Size>11</Size>\n                  <Position>14220</Position>\n                  <Nullable>Y</Nullable>\n                  <BriefText>ObjectID</BriefText>\n                  <FullText>\u0418\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440 \u043E\u0431\u044A\u0435\u043A\u0442\u0430</FullText>\n                </Field>\n                <Field ID=\"A01MBST\">\n                  <TableID>A01</TableID>\n                  <Type>number(11)</Type>\n                  <Size>11</Size>\n                  <Position>14221</Position>\n                  <Nullable>Y</Nullable>\n                  <BriefText>ObjectType</BriefText>\n                  <FullText>\u0422\u0438\u043F \u043E\u0431\u044A\u0435\u043A\u0442\u0430</FullText>\n                </Field>\n                <Field ID=\"A01IDEN\">\n                  <TableID>A01</TableID>\n                  <Type>long</Type>\n                  <Nullable>N</Nullable>\n                  <BriefText>ID</BriefText>\n                  <FullText>\u041D\u043E\u043C\u0435\u0440 \u043F\u043E \u043F\u043E\u0440\u044F\u0434\u043A\u0443 \u0441\u0447\u0451\u0442\u0447\u0438\u043A SEQ_A01 \u0442\u0440\u0438\u0433\u0433\u0435\u0440 TA01_0 </FullText>\n                </Field>\n              </Fields>\n              <Indexes>\n                <Index ID=\"IA01IDEN\">\n                  <TableID>A01</TableID>\n                  <Type/>\n                  <Uniqueness>1</Uniqueness>\n                  <Fields>\n                    <Field ID=\"A01IDEN\">\n                      <TableID>A01</TableID>\n                      <Position>1</Position>\n                    </Field>\n                  </Fields>\n                </Index>\n                <Index ID=\"IA01OPID\">\n                  <TableID>A01</TableID>\n                  <Type/>\n                  <Uniqueness>0</Uniqueness>\n                  <Fields>\n                    <Field ID=\"A01OPID\">\n                      <TableID>A01</TableID>\n                      <Position>1</Position>\n                    </Field>\n                  </Fields>\n                </Index>\n                <Index ID=\"IA01_1\">\n                  <TableID>A01</TableID>\n                  <Type>0</Type>\n                  <Uniqueness>0</Uniqueness>\n                  <Fields>\n                    <Field ID=\"A01MBST\">\n                      <TableID>A01</TableID>\n                      <Position>1</Position>\n                    </Field>\n                    <Field ID=\"A01OBID\">\n                      <TableID>A01</TableID>\n                      <Position>2</Position>\n                    </Field>\n                  </Fields>\n                </Index>\n              </Indexes>\n              <BriefText>\u041F\u0440\u043E\u0442\u043E\u043A\u043E\u043B \u0432\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u044F \u043F\u0440\u043E\u0446\u0435\u0441\u0441\u043E\u0432</BriefText>\n              <FullText>\u0421\u043E\u0434\u0435\u0440\u0436\u0438\u0442 \u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0443\u044E \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u044E \u0438 \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u044E \u043E\u0431 \u043E\u0448\u0438\u0431\u043A\u0430\u0445</FullText>\n            </Table>\n          </Object>\n          <ObjectContext>\n            <Users>EVGENIY,GMG,KHATAEV,KOT,LEONID,MARAT,NERVIWKI,OLEG,OSA,ROSTICK,SELIV,SHESTAKOV,VLAD76,VLASENKO,WOWA</Users>\n            <RequestHeads>\n              <ObjectRef ID=\"3176\" ObjectType=\"REQUESTHEAD\" BriefText=\"\u0420\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u0444\u0443\u043D\u043A\u0446\u0438\u043E\u043D\u0430\u043B\u044C\u043D\u043E\u0441\u0442\u0438 \u043F\u0440\u043E\u0442\u043E\u043A\u043E\u043B\u0430\" Author=\"WOWA\" Done=\"2006.12.25\"/>\n              <ObjectRef ID=\"3347\" ObjectType=\"REQUESTHEAD\" BriefText=\"\u0423\u0441\u043A\u043E\u0440\u0435\u043D\u0438\u0435 \u0434\u043E\u0441\u0442\u0443\u043F\u0430 \u043A \u043F\u0440\u043E\u0442\u043E\u043A\u043E\u043B\u0443\" Author=\"SELIV\" Done=\"2007.11.27\"/>\n              <ObjectRef ID=\"3483\" ObjectType=\"REQUESTHEAD\" BriefText=\"\u0420\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u0432\u043E\u0437\u043C\u043E\u0436\u043D\u043E\u0441\u0442\u0435\u0439 \u043F\u0440\u043E\u0442\u043E\u043A\u043E\u043B\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F\" Author=\"SELIV\" Done=\"2008.10.13\"/>\n              <ObjectRef ID=\"4750\" ObjectType=\"REQUESTHEAD\" BriefText=\"\u0420\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u0432\u043E\u0437\u043C\u043E\u0436\u043D\u043E\u0441\u0442\u0435\u0439 \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438 \u0440\u0435\u0433\u043B\u0430\u043C\u0435\u043D\u0442\u043D\u044B\u0445 \u0437\u0430\u0434\u0430\u043D\u0438\u0439. \u0412 \u0440\u0430\u043C\u043A\u0430\u0445 \u0437\u0430\u044F\u0432\u043A\u0438 \nbas00021963\" Author=\"ROSTICK\" Done=\"2014.04.21\"/>\n            </RequestHeads>\n          </ObjectContext>\n        </Subject>\n      </Request>\n    </Requests>\n  </RequestHead>\n  <Status/>\n  <Context ID=\"355\">\n    <UserName>leonid</UserName>\n    <UserPassword>o</UserPassword>\n    <UserStatus></UserStatus>\n    <IPAddress/>\n    <VerMask>\u0412</VerMask>\n    <SubMask>\u0412</SubMask>\n  </Context>\n</UCMsg>"
    },
    {
        key: "\n<UCMsg ID=\"9\">\n  <RequestHead ID=\"3176\">\n    <Action>info</Action>\n  </RequestHead>\n  <Context ID=\"555\">\n    <UserName>leonid</UserName>\n    <UserPassword>o</UserPassword>\n    <UserStatus></UserStatus>\n    <IPAddress></IPAddress>\n    <VerMask>\u0412</VerMask>\n    <SubMask>\u0412</SubMask>\n  </Context>\n</UCMsg>",
        val: "\n<UCMsg ID=\"9\">\n  <RequestHead ID=\"3176\">\n    <Action>info</Action>\n    <Requests>\n      <Request ID=\"13102\">\n        <Action>info</Action>\n        <Subject>\n          <Action>add</Action>\n          <Object Type=\"FIELD\">\n            <Field ID=\"A01LEVL\">\n              <TableID>A01</TableID>\n              <Type>string(1)</Type>\n              <Size>1</Size>\n              <Nullable>Y</Nullable>\n              <BriefText>ErrorLevel</BriefText>\n              <FullText>\u0423\u0440\u043E\u0432\u0435\u043D\u044C \u043E\u0448\u0438\u0431\u043A\u0438(I-\u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u044F,W-\u043F\u0440\u0435\u0434\u0443\u043F\u0440\u0435\u0436\u0434\u0435\u043D\u0438\u0435,E-\u043E\u0448\u0438\u0431\u043A\u0430)</FullText>\n            </Field>\n          </Object>\n        </Subject>\n      </Request>\n      <Request ID=\"13103\">\n        <Action>info</Action>\n        <Subject>\n          <Action>add</Action>\n          <Object Type=\"FIELD\">\n            <Field ID=\"A01OPID\">\n              <TableID>A01</TableID>\n              <Type>memberid</Type>\n              <Nullable>Y</Nullable>\n              <FullText>\u041A\u043E\u0434 \u043E\u043F\u0435\u0440\u0430\u0446\u0438\u0438, \u0437\u0430\u043F\u0443\u0441\u0442\u0438\u0432\u0448\u0438\u0439 \u043F\u0440\u043E\u0446\u0435\u0441\u0441</FullText>\n            </Field>\n          </Object>\n        </Subject>\n      </Request>\n      <Request ID=\"13104\">\n        <Action>info</Action>\n        <Subject>\n          <Action>add</Action>\n          <Object Type=\"FIELD\">\n            <Field ID=\"A01CPTR\">\n              <TableID>A01</TableID>\n              <Type>intmax</Type>\n              <Nullable>Y</Nullable>\n              <FullText>\u0421\u0441\u044B\u043B\u043A\u0430 \u043D\u0430 I23STRF(\u043F\u043E\u0434\u0440\u043E\u0431\u043D\u044B\u0439 \u043F\u0440\u043E\u0442\u043E\u043A\u043E\u043B \u043F\u0440\u043E\u0446\u0435\u0441\u0441\u0430)</FullText>\n            </Field>\n          </Object>\n        </Subject>\n      </Request>\n    </Requests>\n    <BriefText>\u0420\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u0444\u0443\u043D\u043A\u0446\u0438\u043E\u043D\u0430\u043B\u044C\u043D\u043E\u0441\u0442\u0438 \u043F\u0440\u043E\u0442\u043E\u043A\u043E\u043B\u0430</BriefText>\n    <Author>WOWA</Author>\n    <Created>21.12.2006 11:23:54</Created>\n    <Done>25.12.2006 12:31:22</Done>\n  </RequestHead>\n  <Status/>\n  <Context ID=\"355\">\n    <UserName>leonid</UserName>\n    <UserPassword>o</UserPassword>\n    <UserStatus></UserStatus>\n    <IPAddress/>\n    <VerMask>\u0412</VerMask>\n    <SubMask>\u0412</SubMask>\n  </Context>\n</UCMsg>"
    },
    {
        key: "\n<UCMsg ID=\"11\">\n  <Confirms>\n    <Filter>\n      <Status>notapproved</Status>\n      <DateFrom>" + ATools.getdate(-6) + "</DateFrom>\n      <DateTo>" + ATools.getdate(0) + "</DateTo>\n    </Filter>\n  </Confirms>\n  <Context ID=\"555\">\n    <UserName>leonid</UserName>\n    <UserPassword>o</UserPassword>\n    <UserStatus></UserStatus>\n    <IPAddress></IPAddress>\n    <VerMask>\u0412</VerMask>\n    <SubMask>\u0412</SubMask>\n  </Context>\n</UCMsg>",
        val: "\n<UCMsg ID=\"11\">\n  <Status/>\n  <Context ID=\"355\">\n    <UserName>leonid</UserName>\n    <UserPassword>o</UserPassword>\n    <UserStatus></UserStatus>\n    <IPAddress/>\n    <VerMask>\u0412</VerMask>\n    <SubMask>\u0412</SubMask>\n  </Context>\n  <Confirms>\n    <Confirm>\n      <RequestHead ID=\"5257\">\n        <Action>info</Action>\n        <BriefText>\u043B\u0434\u043B\u0434</BriefText>\n        <Author>LEONID</Author>\n        <Created>31.03 13:08:28</Created>\n      </RequestHead>\n      <Decision/>\n      <UsersConfirm>\n        <UserConfirm ID=\"EVGENIY\" Decision=\"Y\"/>\n        <UserConfirm ID=\"GMG\" Decision=\"\"/>\n        <UserConfirm ID=\"KHATAEV\" Decision=\"\"/>\n        <UserConfirm ID=\"KOT\" Decision=\"\"/>\n        <UserConfirm ID=\"LEONID\" Decision=\"\"/>\n        <UserConfirm ID=\"MARAT\" Decision=\"\"/>\n        <UserConfirm ID=\"NERVIWKI\" Decision=\"\"/>\n        <UserConfirm ID=\"OLEG\" Decision=\"\"/>\n        <UserConfirm ID=\"OSA\" Decision=\"\"/>\n        <UserConfirm ID=\"ROSTICK\" Decision=\"\"/>\n        <UserConfirm ID=\"SELIV\" Decision=\"\"/>\n        <UserConfirm ID=\"SHESTAKOV\" Decision=\"\"/>\n        <UserConfirm ID=\"VLAD76\" Decision=\"Y\"/>\n        <UserConfirm ID=\"VLASENKO\" Decision=\"\"/>\n        <UserConfirm ID=\"WOWA\" Decision=\"Y\"/>\n      </UsersConfirm>\n    </Confirm>\n    <Confirm>\n      <RequestHead ID=\"5255\">\n        <Action>info</Action>\n        <BriefText>\u043F\u043E\u0434\u0434\u0435\u0440\u0436\u043A\u0430 \u043C\u043E\u0434\u0435\u043B\u0438 \u0441\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0439 \u0434\u043B\u044F \u043F\u043E\u0434\u0440\u0430\u0437\u0434\u0435\u043B\u0435\u043D\u0438\u0439 \u043A\u043B\u0438\u0435\u043D\u0442\u0441\u043A\u0438\u0445 \u043E\u0440\u0433\u0430\u043D\u0438\u0437\u0430\u0446\u0438\u0439</BriefText>\n        <Author>WOWA</Author>\n        <Created>31.03 15:47:43</Created>\n      </RequestHead>\n      <Decision/>\n      <UsersConfirm>\n        <UserConfirm ID=\"EVGENIY\" Decision=\"Y\"/>\n        <UserConfirm ID=\"GMG\" Decision=\"\"/>\n        <UserConfirm ID=\"KHATAEV\" Decision=\"\"/>\n        <UserConfirm ID=\"KOT\" Decision=\"\"/>\n        <UserConfirm ID=\"LEONID\" Decision=\"\"/>\n        <UserConfirm ID=\"MARAT\" Decision=\"\"/>\n        <UserConfirm ID=\"NERVIWKI\" Decision=\"\"/>\n        <UserConfirm ID=\"OLEG\" Decision=\"\"/>\n        <UserConfirm ID=\"OSA\" Decision=\"\"/>\n        <UserConfirm ID=\"ROSTICK\" Decision=\"\"/>\n        <UserConfirm ID=\"SELIV\" Decision=\"\"/>\n        <UserConfirm ID=\"SHESTAKOV\" Decision=\"\"/>\n        <UserConfirm ID=\"VLAD76\" Decision=\"\"/>\n        <UserConfirm ID=\"VLASENKO\" Decision=\"\"/>\n        <UserConfirm ID=\"WOWA\" Decision=\"Y\"/>\n      </UsersConfirm>\n    </Confirm>\n    <Confirm>\n      <RequestHead ID=\"5248\">\n        <Action>info</Action>\n        <BriefText>\u041D\u0435\u043E\u0431\u0445\u043E\u0434\u0438\u043C\u043E\u0441\u0442\u044C \u0438\u043D\u0434\u0435\u043A\u0441\u043E\u0432 \u043F\u043E \u043F\u043E\u043B\u044F\u043C F13PKID \u0438 F29PKID \u0434\u043B\u044F \u043A\u043E\u043D\u0442\u0440\u043E\u043B\u044F \u0430\u043A\u0442\u0443\u0430\u043B\u0438\u0437\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u043E\u0441\u0442\u0438 \u0432\u0441\u0435\u0445 \u043E\u0431\u044A\u0435\u043A\u0442\u043E\u0432 \u043F\u0430\u043A\u0435\u0442\u0430</BriefText>\n        <Author>LEONID</Author>\n        <Created>15.03 18:26:56</Created>\n      </RequestHead>\n      <Decision/>\n      <UsersConfirm>\n        <UserConfirm ID=\"EVGENIY\" Decision=\"Y\"/>\n        <UserConfirm ID=\"GMG\" Decision=\"\"/>\n        <UserConfirm ID=\"KHATAEV\" Decision=\"\"/>\n        <UserConfirm ID=\"KOT\" Decision=\"\"/>\n        <UserConfirm ID=\"LEONID\" Decision=\"\"/>\n        <UserConfirm ID=\"MARAT\" Decision=\"\"/>\n        <UserConfirm ID=\"NERVIWKI\" Decision=\"\"/>\n        <UserConfirm ID=\"OLEG\" Decision=\"\"/>\n        <UserConfirm ID=\"OSA\" Decision=\"Y\"/>\n        <UserConfirm ID=\"ROSTICK\" Decision=\"\"/>\n        <UserConfirm ID=\"SELIV\" Decision=\"\"/>\n        <UserConfirm ID=\"SHESTAKOV\" Decision=\"\"/>\n        <UserConfirm ID=\"VLAD76\" Decision=\"\"/>\n        <UserConfirm ID=\"VLASENKO\" Decision=\"\"/>\n        <UserConfirm ID=\"WOWA\" Decision=\"Y\"/>\n      </UsersConfirm>\n    </Confirm>\n    <Confirm>\n      <RequestHead ID=\"5244\">\n        <Action>info</Action>\n        <BriefText>\u041E\u0436\u0438\u0434\u0430\u0435\u043C\u044B\u0435 \u043F\u0440\u0438\u0445\u043E\u0434\u043D\u044B\u0435 \u043F\u043B\u0430\u0442\u0451\u0436\u043D\u044B\u0435 \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u044B \u0423\u0424\u042D\u0411\u0421</BriefText>\n        <Author>OSA</Author>\n        <Created>11.03 10:33:56</Created>\n      </RequestHead>\n      <Decision/>\n      <UsersConfirm>\n        <UserConfirm ID=\"EVGENIY\" Decision=\"Y\"/>\n        <UserConfirm ID=\"GMG\" Decision=\"\"/>\n        <UserConfirm ID=\"KHATAEV\" Decision=\"\"/>\n        <UserConfirm ID=\"KOT\" Decision=\"\"/>\n        <UserConfirm ID=\"LEONID\" Decision=\"\"/>\n        <UserConfirm ID=\"MARAT\" Decision=\"\"/>\n        <UserConfirm ID=\"NERVIWKI\" Decision=\"\"/>\n        <UserConfirm ID=\"OLEG\" Decision=\"\"/>\n        <UserConfirm ID=\"OSA\" Decision=\"Y\"/>\n        <UserConfirm ID=\"ROSTICK\" Decision=\"\"/>\n        <UserConfirm ID=\"SELIV\" Decision=\"\"/>\n        <UserConfirm ID=\"SHESTAKOV\" Decision=\"\"/>\n        <UserConfirm ID=\"VLAD76\" Decision=\"\"/>\n        <UserConfirm ID=\"VLASENKO\" Decision=\"\"/>\n        <UserConfirm ID=\"WOWA\" Decision=\"Y\"/>\n      </UsersConfirm>\n    </Confirm>\n    <Filter>\n      <Status>notapproved</Status>\n      <DateFrom>08.07.2015</DateFrom>\n      <DateTo>15.02.2017</DateTo>\n    </Filter>\n  </Confirms>\n</UCMsg>"
    },
    {
        key: "\n<UCMsg ID=\"9\">\n  <RequestHead ID=\"5257\">\n    <Action>info</Action>\n  </RequestHead>\n  <Context ID=\"555\">\n    <UserName>leonid</UserName>\n    <UserPassword>o</UserPassword>\n    <UserStatus></UserStatus>\n    <IPAddress></IPAddress>\n    <VerMask>\u0412</VerMask>\n    <SubMask>\u0412</SubMask>\n  </Context>\n</UCMsg>",
        val: "\n<UCMsg ID=\"9\">\n  <RequestHead ID=\"5257\">\n    <Action>info</Action>\n    <Requests>\n      <Request ID=\"37771\">\n        <Action>info</Action>\n        <Subject>\n          <Action>add</Action>\n          <Object Type=\"FIELD\">\n            <Field ID=\"B62CHEN\">\n              <TableID>B62</TableID>\n              <Type>string(26)</Type>\n              <Size>26</Size>\n              <Position>37771</Position>\n              <Nullable>Y</Nullable>\n              <BriefText>CardholdEmbossName</BriefText>\n              <FullText>\u0418\u043C\u044F \u043A\u043B\u0438\u0435\u043D\u0442\u0430 \u044D\u043C\u0431\u043E\u0441\u0441\u0438\u0440\u0443\u0435\u043C\u043E\u0435 \u043D\u0430 \u043A\u0430\u0440\u0442\u0435 - \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0435\u0442\u0441\u044F \u043F\u0440\u0438 \u0432\u044B\u0433\u0440\u0443\u0437\u043A\u0435 \u0444\u0430\u0439\u043B\u0430 \u043D\u0430 \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u0438\u0437\u0430\u0446\u0438\u044E, \u0435\u0441\u043B\u0438 \u043D\u0435 \u0437\u0430\u0434\u0430\u043D\u043E \u0437\u0430 \u043A\u0430\u0440\u0442\u043E\u0439</FullText>\n            </Field>\n          </Object>\n        </Subject>\n      </Request>\n      <Request ID=\"37772\">\n        <Action>info</Action>\n        <Subject>\n          <Action>add</Action>\n          <Object Type=\"FIELD\">\n            <Field ID=\"B62CMEN\">\n              <TableID>B62</TableID>\n              <Type>string(30)</Type>\n              <Size>30</Size>\n              <Position>37772</Position>\n              <Nullable>Y</Nullable>\n              <BriefText>CompanyEmbossName</BriefText>\n              <FullText>\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435 \u043E\u0440\u0433\u0430\u043D\u0438\u0437\u0430\u0446\u0438\u0438 \u043F\u0440\u0438 \u044D\u043C\u0431\u043E\u0441\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0438 - \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0435\u0442\u0441\u044F \u043F\u0440\u0438 \u0432\u044B\u0433\u0440\u0443\u0437\u043A\u0435 \u0444\u0430\u0439\u043B\u0430 \u043D\u0430 \u043F\u0435\u0440\u0441\u043E\u043D\u0430\u043B\u0438\u0437\u0430\u0446\u0438\u044E, \u0435\u0441\u043B\u0438 \u043D\u0435 \u0437\u0430\u0434\u0430\u043D\u043E \u0437\u0430 \u043A\u0430\u0440\u0442\u043E\u0439</FullText>\n            </Field>\n          </Object>\n        </Subject>\n      </Request>\n    </Requests>\n    <BriefText>\u043B\u0434\u043B\u0434</BriefText>\n    <Author>VLAD76</Author>\n    <Created>31.03.2016 01:08:28</Created>\n  </RequestHead>\n  <Status/>\n  <Context ID=\"355\">\n    <UserName>leonid</UserName>\n    <UserPassword>o</UserPassword>\n    <UserStatus></UserStatus>\n    <IPAddress/>\n    <VerMask>\u0412</VerMask>\n    <SubMask>\u0412</SubMask>\n  </Context>\n</UCMsg>"
    },
    {
        key: "\n<UCMsg ID=\"9\">\n  <RequestHead ID=\"5248\">\n    <Action>info</Action>\n  </RequestHead>\n  <Context ID=\"555\">\n    <UserName>leonid</UserName>\n    <UserPassword>o</UserPassword>\n    <UserStatus></UserStatus>\n    <IPAddress></IPAddress>\n    <VerMask>\u0412</VerMask>\n    <SubMask>\u0412</SubMask>\n  </Context>\n</UCMsg>",
        val: "\n<UCMsg ID=\"5\">\n  <RequestHead ID=\"5382\">\n    <Action>info</Action>\n    <Requests>\n      <Request ID=\"38444\">\n        <Action>info</Action>\n        <Subject>\n          <Action>add</Action>\n          <Object Type=\"FIELD\">\n            <Field ID=\"A19343\">\n              <TableID>A19</TableID>\n              <Type>number(2,1)</Type>\n              <Size>2</Size>\n              <Precision>1</Precision>\n              <Position>38444</Position>\n              <Nullable>Y</Nullable>\n              <BriefText>ewfewf</BriefText>\n              <FullText>wfwef</FullText>\n            </Field>\n          </Object>\n        </Subject>\n      </Request>\n    </Requests>\n    <BriefText>wefwefwe</BriefText>\n    <Author>LEONID</Author>\n  </RequestHead>\n  <Status>\n    <Code>0</Code>\n    <Description>OK</Description>\n  </Status>\n  <Context ID=\"348\">\n    <UserName>LEONID</UserName>\n    <UserPassword>O</UserPassword>\n    <UserStatus>1</UserStatus>\n    <IPAddress/>\n    <VerMask>\u0412</VerMask>\n    <SubMask>\u0412</SubMask>\n  </Context>\n</UCMsg>"
    },
    {
        key: "\n<UCMsg ID=\"11\">\n  <Confirms>\n    <Filter>\n      <Status>approved</Status>\n      <DateFrom>" + ATools.getdate(-6) + "</DateFrom>\n      <DateTo>" + ATools.getdate(0) + "</DateTo>\n    </Filter>\n  </Confirms>\n  <Context ID=\"555\">\n    <UserName>leonid</UserName>\n    <UserPassword>o</UserPassword>\n    <UserStatus></UserStatus>\n    <IPAddress></IPAddress>\n    <VerMask>\u0412</VerMask>\n    <SubMask>\u0412</SubMask>\n  </Context>\n</UCMsg>",
        val: "\n<UCMsg ID=\"11\">\n  <Status/>\n  <Context ID=\"355\">\n    <UserName>leonid</UserName>\n    <UserPassword>o</UserPassword>\n    <UserStatus></UserStatus>\n    <IPAddress/>\n    <VerMask>\u0412</VerMask>\n    <SubMask>\u0412</SubMask>\n  </Context>\n  <Confirms>\n    <Confirm>\n      <RequestHead ID=\"5239\">\n        <Action>info</Action>\n        <BriefText>\u0420\u0430\u0441\u0447\u0435\u0442 \u0440\u0435\u0439\u0442\u0438\u043D\u0433\u0430 \u043A\u043E\u0440\u0440. \u0441\u0447\u0435\u0442\u043E\u0432 (\u0434\u043B\u044F \u0437\u0430\u044F\u0432\u043A\u0438 20685)</BriefText>\n        <Author>EVGENIY</Author>\n        <Created>03.03 17:21:11</Created>\n        <Done>04.03 11:42:06</Done>\n      </RequestHead>\n      <Decision/>\n      <UsersConfirm>\n        <UserConfirm ID=\"ALEXB\" Decision=\"Y\"/>\n        <UserConfirm ID=\"EVGENIY\" Decision=\"Y\"/>\n        <UserConfirm ID=\"GMG\" Decision=\"Y\"/>\n        <UserConfirm ID=\"KHATAEV\" Decision=\"Y\"/>\n        <UserConfirm ID=\"KOT\" Decision=\"Y\"/>\n        <UserConfirm ID=\"LEONID\" Decision=\"Y\"/>\n        <UserConfirm ID=\"MARAT\" Decision=\"Y\"/>\n        <UserConfirm ID=\"NERVIWKI\" Decision=\"Y\"/>\n        <UserConfirm ID=\"OLEG\" Decision=\"Y\"/>\n        <UserConfirm ID=\"OSA\" Decision=\"Y\"/>\n        <UserConfirm ID=\"ROSTICK\" Decision=\"Y\"/>\n        <UserConfirm ID=\"SELIV\" Decision=\"Y\"/>\n        <UserConfirm ID=\"SHESTAKOV\" Decision=\"Y\"/>\n        <UserConfirm ID=\"VLAD76\" Decision=\"Y\"/>\n        <UserConfirm ID=\"VLASENKO\" Decision=\"Y\"/>\n        <UserConfirm ID=\"WOWA\" Decision=\"Y\"/>\n        <UserConfirm ID=\"ALEXB\" Decision=\"\"/>\n      </UsersConfirm>\n    </Confirm>\n    <Confirm>\n      <RequestHead ID=\"5237\">\n        <Action>info</Action>\n        <BriefText>\u0423\u0434\u0430\u043B\u0435\u043D\u0438\u0435 \u043E\u0433\u0440\u0430\u043D\u0438\u0447\u0435\u043D\u0438\u0439 \u0442\u0430\u0431\u043B\u0438\u0446\u044B T06</BriefText>\n        <Author>OSA</Author>\n        <Created>03.03 15:52:26</Created>\n        <Done>04.03 11:42:07</Done>\n      </RequestHead>\n      <Decision/>\n      <UsersConfirm>\n        <UserConfirm ID=\"ALEXB\" Decision=\"Y\"/>\n        <UserConfirm ID=\"EVGENIY\" Decision=\"Y\"/>\n        <UserConfirm ID=\"GMG\" Decision=\"Y\"/>\n        <UserConfirm ID=\"KHATAEV\" Decision=\"Y\"/>\n        <UserConfirm ID=\"KOT\" Decision=\"Y\"/>\n        <UserConfirm ID=\"LEONID\" Decision=\"Y\"/>\n        <UserConfirm ID=\"MARAT\" Decision=\"Y\"/>\n        <UserConfirm ID=\"NERVIWKI\" Decision=\"Y\"/>\n        <UserConfirm ID=\"OLEG\" Decision=\"Y\"/>\n        <UserConfirm ID=\"OSA\" Decision=\"Y\"/>\n        <UserConfirm ID=\"ROSTICK\" Decision=\"Y\"/>\n        <UserConfirm ID=\"SELIV\" Decision=\"Y\"/>\n        <UserConfirm ID=\"SHESTAKOV\" Decision=\"Y\"/>\n        <UserConfirm ID=\"VLAD76\" Decision=\"Y\"/>\n        <UserConfirm ID=\"VLASENKO\" Decision=\"Y\"/>\n        <UserConfirm ID=\"WOWA\" Decision=\"Y\"/>\n        <UserConfirm ID=\"ALEXB\" Decision=\"\"/>\n      </UsersConfirm>\n    </Confirm>\n    <Confirm>\n      <RequestHead ID=\"5236\">\n        <Action>info</Action>\n        <BriefText>\u0423\u0434\u0430\u043B\u0435\u043D\u0438\u0435 \u043F\u043E\u043B\u044F N67ACCT</BriefText>\n        <Author>VLASENKO</Author>\n        <Created>03.03 15:34:01</Created>\n        <Done>04.03 11:42:09</Done>\n      </RequestHead>\n      <Decision/>\n      <UsersConfirm>\n        <UserConfirm ID=\"ALEXB\" Decision=\"Y\"/>\n        <UserConfirm ID=\"EVGENIY\" Decision=\"Y\"/>\n        <UserConfirm ID=\"GMG\" Decision=\"Y\"/>\n        <UserConfirm ID=\"KHATAEV\" Decision=\"Y\"/>\n        <UserConfirm ID=\"KOT\" Decision=\"Y\"/>\n        <UserConfirm ID=\"LEONID\" Decision=\"Y\"/>\n        <UserConfirm ID=\"MARAT\" Decision=\"Y\"/>\n        <UserConfirm ID=\"NERVIWKI\" Decision=\"Y\"/>\n        <UserConfirm ID=\"OLEG\" Decision=\"Y\"/>\n        <UserConfirm ID=\"OSA\" Decision=\"Y\"/>\n        <UserConfirm ID=\"ROSTICK\" Decision=\"Y\"/>\n        <UserConfirm ID=\"SELIV\" Decision=\"Y\"/>\n        <UserConfirm ID=\"SHESTAKOV\" Decision=\"Y\"/>\n        <UserConfirm ID=\"VLAD76\" Decision=\"Y\"/>\n        <UserConfirm ID=\"VLASENKO\" Decision=\"Y\"/>\n        <UserConfirm ID=\"WOWA\" Decision=\"Y\"/>\n        <UserConfirm ID=\"ALEXB\" Decision=\"\"/>\n      </UsersConfirm>\n    </Confirm>\n    <Confirm>\n      <RequestHead ID=\"5235\">\n        <Action>info</Action>\n        <BriefText>\u0417\u0430\u0434\u0430\u043D\u0438\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u043F\u043E \u0443\u043C\u043E\u043B\u0447\u0430\u043D\u0438\u044E \u0434\u043B\u044F N67ACCT - \u0432\u0438\u0434 \u0441\u0447\u0451\u0442\u0430</BriefText>\n        <Author>VLASENKO</Author>\n        <Created>03.03 14:18:38</Created>\n        <Done>03.03 14:36:29</Done>\n      </RequestHead>\n      <Decision/>\n      <UsersConfirm>\n        <UserConfirm ID=\"ALEXB\" Decision=\"Y\"/>\n        <UserConfirm ID=\"EVGENIY\" Decision=\"Y\"/>\n        <UserConfirm ID=\"GMG\" Decision=\"Y\"/>\n        <UserConfirm ID=\"KHATAEV\" Decision=\"Y\"/>\n        <UserConfirm ID=\"KOT\" Decision=\"Y\"/>\n        <UserConfirm ID=\"LEONID\" Decision=\"Y\"/>\n        <UserConfirm ID=\"MARAT\" Decision=\"Y\"/>\n        <UserConfirm ID=\"NERVIWKI\" Decision=\"Y\"/>\n        <UserConfirm ID=\"OLEG\" Decision=\"Y\"/>\n        <UserConfirm ID=\"OSA\" Decision=\"Y\"/>\n        <UserConfirm ID=\"ROSTICK\" Decision=\"Y\"/>\n        <UserConfirm ID=\"SELIV\" Decision=\"Y\"/>\n        <UserConfirm ID=\"SHESTAKOV\" Decision=\"Y\"/>\n        <UserConfirm ID=\"VLAD76\" Decision=\"Y\"/>\n        <UserConfirm ID=\"VLASENKO\" Decision=\"Y\"/>\n        <UserConfirm ID=\"WOWA\" Decision=\"Y\"/>\n        <UserConfirm ID=\"ALEXB\" Decision=\"\"/>\n      </UsersConfirm>\n    </Confirm>\n    <Confirm>\n      <RequestHead ID=\"5230\">\n        <Action>info</Action>\n        <BriefText>\u041F\u043E \u0437\u0430\u044F\u0432\u043A\u0435 bas00024396. \u0420\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u0438\u0435 \u0440\u0430\u0437\u043C\u0435\u0440\u043D\u043E\u0441\u0442\u0438 \u043F\u043E\u043B\u044F N37PORG.</BriefText>\n        <Author>VLAD76</Author>\n        <Created>26.02 09:51:01</Created>\n        <Done>03.03 14:36:30</Done>\n      </RequestHead>\n      <Decision/>\n      <UsersConfirm>\n        <UserConfirm ID=\"ALEXB\" Decision=\"Y\"/>\n        <UserConfirm ID=\"EVGENIY\" Decision=\"Y\"/>\n        <UserConfirm ID=\"GMG\" Decision=\"Y\"/>\n        <UserConfirm ID=\"KHATAEV\" Decision=\"Y\"/>\n        <UserConfirm ID=\"KOT\" Decision=\"Y\"/>\n        <UserConfirm ID=\"LEONID\" Decision=\"Y\"/>\n        <UserConfirm ID=\"MARAT\" Decision=\"Y\"/>\n        <UserConfirm ID=\"NERVIWKI\" Decision=\"Y\"/>\n        <UserConfirm ID=\"OLEG\" Decision=\"Y\"/>\n        <UserConfirm ID=\"OSA\" Decision=\"Y\"/>\n        <UserConfirm ID=\"ROSTICK\" Decision=\"Y\"/>\n        <UserConfirm ID=\"SELIV\" Decision=\"Y\"/>\n        <UserConfirm ID=\"SHESTAKOV\" Decision=\"Y\"/>\n        <UserConfirm ID=\"VLAD76\" Decision=\"Y\"/>\n        <UserConfirm ID=\"VLASENKO\" Decision=\"Y\"/>\n        <UserConfirm ID=\"WOWA\" Decision=\"Y\"/>\n        <UserConfirm ID=\"ALEXB\" Decision=\"\"/>\n      </UsersConfirm>\n    </Confirm>\n    <Confirm>\n      <RequestHead ID=\"5229\">\n        <Action>info</Action>\n        <BriefText>\u041E\u043F\u0442\u0438\u043C\u0438\u0437\u0430\u0446\u0438\u044F \u0432\u044B\u0433\u0440\u0443\u0437\u043A\u0438 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439 \u0432 oa-\u0444\u0430\u0439\u043B\u0435</BriefText>\n        <Author>VLAD76</Author>\n        <Created>03.03 15:10:38</Created>\n        <Done>04.03 11:42:10</Done>\n      </RequestHead>\n      <Decision/>\n      <UsersConfirm>\n        <UserConfirm ID=\"ALEXB\" Decision=\"Y\"/>\n        <UserConfirm ID=\"EVGENIY\" Decision=\"Y\"/>\n        <UserConfirm ID=\"GMG\" Decision=\"Y\"/>\n        <UserConfirm ID=\"KHATAEV\" Decision=\"Y\"/>\n        <UserConfirm ID=\"KOT\" Decision=\"Y\"/>\n        <UserConfirm ID=\"LEONID\" Decision=\"Y\"/>\n        <UserConfirm ID=\"MARAT\" Decision=\"Y\"/>\n        <UserConfirm ID=\"NERVIWKI\" Decision=\"Y\"/>\n        <UserConfirm ID=\"OLEG\" Decision=\"Y\"/>\n        <UserConfirm ID=\"OSA\" Decision=\"Y\"/>\n        <UserConfirm ID=\"ROSTICK\" Decision=\"Y\"/>\n        <UserConfirm ID=\"SELIV\" Decision=\"Y\"/>\n        <UserConfirm ID=\"SHESTAKOV\" Decision=\"Y\"/>\n        <UserConfirm ID=\"VLAD76\" Decision=\"Y\"/>\n        <UserConfirm ID=\"VLASENKO\" Decision=\"Y\"/>\n        <UserConfirm ID=\"WOWA\" Decision=\"Y\"/>\n        <UserConfirm ID=\"ALEXB\" Decision=\"\"/>\n      </UsersConfirm>\n    </Confirm>\n    <Confirm>\n      <RequestHead ID=\"5228\">\n        <Action>info</Action>\n        <BriefText>\u0434\u043E\u0440\u0430\u0431\u043E\u0442\u043A\u0430 \u043C\u0435\u043D\u0435\u0434\u0436\u0435\u0440\u0430 \u043E\u0442\u0447\u0435\u0442\u043E\u0432</BriefText>\n        <Author>SHESTAKOV</Author>\n        <Created>20.02 11:46:51</Created>\n        <Done>03.03 14:36:30</Done>\n      </RequestHead>\n      <Decision/>\n      <UsersConfirm>\n        <UserConfirm ID=\"ALEXB\" Decision=\"Y\"/>\n        <UserConfirm ID=\"EVGENIY\" Decision=\"Y\"/>\n        <UserConfirm ID=\"GMG\" Decision=\"Y\"/>\n        <UserConfirm ID=\"KHATAEV\" Decision=\"Y\"/>\n        <UserConfirm ID=\"KOT\" Decision=\"Y\"/>\n        <UserConfirm ID=\"LEONID\" Decision=\"Y\"/>\n        <UserConfirm ID=\"MARAT\" Decision=\"Y\"/>\n        <UserConfirm ID=\"NERVIWKI\" Decision=\"Y\"/>\n        <UserConfirm ID=\"OLEG\" Decision=\"Y\"/>\n        <UserConfirm ID=\"OSA\" Decision=\"Y\"/>\n        <UserConfirm ID=\"ROSTICK\" Decision=\"Y\"/>\n        <UserConfirm ID=\"SELIV\" Decision=\"Y\"/>\n        <UserConfirm ID=\"SHESTAKOV\" Decision=\"Y\"/>\n        <UserConfirm ID=\"VLAD76\" Decision=\"Y\"/>\n        <UserConfirm ID=\"VLASENKO\" Decision=\"Y\"/>\n        <UserConfirm ID=\"WOWA\" Decision=\"Y\"/>\n        <UserConfirm ID=\"ALEXB\" Decision=\"\"/>\n      </UsersConfirm>\n    </Confirm>\n    <Confirm>\n      <RequestHead ID=\"5157\">\n        <Action>info</Action>\n        <BriefText>\u041D\u0435\u043E\u0431\u0445\u043E\u0434\u0438\u043C\u043E\u0441\u0442\u044C \u043F\u043E\u0438\u0441\u043A\u0430 \u0440\u0430\u043D\u0435\u0435 \u043E\u0442\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u043D\u043E\u0433\u043E \u0444\u0430\u0439\u043B\u0430 \u043F\u043E \u0438\u043C\u0435\u043D\u0438</BriefText>\n        <Author>VLAD76</Author>\n        <Created>03.03 15:11:12</Created>\n        <Done>04.03 11:42:11</Done>\n      </RequestHead>\n      <Decision/>\n      <UsersConfirm>\n        <UserConfirm ID=\"ALEXB\" Decision=\"Y\"/>\n        <UserConfirm ID=\"KHATAEV\" Decision=\"Y\"/>\n        <UserConfirm ID=\"LEONID\" Decision=\"Y\"/>\n        <UserConfirm ID=\"MARAT\" Decision=\"Y\"/>\n        <UserConfirm ID=\"NERVIWKI\" Decision=\"Y\"/>\n        <UserConfirm ID=\"OLEG\" Decision=\"Y\"/>\n        <UserConfirm ID=\"OSA\" Decision=\"Y\"/>\n        <UserConfirm ID=\"ROSTICK\" Decision=\"Y\"/>\n        <UserConfirm ID=\"SELIV\" Decision=\"Y\"/>\n        <UserConfirm ID=\"SHESTAKOV\" Decision=\"Y\"/>\n        <UserConfirm ID=\"VLAD76\" Decision=\"Y\"/>\n        <UserConfirm ID=\"VLASENKO\" Decision=\"Y\"/>\n        <UserConfirm ID=\"WOWA\" Decision=\"Y\"/>\n        <UserConfirm ID=\"ALEXB\" Decision=\"\"/>\n      </UsersConfirm>\n    </Confirm>\n    <Filter>\n      <Status>approved</Status>\n      <DateFrom>20.02.2016</DateFrom>\n      <DateTo>15.02.2017</DateTo>\n    </Filter>\n  </Confirms>\n</UCMsg>"
    },
    {
        key: "\n<UCMsg ID=\"7\">\n  <RequestHead ID=\"0\">\n    <Action>info</Action>\n    <Requests>\n      <Request ID=\"0\">\n        <Action>info</Action>\n        <Subject>\n          <Action>info</Action>\n          <Object Type=\"TABLE\">\n            <Table ID=\"A02\"></Table>\n          </Object>\n        </Subject>\n      </Request>\n    </Requests>\n  </RequestHead>\n  <Context ID=\"555\">\n    <UserName>leonid</UserName>\n    <UserPassword>o</UserPassword>\n    <UserStatus></UserStatus>\n    <IPAddress></IPAddress>\n    <VerMask>\u0412</VerMask>\n    <SubMask>\u0412</SubMask>\n  </Context>\n</UCMsg>\n",
        val: "\n<UCMsg ID=\"7\">\n  <RequestHead ID=\"0\">\n    <Action>info</Action>\n    <Requests>\n      <Request ID=\"0\">\n        <Action>info</Action>\n        <Subject>\n          <Action>info</Action>\n          <Object Type=\"TABLE\">\n            <Table ID=\"A02\">\n              <Fields>\n                <Field ID=\"A02TBNM\">\n                  <TableID>A02</TableID>\n                  <Type>string(40)</Type>\n                  <Size>40</Size>\n                  <Position>1</Position>\n                  <Nullable>N</Nullable>\n                  <BriefText>TableName</BriefText>\n                  <FullText>\u0418\u043C\u044F \u0442\u0430\u0431\u043B\u0438\u0446\u044B</FullText>\n                </Field>\n                <Field ID=\"A02TBRW\">\n                  <TableID>A02</TableID>\n                  <Type>rowid</Type>\n                  <Position>2</Position>\n                  <Nullable>N</Nullable>\n                  <BriefText>TableROWID</BriefText>\n                  <FullText>ROWID \u0441\u0442\u0440\u043E\u043A\u0438 \u0442\u0430\u0431\u043B\u0438\u0446\u044B</FullText>\n                </Field>\n                <Field ID=\"A02PARW\">\n                  <TableID>A02</TableID>\n                  <Type>rowid</Type>\n                  <Position>3</Position>\n                  <Nullable>N</Nullable>\n                  <BriefText>ParentROWID</BriefText>\n                  <FullText>ROWID \u0441\u0442\u0440\u043E\u043A\u0438 \u0441\u0430\u043C\u043E\u0439 \u0440\u043E\u0434\u0438\u0442\u0435\u043B\u044C\u0441\u043A\u043E\u0439 \u0442\u0430\u0431\u043B\u0438\u0446\u044B, \u0438\u0437-\u0437\u0430 \u0430\u0440\u0445\u0438\u0432\u0430\u0446\u0438\u0438 \u043A\u043E\u0442\u043E\u0440\u043E\u0439 \u043F\u0440\u0438\u0448\u043B\u043E\u0441\u044C \u0430\u0440\u0445\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u044D\u0442\u0443.</FullText>\n                </Field>\n                <Field ID=\"A02CRIT\">\n                  <TableID>A02</TableID>\n                  <Type>string(1)</Type>\n                  <Size>1</Size>\n                  <Position>4</Position>\n                  <Nullable>N</Nullable>\n                  <DefVal>&apos;1&apos;</DefVal>\n                  <BriefText>Criteria</BriefText>\n                  <FullText>\u0417\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u043A\u0440\u0438\u0442\u0435\u0440\u0438\u044F \u0430\u0440\u0445\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F \u0434\u043B\u044F \u044D\u0442\u043E\u0439 \u0441\u0442\u0440\u043E\u043A\u0438</FullText>\n                </Field>\n                <Field ID=\"A02BADL\">\n                  <TableID>A02</TableID>\n                  <Type>string(1)</Type>\n                  <Size>1</Size>\n                  <Position>5</Position>\n                  <Nullable>N</Nullable>\n                  <DefVal>&apos;0&apos;</DefVal>\n                  <BriefText>BadLine</BriefText>\n                  <FullText>\u0421\u0442\u0440\u043E\u043A\u0430 \u043F\u043B\u043E\u0445\u0430\u044F? \u0415\u0441\u043B\u0438 != 0, \u0442\u043E \u0434\u0430 =&gt; \u043D\u0435 \u0430\u0440\u0445\u0438\u0432\u0438\u0440\u0443\u0435\u0442\u0441\u044F.</FullText>\n                </Field>\n                <Field ID=\"A02AMOD\">\n                  <TableID>A02</TableID>\n                  <Type>string(8)</Type>\n                  <Size>8</Size>\n                  <Position>6</Position>\n                  <Nullable>Y</Nullable>\n                  <BriefText>ArchiveMode</BriefText>\n                  <FullText>\u0421\u0438\u043C\u0432\u043E\u043B \u0440\u0435\u0436\u0438\u043C\u0430 \u043F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u0438\u043C\u043E\u0433\u043E \u0430\u0440\u0445\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F</FullText>\n                </Field>\n              </Fields>\n              <Indexes>\n                <Index ID=\"IA02PARW\">\n                  <TableID>A02</TableID>\n                  <Type/>\n                  <Uniqueness>0</Uniqueness>\n                  <Fields>\n                    <Field ID=\"A02PARW\">\n                      <TableID>A02</TableID>\n                      <Position>1</Position>\n                    </Field>\n                  </Fields>\n                </Index>\n                <Index ID=\"IA02TBNM\">\n                  <TableID>A02</TableID>\n                  <Type/>\n                  <Uniqueness>0</Uniqueness>\n                  <Fields>\n                    <Field ID=\"A02TBNM\">\n                      <TableID>A02</TableID>\n                      <Position>1</Position>\n                    </Field>\n                  </Fields>\n                </Index>\n              </Indexes>\n              <BriefText>\u0422\u0430\u0431\u043B\u0438\u0446\u0430 ROWID-\u043E\u0432. \u0412 \u043D\u0435\u0435 \u043D\u0430\u043A\u0430\u043F\u043B\u0438\u0432\u0430\u044E\u0442\u0441\u044F ROWID-\u044B \u0441\u0442\u0440\u043E\u043A  \n\u0442\u0430\u0431\u043B\u0438\u0446, \u043F\u043E\u0434\u043B\u0435\u0436\u0430\u0449\u0438\u0445 \u0430\u0440\u0445\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044E</BriefText>\n              <FullText>\u0422\u0430\u0431\u043B\u0438\u0446\u0430 - \u0432\u0440\u0435\u043C\u0435\u043D\u043D\u0430\u044F. \u041D\u043E\u0440\u043C\u0430\u043B\u044C\u043D\u043E\u0435 \u0441\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0435 - \u043F\u0443\u0441\u0442\u043E\u0435. \u0417\u0430\u043F\u043E\u043B\u043D\u044F\u0435\u0442\u0441\u044F \u0438 \u043E\u0447\u0438\u0449\u0430\u0435\u0442\u0441\u044F \u0432 \u043F\u0440\u043E\u0446\u0435\u0441\u0441\u0435 \u0430\u0440\u0445\u0438\u0432\u0430\u0446\u0438\u0438.</FullText>\n            </Table>\n          </Object>\n          <ObjectContext>\n            <Users>EVGENIY,GMG,KHATAEV,KOT,LEONID,MARAT,NERVIWKI,OLEG,OSA,ROSTICK,SELIV,SHESTAKOV,VLAD76,VLASENKO,WOWA</Users>\n          </ObjectContext>\n        </Subject>\n      </Request>\n    </Requests>\n  </RequestHead>\n  <Status/>\n  <Context ID=\"355\">\n    <UserName>LEONID</UserName>\n    <UserPassword>O</UserPassword>\n    <UserStatus>1</UserStatus>\n    <IPAddress/>\n    <VerMask>\u0412</VerMask>\n    <SubMask>\u0412</SubMask>\n  </Context>\n</UCMsg>\n"
    },
    {
        key: "\n<UCMsg ID=\"7\">\n  <RequestHead ID=\"0\">\n    <Action>info</Action>\n    <Requests>\n      <Request ID=\"0\">\n        <Action>info</Action>\n        <Subject>\n          <Action>info</Action>\n          <Object Type=\"TABLE\">\n            <Table ID=\"T95\"></Table>\n          </Object>\n        </Subject>\n      </Request>\n    </Requests>\n  </RequestHead>\n  <Context ID=\"555\">\n    <UserName>leonid</UserName>\n    <UserPassword>o</UserPassword>\n    <UserStatus></UserStatus>\n    <IPAddress></IPAddress>\n    <VerMask>\u0412</VerMask>\n    <SubMask>\u0412</SubMask>\n  </Context>\n</UCMsg>",
        val: "\n<UCMsg ID=\"7\">\n  <RequestHead ID=\"0\">\n    <Action>info</Action>\n    <Requests>\n      <Request ID=\"0\">\n        <Action>info</Action>\n        <Subject>\n          <Action>info</Action>\n          <Object Type=\"TABLE\">\n            <Table ID=\"T95\">\n              <Fields>\n                <Field ID=\"T95JPID\">\n                  <TableID>T95</TableID>\n                  <Type>number(11,0)</Type>\n                  <Size>11</Size>\n                  <Precision>0</Precision>\n                  <Position>0</Position>\n                  <Nullable>Y</Nullable>\n                  <BriefText>JuridicalID</BriefText>\n                  <FullText>\u0418\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440. \u044E\u0440. \u043B\u0438\u0446\u0430</FullText>\n                </Field>\n                <Field ID=\"T95POID\">\n                  <TableID>T95</TableID>\n                  <Type>number(11,0)</Type>\n                  <Size>11</Size>\n                  <Precision>0</Precision>\n                  <Position>1</Position>\n                  <Nullable>Y</Nullable>\n                  <BriefText>PostID</BriefText>\n                  <FullText>\u0418\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440 \u0434\u043E\u043B\u0436\u043D\u043E\u0441\u0442\u0438. \u0421\u0441\u044B\u043B\u043A\u0430 \u043D\u0430 T81CNMK \u0434\u043B\u044F T81CTYP=239</FullText>\n                </Field>\n                <Field ID=\"T95CLID\">\n                  <TableID>T95</TableID>\n                  <Type>number(11,0)</Type>\n                  <Size>11</Size>\n                  <Precision>0</Precision>\n                  <Position>2</Position>\n                  <Nullable>Y</Nullable>\n                  <BriefText>ClientID</BriefText>\n                  <FullText>\u0421\u0441\u044B\u043B\u043A\u0430 \u043D\u0430 \u0444\u0438\u0437. \u043B\u0438\u0446\u043E N31CLID</FullText>\n                </Field>\n                <Field ID=\"T95_ARH\">\n                  <TableID>T95</TableID>\n                  <Type>number(38)</Type>\n                  <Size>38</Size>\n                  <Position>12</Position>\n                  <Nullable>N</Nullable>\n                  <DefVal>0</DefVal>\n                  <BriefText>ArchDate</BriefText>\n                  <FullText>\u0422\u0435\u0445\u043D\u043E\u043B\u043E\u0433\u0438\u0447\u0435\u0441\u043A\u043E\u0435 \u043F\u043E\u043B\u0435. \u0418\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440 \u0437\u0430\u043F\u0438\u0441\u0438 \u0434\u043B\u044F \u0441\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0430\u0446\u0438\u0438 \u0441 \u0430\u0440\u0445\u0438\u0432\u043D\u043E\u0439 \u0431\u0430\u0437\u043E\u0439.</FullText>\n                </Field>\n                <Field ID=\"T95OBID\">\n                  <TableID>T95</TableID>\n                  <Type>memberid</Type>\n                  <Position>37077</Position>\n                  <Nullable>Y</Nullable>\n                  <FullText>\u0418\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u043A\u0430\u0442\u043E\u0440 \u0437\u0430\u043F\u0438\u0441\u0438</FullText>\n                </Field>\n                <Field ID=\"T95LEVL\">\n                  <TableID>T95</TableID>\n                  <Type>nstat</Type>\n                  <Position>37078</Position>\n                  <Nullable>Y</Nullable>\n                  <FullText>\u0423\u0440\u043E\u0432\u0435\u043D\u044C \u043F\u043E\u0434\u043F\u0438\u0441\u0438 (\u0441\u043F\u0440\u0430\u0432\u043E\u0447\u043D\u0438\u043A)</FullText>\n                </Field>\n                <Field ID=\"T95STAT\">\n                  <TableID>T95</TableID>\n                  <Type>nstat</Type>\n                  <Position>37079</Position>\n                  <Nullable>Y</Nullable>\n                  <FullText>\u0421\u0442\u0430\u0442\u0443\u0441 \u0437\u0430\u043F\u0438\u0441\u0438</FullText>\n                </Field>\n                <Field ID=\"T95DBEG\">\n                  <TableID>T95</TableID>\n                  <Type>dateYYMMDD</Type>\n                  <Position>37080</Position>\n                  <Nullable>Y</Nullable>\n                  <FullText>\u0434\u0430\u0442\u0430 \u043D\u0430\u0447\u0430\u043B\u0430 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F</FullText>\n                </Field>\n                <Field ID=\"T95DEND\">\n                  <TableID>T95</TableID>\n                  <Type>dateYYMMDD</Type>\n                  <Position>37081</Position>\n                  <Nullable>Y</Nullable>\n                  <FullText>\u0434\u0430\u0442\u0430 \u043A\u043E\u043D\u0446\u0430 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F</FullText>\n                </Field>\n                <Field ID=\"T95FLAG\">\n                  <TableID>T95</TableID>\n                  <Type>string(10)</Type>\n                  <Size>10</Size>\n                  <Position>37082</Position>\n                  <Nullable>Y</Nullable>\n                  <FullText>\u043E\u0441\u043E\u0431\u044B\u0435 \u043F\u0440\u0438\u0437\u043D\u0430\u043A\u0438 1 \u0441\u0438\u043C\u0432\u043E\u043B= &quot;V&quot; - \u0415\u0434\u0438\u043D\u043E\u043B\u0438\u0447\u043D\u044B\u0439 \u0438\u0441\u043F\u043E\u043B\u043D\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0439 \u043E\u0440\u0433\u0430\u043D</FullText>\n                </Field>\n              </Fields>\n              <Indexes>\n                <Index ID=\"IT95_1\">\n                  <TableID>T95</TableID>\n                  <Type>0</Type>\n                  <Uniqueness>1</Uniqueness>\n                  <Fields>\n                    <Field ID=\"T95OBID\">\n                      <TableID>T95</TableID>\n                      <Position>1</Position>\n                    </Field>\n                  </Fields>\n                </Index>\n                <Index ID=\"IT95_2\">\n                  <TableID>T95</TableID>\n                  <Type>0</Type>\n                  <Uniqueness>1</Uniqueness>\n                  <Fields>\n                    <Field ID=\"T95CLID\">\n                      <TableID>T95</TableID>\n                      <Position>1</Position>\n                    </Field>\n                    <Field ID=\"T95JPID\">\n                      <TableID>T95</TableID>\n                      <Position>2</Position>\n                    </Field>\n                    <Field ID=\"T95DBEG\">\n                      <TableID>T95</TableID>\n                      <Position>3</Position>\n                    </Field>\n                  </Fields>\n                </Index>\n              </Indexes>\n              <Constraints>\n                <Constraint ID=\"CHK_T95CLID\">\n                  <TableID>T95</TableID>\n                  <Type>C</Type>\n                  <Condition>T95CLID IS NOT NULL</Condition>\n                  <Validate>VALIDATE</Validate>\n                </Constraint>\n                <Constraint ID=\"CHK_T95POID\">\n                  <TableID>T95</TableID>\n                  <Type>C</Type>\n                  <Condition>T95POID IS NOT NULL</Condition>\n                  <Validate>VALIDATE</Validate>\n                </Constraint>\n              </Constraints>\n              <BriefText>\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u0440\u0438\u0432\u044F\u0437\u043A\u0438 \u0434\u043E\u043B\u0436\u043D\u043E\u0441\u0442\u043D\u044B\u0445 \u043B\u0438\u0446 \u0441 \u043F\u0440\u0430\u0432\u043E\u043C \u043F\u043E\u0434\u043F\u0438\u0441\u0438 \u043A \u044E\u0440. \u043B\u0438\u0446\u0443</BriefText>\n              <FullText>\u0422\u0430\u0431\u043B\u0438\u0446\u0430 \u043F\u0440\u0438\u0432\u044F\u0437\u043A\u0438 \u0434\u043E\u043B\u0436\u043D\u043E\u0441\u0442\u043D\u044B\u0445 \u043B\u0438\u0446 \u0441 \u043F\u0440\u0430\u0432\u043E\u043C \u043F\u043E\u0434\u043F\u0438\u0441\u0438 \u043A \u044E\u0440. \u043B\u0438\u0446\u0443</FullText>\n            </Table>\n          </Object>\n          <ObjectContext>\n            <Users>LEONID,MARAT,ROSTICK,SELIV,VLAD76,WOWA</Users>\n            <RequestHeads>\n              <ObjectRef ID=\"2806\" ObjectType=\"REQUESTHEAD\" BriefText=\"\u0418\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u0432 \u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u0438 \u044E\u0440. \u043B\u0438\u0446. \u0414\u043E\u043A\u0443\u043C\u0435\u043D\u0442 &quot;H:\retail21DOC\u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0435 \u0432 \u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u0438 \u044E\u0440 \u043B\u0438\u0446.doc&quot;\" Author=\"VLAD76\" Done=\"2004.08.04\"/>\n              <ObjectRef ID=\"5092\" ObjectType=\"REQUESTHEAD\" BriefText=\"\u0420\u0435\u0430\u043B\u0438\u0437\u0430\u0446\u0438\u044F \u043B\u0438\u0446 \u0441 \u043F\u0440\u0430\u0432\u043E\u043C \u043F\u043E\u0434\u043F\u0438\u0441\u0438\" Author=\"WOWA\" Done=\"2015.10.22\"/>\n            </RequestHeads>\n          </ObjectContext>\n        </Subject>\n      </Request>\n    </Requests>\n  </RequestHead>\n  <Status/>\n  <Context ID=\"355\">\n    <UserName>LEONID</UserName>\n    <UserPassword>O</UserPassword>\n    <UserStatus>1</UserStatus>\n    <IPAddress/>\n    <VerMask>\u0412</VerMask>\n    <SubMask>\u0412</SubMask>\n  </Context>\n</UCMsg>\n"
    },
    {
        key: "",
        val: ""
    },
    {
        key: "",
        val: ""
    },
    {
        key: "",
        val: ""
    },
    {
        key: "",
        val: ""
    },
    {
        key: "",
        val: ""
    },
    {
        key: "",
        val: ""
    },
    {
        key: "",
        val: ""
    },
    {
        key: "",
        val: ""
    },
    {
        key: "",
        val: ""
    },
];
var PageControl = (function () {
    function PageControl() {
    }
    PageControl.Initialize = function () {
        kendo.culture("ru-RU");
        $("head").append(hBaseCss);
        this.restoreOldUrl();
    };
    PageControl.setPagePath = function (page, obj) {
        if (obj === void 0) { obj = ""; }
        $.cookie('currTitlePage', page, { expires: 5, path: '/', });
        $.cookie('currObj', obj, { expires: 5, path: '/', });
        var PageStat = PageControl.getPageStat();
        var path = (PageStat.currObj != "") ?
            PageStat.currTitlePage + "-" + PageStat.currObj :
            PageStat.currTitlePage;
        history.pushState({ page: path }, PageStat.currTitlePage, '#' + path);
    };
    PageControl.StartPage = function () {
        QueryCache.load(function () {
            $(window).resize(function () { ATools.doResize(); });
            PageControl.ShowPage('BodyMenu');
            gSuperPage.globalPageEvents();
        });
    };
    PageControl.changeUrl = function () {
        window.onpopstate = function (event) {
            var path = (location.href.substr(location.href.indexOf("#") + 1)).split("-");
            LoadEventManager.addEventHandler("load_pSimpleTable", function () {
                if (path.length > 1) {
                    if (path[0] !== "")
                        PageControl.selectObjOnPage(path[0], path[1]);
                }
            });
            pBodyMenu.selectMenu(path[0]);
        };
    };
    PageControl.selectObjOnPage = function (page, obj) {
        function select(page, obj) {
            switch (page) {
                case 'Structure':
                case 'View':
                case 'Procedures':
                case 'Sequence':
                    $("#pSimpleTable").find("tr").each(function (i, v) {
                        if (($(this).find(".pSimpleTable-name").text()).toUpperCase().trim() == obj)
                            $(this).find(".k-icon").trigger("click");
                    });
                    break;
                case 'Orders':
                case 'ArhOrders':
                    $("#pSimpleTable").find("tr").each(function (i, v) {
                        if (($(this).find("td:eq(1)").text()).toUpperCase().trim() == obj)
                            $(this).find(".k-icon").trigger("click");
                    });
                    break;
                default:
                    break;
            }
        }
        switch (page) {
            case 'Structure':
            case 'View':
            case 'Procedures':
            case 'Sequence':
                QueryCache.get('getSchemaList', function (x) {
                    var si = x.indexOf("\"" + obj + "\""), Ownership = "0";
                    if (si > 0) {
                        var sir = x.indexOf("Ownership", si) + 11;
                        Ownership = x.substr(sir, 1);
                        if (Ownership == "0")
                            setTimeout(function () {
                                $(".s-Ownership-c-i").trigger("click");
                                select(page, obj);
                            }, 1);
                        else
                            select(page, obj);
                    }
                });
                break;
            default:
                select(page, obj);
                break;
        }
    };
    PageControl.showHelp = function () {
        $("#content_cont").on('mouseover', '.helpinfo', function (e) {
            var info = $('#s-help-info');
            info.html($(this).attr("helptext")).css({ "display": "block", "top": 0, "left": 0 });
            var _height = info.height();
            var __width = info.width();
            var win_height = MainConfig.win_h;
            var win__width = MainConfig.win_w;
            var pos = $(this).offset();
            var x = 0;
            var y = 0;
            if ((pos.left + __width) > win__width) {
                x = pos.left - __width + 8;
            }
            else {
                x = pos.left + 1;
            }
            if ((pos.top - _height - 14) < 0) {
                y = pos.top + _height + 20;
            }
            else {
                y = pos.top - _height - 14;
            }
            info.css({ "top": y, "left": x });
        });
        $("#content_cont").on('mouseleave', '.helpinfo', function (e) {
            $('#s-help-info').css({ "display": "none" });
        });
    };
    PageControl.pageUpdate = function () {
        this.ShowPage(this.currPage);
    };
    PageControl.restoreOldUrl = function () {
        var PageStat = PageControl.getPageStat();
        var loginParams = pLoginForm.getLoginCookie();
        MainConfig.hozObjects = (loginParams.hozObjects == 'true') ? true : false;
        var path = (PageStat.currObj != "") ? PageStat.currTitlePage + "-" + PageStat.currObj : PageStat.currTitlePage;
        if ((PageStat.currTitlePage !== "") &&
            (PageStat.currTitlePage !== 'LoginForm') &&
            (typeof (loginParams.login) !== 'undefined')) {
            MainConfig.contextLogin = loginParams.login;
            MainConfig.contextPass = loginParams.passw;
            MainConfig.contextVer = loginParams.ver;
            MainConfig.contextSys = loginParams.sys;
            MainConfig.contextNormVer = loginParams.contextNormVer;
            MainConfig.contextNormSys = loginParams.contextNormSys;
            MainConfig.isDeveloper = loginParams.isDeveloper;
            LoadEventManager.addEventHandler("load_pSimpleTable", function () {
                if (PageStat.currTitlePage !== 'Structure') {
                    setTimeout(function () {
                        LoadEventManager.addEventHandler("load_pSimpleTable", function () {
                            if (PageStat.currObj !== "")
                                PageControl.selectObjOnPage(PageStat.currTitlePage, PageStat.currObj);
                        });
                        pBodyMenu.selectMenu(PageStat.currTitlePage);
                    }, 100);
                }
                else if (PageStat.currObj !== "")
                    PageControl.selectObjOnPage(PageStat.currTitlePage, PageStat.currObj);
            });
            PageControl.StartPage();
        }
        else {
            PageControl.ShowPage('LoginForm');
        }
    };
    PageControl.getPageStat = function () {
        var currTitlePage = $.cookie('currTitlePage');
        var currObj = $.cookie('currObj');
        if (typeof (currObj) == 'undefined')
            currObj = "";
        if (typeof (currTitlePage) == 'undefined')
            currTitlePage = "";
        return { currTitlePage: currTitlePage, currObj: currObj };
    };
    PageControl.ShowPage = function (namePage) {
        $("#content").addClass('loading_div');
        this.currPage = $.trim(namePage);
        $.cookie('currTitlePage', this.currPage, { expires: 5, path: '/', });
        $.cookie('currObj', "", { expires: 5, path: '/', });
        this.setPagePath(this.currPage);
        switch (this.currPage) {
            case 'LoginForm':
                pLoginForm.Initialize();
                break;
            case 'Structure':
                pStructure.Initialize();
                break;
            case 'Procedures':
                pProcedures.Initialize();
                break;
            case 'BodyMenu':
                pBodyMenu.Initialize();
                break;
            case 'DataTypes':
                pDataTypes.Initialize();
                break;
            case 'View':
                pView.Initialize();
                break;
            case 'Sequence':
                pSequence.Initialize();
                break;
            case 'Search':
                pSearch.Initialize();
                break;
            case 'Class':
                pClass.Initialize();
                break;
            case 'Orders':
                pOrders.Initialize('notapproved');
                break;
            case 'ArhOrders':
                pOrders.Initialize('approved');
                break;
            case 'Wiki':
                window.open("http://192.168.131.10/wikipsit/index.php");
                PageControl.ShowPage('Structure');
                break;
            default:
                PageControl.error404();
                break;
        }
    };
    PageControl.error404 = function () {
        $("#content").html('<div style="margin:30px;">Ошибка! Такой страницы не существует!</div>');
    };
    PageControl.currPage = "";
    return PageControl;
}());
var QueryCache = (function () {
    function QueryCache() {
    }
    QueryCache.load = function (callback) {
        (new DBCPromise)
            .then(XMLquery.DataTypes(), function (xml) {
            QueryCache.storage.DataTypes = { xml: xml, update: false };
            pDataTypes.LoadTypes();
        })
            .then(XMLquery.getSchemaList(), function (xml) {
            QueryCache.storage.getSchemaList = { xml: xml, update: false };
        })
            .then(XMLquery.getConstrList(), function (xml) {
            QueryCache.storage.getConstrList = { xml: xml, update: false };
        })
            .then(XMLquery.SubSystemsList(), function (xml) {
            xml = pLoginForm.formatXmlReq(xml);
            MainConfig.SubSystems = ATools.DataSourceFromXml(xml, "SubSystems SubSystem");
            MainConfig.Versions = ATools.DataSourceFromXml(xml, "SubSystem Version");
            callback();
        })
            .then(XMLquery.getTsd(), function (xml) {
            QueryCache.storage.getTsd = { xml: xml, update: false };
            pSearch.loadTsd();
        });
    };
    QueryCache.get = function (query, callback) {
        switch (query) {
            case 'getSchemaList':
                if (QueryCache.storage.getSchemaList.update)
                    DataBaseControl.SendRequest(XMLquery.getSchemaList(), function (xml) {
                        QueryCache.storage.getSchemaList = { xml: xml, update: false };
                        callback(QueryCache.storage.getSchemaList.xml);
                    });
                else
                    callback(QueryCache.storage.getSchemaList.xml);
                break;
            case 'getConstrList':
                if (QueryCache.storage.getConstrList.update)
                    DataBaseControl.SendRequest(XMLquery.getConstrList(), function (xml) {
                        QueryCache.storage.getConstrList = { xml: xml, update: false };
                        callback(QueryCache.storage.getConstrList.xml);
                    });
                else
                    callback(QueryCache.storage.getConstrList.xml);
                break;
        }
    };
    QueryCache.storage = {};
    return QueryCache;
}());
var XMLquery = (function () {
    function XMLquery() {
    }
    XMLquery.getClasesByTabName = function (id) {
        return "<UCMsg ID=\"14\">\n                  <Schema>\n                    <ObjectRefs ObjectsType=\"CLASS\" TableID=\"" + id + "\"/>\n                  </Schema>\n                  " + XMLquery.getContext() + "\n                </UCMsg>";
    };
    XMLquery.getTabsByClassID = function (id) {
        return "<UCMsg ID=\"15\">\n                  <Schema>\n                    <ObjectRefs ObjectsType=\"TABLE\" ClassID=\"" + id + "\"/>\n                  </Schema>\n                  " + XMLquery.getContext() + "\n                </UCMsg>";
    };
    XMLquery.getClassByID = function (id) {
        return "<UCMsg ID=\"16\">\n                  <RequestHead ID=\"0\">\n                    <Action>info</Action>\n                    <Requests>\n                      <Request ID=\"0\">\n                        <Action>info</Action>\n                        <Subject>\n                          <Action>info</Action>\n                          <ObjectType>CLASS</ObjectType>\n                          <Object>\n                            <Class ID=\"" + id + "\"></Class>\n                          </Object>\n                        </Subject>\n                      </Request>\n                    </Requests>\n                  </RequestHead>\n                  " + XMLquery.getContext() + "\n                </UCMsg>";
    };
    XMLquery.getClassList = function () {
        return "<UCMsg ID=\"17\">\n                  <Schema>\n                    <ObjectRefs ObjectsType=\"CLASS\"/>\n                  </Schema>\n                  " + XMLquery.getContext() + "\n                </UCMsg>";
    };
    XMLquery.getContext = function () {
        return "<Context ID=\"555\">\n                  <UserName>" + MainConfig.contextLogin + "</UserName>\n                  <UserPassword>" + MainConfig.contextPass + "</UserPassword>\n                  <UserStatus></UserStatus>\n                  <IPAddress></IPAddress>\n                  <VerMask>" + MainConfig.contextVer + "</VerMask>\n                  <SubMask>" + MainConfig.contextSys + "</SubMask>\n                </Context>";
    };
    XMLquery.SubSystemsList = function () {
        return "<UCMsg ID=\"1\">\n                  <SubSystems></SubSystems>\n                  <Context ID=\"0\">\n                    <UserName>Leonid</UserName>\n                    <UserPassword>O</UserPassword>\n                    <IPAddress></IPAddress>\n                    <VerMask>\u0412</VerMask>\n                    <SubMask>\u0412</SubMask>\n                  </Context>\n                </UCMsg>";
    };
    XMLquery.getSchemaList = function () {
        return "<UCMsg ID=\"2\">\n                  <Schema></Schema>\n                  " + XMLquery.getContext() + "\n                </UCMsg>";
    };
    XMLquery.getSchemaList2 = function (requestHeadID) {
        return "<UCMsg ID=\"2\">\n                  <Schema></Schema>\n                  <Context ID=\"555\">\n                    <UserName>" + MainConfig.contextLogin + "</UserName>\n                    <UserPassword>" + MainConfig.contextPass + "</UserPassword>\n                    <UserStatus></UserStatus>\n                    <IPAddress></IPAddress>\n                    <VerMask>" + MainConfig.contextVer + "</VerMask>\n                    <SubMask>" + MainConfig.contextSys + "</SubMask>\n                    <RequestHeadID>" + requestHeadID + "</RequestHeadID>\n                  </Context>\n                </UCMsg>";
    };
    XMLquery.DataTypes = function () {
        return "<UCMsg ID=\"3\">\n                  <DataTypes></DataTypes>\n                  " + XMLquery.getContext() + "\n                </UCMsg>";
    };
    XMLquery.ViewByName = function (Name) {
        return "<UCMsg ID=\"4\">\n                  <RequestHead ID=\"0\">\n                    <Action>info</Action> \n                    <Requests>\n                      <Request ID=\"0\"> \n                        <Action>info</Action>\n                        <Subject>\n                          <Action>info</Action>\n                          <ObjectType>VIEW</ObjectType>\n                          <Object>\n                            <View ID=\"" + Name + "\"></View>\n                          </Object>\n                        </Subject>\n                      </Request>\n                    </Requests>\n                  </RequestHead>\n                  " + XMLquery.getContext() + "\n                </UCMsg>";
    };
    XMLquery.SequenceByName = function (Name) {
        return "<UCMsg ID=\"5\">\n                  <RequestHead ID=\"0\">\n                    <Action>info</Action>\n                    <Requests>\n                      <Request ID=\"0\">\n                        <Action>info</Action>\n                        <Subject>\n                          <Action>info</Action>\n                          <ObjectType>SEQN</ObjectType>\n                          <Object>\n                            <Sequence ID=\"" + Name + "\"></Sequence>\n                          </Object>\n                        </Subject>\n                      </Request>\n                    </Requests>\n                  </RequestHead>\n                  " + XMLquery.getContext() + "\n                </UCMsg>";
    };
    XMLquery.QueryByName = function (Name) {
        return "<UCMsg ID=\"6\">\n                  <RequestHead ID=\"0\">\n                    <Action>info</Action>\n                    <Requests>\n                      <Request ID=\"0\">\n                        <Action>info</Action>\n                        <Subject>\n                          <Action>info</Action>\n                          <ObjectType>QUERY</ObjectType>\n                          <Object>\n                            <Query ID=\"" + Name + "\"></Query>\n                          </Object>\n                        </Subject>\n                      </Request>\n                    </Requests>\n                  </RequestHead>\n                  " + XMLquery.getContext() + "\n                </UCMsg>";
    };
    XMLquery.FieldsByTabName2 = function (Name, reqID) {
        return "<UCMsg ID= \"7\">\n                  <RequestHead ID=\"0\">\n                    <Action>info</Action>\n                    <Requests>\n                      <Request ID=\"0\">\n                        <Action>info</Action>\n                        <Subject>\n                          <Action>info</Action>\n                          <ObjectType>TABLE</ObjectType>\n                          <Object>\n                            <Table ID=\"" + Name + "\"></Table> \n                          </Object>\n                        </Subject>\n                      </Request>\n                    </Requests>\n                  </RequestHead>\n                  <Context ID=\"555\">\n                    <UserName>" + MainConfig.contextLogin + "</UserName>\n                    <UserPassword>" + MainConfig.contextPass + "</UserPassword>\n                    <UserStatus></UserStatus>\n                    <IPAddress></IPAddress>\n                    <VerMask>" + MainConfig.contextVer + "</VerMask>\n                    <SubMask>" + MainConfig.contextSys + "</SubMask>\n                    <RequestHeadID>" + reqID + "</RequestHeadID>\n                  </Context>\n                </UCMsg>";
    };
    XMLquery.FieldsByTabName = function (Name) {
        return "<UCMsg ID= \"7\">\n                  <RequestHead ID=\"0\">\n                    <Action>info</Action>\n                    <Requests>\n                      <Request ID=\"0\">\n                        <Action>info</Action>\n                        <Subject>\n                          <Action>info</Action>\n                          <ObjectType>TABLE</ObjectType>\n                          <Object>\n                            <Table ID=\"" + Name + "\"></Table>\n                          </Object>\n                        </Subject>\n                      </Request>\n                    </Requests>\n                  </RequestHead>\n                  " + XMLquery.getContext() + "\n                </UCMsg>";
    };
    XMLquery.getCurrTsd = function () {
        return "<UCMsg ID=\"8\">\n                  <Tsd></Tsd>\n                  " + XMLquery.getContext() + "\n                </UCMsg>";
    };
    XMLquery.getTsd = function () {
        return "<UCMsg ID=\"8\">\n                  <Utils>\n                    <File>\n                      <Type>TSD</Type>\n                      <Date>" + ATools.getDateDDMMYY() + "</Date>\n                    </File>\n                  </Utils>\n                  " + XMLquery.getContext() + "\n                </UCMsg>";
    };
    XMLquery.RequestInfo = function (reqName) {
        return "<UCMsg ID=\"9\">\n                  <RequestHead ID=\"" + reqName + "\">\n                    <Action>info</Action>\n                  </RequestHead>\n                  " + XMLquery.getContext() + "\n                </UCMsg>";
    };
    XMLquery.changeText = function (id, text, objecttype, texttype, requestid) {
        return "<UCMsg ID=\"10\">\n                  <Utils>\n                    <ChangeText>\n                      <ID>" + id + "</ID>\n                      <ObjectType>" + objecttype + "</ObjectType>\n                      <TextType>" + texttype + "</TextType>\n                      <Text>" + text + "</Text>\n                      <RequestID>" + requestid + "</RequestID>\n                    </ChangeText>\n                  </Utils> \n                  " + XMLquery.getContext() + "\n                </UCMsg>";
    };
    XMLquery.AppInfo = function (approved, from, to) {
        return "<UCMsg ID=\"11\">\n                  <Confirms>\n                    <Filter>\n                      <Status>" + approved + "</Status>\n                      <DateFrom>" + from + "</DateFrom>\n                      <DateTo>" + to + "</DateTo>\n                    </Filter>\n                  </Confirms>\n                  " + XMLquery.getContext() + "\n                </UCMsg>";
    };
    XMLquery.ChangeOwnership = function (ID, ObjectType, Ownership) {
        return "<UCMsg ID=\"12\">\n                  <Utils>\n                    <ChangeOwnership>\n                      <ID>" + ID + "</ID>\n                      <ObjectType>" + ObjectType + "</ObjectType>\n                      <Ownership>" + Ownership + "</Ownership>\n                    </ChangeOwnership>\n                  </Utils>\n                  " + XMLquery.getContext() + "\n                </UCMsg>";
    };
    XMLquery.getConstrList = function () {
        return "<UCMsg ID=\"13\">\n                  <Schema>\n                    <ObjectRefs ObjectsType=\"CONSTRAINT\"/>\n                  </Schema>\n                  " + XMLquery.getContext() + "\n                </UCMsg>";
    };
    return XMLquery;
}());
var gSuperPage = (function () {
    function gSuperPage() {
    }
    gSuperPage.closeOpenRowTable = function (_this, e, typeTable) {
        _this.collapseRow(_this.tbody.find(' > tr.k-master-row').not(e.masterRow));
        _this.tbody.find(' > tr.k-master-row').not(e.masterRow).addClass('displayNone');
        $(e.masterRow[0]).addClass('DevSysSelectRow');
        if (typeTable === 'simple') {
            $('#pSimpleTable .k-grid-content').scrollTop(0);
            $('.k-minus')
                .on('click', function () {
                $(e.masterRow[0]).removeClass('DevSysSelectRow');
                var currSelectRow = $('#pSimpleTable > div > table > tbody > .k-master-row').not('.displayNone').find('td').eq(1).text();
                $('#pSimpleTable').find('tr').removeClass('displayNone');
                var green = $('.s-Ownership-c-i').find('.s-Ownership-green-i').length;
                if (green)
                    ATools.Ownership('red', 0);
                $('.k-master-row').each(function () {
                    var eachRow = $(this).find('td').eq(1).text();
                    if (eachRow == currSelectRow) {
                        var fordz = $(this).position();
                        $('#pSimpleTable .k-grid-content').scrollTop(fordz.top);
                        $('.k-minus').off();
                    }
                });
            });
        }
        if (typeTable === 'grid') {
            $('#grid .k-grid-content').scrollTop(0);
            $('.k-minus')
                .on('click', function () {
                $(e.masterRow[0]).removeClass('DevSysSelectRow');
                var currSelectRow = $('#grid > div > table > tbody > .k-master-row').not('.displayNone').find('td').eq(1).text();
                $('#grid').find('tr').removeClass('displayNone');
                var green = $('.s-Ownership-c-i').find('.s-Ownership-green-i').length;
                if (green)
                    ATools.Ownership('red', 0);
                $('.k-master-row').each(function () {
                    var eachRow = $(this).find('td').eq(1).text();
                    if (eachRow == currSelectRow) {
                        var fordz = $(this).position();
                        $('#grid .k-grid-content').scrollTop(fordz.top);
                        $('.k-minus').off();
                    }
                });
            });
        }
        if (typeTable === 'request') {
            $('.requests_tab .k-minus').on('click', function () {
                $(e.masterRow[0]).removeClass('DevSysSelectRow');
                $('.requests_tab tr').removeClass('displayNone');
            });
        }
    };
    gSuperPage.showRequests = function (row, xml) {
        var RequestHeads = ATools.getXmlVal(xml, 'RequestHeads');
        if (RequestHeads.length > 0) {
            row.find(".requests_tab").kendoGrid({
                dataSource: ATools.DataSourceFromXml(xml, 'RequestHeads > ObjectRef'),
                scrollable: true,
                detailExpand: function (e) {
                    gSuperPage.closeOpenRowTable(this, e, 'request');
                },
                detailTemplate: kendo.template("<div class='content_request'></div>"),
                detailInit: function (e) {
                    DataBaseControl.SendRequest(XMLquery.RequestInfo(e.data.ID), function (CurrentRequestInfo) {
                        gSuperPage.DispalyRequestItems($('tr[data-uid="' + e.data.uid + '"]').next().find(".content_request"), CurrentRequestInfo);
                    });
                },
                columns: [
                    { field: "ID", title: "Номер Заявки", format: "{0:c}", width: "100px" },
                    { field: "BriefText", title: "Краткое описание" },
                    { field: "Done", title: "Выполнена", format: "{0:c}", width: "100px" },
                    { field: "Author", title: "Автор", format: "{0:c}", width: "100px" }
                ]
            });
        }
        else {
            row.find(".requests_tab").html("<div>По данному объекту нет заявок</div>");
        }
    };
    gSuperPage.constructSimpleTable = function (tableType, diffTemp) {
        if (diffTemp === void 0) { diffTemp = false; }
        if (!diffTemp)
            $("#content").html(this.templateSimpleTable);
        var select_arr = [];
        QueryCache.get('getSchemaList', function (xmlq) {
            var DSviewSchemaList = ATools.DataSourceFromXml(xmlq, "ObjectRefs ObjectRef");
            DSviewSchemaList = ATools.DataSourceFilter(DSviewSchemaList, "ObjectType=" + tableType);
            var loadObjList = [];
            var top_tab_select_name = "";
            var mainGrid = $("#pSimpleTable").kendoGrid({
                dataSource: {
                    data: DSviewSchemaList,
                    schema: {
                        model: {
                            fields: {
                                ID: 'ID',
                                BriefText: 'BriefText'
                            }
                        }
                    }
                },
                scrollable: true,
                selectable: "multiple",
                change: function (arg) {
                    if (diffTemp) {
                        $('#grid .k-minus').trigger("click");
                        var selected = $.map(this.select(), function (item) {
                            return $(item).find(".pSimpleTable-name").text();
                        });
                        var ClassID = selected[0];
                        DataBaseControl.SendRequest(XMLquery.getClasesByTabName(ClassID), function (xmlData2) {
                            var DSviewSchemaList = ATools.DataSourceFromXml(xmlData2, "ObjectRefs ObjectRef");
                            function isSelected(currName) {
                                var flag = false;
                                for (var i = 0; i < DSviewSchemaList.length; i++) {
                                    if (currName == DSviewSchemaList[i]['ID']) {
                                        flag = true;
                                        break;
                                    }
                                }
                                return flag;
                            }
                            if (top_tab_select_name != ClassID) {
                                $('#grid .k-master-row').each(function () {
                                    var p = $(this);
                                    p.removeClass('displayNone2');
                                    var currName = p.find('.pSimpleTable-name').text();
                                    var flag = isSelected(currName);
                                    if (!flag)
                                        p.addClass('displayNone2');
                                });
                                top_tab_select_name = ClassID;
                            }
                            else {
                                $('#grid .k-master-row').each(function () {
                                    var p = $(this);
                                    p.removeClass('displayNone2');
                                });
                                $('#pSimpleTable .k-master-row').removeClass('k-state-selected');
                                top_tab_select_name = "";
                            }
                        });
                    }
                },
                resizable: true,
                detailExpand: function (e) {
                    gSuperPage.closeOpenRowTable(this, e, 'simple');
                    var id = $(e.masterRow[0]).find("td:eq(1)").text();
                    for (var i in loadObjList)
                        if (loadObjList[i].n == id)
                            if (loadObjList[i].f)
                                LoadEventManager.execEvent("load_pSimpleTable_obj");
                            else
                                loadObjList[i].f = true;
                },
                detailTemplate: kendo.template(gSuperPage.simpleTemplateTab),
                detailInit: function (e) {
                    loadObjList.push({ n: e.data['ID'], f: false });
                    var detailRow = e.detailRow;
                    detailRow.find(".tabstrip").kendoTabStrip({
                        animation: {
                            open: {
                                duration: 1, effects: "fadeIn"
                            }
                        }
                    });
                    var otherTabStrip = detailRow.find(".tabstrip").data("kendoTabStrip");
                    var CurReqXml;
                    switch (tableType) {
                        case 'VIEW':
                            CurReqXml = XMLquery.ViewByName(e.data['ID']);
                            break;
                        case 'SEQUENCE':
                            CurReqXml = XMLquery.SequenceByName(e.data['ID']);
                            break;
                        case 'QUERY':
                            CurReqXml = XMLquery.QueryByName(e.data['ID']);
                            break;
                        case 'TABLE':
                            CurReqXml = XMLquery.FieldsByTabName(e.data['ID']);
                            break;
                    }
                    PageControl.setPagePath(PageControl.currPage, e.data['ID']);
                    DataBaseControl.SendRequest(CurReqXml, function (objData) {
                        var Users = ATools.getXmlVal(objData, 'Users');
                        Users = (Users.length == 0) ? 'Нет хозяев' : Users;
                        detailRow.find(".tab_object").html("\u0425\u043E\u0437\u044F\u0435\u0432\u0430: " + Users + " <br><br> <div id=\"body_" + e.data['ID'] + "\"></div>");
                        switch (tableType) {
                            case 'VIEW':
                                pView.getBody(objData, 'body_' + e.data['ID'], otherTabStrip);
                                break;
                            case 'SEQUENCE':
                                pSequence.getBody(objData, 'body_' + e.data['ID'], otherTabStrip);
                                break;
                            case 'QUERY':
                                pProcedures.getBody(objData, 'body_' + e.data['ID'], otherTabStrip);
                                break;
                            case 'TABLE':
                                pStructure.getBody(objData, 'body_' + e.data['ID'], otherTabStrip);
                                break;
                        }
                        gSuperPage.showRequests(detailRow, objData);
                    });
                },
                filterable: { mode: "row" },
                columns: [
                    {
                        field: "ID", title: "Имя", width: "190px",
                        filterable: {
                            cell: {
                                operator: "contains"
                            }
                        },
                        template: (MainConfig.contextLogin === 'SOMEONE' || MainConfig.hozObjects) ? "<div class='pSimpleTable-name'>#: ID #</div>" : "<div class='s-Ownership-c'><div class='s-Ownership-#: ATools.OwnershipTreangle(Ownership) #'></div></div><div class='pSimpleTable-name'>#: ID #</div>"
                    },
                    {
                        field: "BriefText", title: "Краткое описание",
                        template: "<span class='s-edit-text' ID='#: ID #' ObjectType='" + tableType + "' TextType='BriefText' RequestID='0' ><div></div>#: ATools.changeTextFix(BriefText) #</span>",
                        filterable: {
                            cell: {
                                operator: "contains"
                            }
                        }
                    }
                ]
            }).data("kendoGrid");
            mainGrid.dataSource.originalFilter = mainGrid.dataSource.filter;
            mainGrid.dataSource.filter = function () {
                if (arguments.length > 0) {
                    this.trigger("filtering", arguments);
                }
                var result = mainGrid.dataSource.originalFilter.apply(this, arguments);
                return result;
            };
            mainGrid.dataSource.bind("filtering", function () {
                setTimeout(function () {
                    var val = $(".k-filtercell input").val();
                    var val2 = $('.k-master-row').length;
                    if ((val.length > 0) && (val2 == 1)) {
                        $(".k-master-row .k-plus").trigger('click');
                    }
                }, 400);
            });
            if (MainConfig.contextLogin !== 'SOMEONE' && !MainConfig.hozObjects)
                $('.k-header').eq(1).html('<div class="s-Ownership-c-i"><div class="s-Ownership-green-i"></div></div><div class="pSimpleTable-name">Имя</div>');
            $("#pSimpleTable").find("tr:eq(1) th:eq(0)").html("<div class='s-t-up helpinfo'   helptext='\u041B\u0438\u0441\u0442\u0430\u0442\u044C \u043E\u0431\u044A\u0435\u043A\u0442\u044B \u0432\u0432\u0435\u0440\u0445<br>(\u0433\u043E\u0440\u044F\u0447\u0430\u044F \u043A\u043B\u0430\u0432\u0438\u0448\u0430 - PgUp)'></div>\n                 <div class='s-t-down helpinfo' helptext='\u041B\u0438\u0441\u0442\u0430\u0442\u044C \u043E\u0431\u044A\u0435\u043A\u0442\u044B \u0432\u043D\u0438\u0437 <br>(\u0433\u043E\u0440\u044F\u0447\u0430\u044F \u043A\u043B\u0430\u0432\u0438\u0448\u0430 - PgDn)'></div>");
            $(".s-t-down").on('click', function () {
                var indexTab = 0;
                $(".DevSysSelectRow").next().find(".k-tabstrip-items li").each(function (i, v) {
                    if ($(this).hasClass("k-tab-on-top"))
                        indexTab = i;
                });
                var xx = $(".DevSysSelectRow").next().next();
                $(".DevSysSelectRow").find("td:eq(0) .k-icon").trigger("click");
                while (xx.css("display") == "none")
                    xx = xx.next();
                LoadEventManager.addEventHandler("load_pSimpleTable_obj", function () {
                    $(".DevSysSelectRow").next().find(".k-tabstrip-items li").each(function (i, v) {
                        if (i == indexTab)
                            $(this).trigger("click");
                    });
                });
                xx.find("td:eq(0) .k-icon").trigger("click");
            });
            $(".s-t-up").on('click', function () {
                var indexTab = 0;
                $(".DevSysSelectRow").next().find(".k-tabstrip-items li").each(function (i, v) {
                    if ($(this).hasClass("k-tab-on-top"))
                        indexTab = i;
                });
                var xx = $(".DevSysSelectRow").prev();
                $(".DevSysSelectRow").find("td:eq(0) .k-icon").trigger("click");
                while (xx.css("display") == "none")
                    xx = xx.prev();
                LoadEventManager.addEventHandler("load_pSimpleTable_obj", function () {
                    $(".DevSysSelectRow").next().find(".k-tabstrip-items li").each(function (i, v) {
                        if (i == indexTab) {
                            $(this).trigger("click");
                        }
                    });
                });
                xx.find("td:eq(0) .k-icon").trigger("click");
            });
            $("#pSimpleTable").on('click', '.k-master-row td .pSimpleTable-name', function () {
                $(this).parent().parent().find(".k-icon").trigger('click');
            });
            $("#pSimpleTable").on('click', '.DevSysSelectRow ~ .k-detail-row > td:eq(0)', function () {
                $(this).parent().prev().find(".k-icon").trigger('click');
            });
            ATools.Ownership('red', 0);
            ATools.resize("#pSimpleTable");
            LoadEventManager.execEvent("load_pSimpleTable");
        });
    };
    gSuperPage.voiteIcon = function () {
        $("#content_cont").on("click", ".voteico-yes", function () {
            var cont = $(this).parent().parent().parent();
            var idOrder = cont.find('td').eq(1).html();
            var req = "<UCMsg ID=\"6\">\n                   <Confirms>\n                     <Confirm>\n                       <RequestHead ID=\"" + idOrder + "\"></RequestHead>\n                       <Decision>1</Decision>\n                     </Confirm>\n                   </Confirms>\n                   " + XMLquery.getContext() + "\n                 </UCMsg>";
            DataBaseControl.SendRequest(req, function (xml) { });
            cont.find("td").eq(4).find(".CurrUser").removeClass("ignored").addClass("approved");
            cont.find(".s-vc").css("display", "none");
        });
        $("#content_cont").on("click", ".voteico-no", function () {
            var cont = $(this).parent().parent().parent();
            var idOrder = $(this).parent().parent().parent().find('td').eq(1).text();
            $("#pSimpleTable").after("<div class=\"s-body-vote\">\n                <div class=\"s-cbv\"></div>\n                <div class=\"s-labelVote\">\u041F\u0440\u0438\u0447\u0438\u043D\u0430:</div>\n                <textarea id=\"s-reason-t\" rows=\"3\" style=\"width: 100%;margin-bottom: 9px;\" class=\"k-textbox\" ></textarea>\n                <br>\n                <button class=\"k-button s-app-button\" style=\"margin-left: 0px;\">\u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u044C</button>\n            </div>");
            var pos = $(this).offset();
            $(".s-body-vote").css({ "top": pos.top - 75 - 6, "left": pos.left - 210 + 30 });
            $('.s-app-button').bind("click", function () {
                var reason_text = $('#s-reason-t').val();
                var req = "<UCMsg ID=\"6\">\n                      <Confirms>\n                        <Confirm>\n                          <RequestHead ID=\"" + idOrder + "\"></RequestHead>\n                          <BriefText>" + reason_text + "</BriefText>\n                          <Decision>0</Decision>\n                        </Confirm>\n                      </Confirms>\n                      " + XMLquery.getContext() + "\n                    </UCMsg>";
                DataBaseControl.SendRequest(req, function (xml) { });
                $(".s-body-vote").remove();
                cont.find("td").eq(4).find(".CurrUser").removeClass("ignored").addClass("notapproved");
                cont.find(".s-vc").css("display", "none");
            });
        });
    };
    gSuperPage.globalPageEvents = function () {
        gSuperPage.voiteIcon();
        PageControl.showHelp();
        $("body").on("click", function () {
            setTimeout(function () {
                $("#s-help-info").css("display", "none");
            }, 100);
        });
        $("body").keyup(function (e) {
            if (e.which === 33)
                $(".s-t-up").trigger("click");
            if (e.which === 34)
                $(".s-t-down").trigger("click");
            if (e.which === 27)
                $("#DevSysAlertWindow").prev().find(".k-i-close").trigger("click");
        });
        $("#content_cont").on("click", "#CreateOrderForm .s-t-down", function () {
            var res1 = [];
            var res2 = [];
            var index = $(this).parent().parent();
            var id = index.find("input").attr("id");
            id = id.substr(id.lastIndexOf("-") + 1);
            res1.push($("#ofs-fiel-" + id).val());
            res1.push($("#ofs-type-" + id).val());
            res1.push($("#ofs-pres-" + id).val());
            res1.push($("#ofs-size-" + id).val());
            res1.push($("#ofs-null-" + id).is(':checked') ? "Y" : "N");
            res1.push($("#ofs-brie-" + id).val());
            res1.push($("#ofs-full-" + id).val());
            res2.push($("#ofs-fiel-" + (parseInt(id) + 1)).val());
            res2.push($("#ofs-type-" + (parseInt(id) + 1)).val());
            res2.push($("#ofs-pres-" + (parseInt(id) + 1)).val());
            res2.push($("#ofs-size-" + (parseInt(id) + 1)).val());
            res2.push($("#ofs-null-" + (parseInt(id) + 1)).is(':checked') ? "Y" : "N");
            res2.push($("#ofs-brie-" + (parseInt(id) + 1)).val());
            res2.push($("#ofs-full-" + (parseInt(id) + 1)).val());
            $("#ofs-fiel-" + (parseInt(id) + 1)).val(res1[0]);
            $("#ofs-fiel-" + (parseInt(id) + 1)).trigger("propertychange");
            OFTools.setValComboBox("ofs-type-" + (parseInt(id) + 1), res1[1], true);
            $("#ofs-pres-" + (parseInt(id) + 1)).val(res1[2]);
            $("#ofs-size-" + (parseInt(id) + 1)).val(res1[3]);
            OFTools.setValCheckInput("ofs-null-" + (parseInt(id) + 1), res1[4]);
            $("#ofs-brie-" + (parseInt(id) + 1)).val(res1[5]);
            $("#ofs-full-" + (parseInt(id) + 1)).val(res1[6]);
            $("#ofs-fiel-" + (parseInt(id) + 0)).val(res2[0]);
            $("#ofs-fiel-" + (parseInt(id) + 0)).trigger("propertychange");
            OFTools.setValComboBox("ofs-type-" + (parseInt(id) + 0), res2[1], true);
            $("#ofs-pres-" + (parseInt(id) + 0)).val(res2[2]);
            $("#ofs-size-" + (parseInt(id) + 0)).val(res2[3]);
            OFTools.setValCheckInput("ofs-null-" + (parseInt(id) + 0), res2[4]);
            $("#ofs-brie-" + (parseInt(id) + 0)).val(res2[5]);
            $("#ofs-full-" + (parseInt(id) + 0)).val(res2[6]);
        });
        $("#content_cont").on("click", "#CreateOrderForm .s-t-up", function () {
            var res1 = [];
            var res2 = [];
            var index = $(this).parent().parent();
            var id = index.find("input").attr("id");
            id = id.substr(id.lastIndexOf("-") + 1);
            res1.push($("#ofs-fiel-" + id).val());
            res1.push($("#ofs-type-" + id).val());
            res1.push($("#ofs-pres-" + id).val());
            res1.push($("#ofs-size-" + id).val());
            res1.push($("#ofs-null-" + id).is(':checked') ? "Y" : "N");
            res1.push($("#ofs-brie-" + id).val());
            res1.push($("#ofs-full-" + id).val());
            res2.push($("#ofs-fiel-" + (parseInt(id) - 1)).val());
            res2.push($("#ofs-type-" + (parseInt(id) - 1)).val());
            res2.push($("#ofs-pres-" + (parseInt(id) - 1)).val());
            res2.push($("#ofs-size-" + (parseInt(id) - 1)).val());
            res2.push($("#ofs-null-" + (parseInt(id) - 1)).is(':checked') ? "Y" : "N");
            res2.push($("#ofs-brie-" + (parseInt(id) - 1)).val());
            res2.push($("#ofs-full-" + (parseInt(id) - 1)).val());
            $("#ofs-fiel-" + (parseInt(id) - 1)).val(res1[0]);
            $("#ofs-fiel-" + (parseInt(id) - 1)).trigger("propertychange");
            OFTools.setValComboBox("ofs-type-" + (parseInt(id) - 1), res1[1], true);
            $("#ofs-pres-" + (parseInt(id) - 1)).val(res1[2]);
            $("#ofs-size-" + (parseInt(id) - 1)).val(res1[3]);
            OFTools.setValCheckInput("ofs-null-" + (parseInt(id) - 1), res1[4]);
            $("#ofs-brie-" + (parseInt(id) - 1)).val(res1[5]);
            $("#ofs-full-" + (parseInt(id) - 1)).val(res1[6]);
            $("#ofs-fiel-" + (parseInt(id) + 0)).val(res2[0]);
            $("#ofs-fiel-" + (parseInt(id) + 0)).trigger("propertychange");
            OFTools.setValComboBox("ofs-type-" + (parseInt(id) + 0), res2[1], true);
            $("#ofs-pres-" + (parseInt(id) + 0)).val(res2[2]);
            $("#ofs-size-" + (parseInt(id) + 0)).val(res2[3]);
            OFTools.setValCheckInput("ofs-null-" + (parseInt(id) + 0), res2[4]);
            $("#ofs-brie-" + (parseInt(id) + 0)).val(res2[5]);
            $("#ofs-full-" + (parseInt(id) + 0)).val(res2[6]);
        });
        $("#content_cont").on("input propertychange", ".upp input", function () {
            $(this).val($(this).val().toUpperCase());
        });
        $("#content_cont").on('click', '.sql_button', function () {
            var curVal = $(this).html();
            if (curVal === '+SQL') {
                $('.sql_button').html('-SQL');
                $('.allsql').show();
            }
            else {
                $('.sql_button').html('+SQL');
                $('.allsql').hide();
            }
        });
        $("#content_cont").on("click", '.s-edit-text div', function () {
            var p = $(this).parent();
            var btext = p.text();
            if (btext === 'нет описания')
                btext = '';
            if (btext === 'Необходимо ввести описание')
                btext = '';
            $(this).parent().select();
            $(this).parent().focus();
            p.html('<textarea style="width: 100%;">' + btext + '</textarea><i>.</i><b>' + btext + '</b><em></em>');
            $(".s-edit-text textarea").on("input propertychange", function () {
                var textarea = $(this).val();
                $('.s-edit-text b').html(textarea);
                var hh = $('.s-edit-text b').height();
                $(this).height((hh < 20) ? 23 : hh);
            });
            $(".s-edit-text textarea").trigger("input");
            $("#MainContainer").off("click", '.s-edit-text');
            p.find('em').bind("click", function () {
                var ftext = jQuery.trim(p.find('textarea').val());
                var id = (p.attr('id') == 'x???') ? '' : p.attr('id');
                if (btext !== ftext) {
                    ftext = ftext.replace(/\</gim, "&lt;").replace(/\>/gim, "&gt;").replace(/\'/gim, "&#39;").replace(/\"/gim, '&quot;');
                    DataBaseControl.SendRequest(XMLquery.changeText(id, ftext, p.attr('objecttype'), p.attr('texttype'), p.attr('requestid')), function (a) { });
                    QueryCache.storage.getSchemaList.update = true;
                }
                if (ftext === '')
                    ftext = 'нет описания';
                p.html('<div></div>' + ftext);
            });
        });
        $("#content_cont").on("click", '.s-Ownership-c-i', function () {
            var green = $(this).find('.s-Ownership-green-i').length;
            var div = $(this).find('div');
            if (green > 0) {
                div.removeClass('s-Ownership-green-i');
                div.addClass('s-Ownership-green-red-i');
                ATools.Ownership('red', 1);
                $('.k-hierarchy-cell .k-icon').html('<div></div>');
            }
            else {
                div.removeClass('s-Ownership-green-red-i');
                div.addClass('s-Ownership-green-i');
                ATools.Ownership('red', 0);
                $('.k-hierarchy-cell .k-icon').html('<div></div>');
            }
        });
        $("#content_cont").on("click", '.s-Ownership-c', function () {
            var green = $(this).find('.s-Ownership-green').length;
            var div = $(this).find('div');
            var tableID = $(this).parent().text();
            if (green > 0) {
                div.removeClass('s-Ownership-green');
                div.addClass('s-Ownership-red');
                if (!($('#s-showAll-eq6').is(':checked')))
                    ATools.Ownership('red', 0);
                DataBaseControl.SendRequest(XMLquery.ChangeOwnership(tableID, 'TABLE', '0'), function (a) { });
            }
            else {
                div.removeClass('s-Ownership-red');
                div.addClass('s-Ownership-green');
                DataBaseControl.SendRequest(XMLquery.ChangeOwnership(tableID, 'TABLE', '1'), function (a) { });
            }
            QueryCache.storage.getSchemaList.update = true;
        });
    };
    gSuperPage.DispalyRequestItems = function (tagContaner, myDS) {
        var DispalyRequestItemsDS = ATools.DataSourceFromXml(myDS, 'RequestHead > Requests > Request > Subject');
        for (var i in DispalyRequestItemsDS) {
            DispalyRequestItemsDS[i]['Action'] = ATools.getXmlVal(DispalyRequestItemsDS[i]['html'], 'Action');
            DispalyRequestItemsDS[i]['ObjectType'] = ATools.getXmlVal(DispalyRequestItemsDS[i]['html'], 'ObjectType');
            DispalyRequestItemsDS[i]['Object'] = ATools.getXmlVal(DispalyRequestItemsDS[i]['html'], 'Object');
        }
        var result = '';
        var errors = 0;
        for (var i in DispalyRequestItemsDS) {
            if (DispalyRequestItemsDS[i]['Object'].length > 0) {
                result +=
                    gSuperPage.DispalyRequestItem(DispalyRequestItemsDS[i]['Action'], DispalyRequestItemsDS[i]['ObjectType'], DispalyRequestItemsDS[i]['Object']);
            }
            else {
                errors++;
                result += '<div class="margin">* пустой пункт заявки</div>';
            }
        }
        if (errors == DispalyRequestItemsDS.length) {
            result = '<div class="margin">Заявка не содержит действий!</div>';
        }
        else {
            result += '<div class="sql_button">+SQL</div>';
            result += '<div class="allsql" style="display: none;">';
            for (var i in DispalyRequestItemsDS) {
                result +=
                    gSuperPage.DispalyRequestItemSQL(DispalyRequestItemsDS[i]['Action'], DispalyRequestItemsDS[i]['ObjectType'], DispalyRequestItemsDS[i]['Object']);
            }
            result += '</div><br/>';
        }
        tagContaner.html(result);
    };
    gSuperPage.getFieldsListID = function (xml) {
        var xmldom = $($.parseXML("<b>" + xml + "</b>"));
        var result = '';
        if ($(xmldom).find('Field').length > 0) {
            $(xmldom).find('Field').each(function () {
                result += ', ' + $(this).attr('ID');
            });
            return result.substr(2);
        }
        else {
            return '-';
        }
    };
    gSuperPage.DispalyRequestItem = function (Action, ObjectType, ObjectXML) {
        function langConvert(val) {
            switch (val) {
                case 'add': return 'Добавить';
                case 'delete': return 'Удалить';
                case 'modify': return 'Изменить';
                case 'TABLE': return 'таблицу';
                case 'FIELD': return 'поле';
                case 'INDEX': return 'индекс';
                case 'QUERY': return 'запрос';
                case 'CONSTRAINT': return 'констрейнт';
                case 'SEQN': return 'последовательность';
                case 'VIEW': return 'представление';
                default: return '??????';
            }
        }
        var xmldom = $($.parseXML(ObjectXML));
        try {
            var typeObj = xmldom.children().get(0).tagName;
        }
        catch (e) {
            return 'error';
        }
        var resultHtml = '';
        resultHtml += '<div class="RequestItem">';
        resultHtml += '<div class="ActionInfo"><ul><li>' + langConvert(Action) + ' ' + langConvert(ObjectType) + '</li></ul></div>';
        switch (typeObj) {
            case 'Field':
                {
                    var zType = ATools.getXmlValObj(xmldom[0], 'Type'), zSize = ATools.getXmlValObj(xmldom[0], 'Size'), zPrec = ATools.getXmlValObj(xmldom[0], 'Precision'), TypeDop = "";
                    if (zType.indexOf("(") == -1) {
                        if (zSize != "")
                            TypeDop += zSize;
                        if (zPrec != "")
                            TypeDop += "," + zPrec;
                        if (TypeDop != "")
                            TypeDop = "(" + TypeDop + ")";
                    }
                    resultHtml += $("<div></div>").kendoGrid({
                        dataSource: [
                            {
                                TableID: ATools.getXmlValObj(xmldom[0], 'TableID'),
                                ID: xmldom.find('Field').attr('ID'),
                                Type: zType + TypeDop,
                                DefVal: ATools.getXmlValObj(xmldom[0], 'DefVal'),
                                Nullable: ATools.getXmlValObj(xmldom[0], 'Nullable'),
                                BriefText: ATools.getXmlValObj(xmldom[0], 'BriefText'),
                                FullText: ATools.getXmlValObj(xmldom[0], 'FullText')
                            }
                        ],
                        scrollable: false,
                        columns: [
                            { field: "TableID", title: "Таблица", format: "{0:c}", width: "90px" },
                            { field: "ID", title: "Поле", format: "{0:c}", width: "90px" },
                            { field: "Type", title: "Тип", format: "{0:c}", width: "120px" },
                            { field: "DefVal", title: "Default", format: "{0:c}", width: "120px" },
                            { field: "Nullable", title: "Nullable", format: "{0:c}", width: "90px" },
                            { field: "BriefText", title: "Кратко", format: "{0:c}", width: "90px" },
                            { field: "FullText", title: "Подробно" }
                        ]
                    }).html();
                }
                break;
            case 'Table':
                {
                    var data_tab = [];
                    $(xmldom).find('Table > Fields > Field').each(function () {
                        var zType = ATools.getXmlValObj(this, 'Type'), zSize = ATools.getXmlValObj(this, 'Size'), zPrec = ATools.getXmlValObj(this, 'Precision'), TypeDop = "";
                        if (zType.indexOf("(") == -1) {
                            if (zSize != "")
                                TypeDop += zSize;
                            if (zPrec != "")
                                TypeDop += "," + zPrec;
                            if (TypeDop != "")
                                TypeDop = "(" + TypeDop + ")";
                        }
                        data_tab.push({
                            id: $(this).attr('ID'),
                            DefVal: ATools.getXmlValObj(this, 'DefVal'),
                            BriefText: ATools.getXmlValObj(this, 'BriefText'),
                            FullText: ATools.getXmlValObj(this, 'FullText'),
                            Nullable: ATools.getXmlValObj(this, 'Nullable'),
                            Type: zType + TypeDop
                        });
                    });
                    resultHtml += $("<div>Имя таблицы: " + $(xmldom).find('Table').attr('ID') + "<br></div>").kendoGrid({
                        dataSource: data_tab,
                        scrollable: false,
                        columns: [
                            { field: "id", title: "Поле", format: "{0:c}", width: "90px" },
                            { field: "Type", title: "Тип", format: "{0:c}", width: "90px" },
                            { field: "DefVal", title: "Default", format: "{0:c}", width: "120px" },
                            { field: "Nullable", title: "Nullable", format: "{0:c}", width: "90px" },
                            { field: "BriefText", title: "Краткое описание", format: "{0:c}", width: "130px" },
                            { field: "FullText", title: "Полное описание" }
                        ]
                    }).html();
                }
                break;
            case 'Index':
                {
                    resultHtml += $("<div></div>").kendoGrid({
                        dataSource: [
                            {
                                ID: xmldom.find('Index').attr('ID'),
                                TableID: ATools.getXmlValObj(xmldom[0], 'TableID'),
                                Uniqueness: ATools.getXmlValObj(xmldom[0], 'Uniqueness'),
                                Type: ATools.getXmlValObj(xmldom[0], 'Type'),
                                indexes: gSuperPage.getFieldsListID(ATools.getXmlValObj(xmldom[0], 'Fields'))
                            }
                        ],
                        scrollable: false,
                        columns: [
                            { field: "TableID", title: "Таблица", format: "{0:c}", width: "90px" },
                            { field: "ID", title: "Индекс", format: "{0:c}", width: "90px" },
                            { field: "Uniqueness", title: "Уникальность", format: "{0:c}", width: "90px" },
                            { field: "Type", title: "Тип", format: "{0:c}", width: "90px" },
                            { field: "indexes", title: "Поля" }
                        ]
                    }).html();
                }
                break;
            case 'Query':
                {
                    var BriefText = ATools.getXmlValObj(xmldom[0], 'BriefText');
                    var comm = (BriefText.length > 0) ? "<br>" + BriefText : '';
                    resultHtml += $("<div></div>").kendoGrid({
                        dataSource: [{ Body: ATools.getXmlValObj(xmldom[0], 'Body') }],
                        scrollable: false,
                        columns: [
                            {
                                field: "Body",
                                title: "Запрос " + xmldom.find('Query').attr('ID') + ' типа ' + ATools.getXmlValObj(xmldom[0], 'Type') + comm,
                                attributes: { style: "word-wrap: break-word;white-space:pre;" }
                            }
                        ]
                    }).html();
                }
                break;
            case 'Constraint':
                {
                    var typecon = ATools.getXmlValObj(xmldom[0], 'Type').trim();
                    typecon = (typecon == "C") ? "CHECK" : typecon;
                    typecon = (typecon == "P") ? "PRIMARY" : typecon;
                    typecon = (typecon == "R") ? "REFERENCE" : typecon;
                    resultHtml += $("<div></div>").kendoGrid({
                        dataSource: [
                            {
                                ID: xmldom.find('Constraint').attr('ID'),
                                TableID: ATools.getXmlValObj(xmldom[0], 'TableID'),
                                Type: typecon,
                                Validate: ATools.getXmlValObj(xmldom[0], 'Validate'),
                                Fields: gSuperPage.getFieldsListID(ATools.getXmlValObj(xmldom[0], 'Fields'))
                            }
                        ],
                        scrollable: false,
                        columns: [
                            { field: "ID", title: "Констрейнт", format: "{0:c}", width: "90px" },
                            { field: "TableID", title: "Таблица", format: "{0:c}", width: "90px" },
                            { field: "Type", title: "Тип", format: "{0:c}", width: "90px" },
                            { field: "Validate", title: "Валидность", format: "{0:c}", width: "90px" },
                            { field: "Fields", title: "Поля" }
                        ]
                    }).html();
                }
                break;
            case 'Sequence':
                {
                    resultHtml += "<div style=\"white-space:pre; font-family:monospace; font-size:12px; border: solid 1px #DBDBDB;\"\n><div class=\"br1\"/>  \u0418\u043C\u044F: " + xmldom.find('Sequence').attr('ID') + "\n  \u041D\u0430\u0447\u0430\u043B\u044C\u043D\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435:     " + ATools.getXmlValObj(xmldom[0], 'StartWith') + "\n  \u041C\u0438\u043D\u0438\u043C\u0430\u043B\u044C\u043D\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435:   " + ATools.getXmlValObj(xmldom[0], 'MinValue') + "\n  \u041C\u0430\u043A\u0441\u0438\u043C\u0430\u043B\u044C\u043D\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435:  " + ATools.getXmlValObj(xmldom[0], 'MaxValue') + "\n  \u0418\u043D\u043A\u0440\u0435\u043C\u0435\u043D\u0442:              " + ATools.getXmlValObj(xmldom[0], 'IncrBy') + "\n  \u0420\u0430\u0437\u043C\u0435\u0440 \u043A\u0435\u0448\u0430:            " + ATools.getXmlValObj(xmldom[0], 'CacheSize') + "\n  \u0426\u0438\u043A\u043B:                   " + ATools.getXmlValObj(xmldom[0], 'CycleFlg') + "\n  \u041F\u043E\u0440\u044F\u0434\u043E\u043A:                " + ATools.getXmlValObj(xmldom[0], 'OrderFlg') + "\n  \u041A\u0440\u0430\u0442\u043A\u043E\u0435 \u043E\u043F\u0438\u0441\u0430\u043D\u0438\u0435:       " + ATools.getXmlValObj(xmldom[0], 'BriefText') + " <div class=\"br1\"/></div>";
                }
                break;
            case 'View':
                {
                    var BriefText = ATools.getXmlValObj(xmldom[0], 'BriefText');
                    var comm = (BriefText.length > 0) ? "<br>" + BriefText : '';
                    resultHtml += $("<div></div>").kendoGrid({
                        dataSource: [{ Body: ATools.getXmlValObj(xmldom[0], 'Body') }],
                        scrollable: false,
                        columns: [
                            {
                                field: "Body",
                                title: "Представление " + xmldom.find('View').attr('ID') + comm,
                                attributes: { style: "word-wrap: break-word;white-space:pre;" }
                            },
                        ]
                    }).html();
                }
                break;
        }
        resultHtml += '</div>';
        return resultHtml;
    };
    gSuperPage.DispalyRequestItemSQL = function (Action, ObjectType, ObjectXML) {
        var xmldom = $($.parseXML("" + ObjectXML));
        try {
            var typeObj = xmldom.children().get(0).tagName;
        }
        catch (e) {
            return '';
        }
        var resultHtml = '';
        switch (typeObj) {
            case 'Field':
                {
                    if (Action === 'add') {
                        var def = ATools.getXmlValObj(xmldom[0], 'DefVal');
                        resultHtml += '<div class="sql-s">' +
                            'ALTER TABLE ' + ATools.getXmlValObj(xmldom[0], 'TableID') +
                            ' ADD ' + xmldom.find('Field').attr('ID') +
                            ' ' + ATools.convertToOracle(ATools.getXmlValObj(xmldom[0], 'Type')) +
                            ' ' + ((ATools.getXmlValObj(xmldom[0], 'Nullable') !== 'Y') ? 'NOT ' : '') + 'NULL' +
                            ' ' + ((def.length > 0) ? 'DEFAULT ' + ((/(^\d+$)/.test(def)) ? def : '"' + def + '"') : '') +
                            ';</div>';
                    }
                    ;
                    if (Action === 'delete') {
                        resultHtml += '<div class="sql-s">' +
                            'ALTER TABLE ' + ATools.getXmlValObj(xmldom[0], 'TableID') +
                            ' DROP ' + xmldom.find('Field').attr('ID') +
                            ';</div>';
                    }
                    ;
                    if (Action === 'modify') {
                        resultHtml += '<div class="sql-s">' +
                            'ALTER TABLE ' + ATools.getXmlValObj(xmldom[0], 'TableID') +
                            ' MODIFY( ' + xmldom.find('Field').attr('ID') +
                            ' ' + ATools.convertToOracle(ATools.getXmlValObj(xmldom[0], 'Type')) +
                            ' ' + ((ATools.getXmlValObj(xmldom[0], 'Nullable') !== 'Y') ? 'NOT ' : '') + 'NULL' +
                            ' );</div>';
                    }
                }
                break;
            case 'Table':
                {
                    if (Action === 'add') {
                        var data_tab = [];
                        $(xmldom).find('Table > Fields > Field').each(function () {
                            data_tab.push({
                                id: $(this).attr('ID'),
                                BriefText: ATools.getXmlValObj(this, 'BriefText'),
                                FullText: ATools.getXmlValObj(this, 'FullText'),
                                DefVal: ATools.getXmlValObj(this, 'DefVal'),
                                Nullable: ATools.getXmlValObj(this, 'Nullable'),
                                Type: ATools.getXmlValObj(this, 'Type')
                            });
                        });
                        resultHtml += '<div class="sql-s">' +
                            'CREATE TABLE ' + xmldom.find('Table').attr('ID') + '(\n';
                        for (var i = 0; i < data_tab.length; i++) {
                            var def = data_tab[i].DefVal;
                            resultHtml += data_tab[i].id + ' ' +
                                ATools.convertToOracle(data_tab[i].Type) + ' ' +
                                '\t ' + ((data_tab[i].Nullable !== 'Y') ? 'NOT ' : '') + 'NULL' +
                                ' ' + ((def.length > 0) ? 'DEFAULT ' + ((/(^\d+$)/.test(def)) ? def : '"' + def + '"') : '');
                            if (i != (data_tab.length - 1))
                                resultHtml += ',';
                            resultHtml += '\n';
                        }
                        resultHtml += ');</div>';
                    }
                    ;
                    if (Action === 'delete') {
                        resultHtml += '<div class="sql-s">' +
                            'DROP TABLE ' + xmldom.find('Table').attr('ID') +
                            ';</div>';
                    }
                    ;
                    if (Action === 'modify') {
                        resultHtml += '<div class="sql-s">MODIFY TABLE ERROR;  </div>';
                    }
                }
                break;
            case 'Index':
                {
                    var UNIQUE = (ATools.getXmlValObj(xmldom[0], 'Uniqueness') == '1') ? 'UNIQUE' : '';
                    if (Action === 'add') {
                        resultHtml += '<div class="sql-s">' +
                            'CREATE ' + UNIQUE + ' INDEX ' + xmldom.find('Index').attr('ID') +
                            ' ON ' + ATools.getXmlValObj(xmldom[0], 'TableID') +
                            ' (' + gSuperPage.getFieldsListID(ATools.getXmlValObj(xmldom[0], 'Fields')) + ');</div>';
                    }
                    ;
                    if (Action === 'delete') {
                        resultHtml += '<div class="sql-s">' +
                            'DROP INDEX ' + xmldom.find('Index').attr('ID') +
                            ';</div>';
                    }
                    ;
                    if (Action === 'modify') {
                        resultHtml += '<div class="sql-s">' +
                            'DROP INDEX ' + xmldom.find('Index').attr('ID') +
                            ';\n' +
                            'CREATE ' + UNIQUE + ' INDEX ' + xmldom.find('Index').attr('ID') +
                            ' ON ' + ATools.getXmlValObj(xmldom[0], 'TableID') +
                            ' (' + gSuperPage.getFieldsListID(ATools.getXmlValObj(xmldom[0], 'Fields')) + ');' +
                            +'</div>';
                    }
                    ;
                }
                break;
            case 'Query':
                {
                    if (Action === 'add') {
                        resultHtml += '<div class="sql-s">' + ATools.getXmlValObj(xmldom[0], 'Body') + '</div>';
                    }
                    ;
                    if (Action === 'delete') {
                        resultHtml += '<div class="sql-s">' +
                            'DROP TRIGGER ' + xmldom.find('Query').attr('ID') + ';</div>';
                    }
                    ;
                    if (Action === 'modify') {
                        resultHtml += '<div class="sql-s">' + ATools.getXmlValObj(xmldom[0], 'Body') + '</div>';
                    }
                }
                break;
            case 'Constraint':
                {
                    if (Action === 'add') {
                        resultHtml += '<div class="sql-s">' +
                            'ALTER TABLE ' + ATools.getXmlValObj(xmldom[0], 'TableID') +
                            ' ADD CONSTRAINT ' + xmldom.find('Constraint').attr('ID') + ' ' +
                            ATools.getXmlValObj(xmldom[0], 'Type') + ' ' +
                            gSuperPage.getFieldsListID(ATools.getXmlValObj(xmldom[0], 'Fields')) +
                            ';</div>';
                    }
                    ;
                    if (Action === 'delete') {
                        resultHtml += '<div class="sql-s">' +
                            'ALTER TABLE ' + ATools.getXmlValObj(xmldom[0], 'TableID') +
                            ' DROP CONSTRAINT ' + xmldom.find('Constraint').attr('ID') +
                            ';</div>';
                    }
                    ;
                    if (Action === 'modify') {
                        resultHtml += '<div class="sql-s">' +
                            'ALTER TABLE ' + ATools.getXmlValObj(xmldom[0], 'TableID') +
                            ' DROP CONSTRAINT ' + xmldom.find('Constraint').attr('ID') + ';\n' +
                            'ALTER TABLE ' + ATools.getXmlValObj(xmldom[0], 'TableID') +
                            ' ADD CONSTRAINT ' + xmldom.find('Constraint').attr('ID') + ' ' +
                            ATools.getXmlValObj(xmldom[0], 'Type') + ' ' +
                            gSuperPage.getFieldsListID(ATools.getXmlValObj(xmldom[0], 'Fields')) +
                            ';</div>';
                    }
                }
                break;
            case 'Sequence':
                {
                    resultHtml += '';
                    if (Action === 'add') {
                        resultHtml += '<div class="sql-s">';
                        resultHtml += 'CREATE SEQUENCE ' + xmldom.find('Sequence').attr('ID') + '<br>';
                        resultHtml += 'START WITH ' + ATools.getXmlValObj(xmldom[0], 'StartWith') + '<br>';
                        resultHtml += 'INCREMENT BY ' + ATools.getXmlValObj(xmldom[0], 'IncrBy') + '<br>';
                        resultHtml += 'MINVALUE ' + ATools.getXmlValObj(xmldom[0], 'MinValue') + '<br>';
                        resultHtml += 'MAXVALUE ' + ATools.getXmlValObj(xmldom[0], 'MaxValue') + '<br>';
                        resultHtml += ((ATools.getXmlValObj(xmldom[0], 'CycleFlg') == 'Y') ? 'NOCYCLE <br>' : '');
                        resultHtml += ((ATools.getXmlValObj(xmldom[0], 'OrderFlg') == 'Y') ? 'NOORDER <br>' : '');
                        resultHtml += 'CACHE ' + ATools.getXmlValObj(xmldom[0], 'CacheSize') + ';';
                        resultHtml += '</div>';
                    }
                    ;
                    if (Action === 'delete') {
                        resultHtml += '<div class="sql-s">' + 'DROP SEQUENCE ' + xmldom.find('Sequence').attr('ID') + ';</div>';
                    }
                    ;
                    if (Action === 'modify') {
                        resultHtml += '<div class="sql-s">';
                        resultHtml += 'CREATE OR REPLACE SEQUENCE ' + xmldom.find('Sequence').attr('ID') + '<br>';
                        resultHtml += 'START WITH ' + ATools.getXmlValObj(xmldom[0], 'StartWith') + '<br>';
                        resultHtml += 'INCREMENT BY ' + ATools.getXmlValObj(xmldom[0], 'IncrBy') + '<br>';
                        resultHtml += 'MINVALUE ' + ATools.getXmlValObj(xmldom[0], 'MinValue') + '<br>';
                        resultHtml += 'MAXVALUE ' + ATools.getXmlValObj(xmldom[0], 'MaxValue') + '<br>';
                        resultHtml += ((ATools.getXmlValObj(xmldom[0], 'CycleFlg') == 'Y') ? 'NOCYCLE <br>' : '');
                        resultHtml += ((ATools.getXmlValObj(xmldom[0], 'OrderFlg') == 'Y') ? 'NOORDER <br>' : '');
                        resultHtml += 'CACHE ' + ATools.getXmlValObj(xmldom[0], 'CacheSize') + ';';
                        resultHtml += '</div>';
                    }
                    ;
                }
                break;
            case 'View':
                {
                    resultHtml += '';
                    if (Action === 'add') {
                        resultHtml += '<div class="sql-s">' +
                            'CREATE OR REPLACE VIEW ' + xmldom.find('View').attr('ID') + ' AS ' +
                            ATools.getXmlValObj(xmldom[0], 'Body') +
                            ';</div>';
                    }
                    ;
                    if (Action === 'delete') {
                        resultHtml += '<div class="sql-s">' +
                            'DROP VIEW ' + xmldom.find('View').attr('ID') +
                            ';</div>';
                    }
                    ;
                    if (Action === 'modify') {
                        resultHtml += '<div class="sql-s">' +
                            'CREATE OR REPLACE VIEW ' + xmldom.find('View').attr('ID') + ' AS ' +
                            ATools.getXmlValObj(xmldom[0], 'Body') +
                            ';</div>';
                    }
                }
                break;
        }
        return resultHtml + '<br>';
    };
    gSuperPage.simpleTemplateTab = "<div class=\"tabstrip\">\n          <ul>\n            <li class=\"k-state-active\">\u0422\u0435\u043A\u0441\u0442</li>\n            <li>\u0417\u0430\u044F\u0432\u043A\u0438</li>\n          </ul>\n          <div class=\"structTabs\">\n            <div class=\"tab_object\"></div>\n          </div>\n          <div class=\"structTabs\">\n            <div class=\"requests_tab\"></div>\n          </div>\n        </div>";
    gSuperPage.templateSimpleTable = '<div id="pSimpleTable"></div>';
    return gSuperPage;
}());
var hBaseCss = "\n<style type=\"text/css\">\n    body {\n        padding: 0px;\n        margin: 0px;\n        font-family: 'Open Sans', arial, sans-serif;\n    }\n    .k-block, .k-widget, .k-popup, .k-content, .k-toolbar, .k-dropdown .k-input {\n        color: #3A3A3A; /* \u0442\u0435\u043C\u043D\u0435\u0435 \u043D\u0430\u0434\u043F\u0438\u0441\u0438 */\n    }\n    .k-grid td {\n        border-width: 0 0 1px 1px !important; /* \u0432 \u0442\u0430\u0431\u043B\u0438\u0446\u0430\u0445 \u044F\u0447\u0435\u0439\u043A\u0438 \u0441\u0432\u0435\u0440\u0445\u0443 \u0438 \u0441\u043D\u0438\u0437\u0443 \u0438\u043C\u0435\u044E\u0442 \u0431\u043E\u0440\u0434\u0435\u0440 */\n    }\n\n    #content {\n        background: #eee;\n        /* background: url(styles/Metro/indeterminate.gif); */\n    }\n\n    #content tr.k-alt {\n        background: transparent; /* \u0443\u0431\u0438\u0440\u0430\u0435\u043C \u0447\u0435\u0440\u0435\u0434\u043E\u0432\u0430\u043D\u0438\u0435 \u0446\u0432\u0435\u0442\u043E\u0432 \u0443 \u0444\u043E\u043D\u0430 \u0441\u0442\u0440\u043E\u043A \u0442\u0430\u0431\u043B\u0438\u0446 */\n    }\n\n    #content .k-state-selected { /* \u0441\u0442\u0438\u043B\u044C \u0432\u044B\u0434\u0435\u043B\u0435\u043D\u043D\u043E\u0439 \u044F\u0447\u0435\u0439\u043A\u0438 */\n        color: #3A3A3A;\n        background-color: rgba(216, 240, 158, 0.72)!important;\n    } \n    \n\n    .displayNone {\n        display: none;   /* \u0441\u043A\u0440\u044B\u0432\u0430\u0435\u043C \u044F\u0447\u0435\u0439\u043A\u0438 \u0442\u0430\u0431\u043B\u0438\u0446\u044B \u043D\u0430\u0437\u043D\u0430\u0447\u0430\u044F/\u0443\u0434\u0430\u043B\u044F\u044F \u044D\u0442\u043E\u0442 \u043A\u043B\u0430\u0441\u0441 */\n    }\n\n    .displayNone2 {\n        display: none;   /* \u0441\u043A\u0440\u044B\u0432\u0430\u0435\u043C \u044F\u0447\u0435\u0439\u043A\u0438 \u0442\u0430\u0431\u043B\u0438\u0446\u044B \u043D\u0430\u0437\u043D\u0430\u0447\u0430\u044F/\u0443\u0434\u0430\u043B\u044F\u044F \u044D\u0442\u043E\u0442 \u043A\u043B\u0430\u0441\u0441 */\n    }\n\n\n    /* \u043C\u0438\u043D\u0438\u043C\u0430\u043B\u044C\u043D\u0430\u044F \u0432\u044B\u0441\u043E\u0442\u0430 \u0432\u043A\u043B\u0430\u0434\u043A\u0438 */\n    .k-tabstrip .k-content {\n        min-height: 100px;\n    }\n\n    /* SQL \u043A\u043E\u0434 \u043F\u043E \u0437\u0430\u044F\u0432\u043A\u0435 */\n    .sql_button {\n        margin: 19px 0px 0px 10px;\n        color: darkgreen;\n        cursor: pointer;\n    }\n\n    .allsql {\n        white-space: pre;\n        margin: 5px 10px 0px 10px;\n        background-color: #f5f5f5;\n        padding: 8px;\n    }\n\n    /* \u043A\u043E\u043C\u043C\u0435\u043D\u0442\u0430\u0440\u0438\u0438 \u0438 \u043F\u0440\u0430\u0432\u043A\u0430 \u043A\u043E\u043C\u043C\u0435\u043D\u0442\u0430\u0440\u0438\u0435\u0432 */\n    .s-edit-text {\n        position: relative;\n        white-space: pre-line;\n        display: inline-block;\n        width: 100%;\n    }\n    \n    .s-edit-text i {        \n        font-size: 1px;\n    }\n\n    .s-edit-text em {\n        position: fixed;\n        top: 0px;\n        margin-top: 0px;\n        left: 0px;\n        width: 100%;\n        height: 100%;\n        background-color: transparent;\n        z-index: 9998;\n    }\n\n    .s-edit-text div {\n        position: absolute;\n        border-bottom: 2px solid #698906;\n        padding-top: 15px;\n        padding-left: 9px;\n        cursor: pointer;\n    }\n\n    .s-edit-text b {\n        visibility: hidden;\n        width: 100%;\n        border: 0px;\n        outline: none;\n        font-style: italic;\n        color: #698906;\n        position: relative;\n        font-size: 17px;\n    }\n\n    .s-edit-text textarea {\n        width: 100%;\n        border: 0px;\n        outline: none;\n        background: transparent;\n        font-style: italic;\n        color: #698906;\n        z-index: 9999;\n        position: absolute;\n    }\n\n    /* \u043F\u0443\u043D\u043A\u0442 \u0437\u0430\u044F\u0432\u043A\u0438 \u0432 \u0442\u0430\u0431\u043B\u0438\u0446\u0430\u0445 */\n    .RequestItem {\n        margin: 18px 0px 18px 0px;\n    }\n\n    /* \u043F\u0440\u043E\u0441\u0442 \u043E\u0442\u0441\u0442\u0443\u043F */\n    .margin {\n        margin: 15px 25px;\n    }\n\n    /* \u0446\u0432\u0435\u0442 \u0440\u0430\u0441\u043A\u0440\u044B\u0442\u043E\u0433\u043E \u043E\u0431\u044A\u0435\u043A\u0442\u0430 \u0432 \u0442\u0430\u0431\u043B\u0438\u0446\u0435 \u0442\u0438\u043F\u0430 SIMPLE */\n    .DevSysSelectRow {\n        background-color: #EBF3D0 !important;\n    }\n\n    /* \u043F\u043E\u043A\u0430\u0437\u0430\u0442\u044C \u043A\u0432\u0430\u0434\u0440\u0430\u0442 \u0432 \u0441\u043F\u0438\u0441\u043A\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0439 \u0437\u0430\u044F\u0432\u043A\u0438 */\n    li {\n        list-style: square outside;\n    }\n    \n    .br1 {\n        height: 6px;\n    }\n\n    ul {\n        margin: 3px 0px 3px -21px;\n    }\n\n    .RequestItem table {\n        border: solid 1px #DBDBDB;\n    }\n    \n    /* new checkbox begin */\n    .cb label {\n    \tdisplay: inline-block;\n    \tcursor: pointer;\n    \tposition: relative; \n    \tpadding-left: 25px;\n    \tmargin-right: 15px;\n    \tfont-size: 13px;\n    }    \n    .cb label:before {\n    \tborder-radius: 4px;\n    \tcontent: \"\";\n    \tdisplay: inline-block;\n    \twidth: 16px;\n    \theight: 16px;\n    \tmargin-right: 10px;\n    \tposition: absolute;\n    \tleft: 0;\n    \tbottom: -7px;\n    \tbackground-color: #eee;\n    \tbox-shadow: inset 0px 2px 3px 0px rgba(0, 0, 0, .3), 0px 1px 0px 0px rgba(255, 255, 255, .8);\n    }    \n    /* \u0443\u0431\u0440\u0430\u0442\u044C \u0441\u0442\u0430\u0440\u044B\u0439 \u0447\u0435\u043A\u0431\u043E\u043A\u0441 */\n    .cb input[type=checkbox] {\n    \tdisplay: none;\n    }    \n    /* \u0433\u0430\u043B\u043A\u0430 */\n    .cb input[type=checkbox]:checked + label:before {\n    \tcontent: \"\\2713\";\n    \ttext-shadow: 1px 1px 1px rgba(0, 0, 0, .2);\n    \tfont-size: 15px;\n    \tcolor: #666;\n    \ttext-align: center;\n        line-height: 15px;\n    }\n    /* new checkbox end */\n\n\n    /* \u0442\u0430\u0431\u043B\u0438\u0447\u043A\u0430 \u043F\u043E\u043C\u043E\u0449\u0438 */\n    #s-help-info { \n        position: absolute; \n        display: none; \n        z-index: 9999; \n        padding: 4px; \n        border: 1px solid #698906; \n        background-color: white; \n        font-size: 12px; \n    }\n\n\n    .structTabs {\n        min-height: 100px;\n        padding: 10px !important;\n    }\n\n    .s-t-up {\n        cursor: pointer;\n        display: block;\n        position: absolute;\n        left: 9px;\n        width: 0;\n        top: 5px;\n        height: 0;\n        border: 5px solid transparent;\n        border-bottom-color: #9c9c9c;\n        border-top: 0;\n    }\n    .s-t-down {\n        cursor: pointer;\n        display: block;\n        position: absolute;\n        left: 9px;\n        width: 0;\n        top: 17px;\n        height: 0;\n        border: 5px solid transparent;\n        border-top-color: #9c9c9c;\n        border-bottom: 0;\n    }\n          \n\n    .DevSysSelectRow ~ .k-detail-row > td:first-child:hover {\n        background: antiquewhite;\n    }\n\n\n    #pSimpleTable\n    {\n      border-width: 0;\n      height: 100%; /* DO NOT USE !important for setting the Grid height! */\n    }\n\n</style>\n\n<!--[if IE]>\n<style type=\"text/css\">\n    \n\n</style>\n<![endif]-->\n";
{
    var hBodyMenu = "\n<div id=\"top_border\"></div>\n<div id=\"s-help-info\"></div> \n<div id=\"content_cont\">\n    <div id=\"content\">\n\n    </div> \n</div>\n<div id=\"titlePage\"></div>\n<div id=\"main_menu_block\" class=\"k-item\">\n    <div id=\"Logo\"><a href=\"/\"><div></div><span>DEV-SYSTEM</span></a></div>\n    <style type=\"text/css\">\n        #Logo {\n            height: 75px;\n            background-color: #8ebc00; /* rgb(25, 150, 228); */\n            display: block;\n            color: #ffffff;\n        }\n\n        #Logo a {\n            color: #ffffff; \n        }\n\n        #Logo span { \n            margin: 27px 0px 0px 61px;\n            position: absolute;\n            font-size: 19px;\n        }\n\n        #Logo div {\n            position: absolute;\n            display: block;\n            margin: 18px 0px 0px 10px;\n            width: 40px;\n            height: 40px;\n            background-size: cover;\n            background-image: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALMAAACrCAYAAAAtka0FAAAABGdBTUEAAK/INwWK6QAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAABH+SURBVHjaYvz//z/DKBgFwwEABBDTaBCMguECAAJoNDGPgmEDAAJoNDGPgmEDAAJoNDGPgmEDAAJoNDGPgmEDAAJoNDGPgmEDAAJoNDGPgmEDAAJoNDGPgmEDAAJoNDGPgmEDAAJoNDGPgmEDAAJoNDGPgmEDAAKIZTQIKAaSQBwJxIJALIBEC6DxQeADEL+H0h/Q+CB6ORA/Hw1S8gBAAI0mZsqBFRB3E6lWAopxgYdAvHY0SMkDAAE02sygHCgMUrNGHAAIoNHETDmQH6RmjTgAEECjiXm0ZB42ACCARhMz5UBukJo14gBAADGO7jShGIBGInipZNZnBsTIxyggEQAE0GjJTBkQpGJCZoCaJTgarOQBgAAaTcyDr4072m4mEwAE0GhiHnxt3NF2M5kAIIBGE/NoyTxsAEAAjSZmyoD8EDFzRACAABpNzKMl87ABAAE0mphH28zDBgAE0FBOzKBFUklAzDpaMlMNsELDdEguQAMIoKGamEHjsVuAeDYQ72WALMMcCDfQYkyY2mPXxAJJaFjOhoYt71BLFAABNBQTsxQQHwBiVyjfGojPALHtMCiVB6p0toWGoTWU7woNY6mhlDAAAmioJWZtID4GxAZo4qA1wnuAuGCIt5cHot1cAA079HXWBtCw1h4qiQMggIZSYnYA4kNALIunDd3LANmtwT1aMhME3NCw6sXTRpaFhrnDUEggAAE0VBIzaFvSdgbiFuGEAfEJIFajsZvkh6jZDNCwOQENK0JAABr2kYM9kQAE0FBIzPlAvBiI2UjQowXEJ4E4YLRkxgAB0LDRIkEPGzQO8gdzQgEIoMGemCOh1SAjGXr5GCD76dqBmJmKbuIH4mggtqChvy2gdvBT0UxmaFishYYNqYARGheDtoQGCKDBvJ7ZHoh3kFgi4wL7oZHwmkz9wkDsB8TBQOxMJTcRA34xQIbLQAlwExC/JdMcUWj72JFKbvIA4oODLcEABNBgTcygKvAwA3UXqj+GthFPkZCAQ6EJ2I5h4CcS/kA7Y6CEvZqEhG0GxKvwdJzJAaANCaDhvGuDKdEABNBgTMygwXvQkBAthqd+Qdt9s/CoEQLiYiDOAWKeQVprfQHiKdBq/x0edWlAPJFGNckjBsgxC4PmnA+AABpsiRk063SAAXMcmdpgIRBnAfEPJDHQzFsREOcyDJ3ZL9A2q8lA3McAOUQGBjiAeBoQx9PY/gsMkGG7z4MhMAACaDAlZlA1vhmI3ehk33loMwKUCAqgJTYfw9AEn6Al8ARopgQ1QwzpZPcuIPaFNoMGFAAE0GBKzKAO2hI62wlKyExUHjUYSPARiP8x0H8fYQy0gzmgACCABlNiBiWqbQyINRejYGiA3UDsBc1EAwoAAmiwtZlBIwinGUZ3WwwVADobz5SB/CFDqgKAABpskyZvoe3Yn6PpZNCDn9C4ejtYHAQQQINxBvAsdERhFAxukAuNq0EDAAJosE5nzwXieaPpZdCCedA4GlQAIIAG83Q2aKwUNONlPJp2Bl3NCZoR/THYHAYQQIP9rDkFaIdQaDQNDQrwDtrhezAYHQcQQIN91Rwo0ECrx/6NpqMBB/+gcfFgsDoQIICGwnpm0AxT42haGnDQCI2LQQsAAmioHGkLWksLWgLpNZqmBgSAJrNAS2AHdWIBCKChdD6zALT9rDSatugK7kHbyR8Gu0MBAmgobWgFBWYIEH8fTV90A9+hYf5hKDgWIICG2lEDF4E4czSN0Q1kQsN8SACAABqKh8CANlbOGE1nNAczoGE9ZABAAA3VO01AOycOALH5aJqjCQDt3nZggOzMGTIAIICG8gU9MgyQ2SiR0bRHVfCGATLr+mSoORwggIbyKaCgheiMo2mP+gUcNGyHHAAIoKF8d3YeA2T982ADoA2e54D4GZT9DIpBAHQQoSSUBmEjhoE5wRQfEIaGbetQSxAAATRUmxmgMee7DIPnzrzrQLyRATKxAzrKgNhABZWCoKMAQBMS/kCsOUj8AxqKU2YYIkNyMAAQQEO1mVE4CBIyKMGCNo7qArEOEFdDO07/STTjJFSvDtSs1QwDP9MmAA3jIQUAAmgolszC0FJ5II8DAJ2QVMEAOdOYFsAEiDsYqHMCEbngM7R0fjtUEgZAAA3FkrlkABPyCyD2BmIXGiZkBqjZLlC7XgyQX3mhYT1kAEAADbWSWRRaKnMPgN2gTl0gA/2HrEBDkOuhnUV6g6/Q0vn1UEgcAAE01Erm0AFKyGsYIAc5DsTY6xOo3WsGwG5uaJgPCQAQQEMtMQcPgJ09QBwBxN8G0N/foG7oGSFhThYACKCh1MwANTGeMlD3rGViSuQIhsGzjhc0lLeCAbKSjV7gLxBLD4WmBkAADaWS2Z/OCRnURk5kGFwL0v9D3XSOjnYyQ8N+0AOAABpKiZme1d0LaGfv2yAMh29Qt70YpmFPNgAIoKHSzAAdBAiaGqbXbaygIbEdgzxMQKfXb6WTXb8ZINPu7wdzgAAE0FApmX3omJD3D4GEzAB143462cUKjYNBDQACaLCVzKBOngID5NR8EC0PpUEzYuJ0apOCLsc5M0QyOShcTjDQZ/XgS2i4PGCAHJgIoh9B6UHROQQIIHomZlCAS0ATqDxSQkXmcw1weKyGjl4MJQAa3RjoseBv0AT+ECmhI/Nf0KMjDRBAtEjMoKWNDmglqxyUzT7IEwZooc+1IZaYQZcZXR7kbvwJTdSP0Er2AwyI5bEUA4AAokVizgbiSQxDD4CWceowDE1whWHwLB8lBYDWTU+llmEAAUSLxflD9Vy4jTRqWqkwIO4XAd2jcocGVe7GIZqYqZpWAAKIFqMZgkM0MW+iolmgiYZKBshBgzcYIPd9LIeyQWIVDNSdANo0RMOcqmkFIIBGEzMEgMawT1HJLEUgPgrELQzYb68CibVC1ShSyc5TDIPoPr6BSisAAUSLxDwUmxnnqFT1M0NLYFMi1JpC1VKjhP7PQN8p7kGZVgACiBaJWWAIBiq1etSlRCZk5ARdNsj8QE9A1bQCEECjzQzqJQRQZ6+cDH1lDNSZ9BjxzQyAABptZlAvIagwkHfDKx9U70gsmamaVgACaLRkpl5CMBwgvUM5MVM1rQAE0FA+0WgUjAIUABBAtEjM74ZgOEhRwYzzA6SXmn6gN6BqWgEIIFok5vdDMFCpcUQWaGbvExn6PkH1jsTETNW0AhBAo4mZegkBNNbbSYa+LgbqjHFLjvTEDBBAo4mZuqVaNwPk3hViwWloYh5MfhiyiRkggEYTMwSADlihxlgvaCdzJJEJ+jRU7V8q2MvIMDCHxAyqtAIQQKOJGVFFm1HJrPtAbM2A/27pOVA196lkp9loM4OBASCARkczEMCPimaBSlt8EyGqVCqRaeF2egKqphWAABotmRGAmmdD2EMxufID6fYhWzIDBBAtdpqIQ6tQBQbUbVMgmm+QBy61tk3tIyKxHgRiJyrYNRS2TYGGHx8wYG6bAi2DfUktSwACiN67swUZ8G9oHeh1HdTY0GoPTczEACdooqYEDIYNre8Y8G9opUttDRBAg+2oAV4G7EcNgLb/S9PBfmocNUBMqUyt0pmeRw08hdqFXLLCStrPgyHxAATQUDnRKBqIF9HJLtDBKi50KJWpUTrvYaDf6fpxQLx0MCcSgAAaKomZnwFy9gIbnewj93guUkplSktneh7PBbrcEnTmyaC+Ug0ggIbKqjlQIO6lo32gMWIZKo9gUFOfDAP+cWxqg70MQ+BuQIAAGkpLQNfS0S5QKQS6eoGUE5bqKbCPFL1cULdJDNOwJxsABNBQOmwcdMsUaAE6PS/iJPawcXLayuS0nQfisPE/DJB1H4P+1imAABpKJTMoMA/R2U5QoukgYrSgngp21RORkDvonJAZoGE+JK5PAwigobbTZCCquxJoachF5bYyKeZwQd1QMkLCnCwAEEBD7eq0gbzQEtfVafsYqDc1jW1kYyCvThtSF1sCBNBQK5lBgTp5gOwGJSbQ1cAeNCiVcZnnAbVzoJZ3TmYYQje0AgTQULxuGHRwyD0GyNjzQAHYdcNdVE7MsNK5jGHgrxsGDcUpMQyhy+ABAmgoJmYQqAXihgF2w38G2k0j09JsYgEofJuHUqIACKChmpj5oG3noXp87mAH76Bt5U9DydEAATRUz80ABXLPaJqjGegZagkZBAACaKiWzCAAutcZtEVfbDTtURW8YoDskvk61BwOEEBD+UQj0M1ULKNpj+qABRq2Qw4ABNBQTcwcDJCF9KNtZuoDIWjYcgw1hwME0FBNzFMYhubW+qECjKBhPKQAQAANxcSczAC5DH0U0BYkQsN6yACAABpqHUDQNiHQwhf20bRGFwC6v8+OYYjcWAsQQENtCSjoFCD50TRGVwDa7we6rmLQT2sDBNBQaWaA3Ll0NCEPCJCHhv2gTysAATRUEnMDELuOpqsBA64MA798gCAACKCh0MzwAeINDAO/VmGkA1BCCQDiLYPVgQABNNgTM2h9AOjCRoHRtDQoAGgFHeiQxruD0XEAATSYmxmcDJA9eKMJefAAAWiccA5GxwEE0GBOzDOAWG80/Qw6oAeNm0EHAAJosCbmTCCOGU03gxbEQONoUAGAABqMbWbQWW+gnRxso2lmUAPQKUegnTAnBouDAAJosCVm0HJO0GyT9GhaGRIAdJgiaFb21WBwDEAADaZmBjMQLx9NyEMKSEPjjHkwOAYggAZTYg4HYgc62/mGYQjtPiYCvIX6iZ7AARp3Aw4AAmgwJeaVQLyNjvaBtvAbM0DGskEbZN8P4UT8HuoHZaifTtLR7m3QuBtwABBAg63NDNoKdYCB9muVQUNLhdBODAyAji4oAOJ8hoE9xoAUADoOYCIQT2BAPaUT1HnuB+IMGtt/DloyD4otVgABNBhHM0BXgB1jgJyeT23wnQEypLQYjxrQVRVFQJwHxDyDNBF/AeJJQNxHoEaJBeLpDLSZ5ACdmm8FxM8HS6AABNBgnc7WBuLDVC4hQQfHgA4dvEikemGo+iBo6TPQ+w3/QGutdQyQWThi2/r6UPVKVK4RbIH46mBKNAABNJjXZjhB22OsVGrXgUopck/nAZXWPtCE7cZAv/1xP4B4FzQBb6GgXS8ArY28qOCm31Bz9g22BAMQQIN9oRHoHo35FOj/B8SNQNzKQJ3L1mHtetAZcL1ALEsjfz8G4mIGyFUU1GqPglYdVjNAjs6lpOMP2k61aDAmFoAAGuzrmUGBVkmmXtCpPKC7SVqomJAZoIlrLY1HDE5C7aBmx+o/NCy8Gci/GbVysCZkEAAIoKGwOB90OGEStHojFpxlgGz12UVDdz0YombvgobNWRKbFknQuBi0ACCAhspOk4XQEoWYI6PmMUA2YT6gsZseDlGzYZnFDhpWhMAnaNgvHOyJBCCAhtJRA3uhEfAEhzxoJ3EaEKdCO04MdEgQQ9Fs5M5lKjTMfuJQ8wQa5nuHQgIBCKChdm4G6I5o0NjmRSwlGWioiJ7XiT0aomajg7nQsEOvDS5Cw/ryUEkcAAE0FA+BAa3UAh3wvRvK301GG3C0ZMbex0AOU3toWA8ZABBAQ/kUUNAkBugCdNC6gH8D5IbXDNQ/7w400jBQBxeCCjfQoiHQWXN/hlqCAAigoZyYBwMAHUpD7XUk56Cl5CggEQAEENNoEAy6tu2j0WAlDwAE0GhiHnxt2wejwUoeAAig0cRMGXg4RMwcEQAggEYT82jJPGwAQACNJubRNvOwAQABNJqYR0vmYQMAAmg0MVMGQOujqXnF2CeGIXQj6mADAAE0mpgHV0k6WipTAAACaDQxD6427mh7mQIAEECjiXm0ZB42ACCARhMz5eDhIDVrxAGAABpNzKMl87ABAAE0utCIciDOADmSALSDWwhKo2PYyjrQirj3WDBMHHQkwMvRICUPAATQaGIeBcMGAATQaDNjFAwbABBAo4l5FAwbABBAo4l5FAwbABBAo4l5FAwbABBAo4l5FAwbABBAo4l5FAwbABBAo4l5FAwbABBAo4l5FAwbABBAo4l5FAwbABBAo4l5FAwbABBAo4l5FAwbABBAo4l5FAwbABBAo4l5FAwbABBAo4l5FAwbABBAo4l5FAwbABBAo4l5FAwbABBAo4l5FAwbABBAo4l5FAwbABBgAGamLY/2B4K6AAAAAElFTkSuQmCC');\n        }\n    </style>\n    <ul id=\"menu\"> \n    </ul>\n    <style type=\"text/css\">\n        #menu {\n            border-width: 0px;\n            color: #b8bbc2;\n            font-size: 14px;\n            background-color: transparent;\n        }\n\n        #menu li a {\n            color: #b8bbc2;\n        }\n\n        #menu li {\n            border-bottom: 1px solid #4a4b51;\n            padding: 3px 0px;\n        }\n\n        #menu li.k-state-selected {\n            background-color: #0d1016;\n        }\n        \n        #menu li.k-state-selected a {\n            color: #ffffff;\n        }\n\n        #menu li.k-state-hover {\n            background: #212329;\n        }\n        .m_select {\n            display: none;\n        }\n\n        /* \u043E\u0442\u0441\u0442\u0443\u043F \u0442\u0435\u043A\u0441\u0442\u0430 \u0441\u043B\u0435\u0432\u0430 \u0432 \u043C\u0435\u043D\u044E */\n        .k-menu .k-item > .k-link {\n            padding: .5em 1.6em .4em;\n        }\n\n         \n    </style>\n    <div id=\"bottom_menu\">\n        <div id=\"subver_info\">\n            <div style=\"margin-left: 23px;\" id=\"subver_info_user\"></div>\n            <ul id=\"SubSystems\">\n                <li class=\"k-state-active\">\n                    <span class=\"k-link k-state-selected\"> \u0421\u0438\u0441\u0442\u0435\u043C\u0430: <span id=\"contextNormSys\"></span></span>\n                    <ul></ul>\n                </li>\n            </ul>\n            <ul id=\"Versions\">\n                <li class=\"k-state-active\">\n                    <span class=\"k-link k-state-selected\"> \u0412\u0435\u0440\u0441\u0438\u044F: <span id=\"contextNormVer\"></span></span>\n                    <ul></ul>\n                </li>\n            </ul>\n            <style type=\"text/css\">\n\n                #SubSystems, #Versions {\n                    border: 0px solid #698906;\n                }\n\n                    #SubSystems .k-state-hover,\n                    #SubSystems .k-state-hover:hover,\n                    #Versions .k-state-hover:hover,\n                    #Versions .k-state-hover {\n                        background-color: #000000;\n                        background-image: none,linear-gradient(to bottom,#000000 0,#000000 100%);\n                    }\n\n                    #SubSystems .k-state-selected,\n                    #SubSystems .k-header,\n                    #Versions .k-header,\n                    #Versions .k-state-selected {\n                        color: #ffffff;\n                        background-color: #666666;\n                    }\n\n                    #SubSystems .k-state-focused,\n                    #Versions .k-state-focused {\n                        box-shadow: none;\n                    }\n\n                    #SubSystems .k-header,\n                    #Versions .k-header {\n                        padding-left: 23px;\n                        border-bottom: 0px;\n                    }\n\n                    #SubSystems .k-panel > .k-item > .k-link,\n                    #Versions .k-panel > .k-item > .k-link {\n                        padding: 0 3em;\n                    }\n\n                    #SubSystems .k-panel > li.k-item,\n                    #Versions .k-panel > li.k-item {\n                        background-color: #292626;\n                    }\n\n                    #SubSystems ul,\n                    #Versions ul {\n                        border-bottom: 0px;\n                    }\n\n                    #SubSystems .k-i-arrow-s,\n                    #Versions .k-i-arrow-s {\n                        background-position: -16px -32px;\n                    }\n            </style>\n        </div>\n        <div id=\"exit\">\u0412\u044B\u0445\u043E\u0434</div>\n        <div id=\"hide_menu\">&#9668;&nbsp; \u0421\u043A\u0440\u044B\u0442\u044C \u043F\u0430\u043D\u0435\u043B\u044C</div>\n        <div id=\"show_menu\">&#9658; \u041F\u043E\u043A\u0430\u0437\u0430\u0442\u044C \u043F\u0430\u043D\u0435\u043B\u044C</div>\n    </div>\n    <style type=\"text/css\">\n        #bottom_menu {\n            position: absolute;\n            width: 100%;\n            bottom: 30px;\n        }\n\n        #subver_info {\n            background-color: #4D4D4D;\n            padding-top: 3px;\n            margin-top: 39px;\n            text-align: left;\n            line-height: 27px;\n            color: #D8D8D8;\n            font-size: 13px;\n        }\n\n        #exit {\n            color: #E2E1E1;\n            font-size: 12px;\n            padding: 6px 0px 6px 23px;\n            background-color: #666666;\n            cursor: pointer;\n        }\n\n        #exit:hover {\n            background-color: #000000;\n        }\n\n        #show_menu {\n            position: absolute;\n            left: 253px;\n            width: 150px;\n            color: rgb(184, 184, 184);\n            bottom: -30px;\n            font-size: 13px;\n            display: none;\n            cursor: pointer;\n            z-index: 9999;\n            background-color: white;\n            padding: 3px;\n        }\n\n        #show_menu:hover {\n            color: #000000;\n        }\n\n        #hide_menu {\n            color: #E2E1E1;\n            font-size: 12px;\n            padding: 6px 0px 6px 5px;\n            background-color: #4D4D4D;\n            cursor: pointer;\n        }\n\n        #hide_menu:hover {\n            background-color: #000000;\n        }\n    </style>\n</div>\n<style type=\"text/css\">\n\n    #content_cont {\n        width: 100%;\n        height: 100%;\n        position: absolute;\n    }\n\n    #content {\n        position: absolute;\n        left: 209px;\n        font-size: 12px;\n        top: 75px;\n        bottom: 0px;\n        right: 0px;\n    }\n\n    #titlePage {\n        margin: 27px 0px 0px 235px;\n        position: absolute;\n        font-size: 19px;\n        color: rgb(51, 51, 51);\n    }\n\n    #main_menu_block {\n        background-color: #35373d;\n        width: 210px;\n        position: absolute;\n        height: 100%;\n        top: 0px;\n        bottom: 0px;\n    }\n\n    .s-Ownership-c, .s-Ownership-c-i {\n        position: absolute;\n        cursor: pointer;\n        width: 0px;\n        height: 0px;\n    }\n\n    .s-Ownership-c-i {\n        margin-top: -2px;\n    }\n\n    .s-Ownership-green, .s-Ownership-green-i { \n        position: absolute;\n        width: 0px;\n        height: 0px;\n        border: 6px solid transparent;\n        border-left: 4px solid rgb(188, 215, 104);\n        border-top: 4px solid rgb(188, 215, 104);\n        margin: -5px 0px 0px -8px;\n    }\n\n    .s-Ownership-green-red-i {\n        position: absolute;\n        width: 0px;\n        height: 0px;\n        border: 6px solid transparent;\n        border-left: 4px solid rgb(188, 215, 104);\n        border-top: 4px solid rgb(255, 197, 112);\n        margin: -5px 0px 0px -8px;\n    }\n\n    .s-Ownership-red, .s-Ownership-red-i {\n        position: absolute;\n        width: 0px;\n        height: 0px;\n        border: 6px solid transparent;\n        border-left: 4px solid rgb(255, 197, 112);\n        border-top: 4px solid rgb(255, 197, 112);\n        margin: -5px 0px 0px -8px;\n    }\n\n    .pSimpleTable-name {\n        cursor: pointer;\n        margin-left: 5px;\n    }\n  \n    #top_border {\n        z-index: 1;\n        top: 75px;\n        position: absolute;\n        width: 100%;\n        border-top:1px solid #c7c7c7;    \n    }\n    \n\n</style>\n";
}
var pBodyMenu = (function () {
    function pBodyMenu() {
    }
    pBodyMenu.Initialize = function () {
        $("body").html(this.template);
        var menu_list = [
            ["DataTypes", "Типы данных"],
            ["Structure", "Таблицы"],
            ["View", "Представления"],
            ["Procedures", "Процедуры"],
            ["Sequence", "Последовательности"],
            ["Class", "Классы"],
            ["Orders", "Текущие заявки"],
            ["ArhOrders", "Архив заявок"],
            ["Search", "Поиск по базе"],
            ["Wiki", "Вики ПСиT"],
        ];
        for (var t = 0; t < menu_list.length; t++)
            if (menu_list[t][0] == "Class")
                menu_list.splice(t, 1);
        $("body").html(this.template);
        for (var t = 0; t < menu_list.length; t++) {
            $("#menu").append('<li><a><span class="m_select">' +
                menu_list[t][0] +
                '</span><span class="id">' +
                menu_list[t][1] +
                '</span></a></li>');
        }
        ;
        $("#menu").kendoMenu({
            orientation: "vertical",
            select: function (e) {
                $("#menu").find(".k-state-selected").removeClass("k-state-selected");
                $(e.item).addClass("k-state-selected");
                pBodyMenu.setTitlePage($(e.item).find(".id").text());
                PageControl.ShowPage($(e.item).find(".m_select").text());
            }
        });
        pBodyMenu.subver_info_template = $("#subver_info").html();
        pBodyMenu.updateSubVerMenu();
        $(document).on('change', '.show_hoz_ch', function () {
            if (this.checked) {
                $.cookie('devSys_hozObjects', 'false', { expires: 5, path: '/', });
                PageControl.restoreOldUrl();
            }
            else {
                $.cookie('devSys_hozObjects', 'true', { expires: 5, path: '/', });
                PageControl.restoreOldUrl();
            }
        });
        $("#exit").bind("click", function () {
            PageControl.ShowPage('LoginForm');
        });
        $("#hide_menu").on('click', function () {
            $("#main_menu_block").animate({
                left: "-250px"
            }, 1000);
            $("#content").animate({
                left: "0px"
            }, 1000);
            $("#titlePage").animate({
                marginLeft: "30px"
            }, 1000, function () {
                $("#show_menu").show();
            });
        });
        $("#show_menu").on('click', function () {
            $("#show_menu").hide();
            $("#main_menu_block").animate({
                left: "0px"
            }, 1000);
            $("#content").animate({
                left: "209px"
            }, 1000);
            $("#titlePage").animate({
                marginLeft: "235px"
            }, 1000, function () {
            });
        });
        if (MainConfig.isDeveloper === '1') {
        }
        else {
        }
        pBodyMenu.selectMenu('Structure');
        PageControl.changeUrl();
    };
    pBodyMenu.selectMenu = function (name) {
        $('#menu a.k-link').each(function () {
            var txt = $(this).find('.m_select').html();
            if ($.trim(txt) == $.trim(name))
                $(this).click();
        });
    };
    pBodyMenu.disableMenu = function (param) {
        $("#menu").find("li").each(function () {
            if ($(this).find(".m_select").html() === param) {
                $(this).addClass('dis_menu');
            }
        });
        $("#menu").data("kendoMenu").enable(".dis_menu", false);
    };
    pBodyMenu.updateSubVerMenu = function () {
        pLoginForm.setLoginCookie(MainConfig.contextSys, MainConfig.contextVer, MainConfig.contextPass, MainConfig.contextLogin, MainConfig.contextNormVer, MainConfig.contextNormSys);
        $("#subver_info").html(pBodyMenu.subver_info_template);
        $("#subver_info_user").html("\u041F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044C: " + MainConfig.contextLogin);
        if (MainConfig.contextLogin !== 'SOMEONE')
            $("#subver_info_user").after("<div style=\"margin-left: 19px;\" id=\"show_hoz\"><input type=\"checkbox\" class=\"show_hoz_ch\" > \u0445\u043E\u0437\u044F\u0439\u0441\u0442\u0432\u043E\u0432\u0430\u043D\u0438\u0435</div>");
        if (MainConfig.hozObjects)
            $(".show_hoz_ch").prop('checked', false);
        else
            $(".show_hoz_ch").prop('checked', true);
        $("#contextNormSys").html(MainConfig.contextNormSys);
        $("#contextNormVer").html(MainConfig.contextNormVer);
        var SubSystems = '';
        for (var i in MainConfig.SubSystems)
            SubSystems += "<li>" + MainConfig.SubSystems[i]['ID'] + "</li>";
        $("#SubSystems").find("ul").html(SubSystems);
        var Versions = '';
        for (var i in MainConfig.Versions)
            if (MainConfig.Versions[i]['SubMask'] == MainConfig.contextSys)
                Versions += "<li>" + MainConfig.Versions[i]['ID'] + "</li>";
        $("#Versions").find("ul").html(Versions);
        var SubSystemslink = $("#SubSystems").kendoPanelBar({
            select: function (e) {
                var selectval = $(e.item).find("> .k-link").text();
                if (selectval.indexOf('Система') == -1) {
                    $("#SubSystems .k-header").html('Система: ' + selectval + '<span class="k-icon k-i-arrow-s k-panelbar-expand"></span>');
                    SubSystemslink.collapse($("li"), true);
                    for (var i in MainConfig.SubSystems) {
                        if (selectval === MainConfig.SubSystems[i]['ID']) {
                            MainConfig.contextSys = MainConfig.SubSystems[i]['SubMask'];
                            MainConfig.contextVer = MainConfig.SubSystems[i]['SubMask'];
                            MainConfig.contextNormSys = MainConfig.SubSystems[i]['ID'];
                            MainConfig.contextNormVer = 'Текущая';
                            DataBaseControl.SendRequest(XMLquery.getSchemaList(), function (a) { });
                            setTimeout(function () {
                                pBodyMenu.updateSubVerMenu();
                            }, 200);
                            QueryCache.storage.getSchemaList.update = true;
                            PageControl.pageUpdate();
                        }
                    }
                }
            }
        }).data("kendoPanelBar");
        SubSystemslink.collapse(SubSystemslink.select(), false);
        var VerSystemslink = $("#Versions").kendoPanelBar({
            select: function (e) {
                var selectval = $(e.item).find("> .k-link").text();
                if (selectval.indexOf('Версия') == -1) {
                    $("#Versions .k-header").html('Версия: ' + selectval + '<span class="k-icon k-i-arrow-s k-panelbar-expand"></span>');
                    VerSystemslink.collapse($("li"), true);
                    for (var i in MainConfig.Versions) {
                        if ((selectval === MainConfig.Versions[i]['ID']) && (MainConfig.contextSys === MainConfig.Versions[i]['SubMask'])) {
                            MainConfig.contextVer = MainConfig.Versions[i]['VerMask'];
                            MainConfig.contextNormVer = MainConfig.Versions[i]['ID'];
                            DataBaseControl.SendRequest(XMLquery.getSchemaList(), function (a) { });
                            setTimeout(function () {
                                pBodyMenu.updateSubVerMenu();
                            }, 200);
                            QueryCache.storage.getSchemaList.update = true;
                            PageControl.pageUpdate();
                        }
                    }
                }
            }
        }).data("kendoPanelBar");
        VerSystemslink.collapse(VerSystemslink.select(), false);
    };
    pBodyMenu.setTitlePage = function (text) {
        $('#titlePage').html(text.toUpperCase());
    };
    pBodyMenu.template = hBodyMenu;
    return pBodyMenu;
}());
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var pClass = (function (_super) {
    __extends(pClass, _super);
    function pClass() {
        _super.apply(this, arguments);
    }
    pClass.Initialize = function () {
        var top_tab_select_name = "";
        var top_tab_select = false;
        var select_arr = [];
        $("#content").html("\n                 <style>\n                   #splitter,\n                   #grid\n                   {\n                     margin: 0;\n                     padding: 0;\n                     border-width: 0;\n                     height: 100%; /* DO NOT USE !important for setting the Grid height! */\n                   }\n                 </style>\n                 <div id=\"splitter\">\n                   <div id=\"left-pane\">                    \n                     <div id=\"grid\"></div>\n                   </div>\n                   <div id=\"right-pane\">\n                     <div id=\"pSimpleTable\"></div>\n                   </div>\n                 </div>\n            ");
        gSuperPage.constructSimpleTable("TABLE", true);
        DataBaseControl.SendRequest(XMLquery.getClassList(), function (xmlq) {
            var DSviewSchemaList = ATools.DataSourceFromXml(xmlq, "ObjectRefs ObjectRef");
            DSviewSchemaList = ATools.DataSourceFilter(DSviewSchemaList, "ObjectType=CLASS");
            $("#grid").kendoGrid({
                dataSource: DSviewSchemaList,
                resizable: true,
                filterable: { mode: "row" },
                selectable: "multiple",
                change: function (arg) {
                    $('#pSimpleTable .k-minus').trigger("click");
                    var selected = $.map(this.select(), function (item) {
                        return $(item).find(".pSimpleTable-name").text();
                    });
                    var ClassID = selected[0];
                    DataBaseControl.SendRequest(XMLquery.getTabsByClassID(ClassID), function (xmlData2) {
                        var DSviewSchemaList = ATools.DataSourceFromXml(xmlData2, "ObjectRefs ObjectRef");
                        function isSelected(currName) {
                            var flag = false;
                            for (var i = 0; i < DSviewSchemaList.length; i++) {
                                if (currName == DSviewSchemaList[i]['ID']) {
                                    flag = true;
                                    break;
                                }
                            }
                            return flag;
                        }
                        if (top_tab_select_name != ClassID) {
                            $('#pSimpleTable .k-master-row').each(function () {
                                var p = $(this);
                                p.removeClass('displayNone2');
                                var currName = p.find('.pSimpleTable-name').text();
                                var flag = isSelected(currName);
                                if (!flag)
                                    p.addClass('displayNone2');
                            });
                            top_tab_select_name = ClassID;
                        }
                        else {
                            $('#pSimpleTable .k-master-row').each(function () {
                                var p = $(this);
                                p.removeClass('displayNone2');
                            });
                            $('#grid .k-master-row').removeClass('k-state-selected');
                            top_tab_select_name = "";
                        }
                    });
                },
                scrollable: true,
                detailExpand: function (e) {
                    gSuperPage.closeOpenRowTable(this, e, 'grid');
                    var ClassID = ($(e.masterRow[0]).find(".pSimpleTable-name").html());
                },
                detailTemplate: kendo.template("<div class=\"tabstrip\">\n                                                        <ul><li class=\"k-state-active\">\u0422\u0435\u043A\u0441\u0442</li></ul>\n                                                        <div class=\"structTabs\"><div class=\"tab_object\"></div></div>\n                                                        </div>"),
                detailInit: function (e) {
                    var detailRow = e.detailRow;
                    detailRow.find(".tab_object").html("<div id=\"body_" + e.data['ID'] + "\"></div>");
                    detailRow.find(".tabstrip").kendoTabStrip({
                        animation: {
                            open: {
                                duration: 1, effects: "fadeIn"
                            }
                        }
                    });
                    DataBaseControl.SendRequest(XMLquery.getClassByID(e.data['ID']), function (xmlData) {
                        var IdBodyTag = 'body_' + e.data['ID'];
                        $("#" + IdBodyTag).html("<div id='" + IdBodyTag + "_FullText'></div><div id='" + IdBodyTag + "_tab'></div>");
                        $("#" + IdBodyTag + "_FullText").html("\u041E\u043F\u0438\u0441\u0430\u043D\u0438\u0435: " + ATools.getXmlVal(xmlData, 'Class > Name') + "<br><br>");
                        $("#" + IdBodyTag + "_tab").kendoGrid({
                            dataSource: {
                                data: xmlData,
                                schema: {
                                    type: 'xml',
                                    data: '/UCMsg/RequestHead/Requests/Request/Subject/Object/Class/Attributes/Attribute',
                                    model: {
                                        fields: {
                                            ID: '@ID',
                                            Name: 'Name/text()',
                                            ShortName: 'ShortName/text()',
                                            ClassID: 'ClassID/text()',
                                            PrntID: 'PrntID/text()',
                                            Expression: 'Expression/text()'
                                        }
                                    }
                                }
                            },
                            scrollable: false,
                            columns: [
                                { field: "ID", title: 'ID', format: "{0:c}", width: "90px" },
                                { field: "Name", title: 'Имя', format: "{0:c}", width: "130px" },
                                { field: "ShortName", title: 'Короткое имя', format: "{0:c}", width: "100px" },
                                { field: "ClassID", title: 'ID Класса', format: "{0:c}", width: "70px" },
                                { field: "PrntID", title: 'PrntID', format: "{0:c}", width: "60px" },
                                { field: "Expression", title: 'Expression', format: "{0:c}" }
                            ]
                        });
                    });
                },
                columns: [
                    {
                        field: "ID",
                        title: "ID",
                        width: "190px",
                        filterable: {
                            cell: {
                                operator: "contains"
                            }
                        },
                        template: "<div class='pSimpleTable-name'>#: ID #</div>"
                    },
                    {
                        field: "Name",
                        title: "Имя",
                        filterable: {
                            cell: {
                                operator: "contains"
                            }
                        }
                    }
                ]
            });
            $("#grid").on('click', '.k-master-row td .pSimpleTable-name', function () {
                $(this).parent().parent().find(".k-icon").trigger('click');
            });
            $("#grid").on('click', '.DevSysSelectRow ~ .k-detail-row > td:eq(0)', function () {
                $(this).parent().prev().find(".k-icon").trigger('click');
            });
            $("#splitter").kendoSplitter({
                orientation: "vertical",
                panes: [{ size: "200" }, {}]
            });
        });
    };
    pClass.getBody = function (xmlData, IdBodyTag, otherTabStrip) {
        $("#" + IdBodyTag).html("<div id='" + IdBodyTag + "_FullText'></div><div id='" + IdBodyTag + "_tab'></div>");
        $("#" + IdBodyTag + "_FullText").html("\u041F\u043E\u0434\u0440\u043E\u0431\u043D\u043E\u0435 \u043E\u043F\u0438\u0441\u0430\u043D\u0438\u0435: " + ATools.editText(ATools.getXmlVal(xmlData, 'Table > FullText'), ATools.getXmlVal(xmlData, 'TableID'), 'TABLE', 'FullText', '0') + "\n            <br><br>");
        $("#" + IdBodyTag + "_tab").kendoGrid({
            dataSource: {
                data: xmlData,
                schema: {
                    type: 'xml',
                    data: '/UCMsg/RequestHead/Requests/Request/Subject/Object/Table/Fields/Field',
                    model: {
                        fields: {
                            ID: '@ID',
                            Type: 'Type/text()',
                            Position: 'Position/text()',
                            Nullable: 'Nullable/text()',
                            BriefText: 'BriefText/text()',
                            FullText: 'FullText/text()',
                            DefVal: 'DefVal/text()',
                        }
                    }
                }
            },
            scrollable: false,
            columns: [
                { field: "ID", title: 'Поле', format: "{0:c}", width: "90px" },
                { field: "Type", title: 'Тип', format: "{0:c}", width: "130px" },
                { field: "Nullable", title: 'Nullable', format: "{0:c}", width: "100px" },
                { field: "DefVal", title: 'Default', format: "{0:c}", width: "70px" },
                {
                    field: "BriefText", title: "Кратко", width: "210px",
                    template: "<span class='s-edit-text' ID='#: ID #' ObjectType='FIELD' TextType='BriefText' RequestID='0' ><div></div>#: ATools.changeTextFix(BriefText) #</span>"
                },
                {
                    field: "FullText", title: 'Подробно',
                    template: "<span class='s-edit-text' ID='#: ID #' ObjectType='FIELD' TextType='FullText'  RequestID='0' ><div></div>#: ATools.changeTextFix(FullText)  #</span>"
                }
            ]
        });
        var result = '';
        var err = 0;
        var Indexes = ATools.DataSourceFromXml(xmlData, "Object > Table > Indexes > Index");
        if (Indexes.length > 0) {
            result += '<div class="br1" />Индексы:<ul>';
            for (var i in Indexes) {
                Indexes[i].Uniqueness = ATools.getXmlVal(Indexes[i].html, "Uniqueness");
                Indexes[i].TableID = ATools.getXmlVal(Indexes[i].html, "TableID");
                Indexes[i].Fields = gSuperPage.getFieldsListID(ATools.getXmlVal(Indexes[i].html, "Fields"));
                result += '<li>';
                result += (Indexes[i].Uniqueness == 1) ? "<b style=color:#f35800;>Unique</b> " : "";
                result += Indexes[i].ID;
                result += " (" + Indexes[i].Fields + ')';
                result += '</li>';
            }
            result += '</ul>';
        }
        else {
            err++;
        }
        var Constraints = ATools.DataSourceFromXml(xmlData, "Object > Table > Constraints > Constraint");
        if (Constraints.length > 0) {
            result += '<div class="br1" />Констрейты:<ul>';
            for (var i in Constraints) {
                Constraints[i].Validate = ATools.getXmlVal(Constraints[i].html, "Validate");
                Constraints[i].Type = ATools.getXmlVal(Constraints[i].html, "Type");
                Constraints[i].Condition = ATools.getXmlVal(Constraints[i].html, "Condition");
                Constraints[i].Fields = gSuperPage.getFieldsListID(ATools.getXmlVal(Constraints[i].html, "Fields"));
                result += '<li>';
                result += Constraints[i].ID;
                result += ' [';
                result += Constraints[i].Type;
                result += (Constraints[i].Condition.length > 0) ? ' (' + Constraints[i].Condition + ')' : '';
                result += '] ';
                result += Constraints[i].Validate;
                result += " (" + Constraints[i].Fields + ')';
                result += '</li>';
            }
            result += '</ul>';
        }
        else {
            err++;
        }
        if (result == "")
            result = "Таблица не содержит индексов и констрейнтов.";
        otherTabStrip.insertAfter({ text: "Индексы и констрейнты", content: result }, otherTabStrip.tabGroup.children("li:first"));
        LoadEventManager.execEvent("load_pSimpleTable_obj");
    };
    return pClass;
}(gSuperPage));
var pDataTypes = (function () {
    function pDataTypes() {
    }
    pDataTypes.LoadTypes = function () {
        pDataTypes.allTypes = ATools.DataSourceFromXml(QueryCache.storage.DataTypes.xml, "DataTypes DataType");
    };
    pDataTypes.Initialize = function () {
        $("#content").html(this.template);
        $("#pSimpleTable").kendoGrid({
            dataSource: pDataTypes.allTypes,
            scrollable: true,
            sortable: true,
            resizable: true,
            filterable: { mode: "row" },
            columns: [
                { field: "ID", title: "Тип UC", format: "{0:c}", width: "170px" },
                { field: "BaseType", title: "Базовый тип", format: "{0:c}", width: "170px" },
                { field: "Size", title: "Oracle", format: "{0:c}", width: "170px" },
                { field: "OracleType", title: "Размер", type: "number", width: "170px" },
                { field: "BriefText", title: "Комментарий" }
            ]
        });
        ATools.resize("#DataTypes");
    };
    pDataTypes.template = '<div id="pSimpleTable"></div>';
    return pDataTypes;
}());
{
    var hLoginForm = "\n<div id=\"loginCont\">\n    <div id=\"login_form\">\n        <div id=\"title\">\u0412\u0445\u043E\u0434</div>\n        <input type=\"text\" value=\"\" placeholder=\"\u041B\u043E\u0433\u0438\u043D\" id=\"login_inp\" class=\"selectIndex k-textbox\" />\n        <input type=\"password\" value=\"\" placeholder=\"\u041F\u0430\u0440\u043E\u043B\u044C\" id=\"passw_inp\" class=\"selectIndex k-textbox\" />\n        <input id=\"SysSelect\" />\n        <input id=\"VerSelect\" />\n        <button id=\"auth\" class=\"k-primary k-button\" onclick=\"pLoginForm.authorization()\"> \u0412\u043E\u0439\u0442\u0438 </button>\n    </div>\n</div>\n<div id=\"Logo\"><div></div><span>DEV-SYSTEM</span></div> \n\n<style type=\"text/css\">\n    #Logo {\n        height: 75px;\n        background-color: #637879;\n        display: block;\n        color: #ffffff;\n        width: 100%;\n        position: absolute;\n    }\n\n    #Logo div {\n        position: absolute;\n        display: block;\n        margin: 18px 0px 0px 10px;\n        width: 40px;\n        height: 40px;\n        background-size: cover;\n        background-image: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALMAAACrCAYAAAAtka0FAAAABGdBTUEAAK/INwWK6QAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAABH+SURBVHjaYvz//z/DKBgFwwEABBDTaBCMguECAAJoNDGPgmEDAAJoNDGPgmEDAAJoNDGPgmEDAAJoNDGPgmEDAAJoNDGPgmEDAAJoNDGPgmEDAAJoNDGPgmEDAAJoNDGPgmEDAAJoNDGPgmEDAAJoNDGPgmEDAAKIZTQIKAaSQBwJxIJALIBEC6DxQeADEL+H0h/Q+CB6ORA/Hw1S8gBAAI0mZsqBFRB3E6lWAopxgYdAvHY0SMkDAAE02sygHCgMUrNGHAAIoNHETDmQH6RmjTgAEECjiXm0ZB42ACCARhMz5UBukJo14gBAADGO7jShGIBGInipZNZnBsTIxyggEQAE0GjJTBkQpGJCZoCaJTgarOQBgAAaTcyDr4072m4mEwAE0GhiHnxt3NF2M5kAIIBGE/NoyTxsAEAAjSZmyoD8EDFzRACAABpNzKMl87ABAAE0mphH28zDBgAE0FBOzKBFUklAzDpaMlMNsELDdEguQAMIoKGamEHjsVuAeDYQ72WALMMcCDfQYkyY2mPXxAJJaFjOhoYt71BLFAABNBQTsxQQHwBiVyjfGojPALHtMCiVB6p0toWGoTWU7woNY6mhlDAAAmioJWZtID4GxAZo4qA1wnuAuGCIt5cHot1cAA079HXWBtCw1h4qiQMggIZSYnYA4kNALIunDd3LANmtwT1aMhME3NCw6sXTRpaFhrnDUEggAAE0VBIzaFvSdgbiFuGEAfEJIFajsZvkh6jZDNCwOQENK0JAABr2kYM9kQAE0FBIzPlAvBiI2UjQowXEJ4E4YLRkxgAB0LDRIkEPGzQO8gdzQgEIoMGemCOh1SAjGXr5GCD76dqBmJmKbuIH4mggtqChvy2gdvBT0UxmaFishYYNqYARGheDtoQGCKDBvJ7ZHoh3kFgi4wL7oZHwmkz9wkDsB8TBQOxMJTcRA34xQIbLQAlwExC/JdMcUWj72JFKbvIA4oODLcEABNBgTcygKvAwA3UXqj+GthFPkZCAQ6EJ2I5h4CcS/kA7Y6CEvZqEhG0GxKvwdJzJAaANCaDhvGuDKdEABNBgTMygwXvQkBAthqd+Qdt9s/CoEQLiYiDOAWKeQVprfQHiKdBq/x0edWlAPJFGNckjBsgxC4PmnA+AABpsiRk063SAAXMcmdpgIRBnAfEPJDHQzFsREOcyDJ3ZL9A2q8lA3McAOUQGBjiAeBoQx9PY/gsMkGG7z4MhMAACaDAlZlA1vhmI3ehk33loMwKUCAqgJTYfw9AEn6Al8ARopgQ1QwzpZPcuIPaFNoMGFAAE0GBKzKAO2hI62wlKyExUHjUYSPARiP8x0H8fYQy0gzmgACCABlNiBiWqbQyINRejYGiA3UDsBc1EAwoAAmiwtZlBIwinGUZ3WwwVADobz5SB/CFDqgKAABpskyZvoe3Yn6PpZNCDn9C4ejtYHAQQQINxBvAsdERhFAxukAuNq0EDAAJosE5nzwXieaPpZdCCedA4GlQAIIAG83Q2aKwUNONlPJp2Bl3NCZoR/THYHAYQQIP9rDkFaIdQaDQNDQrwDtrhezAYHQcQQIN91Rwo0ECrx/6NpqMBB/+gcfFgsDoQIICGwnpm0AxT42haGnDQCI2LQQsAAmioHGkLWksLWgLpNZqmBgSAJrNAS2AHdWIBCKChdD6zALT9rDSatugK7kHbyR8Gu0MBAmgobWgFBWYIEH8fTV90A9+hYf5hKDgWIICG2lEDF4E4czSN0Q1kQsN8SACAABqKh8CANlbOGE1nNAczoGE9ZABAAA3VO01AOycOALH5aJqjCQDt3nZggOzMGTIAIICG8gU9MgyQ2SiR0bRHVfCGATLr+mSoORwggIbyKaCgheiMo2mP+gUcNGyHHAAIoKF8d3YeA2T982ADoA2e54D4GZT9DIpBAHQQoSSUBmEjhoE5wRQfEIaGbetQSxAAATRUmxmgMee7DIPnzrzrQLyRATKxAzrKgNhABZWCoKMAQBMS/kCsOUj8AxqKU2YYIkNyMAAQQEO1mVE4CBIyKMGCNo7qArEOEFdDO07/STTjJFSvDtSs1QwDP9MmAA3jIQUAAmgolszC0FJ5II8DAJ2QVMEAOdOYFsAEiDsYqHMCEbngM7R0fjtUEgZAAA3FkrlkABPyCyD2BmIXGiZkBqjZLlC7XgyQX3mhYT1kAEAADbWSWRRaKnMPgN2gTl0gA/2HrEBDkOuhnUV6g6/Q0vn1UEgcAAE01Erm0AFKyGsYIAc5DsTY6xOo3WsGwG5uaJgPCQAQQEMtMQcPgJ09QBwBxN8G0N/foG7oGSFhThYACKCh1MwANTGeMlD3rGViSuQIhsGzjhc0lLeCAbKSjV7gLxBLD4WmBkAADaWS2Z/OCRnURk5kGFwL0v9D3XSOjnYyQ8N+0AOAABpKiZme1d0LaGfv2yAMh29Qt70YpmFPNgAIoKHSzAAdBAiaGqbXbaygIbEdgzxMQKfXb6WTXb8ZINPu7wdzgAAE0FApmX3omJD3D4GEzAB143462cUKjYNBDQACaLCVzKBOngID5NR8EC0PpUEzYuJ0apOCLsc5M0QyOShcTjDQZ/XgS2i4PGCAHJgIoh9B6UHROQQIIHomZlCAS0ATqDxSQkXmcw1weKyGjl4MJQAa3RjoseBv0AT+ECmhI/Nf0KMjDRBAtEjMoKWNDmglqxyUzT7IEwZooc+1IZaYQZcZXR7kbvwJTdSP0Er2AwyI5bEUA4AAokVizgbiSQxDD4CWceowDE1whWHwLB8lBYDWTU+llmEAAUSLxflD9Vy4jTRqWqkwIO4XAd2jcocGVe7GIZqYqZpWAAKIFqMZgkM0MW+iolmgiYZKBshBgzcYIPd9LIeyQWIVDNSdANo0RMOcqmkFIIBGEzMEgMawT1HJLEUgPgrELQzYb68CibVC1ShSyc5TDIPoPr6BSisAAUSLxDwUmxnnqFT1M0NLYFMi1JpC1VKjhP7PQN8p7kGZVgACiBaJWWAIBiq1etSlRCZk5ARdNsj8QE9A1bQCEECjzQzqJQRQZ6+cDH1lDNSZ9BjxzQyAABptZlAvIagwkHfDKx9U70gsmamaVgACaLRkpl5CMBwgvUM5MVM1rQAE0FA+0WgUjAIUABBAtEjM74ZgOEhRwYzzA6SXmn6gN6BqWgEIIFok5vdDMFCpcUQWaGbvExn6PkH1jsTETNW0AhBAo4mZegkBNNbbSYa+LgbqjHFLjvTEDBBAo4mZuqVaNwPk3hViwWloYh5MfhiyiRkggEYTMwSADlihxlgvaCdzJJEJ+jRU7V8q2MvIMDCHxAyqtAIQQKOJGVFFm1HJrPtAbM2A/27pOVA196lkp9loM4OBASCARkczEMCPimaBSlt8EyGqVCqRaeF2egKqphWAABotmRGAmmdD2EMxufID6fYhWzIDBBAtdpqIQ6tQBQbUbVMgmm+QBy61tk3tIyKxHgRiJyrYNRS2TYGGHx8wYG6bAi2DfUktSwACiN67swUZ8G9oHeh1HdTY0GoPTczEACdooqYEDIYNre8Y8G9opUttDRBAg+2oAV4G7EcNgLb/S9PBfmocNUBMqUyt0pmeRw08hdqFXLLCStrPgyHxAATQUDnRKBqIF9HJLtDBKi50KJWpUTrvYaDf6fpxQLx0MCcSgAAaKomZnwFy9gIbnewj93guUkplSktneh7PBbrcEnTmyaC+Ug0ggIbKqjlQIO6lo32gMWIZKo9gUFOfDAP+cWxqg70MQ+BuQIAAGkpLQNfS0S5QKQS6eoGUE5bqKbCPFL1cULdJDNOwJxsABNBQOmwcdMsUaAE6PS/iJPawcXLayuS0nQfisPE/DJB1H4P+1imAABpKJTMoMA/R2U5QoukgYrSgngp21RORkDvonJAZoGE+JK5PAwigobbTZCCquxJoachF5bYyKeZwQd1QMkLCnCwAEEBD7eq0gbzQEtfVafsYqDc1jW1kYyCvThtSF1sCBNBQK5lBgTp5gOwGJSbQ1cAeNCiVcZnnAbVzoJZ3TmYYQje0AgTQULxuGHRwyD0GyNjzQAHYdcNdVE7MsNK5jGHgrxsGDcUpMQyhy+ABAmgoJmYQqAXihgF2w38G2k0j09JsYgEofJuHUqIACKChmpj5oG3noXp87mAH76Bt5U9DydEAATRUz80ABXLPaJqjGegZagkZBAACaKiWzCAAutcZtEVfbDTtURW8YoDskvk61BwOEEBD+UQj0M1ULKNpj+qABRq2Qw4ABNBQTcwcDJCF9KNtZuoDIWjYcgw1hwME0FBNzFMYhubW+qECjKBhPKQAQAANxcSczAC5DH0U0BYkQsN6yACAABpqHUDQNiHQwhf20bRGFwC6v8+OYYjcWAsQQENtCSjoFCD50TRGVwDa7we6rmLQT2sDBNBQaWaA3Ll0NCEPCJCHhv2gTysAATRUEnMDELuOpqsBA64MA798gCAACKCh0MzwAeINDAO/VmGkA1BCCQDiLYPVgQABNNgTM2h9AOjCRoHRtDQoAGgFHeiQxruD0XEAATSYmxmcDJA9eKMJefAAAWiccA5GxwEE0GBOzDOAWG80/Qw6oAeNm0EHAAJosCbmTCCOGU03gxbEQONoUAGAABqMbWbQWW+gnRxso2lmUAPQKUegnTAnBouDAAJosCVm0HJO0GyT9GhaGRIAdJgiaFb21WBwDEAADaZmBjMQLx9NyEMKSEPjjHkwOAYggAZTYg4HYgc62/mGYQjtPiYCvIX6iZ7AARp3Aw4AAmgwJeaVQLyNjvaBtvAbM0DGskEbZN8P4UT8HuoHZaifTtLR7m3QuBtwABBAg63NDNoKdYCB9muVQUNLhdBODAyAji4oAOJ8hoE9xoAUADoOYCIQT2BAPaUT1HnuB+IMGtt/DloyD4otVgABNBhHM0BXgB1jgJyeT23wnQEypLQYjxrQVRVFQJwHxDyDNBF/AeJJQNxHoEaJBeLpDLSZ5ACdmm8FxM8HS6AABNBgnc7WBuLDVC4hQQfHgA4dvEikemGo+iBo6TPQ+w3/QGutdQyQWThi2/r6UPVKVK4RbIH46mBKNAABNJjXZjhB22OsVGrXgUopck/nAZXWPtCE7cZAv/1xP4B4FzQBb6GgXS8ArY28qOCm31Bz9g22BAMQQIN9oRHoHo35FOj/B8SNQNzKQJ3L1mHtetAZcL1ALEsjfz8G4mIGyFUU1GqPglYdVjNAjs6lpOMP2k61aDAmFoAAGuzrmUGBVkmmXtCpPKC7SVqomJAZoIlrLY1HDE5C7aBmx+o/NCy8Gci/GbVysCZkEAAIoKGwOB90OGEStHojFpxlgGz12UVDdz0YombvgobNWRKbFknQuBi0ACCAhspOk4XQEoWYI6PmMUA2YT6gsZseDlGzYZnFDhpWhMAnaNgvHOyJBCCAhtJRA3uhEfAEhzxoJ3EaEKdCO04MdEgQQ9Fs5M5lKjTMfuJQ8wQa5nuHQgIBCKChdm4G6I5o0NjmRSwlGWioiJ7XiT0aomajg7nQsEOvDS5Cw/ryUEkcAAE0FA+BAa3UAh3wvRvK301GG3C0ZMbex0AOU3toWA8ZABBAQ/kUUNAkBugCdNC6gH8D5IbXDNQ/7w400jBQBxeCCjfQoiHQWXN/hlqCAAigoZyYBwMAHUpD7XUk56Cl5CggEQAEENNoEAy6tu2j0WAlDwAE0GhiHnxt2wejwUoeAAig0cRMGXg4RMwcEQAggEYT82jJPGwAQACNJubRNvOwAQABNJqYR0vmYQMAAmg0MVMGQOujqXnF2CeGIXQj6mADAAE0mpgHV0k6WipTAAACaDQxD6427mh7mQIAEECjiXm0ZB42ACCARhMz5eDhIDVrxAGAABpNzKMl87ABAAE0utCIciDOADmSALSDWwhKo2PYyjrQirj3WDBMHHQkwMvRICUPAATQaGIeBcMGAATQaDNjFAwbABBAo4l5FAwbABBAo4l5FAwbABBAo4l5FAwbABBAo4l5FAwbABBAo4l5FAwbABBAo4l5FAwbABBAo4l5FAwbABBAo4l5FAwbABBAo4l5FAwbABBAo4l5FAwbABBAo4l5FAwbABBAo4l5FAwbABBAo4l5FAwbABBAo4l5FAwbABBAo4l5FAwbABBAo4l5FAwbABBAo4l5FAwbABBgAGamLY/2B4K6AAAAAElFTkSuQmCC');\n    }\n\n    #Logo span {\n        margin: 27px 0px 0px 61px;\n        position: absolute;\n        font-size: 19px;\n        text-shadow: 3px 4px 2px #555555;\n    }\n\n    #loginCont {\n        height: 100%;\n        width: 100%;\n        background-color: #e1e5ec;\n        position: absolute;\n    }\n\n    #login_form {\n        padding: 0px;\n        background-color: #e1e5ec;\n        position: absolute;\n        margin-top: -135px;\n        margin-left: -135px;\n        left: 50%;\n        top: 50%;\n    }\n\n    #login_form, #login_inp, #passw_inp, #auth {\n        width: 270px;\n    }\n\n    #title {\n        font-size: 23px;\n        font-weight: bold;\n        color: #7a8195;\n        font-family: 'PT Sans', sans-serif;\n    }\n\n    .k-dropdown .k-input {\n        color: #767676;\n    }\n\n\n    .k-dropdown .k-state-focused .k-input {\n        color: #fff !important;\n    }\n\n    .k-dropdown {\n        width: 100%;\n        margin-top: 16px;\n    }\n\n    .k-dropdown, #login_inp, #passw_inp, #auth {\n        margin-top: 15px;\n    }\n</style>\n";
}
var pLoginForm = (function () {
    function pLoginForm() {
    }
    pLoginForm.formatXmlReq = function (xml) {
        function addsub(xml, sub) { return xml.substr(0, xml.indexOf(">") - 1) + ' SubMask="' + sub + '"/>'; }
        xml = $($.parseXML('<b>' + xml + '</b>'));
        var finxml = "";
        $(xml).find("SubSystem").each(function (index, data) {
            var SubMask = $(data).attr("SubMask");
            var roothtml = (((new XMLSerializer()).serializeToString(data)));
            roothtml = roothtml.substr(0, roothtml.indexOf(">") + 1);
            var arrlist = [];
            var arrlistfinal = "";
            $(data).children().each(function (index2, data2) {
                if (index2 > 0)
                    arrlist.push(addsub((new XMLSerializer()).serializeToString(data2), SubMask));
                else
                    arrlistfinal += (addsub((new XMLSerializer()).serializeToString(data2), SubMask)).replace(/\"\w+_It/, '\"Текущая');
            });
            for (var i = (arrlist.length - 1); i > -1; i--) {
                arrlistfinal += "\n" + arrlist[i];
            }
            finxml += roothtml + "\n" + arrlistfinal + "\n</SubSystem>\n";
        });
        return '<UCMsg>\n<SubSystems>\n' + finxml + '</SubSystems>\n</UCMsg>';
    };
    pLoginForm.Initialize = function () {
        DataBaseControl.SendRequest(XMLquery.SubSystemsList(), function (SubSystemsList) {
            $("body").html(pLoginForm.template);
            SubSystemsList = pLoginForm.formatXmlReq(SubSystemsList);
            MainConfig.SubSystems = ATools.DataSourceFromXml(SubSystemsList, "SubSystems SubSystem");
            MainConfig.Versions = ATools.DataSourceFromXml(SubSystemsList, "SubSystem Version");
            var SysSelect = $("#SysSelect").kendoDropDownList({
                dataTextField: "ID",
                dataValueField: "SubMask",
                optionLabel: "Система",
                dataSource: MainConfig.SubSystems,
                change: function () {
                    var sys = $("#SysSelect").data("kendoDropDownList").value();
                    $("#VerSelect").data("kendoDropDownList").value(sys);
                }
            }).data("kendoDropDownList");
            var VerSelect = $("#VerSelect").kendoDropDownList({
                cascadeFrom: "SysSelect",
                dataTextField: "ID",
                dataValueField: "VerMask",
                optionLabel: "Версия",
                dataSource: MainConfig.Versions
            }).data("kendoDropDownList");
            var loginParams = pLoginForm.getLoginCookie();
            console.log(MainConfig.hozObjects);
            if (typeof (loginParams.login) === 'undefined') {
                loginParams.login = 'SOMEONE';
                loginParams.passw = 'ABSENT';
                loginParams.sys = 'В';
                loginParams.ver = 'В';
            }
            $("#login_inp").val(loginParams.login);
            $("#passw_inp").val(loginParams.passw);
            SysSelect.value(loginParams.sys);
            VerSelect.value(loginParams.ver);
            $('body').on('keypress', function (e) {
                if (e.which === 13) {
                    pLoginForm.authorization();
                }
            });
        });
    };
    pLoginForm.authorization = function () {
        MainConfig.contextLogin = $("#login_inp").val();
        MainConfig.contextPass = $("#passw_inp").val();
        if (MainConfig.contextLogin === '') {
            MainConfig.contextLogin = 'SOMEONE';
            MainConfig.contextPass = 'ABSENT';
        }
        MainConfig.contextVer = $("#VerSelect").data("kendoDropDownList").value();
        MainConfig.contextSys = $("#SysSelect").data("kendoDropDownList").value();
        MainConfig.contextNormVer = $("#VerSelect").data("kendoDropDownList").text();
        MainConfig.contextNormSys = $("#SysSelect").data("kendoDropDownList").text();
        pLoginForm.setLoginCookie(MainConfig.contextSys, MainConfig.contextVer, MainConfig.contextPass, MainConfig.contextLogin, MainConfig.contextNormVer, MainConfig.contextNormSys);
        if (MainConfig.contextLogin && MainConfig.contextPass && MainConfig.contextVer) {
            DataBaseControl.SendRequest(XMLquery.getSchemaList(), function (SubSystemsList) {
                if (SubSystemsList.indexOf('Invalid Password') > 0)
                    ATools.alert('Вы ввели неверный логин или пароль!', 'Ошибка');
                else {
                    MainConfig.isDeveloper = $($($.parseXML('<b>' + SubSystemsList + '</b>'))).find("UserStatus").text();
                    $.cookie('devSys_isDeveloper', MainConfig.isDeveloper, { expires: 5, path: '/', });
                    $('body').off('keypress');
                    PageControl.StartPage();
                }
            });
        }
        else {
            ATools.alert('введите логин, пароль и выберите систему!');
        }
    };
    pLoginForm.clearLoginCookie = function () {
        $.cookie("devSys_ver", '', { expires: 5, path: '/' });
        $.cookie("devSys_sys", '', { expires: 5, path: '/' });
        $.cookie("devSys_passw", '', { expires: 5, path: '/' });
        $.cookie("devSys_login", '', { expires: 5, path: '/' });
        $.cookie('currTitlePage', '', { expires: 5, path: '/' });
        $.cookie('currObj', '', { expires: 5, path: '/' });
        $.cookie("devSys_contextNormVer", '', { expires: 5, path: '/' });
        $.cookie("devSys_contextNormSys", '', { expires: 5, path: '/' });
    };
    pLoginForm.setLoginCookie = function (sys, ver, passw, login, contextNormVer, contextNormSys) {
        $.cookie('devSys_ver', ver, { expires: 5, path: '/', });
        $.cookie('devSys_sys', sys, { expires: 5, path: '/', });
        $.cookie('devSys_passw', passw, { expires: 5, path: '/', });
        $.cookie('devSys_login', login, { expires: 5, path: '/', });
        $.cookie('devSys_contextNormVer', contextNormVer, { expires: 5, path: '/', });
        $.cookie('devSys_contextNormSys', contextNormSys, { expires: 5, path: '/', });
    };
    pLoginForm.getLoginCookie = function () {
        return {
            sys: $.cookie('devSys_sys'),
            ver: $.cookie('devSys_ver'),
            passw: $.cookie('devSys_passw'),
            login: $.cookie('devSys_login'),
            hozObjects: $.cookie('devSys_hozObjects'),
            contextNormVer: $.cookie('devSys_contextNormVer'),
            contextNormSys: $.cookie('devSys_contextNormSys'),
            isDeveloper: $.cookie('devSys_isDeveloper')
        };
    };
    pLoginForm.template = hLoginForm;
    return pLoginForm;
}());
{
    var fpOrders = "<div id=\"TopTemplateRight\"> \n            <button id=\"delReq\"  onclick=\"pOrders.deleteOrderExec()\" class=\"k-button\">\u0423\u0434\u0430\u043B\u0438\u0442\u044C \u0437\u0430\u044F\u0432\u043A\u0443</button>\n            <button id=\"delReq\"  onclick=\"pOrders.closeOrderEditFormExec()\" class=\"k-button\">\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u0437\u0430\u044F\u0432\u043A\u0443</button>\n            <button id=\"sendReq\" onclick=\"pOrders.exeReq()\" class=\"k-button k-primary\">\u041E\u043F\u0443\u0431\u043B\u0438\u043A\u043E\u0432\u0430\u0442\u044C \u0437\u0430\u044F\u0432\u043A\u0443</button>\n        </div>\n        <div id=\"AppForm\">\n          <form id=\"AppFormTop\" name= \"form\" onSubmit= \"return pOrders.updateRequestStructure()\" >\n            <div>\n              <span class=\"s\"><div>\u041D\u0410\u0427\u0418\u041D\u0410\u042F \u0421: </div></span><input type='text' value='' id= 'a_from' />\n              <span class=\"s\"><div class=\"z\">\u041F\u041E:</div></span><input type='text' value='' id= 'a_to' />\n              <button class='k-button'>\u041F\u043E\u043A\u0430\u0437\u0430\u0442\u044C</button>\n            </div>\n          </form>\n        </div>\n        <div id=\"pSimpleTable\"></div>\n\n        <style type=\"text/css\">\n            #TopTemplateRight {\n                position: fixed;\n                top: 25px;\n                right: 20px;\n            }\n\n            #AppForm {\n                position: absolute;\n                margin-top: -50px;\n                margin-left: 280px;\n            }\n\n            #AppFormTop .s{\n                margin: 3px;\n                width: 80px;\n                position: static;\n                display: inline-block;\n            }\n            \n            #AppFormTop .s div{\n                position: absolute;\n                margin-top: -7px;\n            }\n            \n            #AppFormTop .z{\n                margin-left: 57px;\n            }\n\n            .approved {\n            color:#2fcb34;\n            }\n            .notapproved {\n            color:#AC4308;\n            }\n            .ignored {\n              color:rgb(58, 58, 58);;  \n            }\n            \n            .confico {\n                position: absolute;\n                background-image: url('styles/Metro/vote-icon.png');\n                background-repeat: no-repeat;\n                width: 18px;\n                background-position-x: 3px;\n                background-position-y: 3px;\n                background-position: calc(100% - 3px) center;\n                height: 18px;\n                background-color: #FF9800;\n                cursor: pointer;\n                z-index: 2;\n            }\n            .editico {\n                position: absolute;\n                background-image: url('styles/Metro/edit-icon.png');\n                background-repeat: no-repeat;\n                width: 18px;\n                background-position-x: 3px;\n                background-position-y: 3px;\n                background-position: calc(100% - 3px) center;\n                height: 18px;\n                background-color: #8ebc00;\n                cursor: pointer;\n                z-index: 3;\n            }\n            .delico {\n                position: absolute;\n                background-image: url('styles/Metro/vote-icon-no.png');\n                background-repeat: no-repeat;\n                width: 18px;\n                background-position-x: 3px;\n                background-position-y: 3px;\n                background-position: calc(100% - 3px) center;\n                height: 18px;\n                background-color: #FF9800;\n                cursor: pointer;\n                margin-left: 20px;\n                z-index: 3;\n            }\n\n            .saveico {\n                position: absolute;\n                background-image: url('styles/Metro/save-icon.png');\n                background-repeat: no-repeat;\n                width: 18px;\n                background-position-x: 3px;\n                background-position-y: 3px;\n                background-position: center;\n                height: 18px;\n                background-color: #8ebc00;\n                cursor: pointer;\n                z-index: 2;    \n                margin-left: 20px;\n            }\n\n            .voteico-yes {\n                position: absolute;\n                background-image: url('styles/Metro/vote-ico-yes.png');\n                background-repeat: no-repeat;\n                width: 20px;\n                background-position-x: 4px;\n                background-position-y: 4px;\n                background-position: calc(100% - 4px) center;\n                height: 20px;\n                left: 306px;\n                margin-top: 0px;\n                background-color: #8ebc00;\n                cursor: pointer;\n                z-index: 0;\n            }\n\n            .voteico-no {\n                position: absolute;\n                background-image: url('styles/Metro/vote-ico-no.png');\n                background-repeat: no-repeat;\n                width: 20px;\n                background-position-x: 4px;\n                background-position-y: 4px;\n                height: 20px;\n                left: 328px;\n                margin-top: 0px;\n                background-color: #FF9800;\n                cursor: pointer;\n                z-index: 0;\n            }\n\n            #AddOrder {\n                position: fixed;\n                background-color: #8ebc00;\n                z-index: 9990;\n                top: 20px;\n                right: 20px;\n                padding: 1px 11px;\n                font-size: 24px;\n                color: white;\n                font-weight: 500;\n                cursor: pointer;\n            }\n            \n            /* \u0444\u0438\u043A\u0441 \u0431\u0430\u0433\u0430 \u0441 \u043E\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0438\u0435\u043C \u043F\u043E\u0434\u0447\u0435\u0440\u043A\u0438\u0432\u0430\u043D\u0438\u044F  */\n            .k-input\n            {\n(-bracket-:hack;\n        border-bottom: solid 1px #dbdbdb !important;\n    );\n                 \n            }\n\n\n            #CreateOrderForm td .k-combobox \n            {\n                background: transparent;\n            }\n\n\n            .k-grid td {\n                position: static;\n                vertical-align: top;\n            }\n            \n            .error\n            {\n                color: #E91E63;\n                width: 100%;\n                white-space: normal;\n            }    \n \n            .ofs-submit \n            {\n                margin: 10px 0px !important;\n            }\n\n            .ofs-unit\n            {\n                position: relative;\n                border-top: solid #b6b6b6 1px;\n            }\n\n            .ofs-controls \n            {\n                position: absolute;\n                right: 0px;\n                top: 4px;\n                width: 40px;\n            }\n\n            #ofs-real-body\n            {\n                margin: 30px 0px -5px 0px;\n            }\n\n            .ofs-unit .RequestItem {\n                margin: 4px 0px 34px 0px;\n            }\n\n            /* \u0437\u0430\u0433\u043B\u0443\u0448\u043A\u0438 \u0434\u043B\u044F tablesFields */\n            .ofsh {\n                position: absolute;\n                width: 100%;\n                height: 100%;\n                background: #ffffff;\n                z-index:9999;\n                top: 0px;\n                left: 0px;\n            }\n\n            .forInsertionForms \n            {\n                margin-bottom: 40px;\n            }\n\n            .orderTools\n            {    \n                position: static;\n                margin-top: -20px;\n                margin-left: -50px;\n            }\n            .orderTools2\n            {    \n                position: static;\n                margin-top: -20px;\n                margin-left: 40px;\n            }\n\n\n/* \u0441\u0442\u0440\u0435\u043B\u043A\u0430 \u043F\u043E\u0434\u0441\u043A\u0430\u0437\u043A\u0430 \u0434\u043B\u044F \u0437\u0430\u043F\u043E\u043B\u043D\u0435\u043D\u0438\u044F \u043E\u043F\u0438\u0441\u0430\u043D\u0438\u044F \u0437\u0430\u044F\u0432\u043A\u0438 */\n\n.p-arrow:before,\n.p-arrow:after {\n  margin-top:-80px;\n  content: \"\";\n  display: block;\n  position: absolute;\n  }\n.p-arrow:nth-child(1):before {\n  margin-top:-60px;\n  margin-left:10px;\n  width: 20px;\n  height: 20px;\n  background: rgb(230, 193, 136);  \n  }\n.p-arrow:nth-child(1):after {\n  width: 0;\n  height: 0;\n  border: 20px solid transparent;\n  border-bottom-color: rgb(230, 193, 136);  \n  border-top: 0;  \n}\n\n  @keyframes go-left-right {\n    from { top: 0px; }\n    to { top: 20px; }\n  }\n\n  @-webkit-keyframes go-left-right {\n    from { top: 0px; }\n    to { top: 20px; }\n  }\n\n  .p-arrow {\n    animation: go-left-right 1s infinite alternate;\n    -webkit-animation: go-left-right 1s infinite alternate;\n    position: relative;\n  }\n\n.p-arr {       \n    opacity: 0;\n    top: 90px;\n    left: 676px;\n    position: absolute;\n    background: white;\n    padding: 0px;\n}\n\n#k-dont-click-me {    \n    position: absolute;\n    margin-top: -10px;\n    width: 300px;\n    height: 40px;\n    background: red;\n    z-index: 99;\n    cursor: pointer;\n    opacity: 0;\n}\n\n/* \u0433\u043E\u043B\u043E\u0441\u043E\u0432\u0430\u043D\u0438\u0435 \u0437\u0430 \u0437\u0430\u044F\u0432\u043A\u0443 \u0438 \u043F\u0440\u043E\u0442\u0438\u0432 */\n\n.s-conf-list {\n    padding-right: 43px;\n}\n\n.s-vc {    \n    position: relative;\n    height: 0px;\n    width: 100%;\n}\n\n\n\n/* \u0442\u0430\u0431\u043B\u0438\u0447\u043A\u0430 \u043F\u0440\u0438\u0447\u0438\u043D\u044B \u043E\u0442\u043A\u0430\u0437\u0430 */\n\n.s-body-vote { \n\tposition: absolute; \n\tpadding: 10px; \n\ttop: -6px; \n\t/* top: -96px; */ \n\tleft: 370px; \n\tbackground-color: #fff; \n\tborder: 1px solid rgb(190, 189, 189); \n\twidth: 300px; \n\theight: 110px; \n\tcursor: default; \n\tz-index: 3; \n} \n\n.s-cbv { \n\tposition: absolute; \n\tleft: -7px; \n\tbackground-color: #fff; \n\twidth: 10px; \n\tborder-bottom: 1px solid rgb(190, 189, 189); \n\tborder-left: 1px solid rgb(190, 189, 189); \n\theight: 10px; \n\t/* top: 99px; */ \n\t-moz-transform: rotate(45deg); \n\t/* \u0414\u043B\u044F Firefox */ \n\t-ms-transform: rotate(45deg); \n\t/* \u0414\u043B\u044F IE */ \n\t-webkit-transform: rotate(45deg); \n\t/* \u0414\u043B\u044F Safari, Chrome, iOS */ \n\t-o-transform: rotate(45deg); \n\t/* \u0414\u043B\u044F Opera */ \n\ttransform: rotate(45deg); \n} \n\n.s-labelVote { \n\tfont-size: 12px; \n\tcolor: #787878; \n    margin-bottom: 2px;\n} \n\n        </style>";
}
var pOrders = (function () {
    function pOrders() {
    }
    pOrders.updateRequestStructure = function (event) {
        var l_a_from = $('#a_from').val();
        var l_a_to = $('#a_to').val();
        pOrders.Initialize(pOrders.currMode, l_a_from, l_a_to);
        return false;
    };
    pOrders.Initialize = function (mode, from, to) {
        if (from === void 0) { from = ATools.getdate(-6); }
        if (to === void 0) { to = ATools.getdate(0); }
        var mythis = this;
        $("#content").html(this.template);
        $("#TopTemplateRight").css("display", "none");
        pOrders.currMode = mode;
        var p_from = from;
        var p_to = to;
        var p_mode = mode;
        $("#a_from").val(p_from);
        $("#a_to").val(p_to);
        $("#a_from").kendoDatePicker({ format: "dd.MM.yyyy" });
        $("#a_to").kendoDatePicker({ format: "dd.MM.yyyy" });
        DataBaseControl.SendRequest(XMLquery.AppInfo(p_mode, p_from, p_to), function (AppInfoList) {
            if ((p_mode == 'notapproved') && (MainConfig.contextLogin != "SOMEONE")) {
                $('#content').prepend('<div id="AddOrder" class="helpinfo" helptext="Создать новую заявку" >+</div>');
                $('#AddOrder').on('click', function () {
                    mythis.addNewOrder();
                });
            }
            if (true) {
                var baseColumns = new Array();
                baseColumns['approved'] = [
                    { field: "ID", title: "Заявка", format: "{0:c}", width: "90px" },
                    { field: "Author", title: "Автор", format: "{0:c}", width: "90px" },
                    { field: "Created", title: "Создана", format: "{0:c}", width: "100px" },
                    { field: "Done", title: "Выполнена", format: "{0:c}", width: "100px" },
                    {
                        field: "Confirm",
                        title: "Подтвердили",
                        template: "#= pOrders.TamplateFuncgetUsersConfirm(Confirm) #"
                    },
                    { field: "BriefText", title: "Краткое описание" }
                ];
                baseColumns['notapproved'] = [
                    { field: "ID", title: "Заявка", format: "{0:c}", width: "90px" },
                    {
                        field: "Author",
                        title: "Автор",
                        width: "90px",
                        template: "#= pOrders.TamplateCheckEdit(Author) #"
                    },
                    { field: "Created", title: "Создана", width: "100px" },
                    {
                        field: "Confirm",
                        title: "Подтвердили",
                        width: "360px",
                        template: "#= pOrders.TamplateFuncgetUsersConfirm(Confirm) #"
                    },
                    {
                        field: "BriefText",
                        title: "Краткое описание",
                        template: "<span class='s-edit-text' ID='#: ID #' ObjectType='CONFIRMS' TextType='BriefText' RequestID='0' ><div></div>#: ATools.changeTextFix(BriefText) #</span>"
                    }
                ];
                var dsOrders = {
                    autoSync: false,
                    schema: {
                        type: 'xml',
                        data: '/UCMsg/Confirms/Confirm',
                        model: {
                            fields: {
                                ID: 'RequestHead/@ID',
                                Done: 'RequestHead/Done/text()',
                                Author: 'RequestHead/Author/text()',
                                Created: 'RequestHead/Created/text()',
                                BriefText: 'RequestHead/BriefText/text()',
                                Confirm: 'UsersConfirm'
                            }
                        }
                    },
                    data: AppInfoList,
                    sort: {
                        field: "ID",
                        dir: "desc"
                    }
                };
                if (ATools.getXmlVal(AppInfoList, 'UCMsg > Confirms > Confirm').length == 0) {
                    dsOrders = { data: [] };
                    $("#pSimpleTable").after('<div class="margin" id="pznotfound" style="position: absolute;top: 40px;">Заявок не найдено</div>');
                }
                var loadObjList = [];
                $("#pSimpleTable").kendoGrid({
                    dataSource: dsOrders,
                    detailExpand: function (e) {
                        gSuperPage.closeOpenRowTable(this, e, 'simple');
                        var id = $(e.masterRow[0]).find("td:eq(1)").text();
                        for (var i in loadObjList)
                            if (loadObjList[i].n == id)
                                if (loadObjList[i].f)
                                    LoadEventManager.execEvent("load_pSimpleTable_obj");
                                else
                                    loadObjList[i].f = true;
                    },
                    dataBound: function (e) {
                    },
                    scrollable: true,
                    resizable: true,
                    detailTemplate: kendo.template("<div class='content_request'></div>"),
                    detailInit: function (e) {
                        var RequestHeadId = e.data['ID'];
                        loadObjList.push({ n: e.data['ID'], f: false });
                        PageControl.setPagePath(PageControl.currPage, RequestHeadId);
                        if (RequestHeadId == 'x???') {
                            pOrders.pCreateOrder($('tr[data-uid="' + e.data.uid + '"]').next().find(".content_request"));
                        }
                        else {
                            DataBaseControl.SendRequest(XMLquery.RequestInfo(RequestHeadId), function (CurrentRequestInfo) {
                                gSuperPage.DispalyRequestItems($('tr[data-uid="' + e.data.uid + '"]').next().find(".content_request"), CurrentRequestInfo);
                                LoadEventManager.execEvent("load_pSimpleTable_obj");
                            });
                        }
                    },
                    sortable: true,
                    filterable: true,
                    columns: baseColumns[mode]
                });
                $("#pSimpleTable tr").each(function (index) {
                    var usersList = [];
                    var autor = $(this).find('td').eq(2).text();
                    var orderId = $(this).find('td').eq(1).text();
                });
                ATools.resize("#pSimpleTable");
                LoadEventManager.execEvent("load_pSimpleTable");
            }
        });
    };
    pOrders.TamplateCheckEdit = function (Author) {
        if ((Author.toUpperCase()) === (MainConfig.contextLogin).toUpperCase())
            return Author +
                '<div class="orderTools">' +
                '<div onclick="pOrders.sendAnOrderToEdit ($(this).parent().parent().parent())" class="editico helpinfo" helptext="Отреактировать заявку"             ></div>' +
                '<div onclick="pOrders.deleteOrder       ($(this).parent().parent().parent())" class="delico  helpinfo" helptext="Удалить заявку"                    ></div>' +
                '</div>';
        else
            return Author;
    };
    pOrders.TamplateFuncgetUsersConfirm = function (obj) {
        if (obj == null)
            return "";
        var buff = '', voiteYes = false, result = "";
        var DecisionY = 0;
        for (var i = 0; i < obj.UserConfirm.length; i++) {
            if (obj.UserConfirm[i]["@Decision"] == 'Y')
                DecisionY++;
        }
        for (var i = 0; i < obj.UserConfirm.length; i++) {
            var tag = '', stat = "", isCurrUser = false;
            if (obj.UserConfirm[i]["@ID"].toUpperCase().trim() == MainConfig.contextLogin.toUpperCase().trim())
                isCurrUser = true;
            if (obj.UserConfirm[i]["@Decision"] == 'Y') {
                stat = "approved";
            }
            else if (obj.UserConfirm[i]["@Decision"] == 'N') {
                stat = "notapproved";
            }
            else {
                stat = "ignored";
            }
            if (pOrders.currMode == 'approved')
                stat = "ignored";
            tag = 'span class="' + stat + ((isCurrUser) ? " CurrUser" : "") + '"';
            if ((isCurrUser) && (stat == 'ignored'))
                voiteYes = true;
            if (((obj.UserConfirm[i]["@ID"] == 'ALEXB') && (DecisionY == (obj.UserConfirm.length - 1))) || (obj.UserConfirm[i]["@ID"] != 'ALEXB'))
                buff += ", <" + tag + ">" + obj.UserConfirm[i]["@ID"] + "</span>";
        }
        buff = buff.substring(2);
        if ((voiteYes) && (pOrders.currMode == 'notapproved'))
            result += "<div class=\"s-vc\">\n                            <div class=\"voteico-yes helpinfo\" helptext=\"\u041F\u0440\u043E\u0433\u043E\u043B\u043E\u0441\u043E\u0432\u0430\u0442\u044C \u0437\u0430 \u0437\u0430\u044F\u0432\u043A\u0443\"     ></div>\n                            <div class=\"voteico-no  helpinfo\" helptext=\"\u041F\u0440\u043E\u0433\u043E\u043B\u043E\u0441\u043E\u0432\u0430\u0442\u044C \u043F\u0440\u043E\u0442\u0438\u0432 \u0437\u0430\u044F\u0432\u043A\u0438\" ></div>\n                       </div>";
        result += '<div class="s-conf-list">' + buff + '</div>';
        return result;
    };
    pOrders.addNewOrder = function () {
        $("#AppForm").css("display", "none");
        this.RequestHead_Action = "add";
        this.currOrderNumber = -1;
        this.editItemindex = -1;
        this.orderBreftext = "";
        pOrders.allOrders = [];
        $("#pznotfound").css('display', 'none');
        $("#pSimpleTable").data('kendoGrid').dataSource.add({
            ID: "x???",
            Author: MainConfig.contextLogin.toUpperCase() + ' ',
            Created: "",
            BriefText: "Необходимо ввести описание",
            Confirm: null
        });
        $("#pSimpleTable .k-master-row:first .k-icon").trigger('click');
        $("td:contains('x???')").css("font-size", "0px");
    };
    pOrders.pCreateOrder = function (htmlbody) {
        var mythis = this;
        $("#AddOrder").css("display", "none");
        htmlbody.parent().parent().prev().find("td:eq(0)").find(".k-icon").css("display", "none");
        htmlbody.html("<div class=\"RequestItem\">  \n             <div class=\"p-arr\">\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u043E\u043F\u0438\u0441\u0430\u043D\u0438\u0435 \u0437\u0430\u044F\u0432\u043A\u0438!<div class=\"p-arrow\"></div></div>\n\n             <div id=\"ofs-addneworder\" style=\"margin-bottom:10px;\">\n               <input id=\"ofs-action-combobox\" style=\"width: 300px;\" />\n             </div>\n             <div id=\"ofs-action-body\"></div>\n             <div id=\"ofs-real-body\"></div>\n           </div>");
        var comboboxDataS = [];
        $.each(pOrdersForms, function (i, value) {
            comboboxDataS.push({ text: value.label, value: value.labelXml });
        });
        comboboxDataS.sort(function (a, b) {
            var nameA = a.text.toLowerCase(), nameB = b.text.toLowerCase();
            if (nameA < nameB)
                return -1;
            if (nameA > nameB)
                return 1;
            return 0;
        });
        $("#ofs-action-body").addClass("forInsertionForms");
        $("#ofs-action-combobox").kendoComboBox({
            dataTextField: "text",
            dataValueField: "value",
            placeholder: "Выберите действие...",
            dataSource: comboboxDataS,
            change: function () {
                mythis.orderBreftext = htmlbody.parent().parent().prev().find("td:eq(5)").text();
                if ((mythis.orderBreftext == "") || (mythis.orderBreftext == "нет описания")) {
                    $(".p-arr").animate({ opacity: 1 }, 1000, function () {
                        setTimeout(function () {
                            $(".p-arr").animate({ opacity: 0 }, 1000);
                        }, 3000);
                    });
                    OFTools.setValComboBox("ofs-action-combobox", "");
                }
                else {
                    var thisval = this.value();
                    $.each(pOrdersForms, function (i, value) {
                        if (thisval == value.labelXml) {
                            value.getForm("", pOrders.submitForm);
                            mythis.Request_Action = "add";
                        }
                    });
                }
            }
        });
    };
    pOrders.submitForm = function (getXmlData, editMode) {
        var mythis = pOrders;
        if (mythis.currOrderNumber != -1)
            mythis.RequestHead_Action = "modify";
        var xxxc = OFTools.getFormData('CreateOrderForm');
        var xmlOrderItem = getXmlData(xxxc);
        var xmlreq = "<UCMsg ID=\"777\">\n          <RequestHead ID=\"" + mythis.currOrderNumber + "\">\n            <Action>" + mythis.RequestHead_Action + "</Action>\n            <Requests>\n              <Request ID=\"" + ((editMode) ? pOrders.allOrders[mythis.editItemindex].ID : "0") + "\">\n                <Action>" + mythis.Request_Action + "</Action>\n                " + xmlOrderItem + "\n              </Request>\n            </Requests>\n            <BriefText>" + mythis.orderBreftext + "</BriefText>\n          </RequestHead>\n          " + XMLquery.getContext() + "\n        </UCMsg>";
        DataBaseControl.SendRequest(xmlreq, function (xmlr) {
            if (mythis.currOrderNumber == -1) {
                $("td:contains('x???')").css("font-size", "12px");
                $("#TopTemplateRight").css("display", "block");
                pOrders.currOrderindex = $(".forInsertionForms").parent().parent().parent().parent().prev();
                pOrders.currOrderindex.find('td').eq(2).html(pOrders.TamplateCheckEdit(MainConfig.contextLogin.toUpperCase()));
                pOrders.currOrderindex.find('td').eq(5).find('span').attr('id', $(xmlr).find("RequestHead").attr("ID"));
                $(".orderTools").css("display", "none");
                $(".forInsertionForms").parent().parent().parent().parent().prev()
                    .find('td').eq(1).html($(xmlr).find("RequestHead").attr("ID"));
            }
            mythis.currOrderNumber = parseInt($(xmlr).find("RequestHead").attr("ID"));
            var RequestID = $(xmlr).find("Request").attr("ID");
            var Action = ATools.getXmlVal(xmlreq, "Subject > Action");
            var ObjectType = ATools.getXmlVal(xmlreq, "Subject > ObjectType");
            var Object = ATools.getXmlVal(xmlreq, "Subject > Object");
            if (editMode) {
                pOrders.allOrders[mythis.editItemindex] = { Action: Action, ObjectType: ObjectType, Object: Object, ID: RequestID };
                mythis.displayOrdersList();
                $("#ofs-addneworder").css("display", "block");
                $("#ofs-action-body").addClass("forInsertionForms");
            }
            else {
                pOrders.allOrders.unshift({ Action: Action, ObjectType: ObjectType, Object: Object, ID: RequestID });
                mythis.displayOrdersList();
                $("#ofs-action-body").html("");
                OFTools.setValComboBox('ofs-action-combobox', "", true);
            }
        });
    };
    pOrders.closeOrderEditFormExec = function () {
        var coi = this.currOrderindex;
        $(".orderTools").css("display", "block");
        $("#TopTemplateRight").css("display", "none");
        $("#AddOrder").css("display", "block");
        $(".editico, .delico, .k-icon").css("display", "block");
        $("#AppFormTop").css("display", "block");
        var idOrder = coi.find('td').eq(1).html();
        DataBaseControl.SendRequest(XMLquery.RequestInfo(idOrder), function (CurrentRequestInfo) {
            gSuperPage.DispalyRequestItems(coi.next().find(".content_request"), CurrentRequestInfo);
        });
    };
    pOrders.deleteOrder = function (index) {
        this.currOrderindex = index;
        this.deleteOrderExec();
    };
    pOrders.deleteOrderExec = function () {
        var coi = this.currOrderindex;
        var idOrder = coi.find('td').eq(1).html();
        if (confirm('Вы уверены, что хотите удалить заявку №' + idOrder + ' ?')) {
            var xmlreq = "<UCMsg ID=\"30\">\n              <RequestHead ID=\"" + idOrder + "\">\n                <Action>delete</Action>\n              </RequestHead>\n              " + XMLquery.getContext() + "\n            </UCMsg>";
            DataBaseControl.SendRequest(xmlreq, function (ret) {
                alert('Заявка успешно удалена');
                PageControl.ShowPage('Orders');
            });
        }
    };
    pOrders.sendAnOrderToEdit = function (index) {
        var mythis = this;
        this.currOrderindex = index;
        pOrders.allOrders = [];
        this.RequestHead_Action = "modify";
        this.orderBreftext = index.find('td').eq(5).text();
        index.find(".editico, .delico, .k-icon").css("display", "none");
        var isOpen = index.find('td').eq(0).find(".k-minus").length;
        if (isOpen == 0)
            index.find('td').eq(0).find(".k-icon").trigger("click");
        var idOrder = index.find('td').eq(1).html();
        this.currOrderNumber = parseInt(idOrder);
        $("#AppFormTop").css("display", "none");
        $("#TopTemplateRight").css("display", "block");
        DataBaseControl.SendRequest(XMLquery.RequestInfo(idOrder), function (xmlb) {
            OFTools.executeWhenDisplayingTag(index.next(), ".RequestItem", function () {
                pOrders.pCreateOrder(index.next().find(".content_request"));
                pOrders.allOrders = [];
                $($.parseXML(xmlb)).find("Requests > Request").each(function (i, xmlelem) {
                    var RequestID = $(xmlelem).attr("ID");
                    var Action = ATools.getXmlVal($(xmlelem).html(), "Subject > Action");
                    var ObjectType = ATools.getXmlVal($(xmlelem).html(), "Subject > ObjectType");
                    var Object = ATools.getXmlVal($(xmlelem).html(), "Subject > Object");
                    pOrders.allOrders.push({ Action: Action, ObjectType: ObjectType, Object: Object, ID: RequestID });
                });
                mythis.displayOrdersList();
            });
        });
    };
    pOrders.deleteOrderItem = function (index) {
        var mythis = this;
        if (confirm('Вы уверены, что хотите удалить этот пункт заявки?')) {
            var xmlreq = "<UCMsg ID=\"27\">\n              <RequestHead ID=\"" + this.currOrderNumber + "\">\n              <Action>modify</Action>\n              <Requests>\n                <Request ID=\"" + pOrders.allOrders[index].ID + "\">\n                  <Action>delete</Action>\n                </Request>\n              </Requests>\n              </RequestHead>\n              " + XMLquery.getContext() + "\n            </UCMsg>";
            DataBaseControl.SendRequest(xmlreq, function (xmlb) {
                pOrders.allOrders.splice(index, 1);
                mythis.displayOrdersList();
            });
        }
    };
    pOrders.editOrderItem = function (index) {
        this.Request_Action = "modify";
        $("#ofs-addneworder").css("display", "none");
        $("#ofs-action-body").html("");
        $("#ofs-action-body").removeClass("forInsertionForms");
        this.displayOrdersList(index);
    };
    pOrders.displayOrdersList = function (editIndex) {
        if (editIndex === void 0) { editIndex = -1; }
        $("#ofs-real-body").html("");
        var result3 = "";
        for (var i = 0; i < pOrders.allOrders.length; i++) {
            if (editIndex != i) {
                result3 = "<div class='ofs-unit'>" +
                    "<div class='ofs-controls'>" +
                    "<div onclick='pOrders.editOrderItem  (" + i + ")' class='editico helpinfo' helptext='Редактировать пункт заявки'></div>" +
                    "<div onclick='pOrders.deleteOrderItem(" + i + ")' class='delico  helpinfo' helptext='Удалить       пункт заявки'></div>" +
                    "</div>" +
                    gSuperPage.DispalyRequestItem(pOrders.allOrders[i].Action, pOrders.allOrders[i].ObjectType, pOrders.allOrders[i].Object) +
                    "</div>";
                $("#ofs-real-body").append(result3);
            }
            else {
                this.editItemindex = i;
                result3 = "<div class='ofs-unit'>" +
                    "<div class='ofs-controls'>" +
                    "</div>" +
                    "<div class='ActionInfo'><ul><li id='ofs-action'></li></ul></div>" +
                    "<div class='forInsertionForms'></div>" +
                    "</div>";
                $("#ofs-real-body").append(result3);
                $.each(pOrdersForms, function (z, value) {
                    var acty = (pOrders.allOrders[i].Action + " " + pOrders.allOrders[i].ObjectType);
                    if (acty.toUpperCase() == (value.labelXml).toUpperCase()) {
                        $("#ofs-action").html(value.label);
                        value.getForm(pOrders.allOrders[i].Object, pOrders.submitForm);
                    }
                });
            }
        }
    };
    pOrders.exeReq = function () {
        if (confirm("Вы действительно хотите опубликовать эту заявку?")) {
            $("#AddOrder").css("display", "block");
            $("#AppFormTop").css("display", "block");
            $("#TopTemplateRight").css("display", "none");
            var xmlreq = "<UCMsg ID=\"36\">\n                <RequestHead ID=\"" + this.currOrderNumber + "\">\n                    <Action>confirm</Action>\n                </RequestHead>\n                " + XMLquery.getContext() + "\n             </UCMsg>";
            DataBaseControl.SendRequest(xmlreq, function (ret) {
                alert('Заявка опубликована!');
                PageControl.ShowPage('Orders');
            });
            $("#s-help-info").css("display", "none");
        }
        else {
        }
    };
    pOrders.template = fpOrders;
    pOrders.orderBreftext = "";
    pOrders.editItemindex = -1;
    pOrders.currOrderNumber = -1;
    pOrders.allOrders = [];
    pOrders.RequestHead_Action = "";
    pOrders.Request_Action = "";
    return pOrders;
}());
var OFTools = (function () {
    function OFTools() {
    }
    OFTools.pickDataSource = function (xml, path, template, filter) {
        if (filter === void 0) { filter = ''; }
        var data = ATools.DataSourceFromXml(xml, path);
        if (filter.length > 0)
            data = ATools.DataSourceFilter(data, filter);
        var templateValue = (template['value']).split('|');
        var templateText = (template['text']).split('|');
        var fdata = [];
        for (var i = 0; i < data.length; i++) {
            var value = '';
            var text = '';
            for (var j = 0; j < templateValue.length; j++) {
                if (typeof (data[i][templateValue[j]]) === 'undefined') {
                    value += templateValue[j];
                }
                else {
                    value += data[i][templateValue[j]];
                }
            }
            for (var l = 0; l < templateText.length; l++) {
                if (typeof (data[i][templateText[l]]) === 'undefined') {
                    text += templateText[l];
                }
                else {
                    text += data[i][templateText[l]];
                }
            }
            fdata.push({ text: text, value: value });
        }
        return fdata;
    };
    OFTools.createDropDownList = function (tagId, dataSource, behavior) {
        if (behavior === void 0) { behavior = function () { }; }
        var myThis = this;
        $('#' + tagId).kendoDropDownList({
            dataSource: dataSource,
            dataValueField: "value",
            dataTextField: "text",
            optionLabel: "...",
            change: function (e) {
                var thisval = this.value();
                behavior(thisval);
            }
        });
    };
    OFTools.loadDropDownList = function (tagId, data) {
        $("#" + tagId).data("kendoDropDownList").dataSource.data(data);
        $("#" + tagId).data("kendoDropDownList").dataSource.query();
    };
    OFTools.loadComboBox = function (tagId, data) {
        $("#" + tagId).data("kendoComboBox").dataSource.data(data);
        $("#" + tagId).data("kendoComboBox").dataSource.query();
    };
    OFTools.createComboBox = function (tagId, dataSource, behavior, width) {
        if (width === void 0) { width = 0; }
        var myThis = this;
        $('#' + tagId).kendoComboBox({
            dataSource: dataSource,
            dataValueField: "value",
            dataTextField: "text",
            change: function (e) {
                var thisval = this.value();
                this.value(thisval + ' ');
                behavior(thisval);
            }
        });
        $('#' + tagId).parent().css('width', "100%");
        if (width > 0)
            ($('#' + tagId).data("kendoComboBox")).list.width(width);
    };
    OFTools.setValComboBox = function (tagId, val, modeTrigger) {
        if (modeTrigger === void 0) { modeTrigger = false; }
        $('#' + tagId).data("kendoComboBox").value(val.trim());
        if (modeTrigger)
            $('#' + tagId).data("kendoComboBox").trigger("change");
    };
    OFTools.setValDropDownList = function (tagId, val, modeTrigger) {
        if (modeTrigger === void 0) { modeTrigger = false; }
        $('#' + tagId).data("kendoDropDownList").value(val.trim());
        if (modeTrigger)
            $('#' + tagId).data("kendoDropDownList").trigger("change");
    };
    OFTools.setValInput = function (tagId, val, modeTrigger) {
        if (modeTrigger === void 0) { modeTrigger = false; }
        if (typeof (val) != 'undefined')
            $('#' + tagId).val(val.trim());
        if (modeTrigger)
            $('#' + tagId).trigger("propertychange");
    };
    OFTools.setValCheckInput = function (tagId, val) {
        if (val === void 0) { val = "N"; }
        if ((val.trim() === 'Y') || (val.trim() === '1')) {
            $("#" + tagId).attr('checked', 'checked');
            $("#" + tagId).prop("checked", true);
        }
        else
            $("#" + tagId).removeAttr('checked');
    };
    OFTools.createMultiSelect = function (tagId, dataSource, behavior, width) {
        if (width === void 0) { width = 0; }
        $('#' + tagId).kendoMultiSelect({
            dataSource: dataSource,
            dataValueField: "value",
            dataTextField: "text",
            change: function (e) {
                var thisval = this.value();
                $('#' + tagId).val(thisval.join("|"));
                behavior(thisval);
            }
        });
        $('#' + tagId).parent().css('width', "100%");
        if (width > 0)
            ($('#' + tagId).data("kendoMultiSelect")).list.width(width);
        $('#' + tagId).parent().find("input:eq(0)").remove();
    };
    OFTools.setValMultiSelect = function (tagId, val, modeTrigger) {
        if (modeTrigger === void 0) { modeTrigger = false; }
        $('#' + tagId).data("kendoMultiSelect").value(val);
    };
    OFTools.loadMultiSelect = function (tagId, data) {
        $("#" + tagId).data("kendoMultiSelect").dataSource.data(data);
        $("#" + tagId).data("kendoMultiSelect").dataSource.query();
    };
    OFTools.constructXmlFields = function (arr, tn) {
        if (typeof (arr) != 'undefined') {
            var s = '';
            for (var i = 0; i < arr.length; i++)
                s += '<Field ID="' + arr[i].trim() + '"><TableID>' + tn.trim() + '</TableID></Field>';
            return s;
        }
        else {
            return '';
        }
    };
    OFTools.getFormData = function (tagId) {
        var data = [];
        $('#' + tagId + ' input, #' + tagId + ' textarea').each(function (i, dat) {
            var key = $(dat).attr('id');
            var keyobj = $(dat);
            var keyobjType = (keyobj.parent().attr("class"));
            if ((typeof key !== 'undefined') && (key.substr(0, 3) == 'ofs')) {
                if (keyobj.attr('type') == 'checkbox') {
                    data.push({ key: key, val: (keyobj.is(':checked')) ? "Y" : "N", active: keyobj.attr('active') });
                }
                else if (keyobj.attr('type') == 'text') {
                    if (keyobjType.indexOf('multiselect') > 0)
                        data.push({ key: key, val: (keyobj.val()).split("|"), active: keyobj.attr('active') });
                    else
                        data.push({ key: key, val: keyobj.val(), active: keyobj.attr('active') });
                }
            }
        });
        var result = {};
        for (var j = 0; j < data.length; j++) {
            if (data[j].active == "on") {
                var dds = data[j].val;
                if (typeof dds == 'string')
                    result[data[j].key] = (dds).trim();
                else
                    result[data[j].key] = dds;
            }
            else
                result[data[j].key] = "";
        }
        return result;
    };
    OFTools.DataTypesFMode = function (ID) {
        switch (ID.trim()) {
            case 'blob':
            case 'clob':
            case 'currency':
            case 'date':
            case 'datetime':
            case 'dateYYMM':
            case 'dateYYMMDD':
            case 'fltp':
            case 'memo':
            case 'rowid':
            case 'xmltype':
                return { s: '-', p: '-' };
            case 'float':
            case 'number':
            case 'rate':
                return { s: 'w', p: 'w' };
            case 'raw':
            case 'string':
            case 'timestamp':
                return { s: 'w', p: '-' };
            default:
                return { s: '-', p: '-' };
        }
    };
    OFTools.showHideTibleFieldsColumns = function (row, column, status, tn) {
        if (tn === void 0) { tn = "tablesFields"; }
        if (row == -1) {
            var input = $("#" + tn + " td:nth-child(" + column + ") input");
            if (status == 'hide') {
                $("#" + tn + " td:nth-child(" + column + "), #" + tn + " th:nth-child(" + column + ")").css("display", "none");
                input.attr("active", "off");
                input.rules("add", { required: false });
            }
            else {
                $("#" + tn + " td:nth-child(" + column + "), #" + tn + " th:nth-child(" + column + ")").css("display", "table-cell");
                input.attr("active", "on");
                input.rules("add", { required: true });
            }
        }
        else {
            var input1 = $("#" + tn + " tr:eq(" + row + ") td:nth-child(" + column + ") input");
            if (status == 'hide') {
                input1.css("visibility", "hidden");
                input1.attr("active", "off");
                input1.rules("add", { required: false });
            }
            else {
                input1.css("visibility", "visible");
                input1.attr("active", "on");
                input1.rules("add", { required: true });
            }
        }
    };
    OFTools.executeWhenDisplayingTag = function (tag, Class, callback) {
        var intr = {
            t: setInterval(function () {
                intr.i++;
                if (tag.find(Class).length > 0) {
                    clearInterval(intr.t);
                    callback();
                }
                if (intr.i > 50)
                    clearInterval(intr.t);
            }, 100),
            i: 0
        };
    };
    OFTools.SqlEditor = function (text, param, callAfter) {
        var p_param = { title: "", gutter: false, height: 0 };
        if (typeof (param.title) === 'undefined') {
            p_param.title = 'Редактор';
        }
        else {
            p_param.title = param.title;
        }
        if (typeof (param.gutter) === 'undefined') {
            p_param.gutter = false;
        }
        else {
            p_param.gutter = param.gutter;
        }
        if (typeof (param.height) === 'undefined') {
            p_param.height = 400;
        }
        else {
            p_param.height = param.height;
        }
        $("body").prepend("<div id='DevSysEditorWindow'>\n               <div id='DevSysToolbar'></div>\n               <div id='DevSysCurrEditor' >" + text + "</div>\n             </div>");
        $("#DevSysCurrEditor").css('height', (p_param.height - 50) + 'px');
        OFTools.editor = ace.edit("DevSysCurrEditor");
        OFTools.editor.setTheme("ace/theme/xcode");
        OFTools.editor.getSession().setMode("ace/mode/sql");
        OFTools.editor.setShowInvisibles(p_param.gutter);
        OFTools.editor.renderer.setShowGutter(p_param.gutter);
        OFTools.editor.renderer.setShowPrintMargin(p_param.gutter);
        OFTools.editor.setHighlightActiveLine(p_param.gutter);
        OFTools.editor.setFontSize("12px");
        $("#DevSysToolbar").kendoToolBar({
            items: [
                { type: "separator" },
                { template: "<label> Размер шрифта:</label>" },
                {
                    template: "<input id='DevSysDropdownPx' style='width: 80px;' />",
                    overflow: "never"
                },
                {
                    type: "button",
                    id: "button1",
                    text: "Сохранить",
                    click: function (e) {
                        $("#DevSysEditorWindow").data("kendoWindow").close();
                    }
                }
            ]
        });
        $("#DevSysDropdownPx").kendoDropDownList({
            dataTextField: "text",
            dataValueField: "value",
            dataSource: [
                { text: "12px", value: 12 },
                { text: "14px", value: 14 },
                { text: "16px", value: 16 },
                { text: "18px", value: 18 },
                { text: "20px", value: 20 },
                { text: "22px", value: 22 },
                { text: "24px", value: 24 },
                { text: "26px", value: 26 },
                { text: "28px", value: 28 }
            ],
            change: function (e) {
                var value = this.value();
                OFTools.editor.setFontSize(value + "px");
            }
        });
        $("#DevSysEditorWindow").kendoWindow({
            width: "800px",
            height: p_param.height + "px",
            resizable: false,
            draggable: false,
            modal: true,
            title: p_param.title + ' ' + ((p_param.gutter) ? "SQL" : ""),
            actions: [
                "Maximize",
                "Close"
            ],
            resize: function () {
                var h = $("#DevSysEditorWindow").css('height');
                $("#DevSysCurrEditor").css('height', (parseInt(h) - 50) + 'px');
                OFTools.editor.resize();
            },
            open: function () {
            },
            close: function () {
                callAfter(OFTools.editor.getValue());
                $("#DevSysEditorWindow").remove();
            }
        }).data("kendoWindow").center().open();
    };
    OFTools.getOrderFormByLabelXml = function (label) {
        var result = null;
        $.each(pOrdersForms, function (i, v) {
            if (v.labelXml.toUpperCase() == label.toUpperCase())
                result = v;
        });
        return result;
    };
    OFTools.chActionOrder = function (xml) {
        var xmlOrderItem = $($.parseXML(xml));
        xmlOrderItem.find("Action:eq(0)").text("modify");
        return (new XMLSerializer()).serializeToString($(xmlOrderItem)[0]);
    };
    OFTools.add_field = function () {
        var add_FIELD = OFTools.getOrderFormByLabelXml("ADD FIELD");
        var add_TABLE = OFTools.getOrderFormByLabelXml("ADD TABLE");
        var count = $("#tablesFields").attr("indexcount");
        add_FIELD.addFieldForm(count, add_TABLE.temp.DataSourceDataTypes, add_TABLE.temp.DataSourceTable);
        $("#ofs-fiel-" + count).parent().css({ "position": "relative", "padding-left": "27px" });
        $("#ofs-fiel-" + count).before("<div class='s-t-down'></div><div class='s-t-up'></div>");
    };
    return OFTools;
}());
pOrdersForms.push({
    label: 'Добавить констрейнт',
    labelXml: 'add CONSTRAINT',
    fields_data: [],
    getForm: function (xmlData, finishCallback) {
        if (xmlData === void 0) { xmlData = ""; }
        if (finishCallback === void 0) { finishCallback = function () { }; }
        var mythis = this, prevals, editMode = false;
        if (xmlData !== "") {
            prevals = (ATools.DataSourceFromXml(xmlData, "Constraint"))[0];
            prevals.Fields = ATools.FieldsFromXml(prevals.Fields);
            editMode = true;
        }
        var form1Proto = "\n          <form id=\"CreateOrderForm\">\n            <table role=\"grid\">\n             <thead class=\"k-grid-header\" role=\"rowgroup\">\n              <tr>\n                <th class=\"k-header\" style=\"width:  80px;\"> \u0422\u0430\u0431\u043B\u0438\u0446\u0430         </th>\n                <th class=\"k-header\" style=\"width: 100px;\"> \u0422\u0438\u043F \u043A\u043E\u043D\u0441\u0442\u0440\u0435\u0439\u043D\u0442\u0430 </th>\n                <th class=\"k-header\"                      > \u0418\u043C\u044F \u043A\u043E\u043D\u0441\u0442\u0440\u0435\u0439\u043D\u0442\u0430 </th>\n                <th class=\"k-header\" style=\"width:  75px;\"> NOVALIDATE      </th>\n                <th class=\"k-header\"                      > \u0423\u0441\u043B\u043E\u0432\u0438\u0435         </th>\n                <th class=\"k-header\"                      > \u0414\u043E\u041E\u043F\u0440\u0435\u0434\u0435\u043B\u0435\u043D\u0438\u0435 (on delelete...)</th>\n                <th class=\"k-header\"                      > \u041F\u0435\u0440\u0432\u0438\u0447\u043D\u044B\u0439 \u041A\u043B\u044E\u0447  </th>\n                <th class=\"k-header\"                      > \u041F\u043E\u043B\u044F \u0442\u0430\u0431\u043B\u0438\u0446\u044B    </th>\n                <th class=\"k-header\"                      > \u041F\u043E\u043B\u044F \u0442\u0430\u0431\u043B\u0438\u0446\u044B    </th>\n              </tr>\n             </thead>\n              <tr>\n                <td class=\"td\"> <input id=\"ofs1-tabl\" name=\"tabl\" type=\"text\"     active=\"on\" /> </td>\n                <td class=\"td\"> <input id=\"ofs1-type\" name=\"type\" type=\"text\"     active=\"on\"                   style=\"width:100%;\" /> </td>\n                <td class=\"td\"> <input id=\"ofs1-name\" name=\"name\" type=\"text\"     active=\"on\" class=\"k-textbox\" style=\"width:100%;\" /> </td>                \n                <td class=\"td\"> <span class=\"cb\">\n                                <input id=\"ofs1-vali\" name=\"vali\" type=\"checkbox\" active=\"on\"><label for=\"ofs1-vali\"/></span> \n                </td>\n                <td class=\"td\"> <input id=\"ofs1-elif\" name=\"elif\" type=\"text\"     active=\"on\" class=\"k-textbox\" style=\"width:100%;\" /> </td>                \n                <td class=\"td\"> <input id=\"ofs1-bopr\" name=\"bopr\" type=\"text\"     active=\"on\" class=\"k-textbox\" style=\"width:100%;\" /> </td>                \n                <td class=\"td\"> <input id=\"ofs1-perv\" name=\"perv\" type=\"text\"     active=\"on\"                   style=\"width:100%;\" /> </td>\n                <td class=\"td\"> <input id=\"ofs1-fiel\" name=\"fiel\" type=\"text\"     active=\"on\" style=\"width:100%;\" /> </td>\n                <td class=\"td\"> <input id=\"ofs1-elifh\" name=\"elifh\" type=\"text\"   active=\"on\" style=\"width:100%;\" /> </td>   \n                <td class=\"td\" style=\"display:none;\"> \n                                <input id=\"ofs1-coun\" name=\"coun\" type=\"text\"     active=\"on\" value=\"0\" /> \n                </td>                \n                             \n              </tr>\n              <tr  id=\"ConstrTableRow\"> \n                <td  colspan=\"3\"> \n                  <table role=\"grid\" id=\"ConstrTable\" style=\"width: 300px;margin:12px;display:none;\">\n                    <thead class=\"k-grid-header\" role=\"rowgroup\">\n                      <tr>\n                        <th class=\"k-header\" style=\"width: 110px;\"> \u041F\u043E\u043B\u0435 \u043A\u043E\u043D\u0441\u0442\u0440\u0435\u0439\u043D\u0442\u0430 </th>\n                        <th class=\"k-header\"                      > \u0421\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0438\u0435     </th>\n                      </tr>\n                    </thead>\n                    <tbody>\n                    </tbody>\n                  </table>               \n                </td>\n              </tr>\n            </table>\n\n\n            <button class=\"k-button k-primary ofs-submit\" id=\"sdadwd2\" type=\"submit\">\u041F\u0440\u0438\u043D\u044F\u0442\u044C</button>\n          </form>";
        DataBaseControl.SendRequest(XMLquery.getSchemaList(), function (xml) {
            $(".forInsertionForms").html(form1Proto);
            OFTools.createComboBox('ofs1-tabl', OFTools.pickDataSource(xml, 'ObjectRefs > ObjectRef', { value: 'ID', text: 'ID| : |BriefText' }, 'ObjectType=TABLE'), function (Fname_start) {
                $("#ofs1-name").val("C" + Fname_start);
                $('#ofs1-name').rules('add', {
                    regex: new RegExp("^[A-Z0-9_]{2,15}$", 'g'),
                    messages: { regex: "Строка должна иметь формат: ^[A-Z0-9_]{2,15}$" }
                });
                DataBaseControl.SendRequest(XMLquery.FieldsByTabName(Fname_start), function (xml2) {
                    var xzzlength = parseInt($("#ofs1-coun").val());
                    mythis.fields_data =
                        OFTools.pickDataSource(xml2, 'Table > Fields > Field', { value: 'ID', text: 'ID| |Type' });
                    OFTools.loadDropDownList("ofs1-elifh", mythis.fields_data);
                    if ($("#ConstrTable").css("display") != "none")
                        for (var i = 0; i < xzzlength; i++)
                            OFTools.loadDropDownList("ofs-tablef-" + i, mythis.fields_data);
                    OFTools.loadMultiSelect('ofs1-fiel', mythis.fields_data);
                });
            }, 400);
            OFTools.createDropDownList('ofs1-elifh', [], function (select) {
                OFTools.setValInput("ofs1-elif", $("#ofs1-elif").val() + select);
            });
            QueryCache.get("getConstrList", function (xmlc) {
                OFTools.createDropDownList('ofs1-perv', OFTools.pickDataSource(xmlc, "ObjectRefs > ObjectRef", { value: 'ID', text: 'ID' }, 'ObjectType=P'), function (select) {
                    $("#ConstrTableRow").css("display", "table-row");
                    $("#ConstrTable").css("display", "table");
                    $("#ConstrTable tbody").html("");
                    var xzz = ($($.parseXML("<b>" + xmlc + "</b>"))
                        .find("*[ID=" + select + "]").attr("BriefText")).split(",");
                    $("#ofs1-coun").val(xzz.length);
                    for (var i = 0; i < xzz.length; i++) {
                        var addFieldConstr = "<tr>\n                               <td class=\"td\"><input id=\"ofs-constf-" + i + "\" name=\"constf-" + i + "\" type=\"text\" active=\"on\" class=\"k-textbox\" value=\"" + xzz[i] + "\" style=\"width:100%;\" readonly=\"readonly\" /></td>\n                               <td class=\"td\"><input id=\"ofs-tablef-" + i + "\" name=\"tablef-" + i + "\" type=\"text\" active=\"on\"                                     style=\"width:100%;\"                     /></td>\n                             </tr>";
                        $("#ConstrTable tbody").append(addFieldConstr);
                        OFTools.createDropDownList("ofs-tablef-" + i, [], function () { });
                        $("#ofs-tablef-" + i).rules("add", { required: true });
                        if (mythis.fields_data.length > 0)
                            OFTools.loadDropDownList("ofs-tablef-" + i, mythis.fields_data);
                    }
                });
            });
            OFTools.createDropDownList('ofs1-type', [{ value: "CHECK", text: "CHECK" },
                { value: "PRIMARY", text: "PRIMARY" },
                { value: "REFERENCE", text: "REFERENCE" }], function (select) {
                $("#ConstrTableRow").css("display", "none");
                $("#ConstrTable").css("display", "none");
                $("#ConstrTableRow tbody").html("");
                OFTools.showHideTibleFieldsColumns(-1, 5, "hide", "CreateOrderForm");
                OFTools.showHideTibleFieldsColumns(-1, 6, "hide", "CreateOrderForm");
                OFTools.showHideTibleFieldsColumns(-1, 7, "hide", "CreateOrderForm");
                OFTools.showHideTibleFieldsColumns(-1, 8, "hide", "CreateOrderForm");
                OFTools.showHideTibleFieldsColumns(-1, 9, "hide", "CreateOrderForm");
                switch (select) {
                    case "CHECK":
                        OFTools.showHideTibleFieldsColumns(-1, 5, "show", "CreateOrderForm");
                        OFTools.showHideTibleFieldsColumns(-1, 9, "show", "CreateOrderForm");
                        $("#ofs1-elifh").rules("add", { required: false });
                        break;
                    case "PRIMARY":
                        OFTools.showHideTibleFieldsColumns(-1, 8, "show", "CreateOrderForm");
                        break;
                    case "REFERENCE":
                        OFTools.showHideTibleFieldsColumns(-1, 6, "show", "CreateOrderForm");
                        OFTools.showHideTibleFieldsColumns(-1, 7, "show", "CreateOrderForm");
                        if ($("#ofs1-coun").val() != "0") {
                            $("#ConstrTableRow").css("display", "table-row");
                            $("#ConstrTable").css("display", "table");
                        }
                        break;
                }
            });
            OFTools.createMultiSelect('ofs1-fiel', [], function (Fname_start) {
            }, 400);
            $("#ConstrTableRow").css("display", "none");
            $.validator.setDefaults({ submitHandler: function () { finishCallback(mythis.getXmlData, editMode); }, ignore: "" });
            $("#CreateOrderForm").validate({
                rules: {
                    tabl: {
                        required: true,
                        minlength: 3,
                        regex: /^[A-Z]{1}[0-9]{2}\s*$/
                    },
                    type: {
                        required: true,
                        minlength: 4,
                    },
                    name: {
                        required: true,
                        minlength: 4,
                    },
                    fiel: {
                        required: true,
                    }
                },
                messages: {
                    tabl: {
                        required: 'Введите имя таблицы!',
                        regex: "Строка должна иметь формат: ^[A-Z]{1}[0-9]{2}\s*$"
                    }
                }
            });
            OFTools.showHideTibleFieldsColumns(-1, 5, "hide", "CreateOrderForm");
            OFTools.showHideTibleFieldsColumns(-1, 6, "hide", "CreateOrderForm");
            OFTools.showHideTibleFieldsColumns(-1, 7, "hide", "CreateOrderForm");
            OFTools.showHideTibleFieldsColumns(-1, 8, "hide", "CreateOrderForm");
            OFTools.showHideTibleFieldsColumns(-1, 9, "hide", "CreateOrderForm");
            if (xmlData !== "") {
                OFTools.setValComboBox("ofs1-tabl", prevals.TableID, true);
                OFTools.setValInput("ofs1-name", prevals.ID);
                OFTools.setValCheckInput("ofs1-vali", prevals.Validate);
                switch (prevals.Type.trim()) {
                    case "CHECK":
                    case "C":
                        OFTools.setValDropDownList("ofs1-type", "CHECK", true);
                        OFTools.setValInput("ofs1-elif", prevals.Condition);
                        break;
                    case "PRIMARY":
                    case "P":
                        OFTools.setValDropDownList("ofs1-type", "PRIMARY", true);
                        setTimeout(function () {
                            OFTools.setValMultiSelect("ofs1-fiel", prevals.Fields, true);
                        }, 1000);
                        break;
                    case "REFERENCE":
                    case "R":
                        OFTools.setValDropDownList("ofs1-type", "REFERENCE", true);
                        OFTools.setValDropDownList("ofs1-perv", $(prevals.html).find("ConstraintPK").attr("ID"), true);
                        OFTools.setValInput("ofs1-bopr", prevals.DeleteRule);
                        setTimeout(function () {
                            for (var i = 0; i < prevals.Fields.length; i++)
                                OFTools.setValDropDownList("ofs-tablef-" + i, prevals.Fields[i], true);
                        }, 1000);
                        break;
                    default:
                }
                xmlData = "";
            }
        });
    },
    getXmlData: function (data) {
        var dop = "";
        switch (data['ofs1-type']) {
            case "CHECK":
                dop = "<Condition>" + data['ofs1-elif'] + "</Condition>";
                break;
            case "PRIMARY":
                dop = "<Fields>" + OFTools.constructXmlFields(data['ofs1-fiel'], data['ofs1-tabl']) + "</Fields>";
                break;
            case "REFERENCE":
                var tab = [], con = [];
                for (var i = 0; i < parseInt(data['ofs1-coun']); i++) {
                    tab.push(data["ofs-tablef-" + i]);
                    con.push(data["ofs-constf-" + i]);
                }
                dop += "<Fields>" + OFTools.constructXmlFields(tab, data['ofs1-tabl']) + "</Fields>\n                            <ConstraintPK ID=\"" + data['ofs1-perv'] + "\">\n                              <TableID >" + data['ofs1-tabl'] + "</TableID>\n                              <Fields  >" + OFTools.constructXmlFields(con, data['ofs1-tabl']) + "</Fields>\n                            </ConstraintPK>\n                            <DeleteRule>" + data['ofs1-bopr'] + "</DeleteRule>";
                break;
            default:
        }
        var result = "<Subject>\n                   <Action>add</Action>\n                   <ObjectType>CONSTRAINT</ObjectType>\n                   <Object>\n                     <Constraint ID=\"" + data['ofs1-name'] + "\">\n                       <TableID     >" + data['ofs1-tabl'] + "</TableID>\n                       <Type        >" + data['ofs1-type'] + "</Type>\n                       <Validate    >" + data['ofs1-vali'] + "</Validate>\n                       " + dop + "\n                     </Constraint>\n                   </Object>\n                 </Subject>";
        return result;
    }
});
pOrdersForms.push({
    label: 'Добавить поле',
    labelXml: 'ADD FIELD',
    addFieldForm: function (index, dataSourceDataTypes, dataSourceTable) {
        function offOnValidation(i, mode) {
            $("#ofs-type-" + i).rules("add", { required: mode });
            $("#ofs-brie-" + i).rules("add", { required: mode });
            $("#ofs-full-" + i).rules("add", { required: mode });
        }
        var nonTablMode = ($("#tablesFields th:eq(0)").css("display") == "none") ? true : false;
        var tablName = $("#tablesFields").attr("tablName");
        var ts = (!nonTablMode) ? "" : ' style="display:none;" ';
        var templ = "<tr>\n            <td class=\"td upp\"" + ts + ">                                 <input  id=\"ofs-tabl-" + index + "\" name=\"tabl-" + index + "\" type=\"text\"     active=\"on\"                                      />      </td>\n            <td class=\"td fnx upp\" >                                 <input  id=\"ofs-fiel-" + index + "\" name=\"fiel-" + index + "\" type=\"text\"     active=\"on\" style=\"width:100%;\" class=\"k-textbox\"/>      </td>\n            <td class=\"td\"     > <div class=\"ofs-h-" + index + "\" >       <input  id=\"ofs-type-" + index + "\" name=\"type-" + index + "\" type=\"text\"     active=\"on\"                                      /></div></td>\n            <td class=\"td\"     > <div class=\"ofs-h-" + index + "\" >       <input  id=\"ofs-deff-" + index + "\" name=\"deff-" + index + "\" type=\"text\"     active=\"on\" style=\"width:100%;\" class=\"k-textbox\"/></td>\n            <td class=\"td\"     > <div class=\"ofs-h-" + index + "\" >       <input  id=\"ofs-size-" + index + "\" name=\"size-" + index + "\" type=\"text\"     active=\"on\" style=\"width:100%;\" class=\"k-textbox\"/></div></td>                                                             \n            <td class=\"td\"     > <div class=\"ofs-h-" + index + "\" >       <input  id=\"ofs-pres-" + index + "\" name=\"pres-" + index + "\" type=\"text\"     active=\"on\" style=\"width:100%;\" class=\"k-textbox\"/></div></td>\n            <td class=\"td\"     > <div class=\"ofs-h-" + index + "\" >                    \n                                                   <span class=\"cb\"> <input  id=\"ofs-null-" + index + "\" name=\"null-" + index + "\" type=\"checkbox\" active=\"on\">\n                                                                     <label for=\"ofs-null-" + index + "\"/></span></div></td>                              \n            <td class=\"td\"     > <div class=\"ofs-h-" + index + "\" >       <input  id=\"ofs-brie-" + index + "\" name=\"brie-" + index + "\" type=\"text\"     active=\"on\" style=\"width:100%;\" class=\"k-textbox\"/></div></td>\n            <td class=\"td\"     > <div class=\"ofs-h-" + index + "\" >       <input  id=\"ofs-full-" + index + "\" name=\"full-" + index + "\" type=\"text\"     active=\"on\" style=\"width:100%;\" class=\"k-textbox\"/></div></td>\n          </tr>";
        $("#tablesFields").append(templ);
        if (!nonTablMode) {
            OFTools.createComboBox("ofs-tabl-" + index, dataSourceTable, function (Fname_start) {
                $("#ofs-fiel-" + index).val(Fname_start).rules("remove", "regex");
                $("#ofs-fiel-" + index).rules("add", {
                    regex: new RegExp("^" + Fname_start + "[A-Z0-9]{2,15}$", "g"),
                    messages: { regex: "Строка должна начинаться с имени таблицы и иметь формат: " + Fname_start + "[A-Z0-9]{2,15}" }
                });
            }, 400);
        }
        var curr_select_type = "";
        OFTools.createComboBox('ofs-type-' + index, dataSourceDataTypes, function (select_type) {
            curr_select_type = select_type;
            console.log(select_type);
            OFTools.showHideTibleFieldsColumns(index, 6, "hide");
            OFTools.showHideTibleFieldsColumns(index, 5, "hide");
            var DataTypes = OFTools.DataTypesFMode(select_type.trim());
            if (DataTypes.p == "w")
                OFTools.showHideTibleFieldsColumns(index, 6, "show");
            if (DataTypes.s == "w")
                OFTools.showHideTibleFieldsColumns(index, 5, "show");
        }, 400);
        if (!nonTablMode) {
            $("#ofs-tabl-" + index).rules("add", {
                required: true,
                minlength: 3,
                regex: /^[A-Z]{1}[0-9]{2}\s$/,
                messages: {
                    required: 'Выберите имя таблицы!'
                }
            });
        }
        if (tablName == "")
            $("#ofs-fiel-" + index).rules("add", {
                required: false,
                regex: /[0-9]{1000}\s/,
                messages: {
                    required: 'Введите имя поля!',
                    regex: "Выберите имя таблицы!"
                }
            });
        else
            $("#ofs-fiel-" + index).rules("add", {
                required: false,
                regex: new RegExp("^" + tablName + "[0-9A-Z_]{2,20}$", "g"),
                messages: {
                    required: 'Введите имя поля!',
                    regex: "Строка должна иметь формат: ^" + tablName + "[0-9A-Z_]{2,20}$"
                }
            });
        if (index == 1)
            $("#ofs-fiel-" + index).rules("add", {
                required: true,
            });
        $("#ofs-type-" + index).rules("add", {
            required: false,
            messages: {
                required: 'Введите тип поля!'
            }
        });
        $("#ofs-size-" + index).rules("add", {
            required: false,
            regex: /^[0-9]+$/
        });
        $("#ofs-pres-" + index).rules("add", {
            required: false,
            regex: /^[0-9]+$/
        });
        $("#ofs-brie-" + index).rules("add", {
            required: false,
            minlength: 2
        });
        $("#ofs-full-" + index).rules("add", {
            required: false,
            minlength: 4
        });
        OFTools.showHideTibleFieldsColumns(index, 5, "hide");
        OFTools.showHideTibleFieldsColumns(index, 6, "hide");
        var cc = $("#tablesFields").attr("indexcount");
        $("#tablesFields").attr("indexcount", parseInt(cc) + 1);
        $("#ofs1-indexcount").val(parseInt(cc));
        $("#ofs-fiel-" + index).on("click", function () {
            var currVal = $(this).val();
            if (currVal == "") {
                $(this).val($("#tablesFields").attr("tablName"));
            }
        });
        if (nonTablMode) {
            $(".ofs-h-" + index).css("display", "none");
            $("#ofs-fiel-" + index).on("input propertychange", function () {
                var currVal = $(this).val();
                var currTabN = $("#tablesFields").attr("tablName");
                if ((currVal != "") && (currVal != currTabN) && (currVal.length > 3)) {
                    $(".ofs-h-" + index).css("display", "block");
                    offOnValidation(index, true);
                }
                else {
                    $(".ofs-h-" + index).css("display", "none");
                    offOnValidation(index, false);
                }
            });
        }
        if (!nonTablMode) {
            $(".ofs-h-" + index).css("display", "block");
            offOnValidation(index, true);
        }
    },
    getForm: function (xmlData, finishCallback) {
        if (xmlData === void 0) { xmlData = ""; }
        if (finishCallback === void 0) { finishCallback = function () { }; }
        var mythis = this, prevals, editMode = false;
        if (xmlData !== "") {
            prevals = (ATools.DataSourceFromXml(xmlData, "Field"))[0];
            editMode = true;
        }
        var form1Proto = "\n          <form id=\"CreateOrderForm\">\n            <table role=\"grid\" id=\"tablesFields\" tablName=\"\" >\n             <thead class=\"k-grid-header\" role=\"rowgroup\">\n              <tr>\n                <th class=\"k-header\" style=\"width:  80px;\"> \u0422\u0430\u0431\u043B\u0438\u0446\u0430  </th>\n                <th class=\"k-header\" style=\"width: 100px;\"> \u041F\u043E\u043B\u0435     </th> \n                <th class=\"k-header\" style=\"width: 100px;\"> \u0422\u0438\u043F      </th>\n                <th class=\"k-header\" style=\"width:  65px;\"> Default  </th>\n                <th class=\"k-header\" style=\"width:  65px;\"> \u0420\u0430\u0437\u043C\u0435\u0440   </th>\n                <th class=\"k-header\" style=\"width:  65px;\"> \u0422\u043E\u0447\u043D\u043E\u0441\u0442\u044C </th>\n                <th class=\"k-header\" style=\"width:  55px;\"> Nullable </th>\n                <th class=\"k-header\"                      > \u041A\u0440\u0430\u0442\u043A\u043E   </th>\n                <th class=\"k-header\"                      > \u041F\u043E\u0434\u0440\u043E\u0431\u043D\u043E </th>\n              </tr>\n             </thead>              \n            </table>\n            <button class=\"k-button k-primary ofs-submit\" id=\"sdadwd2\" type=\"submit\">\u041F\u0440\u0438\u043D\u044F\u0442\u044C</button>\n          </form>";
        DataBaseControl.SendRequest(XMLquery.getSchemaList(), function (xml) {
            $(".forInsertionForms").html(form1Proto);
            $.validator.setDefaults({ submitHandler: function () { finishCallback(mythis.getXmlData, editMode); }, ignore: "" });
            $("#CreateOrderForm").validate({});
            var DataSourceDataTypes1 = OFTools.pickDataSource(QueryCache.storage.DataTypes.xml, 'DataTypes > DataType', { value: 'ID', text: 'ID| |BaseType|(|OracleType|)/|Size|/|BriefText' });
            var DataSourceTable1 = OFTools.pickDataSource(xml, 'ObjectRefs > ObjectRef', { value: 'ID', text: 'ID| : |BriefText' }, 'ObjectType=TABLE');
            mythis.addFieldForm(1, DataSourceDataTypes1, DataSourceTable1);
            if (xmlData !== "") {
                OFTools.setValComboBox("ofs-tabl-1", prevals.TableID, true);
                OFTools.setValInput("ofs-fiel-1", prevals.ID);
                if (prevals.Type.indexOf("(") > 0)
                    prevals.Type = prevals.Type.substr(0, prevals.Type.indexOf("("));
                OFTools.setValComboBox("ofs-type-1", prevals.Type, true);
                var DataTypes = OFTools.DataTypesFMode(prevals.Type);
                if (DataTypes.p == "w")
                    OFTools.setValInput("ofs-pres-1", prevals.Precision);
                if (DataTypes.s == "w")
                    OFTools.setValInput("ofs-size-1", prevals.Size);
                OFTools.setValInput("ofs-deff-1", prevals.DefVal);
                OFTools.setValCheckInput("ofs-null-1", prevals.Nullable);
                OFTools.setValInput("ofs-brie-1", prevals.BriefText);
                OFTools.setValInput("ofs-full-1", prevals.FullText);
                xmlData = "";
            }
        });
    },
    getXmlData: function (data) {
        var result = "<Subject> \n               <Action>add</Action> \n               <ObjectType>FIELD</ObjectType>\n               <Object>  \n                 <Field    ID=\"" + data["ofs-fiel-1"] + "\"> \n                   <TableID   >" + data["ofs-tabl-1"] + "</TableID> \n                   <Type      >" + data["ofs-type-1"] + "</Type> \n                   <Size      >" + data["ofs-size-1"] + "</Size> \n                   <DefVal    >" + data["ofs-deff-1"] + "</DefVal> \n                   <Precision >" + data["ofs-pres-1"] + "</Precision>  \n                   <Nullable  >" + data["ofs-null-1"] + "</Nullable> \n                   <BriefText >" + data["ofs-brie-1"] + "</BriefText> \n                   <FullText  >" + data["ofs-full-1"] + "</FullText> \n                   <Position></Position>\n                 </Field>      \n               </Object>       \n             </Subject>";
        return result;
    },
});
pOrdersForms.push({
    label: "Добавить индекс",
    labelXml: "ADD INDEX",
    getForm: function (xmlData, finishCallback) {
        if (xmlData === void 0) { xmlData = ""; }
        if (finishCallback === void 0) { finishCallback = function () { }; }
        var mythis = this, prevals, editMode = false;
        if (xmlData !== "") {
            prevals = (ATools.DataSourceFromXml(xmlData, "Index"))[0];
            prevals.Fields = ATools.FieldsFromXml(prevals.Fields);
            editMode = true;
        }
        var form1Proto = "\n          <form id=\"CreateOrderForm\">\n            <table role=\"grid\">\n             <thead class=\"k-grid-header\" role=\"rowgroup\">\n              <tr>\n                <th class=\"k-header\" style=\"width:  80px;\"> \u0422\u0430\u0431\u043B\u0438\u0446\u0430    </th>\n                <th class=\"k-header\" style=\"width: 100px;\"> \u0418\u043D\u0434\u0435\u043A\u0441     </th>\n                <th class=\"k-header\" style=\"width:75px;\"  > \u0423\u043D\u0438\u043A\u0430\u043B\u044C\u043D\u044B\u0439 </th>\n                <th class=\"k-header\" style=\"width:105px;\" > \u0424\u0443\u043D\u043A\u0446\u0438\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0439 </th>\n                <th class=\"k-header\"> \u041F\u043E\u043B\u044F     </th>\n              </tr>\n             </thead>\n             <tr>\n                <td class=\"td\"> <input id=\"ofs1-tabl\" name=\"tabl\" type=\"text\"     active=\"on\" /> </td>\n                <td class=\"td\"> <input id=\"ofs1-inde\" name=\"inde\" type=\"text\"     active=\"on\" class=\"k-textbox\" style=\"width:100%;\" /> </td>\n                <td class=\"td\"> <span class=\"cb\">\n                                <input id=\"ofs1-uniq\" name=\"uniq\" type=\"checkbox\" active=\"on\"><label for=\"ofs1-uniq\"/></span> \n                </td>\n                <td class=\"td\"> <span class=\"cb\">\n                                <input id=\"ofs1-func\" name=\"func\" type=\"checkbox\" active=\"on\"><label for=\"ofs1-func\"/></span> \n                </td>\n                <td class=\"td\"> <input id=\"ofs1-fiel\" name=\"fiel\" type=\"text\"     active=\"on\" style=\"width:100%;\" /> \n                                <input id=\"ofs1-tech\" name=\"tech\" type=\"text\"     active=\"on\" class=\"k-textbox\" style=\"width:100%;\" />\n                </td>                \n              </tr>\n            </table>\n            <button class=\"k-button k-primary ofs-submit\" id=\"sdadwd2\" type=\"submit\">\u041F\u0440\u0438\u043D\u044F\u0442\u044C</button>\n          </form>";
        var getSchemaListStr = "";
        var currfields;
        if (pOrders.currOrderNumber == -1)
            getSchemaListStr = XMLquery.getSchemaList();
        else
            getSchemaListStr = XMLquery.getSchemaList2(pOrders.currOrderNumber);
        DataBaseControl.SendRequest(getSchemaListStr, function (xml) {
            $(".forInsertionForms").html(form1Proto);
            OFTools.createComboBox("ofs1-tabl", OFTools.pickDataSource(xml, "ObjectRefs > ObjectRef", { value: "ID", text: "ID| : |BriefText" }, "ObjectType=TABLE"), function (Fname_start) {
                $("#ofs1-inde").val("I" + Fname_start).rules("remove", "regex");
                $("#ofs1-inde").rules("add", {
                    regex: new RegExp("^I" + Fname_start + "[A-Z0-9_]{2,15}$", "g"),
                    messages: { regex: "Строка должна начинаться с имени таблицы и иметь формат: ^I" + Fname_start + "[A-Z0-9_]{2,15}$" }
                });
                var reqXMLstr = '';
                if (pOrders.currOrderNumber == -1)
                    reqXMLstr = XMLquery.FieldsByTabName(Fname_start);
                else
                    reqXMLstr = XMLquery.FieldsByTabName2(Fname_start, pOrders.currOrderNumber);
                $("#ofs1-tech").val("");
                DataBaseControl.SendRequest(reqXMLstr, function (xml2) {
                    var fields = OFTools.pickDataSource(xml2, "Table > Fields > Field", { value: "ID", text: "ID| |Type" });
                    currfields = fields;
                    OFTools.loadMultiSelect("ofs1-fiel", fields);
                });
            }, 400);
            OFTools.createMultiSelect("ofs1-fiel", [], function (x) {
                var ofs1Tech = $("#ofs1-fiel").val();
                if (ofs1Tech.length > 1)
                    $("#ofs1-tech").val(ofs1Tech.replace(new RegExp("\\|", 'g'), "; "));
            }, 400);
            $.validator.setDefaults({ submitHandler: function () { finishCallback(mythis.getXmlData, editMode); }, ignore: "" });
            $("#CreateOrderForm").validate({
                rules: {
                    tabl: {
                        required: true,
                        minlength: 3,
                        regex: /^[A-Z]{1}[0-9]{2}\s$/
                    },
                    inde: {
                        required: true,
                        regex: /[0-9]{1000}\s/
                    },
                    fiel: {
                        required: false
                    }
                },
                messages: {
                    tabl: {
                        required: "Выберите имя таблицы!"
                    },
                    inde: {
                        required: "Введите имя поля!",
                        regex: "Выберите имя таблицы!"
                    }
                }
            });
            $("#CreateOrderForm .k-dropdown-wrap:eq(1)").css("display", "none");
            $("#CreateOrderForm .k-combobox:eq(1)").css("position", "absolute");
            $("#CreateOrderForm .k-combobox:eq(1)").css("marginTop", "26px");
            $("#ofs1-tech").css("display", "none");
            $("#ofs1-func").on('click', function () {
                $("#ofs1-tech").val("");
                OFTools.setValMultiSelect("ofs1-fiel", []);
                if ($("#ofs1-tech").css("display") == "none") {
                    $("#ofs1-tech").css("display", "block");
                    $(".k-multiselect").css("display", "none");
                }
                else {
                    $("#ofs1-tech").css("display", "none");
                    $(".k-multiselect").css("display", "block");
                }
            });
            if (xmlData !== "") {
                OFTools.setValComboBox("ofs1-tabl", prevals.TableID, true);
                OFTools.setValInput("ofs1-inde", prevals.ID);
                OFTools.setValCheckInput("ofs1-uniq", prevals.Uniqueness);
                setTimeout(function () {
                    var itog = "";
                    var jjoin = (prevals.Fields.join(" "));
                    for (var i = 0; i < currfields.length; i++)
                        itog += "|" + currfields[i].value;
                    var pattern = new RegExp("[" + itog.substr(1) + "]+", 'g');
                    var resu = jjoin.split(pattern);
                    var isFunc = false;
                    for (var j = 0; j < resu.length; j++) {
                        if ((resu[j] + "").trim().length > 0)
                            isFunc = true;
                    }
                    console.log(isFunc);
                    if (isFunc) {
                        OFTools.setValCheckInput("ofs1-func", "Y");
                        $("#ofs1-tech").css("display", "block");
                        $(".k-multiselect").css("display", "none");
                        OFTools.setValInput("ofs1-tech", prevals.Fields.join('; '));
                    }
                    else {
                        OFTools.setValMultiSelect("ofs1-fiel", prevals.Fields);
                    }
                }, 1000);
            }
        });
    },
    getXmlData: function (data) {
        var result = "<Subject>\n               <Action>add</Action>\n               <ObjectType>INDEX</ObjectType>\n               <Object>\n                 <Index    ID=\"" + data["ofs1-inde"] + "\">\n                   <TableID   >" + data["ofs1-tabl"] + "</TableID> \n                   <Uniqueness>" + data["ofs1-uniq"] + "</Uniqueness>\n                   <Fields    >" + OFTools.constructXmlFields(data["ofs1-tech"].split(';'), data["ofs1-tabl"]) + "</Fields>\n                   <Type></Type>\n                 </Index>\n               </Object>\n             </Subject>";
        return result;
    }
});
pOrdersForms.push({
    label: "Добавить запрос",
    labelXml: "ADD QUERY",
    getForm: function (xmlData, finishCallback) {
        if (xmlData === void 0) { xmlData = ""; }
        if (finishCallback === void 0) { finishCallback = function () { }; }
        var mythis = this, prevals, editMode = false;
        if (xmlData !== "") {
            prevals = (ATools.DataSourceFromXml(xmlData, "Query"))[0];
            editMode = true;
        }
        var form1Proto = "\n          <style>\n            #CreateOrderForm th { padding: 5px 0px 0px 7px; }\n          </style>\n          <form id=\"CreateOrderForm\">\n            <table role=\"grid\" style=\"width:  300px;\">\n              <thead class=\"k-grid-header\" role=\"rowgroup\"><tr><th class=\"k-header\">\u0418\u043C\u044F \u0437\u0430\u043F\u0440\u043E\u0441\u0430</th></tr></thead>\n              <tr><td class=\"td\"> <input id=\"ofs1-name\" name=\"name\" type=\"text\" active=\"on\" class=\"k-textbox\" style=\"width:100%;\" /></td></tr>\n              \n              <thead class=\"k-grid-header\" role=\"rowgroup\"><tr><th class=\"k-header\">\u0422\u0435\u043A\u0441\u0442 \u0437\u0430\u043F\u0440\u043E\u0441\u0430 (\u043D\u0435 \u0431\u043E\u043B\u0435\u0435 20000 \u0431\u0430\u0439\u0442)</th></tr></thead>\n              <tr><td class=\"td\" style=\"position: relative;\"> <textarea  id=\"ofs1-reqv\" name=\"reqv\" active=\"on\"  type=\"text\" rows=\"7\" style=\"width: 100%;\" class=\"k-textbox\" ></textarea><div class=\"editico edit_Body_m\" style=\"right: 7px; top: 110px;\" ></div></td></tr>\n             \n              <thead class=\"k-grid-header\" role=\"rowgroup\"><tr><th class=\"k-header\">\u041A\u043E\u043C\u043C\u0435\u043D\u0442\u0430\u0440\u0438\u0439</th></tr></thead>\n              <tr><td class=\"td\"> <input id=\"ofs1-comm\" name=\"comm\" type=\"text\" active=\"on\" class=\"k-textbox\" style=\"width:100%;\" /></td></tr>\n              \n            </table>\n            <button class=\"k-button k-primary ofs-submit\" id=\"sdadwd2\" type=\"submit\">\u041F\u0440\u0438\u043D\u044F\u0442\u044C</button>\n          </form>";
        $(".forInsertionForms").html(form1Proto);
        $.validator.setDefaults({ submitHandler: function () { finishCallback(mythis.getXmlData, editMode); }, ignore: "" });
        $("#CreateOrderForm").validate({
            rules: {
                name: {
                    required: true,
                    regex: /^[A-Za-z0-9_]{2,}$/
                },
                reqv: {
                    required: true,
                    minlength: 10,
                    maxlength: 2000
                },
                comm: {
                    required: true
                }
            },
            messages: {
                name: {
                    regex: "Строка должна иметь формат: ^[A-Za-z0-9_]{2,}$"
                }
            }
        });
        $(".edit_Body_m").on("click", function () {
            OFTools.SqlEditor($("#ofs1-reqv").val(), { gutter: true }, function (ret) { $("#ofs1-reqv").val(ret); });
        });
        if (xmlData !== "") {
            OFTools.setValInput("ofs1-name", prevals.ID);
            OFTools.setValInput("ofs1-reqv", prevals.Body);
            OFTools.setValInput("ofs1-comm", prevals.BriefText);
            xmlData = "";
        }
    },
    getXmlData: function (data) {
        var result = "<Subject>\n               <Action>add</Action>\n               <ObjectType>QUERY</ObjectType>\n               <Object>\n                 <Query   ID=\"" + data["ofs1-name"] + "\">\n                   <Body     >" + data["ofs1-reqv"] + "</Body>\n                   <BriefText>" + data["ofs1-comm"] + "</BriefText>\n                 </Query>\n               </Object>\n             </Subject>";
        return result;
    }
});
pOrdersForms.push({
    label: "Добавить последовательность",
    labelXml: "ADD SEQN",
    getForm: function (xmlData, finishCallback) {
        if (xmlData === void 0) { xmlData = ""; }
        if (finishCallback === void 0) { finishCallback = function () { }; }
        var mythis = this, prevals, editMode = false;
        if (xmlData !== "") {
            prevals = (ATools.DataSourceFromXml(xmlData, "Sequence"))[0];
            editMode = true;
        }
        var form1Proto = "\n          <style>\n            #CreateOrderForm th { padding: 5px 0px 0px 7px; }\n          </style>\n          <form id=\"CreateOrderForm\">\n            <table role=\"grid\" style=\"width:  300px;\">\n              <thead class=\"k-grid-header\" role=\"rowgroup\"><tr><th class=\"k-header\">\u0418\u043C\u044F \u043F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u0438</th></tr></thead>\n              <tr><td class=\"td\"> <input id=\"ofs1-name\" name=\"name\" type=\"text\" active=\"on\" class=\"k-textbox\" style=\"width:100%;\" /></td></tr>\n              \n              <thead class=\"k-grid-header\" role=\"rowgroup\"><tr><th class=\"k-header\">\u041A\u043E\u043C\u043C\u0435\u043D\u0442\u0430\u0440\u0438\u0439</th></tr></thead>\n              <tr><td class=\"td\"> <input id=\"ofs1-bref\" name=\"bref\" type=\"text\" active=\"on\" class=\"k-textbox\" style=\"width:100%;\" /></td></tr>\n              \n              <thead class=\"k-grid-header\" role=\"rowgroup\"><tr><th class=\"k-header\">\u041D\u0430\u0447\u0430\u0442\u044C \u0441</th></tr></thead>\n              <tr><td class=\"td\"> <input id=\"ofs1-star\" name=\"star\" type=\"text\" active=\"on\" class=\"k-textbox\" style=\"width:100%;\" /></td></tr>\n              \n              <thead class=\"k-grid-header\" role=\"rowgroup\"><tr><th class=\"k-header\">\u0418\u043D\u043A\u0440\u0435\u043C\u0435\u043D\u0442</th></tr></thead>\n              <tr><td class=\"td\"> <input id=\"ofs1-incr\" name=\"incr\" type=\"text\" active=\"on\" class=\"k-textbox\" style=\"width:100%;\" /></td></tr>\n              \n              <thead class=\"k-grid-header\" role=\"rowgroup\"><tr><th class=\"k-header\">\u041C\u0438\u043D\u0438\u043C\u0430\u043B\u044C\u043D\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435</th></tr></thead>\n              <tr><td class=\"td\"> <input id=\"ofs1-minn\" name=\"minn\" type=\"text\" active=\"on\" class=\"k-textbox\" style=\"width:100%;\" /></td></tr>\n              \n              <thead class=\"k-grid-header\" role=\"rowgroup\"><tr><th class=\"k-header\">\u041C\u0430\u043A\u0441\u0438\u043C\u0430\u043B\u044C\u043D\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435</th></tr></thead>\n              <tr><td class=\"td\"> <input id=\"ofs1-maxx\" name=\"maxx\" type=\"text\" active=\"on\" class=\"k-textbox\" style=\"width:100%;\" /></td></tr>\n              \n              <thead class=\"k-grid-header\" role=\"rowgroup\"><tr><th class=\"k-header\">CycleFlg</th></tr></thead>\n              <td class=\"td\" style=\"height: 25px;\"><span class=\"cb\"><input id=\"ofs1-cycl\" name=\"cycl\" type=\"checkbox\" active=\"on\"><label for=\"ofs1-cycl\"/></span></td>\n\n              <thead class=\"k-grid-header\" role=\"rowgroup\"><tr><th class=\"k-header\">\u041F\u043E\u0440\u044F\u0434\u043E\u043A</th></tr></thead>\n              <td class=\"td\" style=\"height: 25px;\"><span class=\"cb\"><input id=\"ofs1-orde\" name=\"orde\" type=\"checkbox\" active=\"on\"><label for=\"ofs1-orde\"/></span></td>\n\n              <thead class=\"k-grid-header\" role=\"rowgroup\"><tr><th class=\"k-header\">\u041A\u0435\u0448</th></tr></thead>\n              <tr><td class=\"td\"> <input id=\"ofs1-cach\" name=\"cach\" type=\"text\" active=\"on\" class=\"k-textbox\" style=\"width:100%;\" /></td></tr>\n            </table>\n            <button class=\"k-button k-primary ofs-submit\" id=\"sdadwd2\" type=\"submit\">\u041F\u0440\u0438\u043D\u044F\u0442\u044C</button>\n          </form>";
        $(".forInsertionForms").html(form1Proto);
        $.validator.setDefaults({ submitHandler: function () { finishCallback(mythis.getXmlData, editMode); }, ignore: "" });
        $("#CreateOrderForm").validate({
            rules: {
                name: {
                    required: true,
                    regex: /^[A-Z0-9_]{2,}$/
                },
                bref: {
                    required: true
                },
                star: {
                    required: true,
                    number: true
                },
                incr: {
                    required: true,
                    number: true
                },
                minn: {
                    required: true,
                    number: true
                },
                maxx: {
                    required: true,
                    number: true
                },
                cach: {
                    required: true,
                    number: true
                }
            },
            messages: {
                name: {
                    regex: "Строка должна иметь формат: ^[A-Z0-9_]{2,}$"
                }
            }
        });
        if (xmlData !== "") {
            OFTools.setValInput("ofs1-name", prevals.ID);
            OFTools.setValInput("ofs1-star", prevals.StartWith);
            OFTools.setValInput("ofs1-incr", prevals.IncrBy);
            OFTools.setValInput("ofs1-minn", prevals.MinValue);
            OFTools.setValInput("ofs1-maxx", prevals.MaxValue);
            OFTools.setValInput("ofs1-cach", prevals.CacheSize);
            OFTools.setValCheckInput("ofs1-cycl", prevals.CycleFlg);
            OFTools.setValCheckInput("ofs1-orde", prevals.OrderFlg);
            OFTools.setValInput("ofs1-bref", prevals.BriefText);
            xmlData = "";
        }
    },
    getXmlData: function (data) {
        var result = "<Subject>\n               <Action>add</Action>\n               <ObjectType>SEQN</ObjectType>\n               <Object>\n                 <Sequence ID=\"" + data["ofs1-name"] + "\">\n                   <StartWith >" + data["ofs1-star"] + "</StartWith>\n                   <IncrBy    >" + data["ofs1-incr"] + "</IncrBy>\n                   <MinValue  >" + data["ofs1-minn"] + "</MinValue>\n                   <MaxValue  >" + data["ofs1-maxx"] + "</MaxValue>\n                   <CacheSize >" + data["ofs1-cach"] + "</CacheSize>\n                   <CycleFlg  >" + data["ofs1-cycl"] + "</CycleFlg>\n                   <OrderFlg  >" + data["ofs1-orde"] + "</OrderFlg>\n                   <BriefText >" + data["ofs1-bref"] + "</BriefText>\n                 </Sequence>\n               </Object>\n             </Subject>";
        return result;
    }
});
pOrdersForms.push({
    label: 'Добавить таблицу',
    labelXml: 'add TABLE',
    temp: { DataSourceDataTypes: {}, DataSourceTable: {} },
    getForm: function (xmlData, finishCallback) {
        if (xmlData === void 0) { xmlData = ""; }
        if (finishCallback === void 0) { finishCallback = function () { }; }
        var mythis = this, prevals, editMode = false;
        if (xmlData !== "") {
            prevals = (ATools.DataSourceFromXml(xmlData, "Table"))[0];
            prevals.Fields = ATools.DataSourceFromXml("<Fields>" + prevals.Fields + "</Fields>", "Field");
            editMode = true;
        }
        var form1Proto = "\n          <form id=\"CreateOrderForm\">\n            \n            <table role=\"grid\">\n             <thead class=\"k-grid-header\" role=\"rowgroup\">\n              <tr>\n                <th class=\"k-header\" style=\"width:  80px;\"> \u0418\u043C\u044F \u0442\u0430\u0431\u043B\u0438\u0446\u044B </th>\n                <th class=\"k-header\" style=\"width: 200px;\"> \u041A\u0440\u0430\u0442\u043A\u043E      </th>\n                <th class=\"k-header\"                      > \u041F\u043E\u0434\u0440\u043E\u0431\u043D\u043E    </th>\n              </tr>\n             </thead>\n              <tr>\n                <td class=\"td\" style=\"display:none;\"> <input id=\"ofs1-indexcount\" name=\"indexcount\" type=\"text\" active=\"on\" /> </td>\n                <td class=\"td upp\"> <input id=\"ofs1-tabl\" name=\"tabl\" type=\"text\" active=\"on\" class=\"k-textbox\" style=\"width:100%;\" /> </td>\n                <td class=\"td\"> <input id=\"ofs1-bref\" name=\"bref\" type=\"text\" active=\"on\" class=\"k-textbox\" style=\"width:100%;\" /> </td>\n                <td class=\"td\"> <input id=\"ofs1-full\" name=\"full\" type=\"text\" active=\"on\" class=\"k-textbox\" style=\"width:100%;\" /> </td>\n               </tr>\n            </table>\n\n            <br>\n\n            <a style=\"margin:10px 0px 9px 0px;\" \n               onclick=\"OFTools.add_field()\" \n               class=\"k-button k-button-icontext k-grid-add\" href=\"#\">\n               <span class=\"k-icon k-add\"></span>\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u043F\u043E\u043B\u0435\n            </a>\n              \n            <table role=\"grid\" id=\"tablesFields\" tablName=\"\" indexcount=\"1\">\n             <thead class=\"k-grid-header\" role=\"rowgroup\">\n              <tr>\n                <th class=\"k-header\" style=\"width:  80px;\"> \u0422\u0430\u0431\u043B\u0438\u0446\u0430  </th>\n                <th class=\"k-header\" style=\"width: 100px;\"> \u041F\u043E\u043B\u0435     </th>\n                <th class=\"k-header\" style=\"width: 100px;\"> \u0422\u0438\u043F      </th> \n                <th class=\"k-header\" style=\"width:  65px;\"> Default  </th>\n                <th class=\"k-header\" style=\"width:  65px;\"> \u0420\u0430\u0437\u043C\u0435\u0440   </th>\n                <th class=\"k-header\" style=\"width:  65px;\"> \u0422\u043E\u0447\u043D\u043E\u0441\u0442\u044C </th>\n                <th class=\"k-header\" style=\"width:  55px;\"> Nullable </th>\n                <th class=\"k-header\"                      > \u041A\u0440\u0430\u0442\u043A\u043E   </th>\n                <th class=\"k-header\"                      > \u041F\u043E\u0434\u0440\u043E\u0431\u043D\u043E </th>\n              </tr>\n             </thead>              \n            </table>\n\n            <button class=\"k-button k-primary ofs-submit\" id=\"sdadwd2\" type=\"submit\">\u041F\u0440\u0438\u043D\u044F\u0442\u044C</button>\n          </form>";
        DataBaseControl.SendRequest(XMLquery.getSchemaList(), function (xml) {
            $(".forInsertionForms").html(form1Proto);
            $.validator.setDefaults({ submitHandler: function () { finishCallback(mythis.getXmlData, editMode); }, ignore: "" });
            $("#CreateOrderForm").validate({
                rules: {
                    tabl: {
                        required: true,
                        minlength: 3,
                        regex: /^[A-Z0-9]{3,9}\s*$/
                    },
                    bref: {
                        required: true,
                        minlength: 4,
                    },
                    full: {
                        required: true,
                        minlength: 4,
                    },
                },
                messages: {
                    tabl: {
                        required: 'Введите имя таблицы!',
                        regex: "Строка должна иметь формат: ^[A-Z0-9]{3,9}\s*$"
                    }
                }
            });
            mythis.temp.DataSourceDataTypes = OFTools.pickDataSource(QueryCache.storage.DataTypes.xml, 'DataTypes > DataType', { value: 'ID', text: 'ID| |BaseType|(|OracleType|)/|Size|/|BriefText' });
            mythis.temp.DataSourceTable = OFTools.pickDataSource(xml, 'ObjectRefs > ObjectRef', { value: 'ID', text: 'ID| : |BriefText' }, 'ObjectType=TABLE');
            OFTools.showHideTibleFieldsColumns(-1, 1, "hide");
            for (var j = 1; j < 5; j++) {
                OFTools.add_field();
            }
            $("#ofs1-tabl").on("input propertychange", function () {
                var thisval = ($(this).val()).trim();
                $("#tablesFields .fnx input").each(function (i, x) {
                    $("#" + $(x).attr("id")).rules("add", {
                        regex: new RegExp("^" + thisval + "[0-9A-Z_]{2,20}$", "g"),
                        messages: { regex: "Строка должна иметь формат: ^" + thisval + "[0-9A-Z_]{2,20}$" }
                    });
                });
                $("#tablesFields").attr("tablName", thisval);
            });
            if (xmlData !== "") {
                OFTools.setValInput("ofs1-tabl", prevals.ID, true);
                OFTools.setValInput("ofs1-bref", prevals.BriefText);
                OFTools.setValInput("ofs1-full", prevals.FullText);
                for (var l = 0; l < prevals.Fields.length - 4; l++)
                    $(".k-grid-add").trigger("click");
                setTimeout(function () {
                    for (var k = 0; k < prevals.Fields.length; k++) {
                        OFTools.setValInput("ofs-fiel-" + (k + 1), prevals.Fields[k].ID, true);
                        if (prevals.Fields[k].Type.indexOf("(") > 0)
                            prevals.Fields[k].Type = prevals.Fields[k].Type.substr(0, prevals.Fields[k].Type.indexOf("("));
                        OFTools.setValComboBox("ofs-type-" + (k + 1), prevals.Fields[k].Type, true);
                        OFTools.setValInput("ofs-size-" + (k + 1), prevals.Fields[k].Size);
                        OFTools.setValInput("ofs-pres-" + (k + 1), prevals.Fields[k].Precision);
                        OFTools.setValCheckInput("ofs-deff-" + (k + 1), prevals.Fields[k].DefVal);
                        OFTools.setValCheckInput("ofs-null-" + (k + 1), prevals.Fields[k].Nullable);
                        OFTools.setValInput("ofs-brie-" + (k + 1), prevals.Fields[k].BriefText);
                        OFTools.setValInput("ofs-full-" + (k + 1), prevals.Fields[k].FullText);
                    }
                }, 1000);
                xmlData = "";
            }
        });
    },
    getXmlData: function (data) {
        var fields = "";
        for (var i = 1; i <= parseInt(data["ofs1-indexcount"]); i++) {
            if (data["ofs-fiel-" + i] != "")
                fields +=
                    "<Field   ID=\"" + data["ofs-fiel-" + i] + "\">\n                       <TableID  >" + data["ofs1-tabl"] + "</TableID>\n                       <Type     >" + data["ofs-type-" + i] + "</Type>\n                       <DefVal   >" + data["ofs-deff-" + i] + "</DefVal> \n                       <Size     >" + data["ofs-size-" + i] + "</Size>\n                       <Precision>" + data["ofs-pres-" + i] + "</Precision>\n                       <Position>0</Position>\n                       <Nullable >" + data["ofs-null-" + i] + "</Nullable>\n                       <BriefText>" + data["ofs-brie-" + i] + "</BriefText>\n                       <FullText >" + data["ofs-full-" + i] + "</FullText>\n                     </Field>";
        }
        var result = "<Subject>\n                   <Action>add</Action>\n                   <ObjectType>TABLE</ObjectType>\n                   <Object>\n                     <Table ID=\"" + data["ofs1-tabl"] + "\">\n                     <Fields   >" + fields + "</Fields>\n                     <BriefText>" + data["ofs1-bref"] + "</BriefText>\n                     <FullText >" + data["ofs1-full"] + "</FullText>\n                     </Table>\n                   </Object>\n                 </Subject>";
        return ATools.myXmlTrim(result);
    }
});
pOrdersForms.push({
    label: "Добавить представление",
    labelXml: "ADD VIEW",
    getForm: function (xmlData, finishCallback) {
        if (xmlData === void 0) { xmlData = ""; }
        if (finishCallback === void 0) { finishCallback = function () { }; }
        var mythis = this, prevals, editMode = false;
        if (xmlData !== "") {
            prevals = (ATools.DataSourceFromXml(xmlData, "View"))[0];
            editMode = true;
        }
        var form1Proto = "\n          <style>\n            #CreateOrderForm th { padding: 5px 0px 0px 7px; }\n          </style>\n          <form id=\"CreateOrderForm\">\n            <table role=\"grid\" style=\"width:  300px;\">\n              <thead class=\"k-grid-header\" role=\"rowgroup\"><tr><th class=\"k-header\">\u0418\u043C\u044F \u043F\u0440\u0435\u0434\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u0438\u044F</th></tr></thead>\n              <tr><td class=\"td\"> <input id=\"ofs1-name\" name=\"name\" type=\"text\" active=\"on\" class=\"k-textbox\" style=\"width:100%;\" /></td></tr>\n              \n              <thead class=\"k-grid-header\" role=\"rowgroup\"><tr><th class=\"k-header\">\u0421\u043E\u0434\u0435\u0440\u0436\u0430\u0442\u0435\u043B\u044C\u043D\u0430\u044F \u0447\u0430\u0441\u0442\u044C \u0437\u0430\u043F\u0440\u043E\u0441\u0430 (Select ... from)</th></tr></thead>\n              <tr><td class=\"td\" style=\"position: relative;\"> <textarea  id=\"ofs1-reqv\" name=\"reqv\" active=\"on\"  type=\"text\" rows=\"7\" style=\"width: 100%;\" class=\"k-textbox\" ></textarea><div class=\"editico edit_Body_m\" style=\"right: 7px; top: 110px;\" ></div></td></tr>\n             \n              <thead class=\"k-grid-header\" role=\"rowgroup\"><tr><th class=\"k-header\">\u041A\u043E\u043C\u043C\u0435\u043D\u0442\u0430\u0440\u0438\u0439</th></tr></thead>\n              <tr><td class=\"td\"> <input id=\"ofs1-comm\" name=\"comm\" type=\"text\" active=\"on\" class=\"k-textbox\" style=\"width:100%;\" /></td></tr>\n              \n            </table>\n            <button class=\"k-button k-primary ofs-submit\" id=\"sdadwd2\" type=\"submit\">\u041F\u0440\u0438\u043D\u044F\u0442\u044C</button>\n          </form>";
        $(".forInsertionForms").html(form1Proto);
        $.validator.setDefaults({ submitHandler: function () { finishCallback(mythis.getXmlData, editMode); }, ignore: "" });
        $("#CreateOrderForm").validate({
            rules: {
                name: {
                    required: true,
                    regex: /^[A-Z0-9_]{2,}$/
                },
                reqv: {
                    required: true
                },
                comm: {
                    required: true
                }
            },
            messages: {
                name: {
                    regex: "Строка должна иметь формат: ^[A-Z0-9_]{2,}$"
                }
            }
        });
        $(".edit_Body_m").on("click", function () {
            OFTools.SqlEditor($("#ofs1-reqv").val(), { gutter: true }, function (ret) { $("#ofs1-reqv").val(ret); });
        });
        if (xmlData !== "") {
            OFTools.setValInput("ofs1-name", prevals.ID);
            OFTools.setValInput("ofs1-reqv", prevals.Body);
            OFTools.setValInput("ofs1-comm", prevals.BriefText);
            xmlData = "";
        }
    },
    getXmlData: function (data) {
        var result = "<Subject>\n               <Action>add</Action>\n               <ObjectType>VIEW</ObjectType>\n               <Object>\n                 <View    ID=\"" + data["ofs1-name"] + "\">\n                   <Body     >" + data["ofs1-reqv"] + "</Body>\n                   <BriefText>" + data["ofs1-comm"] + "</BriefText>\n                 </View>\n               </Object>\n             </Subject>";
        return result;
    }
});
pOrdersForms.push({
    label: "Удалить констрейнт",
    labelXml: "delete CONSTRAINT",
    constData: {},
    getForm: function (xmlData, finishCallback) {
        if (xmlData === void 0) { xmlData = ""; }
        if (finishCallback === void 0) { finishCallback = function () { }; }
        var mythis = this, prevals, editMode = false;
        if (xmlData !== "") {
            prevals = (ATools.DataSourceFromXml(xmlData, "Constraint"))[0];
            editMode = true;
        }
        var form1Proto = "\n          <style>\n            #CreateOrderForm th { padding: 5px 0px 0px 7px; }\n          </style>\n          <form id=\"CreateOrderForm\">\n            <table role=\"grid\" style=\"width:  300px;\">\n              <thead class=\"k-grid-header\" role=\"rowgroup\"><tr><th class=\"k-header\">\u0422\u0430\u0431\u043B\u0438\u0446\u0430</th></tr></thead>\n              <tr><td class=\"td\"> <input id=\"ofs1-tabl\" name=\"tabl\" type=\"text\" active=\"on\" style=\"width:100%;\" /></td></tr>\n         \n              <thead class=\"k-grid-header\" role=\"rowgroup\"><tr><th class=\"k-header\">\u041A\u043E\u043D\u0441\u0442\u0440\u0435\u0439\u043D\u0442</th></tr></thead>\n              <tr><td class=\"td\"> <input id=\"ofs1-cons\" name=\"cons\" type=\"text\" active=\"on\" style=\"width:100%;\" /></td></tr>\n              \n            </table>\n            <button class=\"k-button k-primary ofs-submit\" id=\"sdadwd2\" type=\"submit\">\u041F\u0440\u0438\u043D\u044F\u0442\u044C</button>\n          </form>";
        DataBaseControl.SendRequest(XMLquery.getSchemaList(), function (xml) {
            $(".forInsertionForms").html(form1Proto);
            OFTools.createComboBox("ofs1-tabl", OFTools.pickDataSource(xml, "ObjectRefs > ObjectRef", { value: "ID", text: "ID| : |BriefText" }, "ObjectType=TABLE"), function (tab) {
                DataBaseControl.SendRequest(XMLquery.FieldsByTabName(tab), function (xmlstr) {
                    var xml = $($.parseXML('<b>' + xmlstr + '</b>'));
                    var index_xml = $(xml).find("Constraints");
                    mythis.constData = xml;
                    var fieldsArr = [];
                    if (index_xml.length > 0) {
                        $(xml).find("Constraints").eq(0).find("Constraint").each(function () {
                            var ID = $(this).attr("ID");
                            fieldsArr[fieldsArr.length] = { value: ID, text: ID };
                        });
                        OFTools.loadDropDownList("ofs1-cons", fieldsArr);
                    }
                    else {
                    }
                });
            }, 400);
            OFTools.createDropDownList("ofs1-cons", [], function () { });
            $.validator.setDefaults({ submitHandler: function () { finishCallback(mythis.getXmlData, editMode); }, ignore: "" });
            $("#CreateOrderForm").validate({
                rules: {
                    tabl: {
                        required: true,
                        regex: /^[A-Z0-9_]{2,}\s*$/
                    },
                    cons: {
                        required: true
                    },
                },
                messages: {
                    tabl: {
                        regex: "Строка должна иметь формат: ^[A-Z0-9_]{2,}\s*$"
                    },
                    cons: {
                        required: "Выберите констрейнт!"
                    },
                }
            });
            if (xmlData !== "") {
                OFTools.setValComboBox("ofs1-tabl", prevals.TableID, true);
                setTimeout(function () {
                    OFTools.setValDropDownList("ofs1-cons", prevals.ID);
                }, 1000);
                xmlData = "";
            }
        });
    },
    getXmlData: function (data) {
        var mythis = this;
        var constData = OFTools.getOrderFormByLabelXml("delete CONSTRAINT").constData;
        var constr = "";
        $(constData).find("Constraints > Constraint").each(function () {
            if ($(this).attr("ID") == data["ofs1-cons"])
                constr = $(this).html();
        });
        var result = "<Subject>\n               <Action>delete</Action>\n               <ObjectType>CONSTRAINT</ObjectType>\n               <Object>\n                 <Constraint ID=\"" + data["ofs1-cons"] + "\">\n                 " + constr + " \n                 </Constraint>\n               </Object>\n             </Subject>";
        return result;
    }
});
pOrdersForms.push({
    label: "Удалить поле",
    labelXml: "delete FIELD",
    constData: {},
    getForm: function (xmlData, finishCallback) {
        if (xmlData === void 0) { xmlData = ""; }
        if (finishCallback === void 0) { finishCallback = function () { }; }
        var mythis = this, prevals, editMode = false;
        if (xmlData !== "") {
            prevals = (ATools.DataSourceFromXml(xmlData, "Field"))[0];
            editMode = true;
        }
        var form1Proto = "\n          <style>\n            #CreateOrderForm th { padding: 5px 0px 0px 7px; }\n          </style>\n          <form id=\"CreateOrderForm\">\n            <table role=\"grid\" style=\"width:  300px;\">\n              <thead class=\"k-grid-header\" role=\"rowgroup\"><tr><th class=\"k-header\">\u0422\u0430\u0431\u043B\u0438\u0446\u0430</th></tr></thead>\n              <tr><td class=\"td\"> <input id=\"ofs1-tabl\" name=\"tabl\" type=\"text\" active=\"on\" style=\"width:100%;\" /></td></tr>\n         \n              <thead class=\"k-grid-header\" role=\"rowgroup\"><tr><th class=\"k-header\">\u041F\u043E\u043B\u0435</th></tr></thead>\n              <tr><td class=\"td\"> <input id=\"ofs1-cons\" name=\"cons\" type=\"text\" active=\"on\" style=\"width:100%;\" /></td></tr>\n              \n            </table>\n            <button class=\"k-button k-primary ofs-submit\" id=\"sdadwd2\" type=\"submit\">\u041F\u0440\u0438\u043D\u044F\u0442\u044C</button>\n          </form>";
        DataBaseControl.SendRequest(XMLquery.getSchemaList(), function (xml) {
            $(".forInsertionForms").html(form1Proto);
            OFTools.createComboBox("ofs1-tabl", OFTools.pickDataSource(xml, "ObjectRefs > ObjectRef", { value: "ID", text: "ID| : |BriefText" }, "ObjectType=TABLE"), function (tab) {
                DataBaseControl.SendRequest(XMLquery.FieldsByTabName(tab), function (xmlstr) {
                    var xml = $($.parseXML('<b>' + xmlstr + '</b>'));
                    mythis.constData = xml;
                    var fieldsArr = [];
                    $(xml).find("Fields").eq(0).find("Field").each(function () {
                        var ID = $(this).attr("ID");
                        fieldsArr[fieldsArr.length] = { value: ID, text: ID };
                    });
                    OFTools.loadDropDownList("ofs1-cons", fieldsArr);
                });
            }, 400);
            OFTools.createDropDownList("ofs1-cons", [], function () { });
            $.validator.setDefaults({ submitHandler: function () { finishCallback(mythis.getXmlData, editMode); }, ignore: "" });
            $("#CreateOrderForm").validate({
                rules: {
                    tabl: {
                        required: true,
                        regex: /^[A-Z0-9_]{2,}\s*$/
                    },
                    cons: {
                        required: true
                    },
                },
                messages: {
                    tabl: {
                        regex: "Строка должна иметь формат: ^[A-Z0-9_]{2,}\s*$"
                    },
                    cons: {
                        required: "Выберите поле!"
                    },
                }
            });
            if (xmlData !== "") {
                OFTools.setValComboBox("ofs1-tabl", prevals.TableID, true);
                setTimeout(function () {
                    OFTools.setValDropDownList("ofs1-cons", prevals.ID);
                }, 1000);
                xmlData = "";
            }
        });
    },
    getXmlData: function (data) {
        var mythis = this;
        var constData = OFTools.getOrderFormByLabelXml("delete FIELD").constData;
        var constr = "";
        $(constData).find("Fields:eq(0) > Field").each(function () {
            if ($(this).attr("ID") == data["ofs1-cons"])
                constr = $(this).html();
        });
        var result = "<Subject>\n               <Action>delete</Action>\n               <ObjectType>FIELD</ObjectType>\n               <Object>\n                 <Field ID=\"" + data["ofs1-cons"] + "\">\n                 " + constr + " \n                 </Field>\n               </Object>\n             </Subject>";
        return result;
    }
});
pOrdersForms.push({
    label: "Удалить индекс",
    labelXml: "delete INDEX",
    constData: {},
    getForm: function (xmlData, finishCallback) {
        if (xmlData === void 0) { xmlData = ""; }
        if (finishCallback === void 0) { finishCallback = function () { }; }
        var mythis = this, prevals, editMode = false;
        if (xmlData !== "") {
            prevals = (ATools.DataSourceFromXml(xmlData, "Index"))[0];
            editMode = true;
        }
        var form1Proto = "\n          <style>\n            #CreateOrderForm th { padding: 5px 0px 0px 7px; }\n          </style>\n          <form id=\"CreateOrderForm\">\n            <table role=\"grid\" style=\"width:  300px;\">\n              <thead class=\"k-grid-header\" role=\"rowgroup\"><tr><th class=\"k-header\">\u0422\u0430\u0431\u043B\u0438\u0446\u0430</th></tr></thead>\n              <tr><td class=\"td\"> <input id=\"ofs1-tabl\" name=\"tabl\" type=\"text\" active=\"on\" style=\"width:100%;\" /></td></tr>\n         \n              <thead class=\"k-grid-header\" role=\"rowgroup\"><tr><th class=\"k-header\">\u0418\u043D\u0434\u0435\u043A\u0441</th></tr></thead>\n              <tr><td class=\"td\"> <input id=\"ofs1-cons\" name=\"cons\" type=\"text\" active=\"on\" style=\"width:100%;\" /></td></tr>\n              \n            </table>\n            <button class=\"k-button k-primary ofs-submit\" id=\"sdadwd2\" type=\"submit\">\u041F\u0440\u0438\u043D\u044F\u0442\u044C</button>\n          </form>";
        DataBaseControl.SendRequest(XMLquery.getSchemaList(), function (xml) {
            $(".forInsertionForms").html(form1Proto);
            OFTools.createComboBox("ofs1-tabl", OFTools.pickDataSource(xml, "ObjectRefs > ObjectRef", { value: "ID", text: "ID| : |BriefText" }, "ObjectType=TABLE"), function (tab) {
                DataBaseControl.SendRequest(XMLquery.FieldsByTabName(tab), function (xmlstr) {
                    var xml = $($.parseXML('<b>' + xmlstr + '</b>'));
                    var index_xml = $(xml).find("Indexes");
                    mythis.constData = xml;
                    var fieldsArr = [];
                    if (index_xml.length > 0) {
                        $(xml).find("Indexes").eq(0).find("Index").each(function () {
                            var ID = $(this).attr("ID");
                            fieldsArr[fieldsArr.length] = { value: ID, text: ID };
                        });
                        OFTools.loadDropDownList("ofs1-cons", fieldsArr);
                    }
                    else {
                    }
                });
            }, 400);
            OFTools.createDropDownList("ofs1-cons", [], function () { });
            $.validator.setDefaults({ submitHandler: function () { finishCallback(mythis.getXmlData, editMode); }, ignore: "" });
            $("#CreateOrderForm").validate({
                rules: {
                    tabl: {
                        required: true,
                        regex: /^[A-Z0-9_]{2,}\s*$/
                    },
                    cons: {
                        required: true
                    },
                },
                messages: {
                    tabl: {
                        regex: "Строка должна иметь формат: ^[A-Z0-9_]{2,}\s*$"
                    },
                    cons: {
                        required: "Выберите констрейнт!"
                    },
                }
            });
            if (xmlData !== "") {
                OFTools.setValComboBox("ofs1-tabl", prevals.TableID, true);
                setTimeout(function () {
                    OFTools.setValDropDownList("ofs1-cons", prevals.ID);
                }, 1000);
                xmlData = "";
            }
        });
    },
    getXmlData: function (data) {
        var mythis = this;
        var constData = OFTools.getOrderFormByLabelXml("delete INDEX").constData;
        var constr = "";
        $(constData).find("Indexes > Index").each(function () {
            if ($(this).attr("ID") == data["ofs1-cons"])
                constr = $(this).html();
        });
        var result = "<Subject>\n               <Action>delete</Action>\n               <ObjectType>INDEX</ObjectType>\n               <Object>\n                 <Index ID=\"" + data["ofs1-cons"] + "\">\n                 " + constr + " \n                 </Index>\n               </Object>\n             </Subject>";
        return result;
    }
});
pOrdersForms.push({
    label: "Удалить процедуру",
    labelXml: "delete QUERY",
    constData: {},
    getForm: function (xmlData, finishCallback) {
        if (xmlData === void 0) { xmlData = ""; }
        if (finishCallback === void 0) { finishCallback = function () { }; }
        var mythis = this, prevals, editMode = false;
        if (xmlData !== "") {
            prevals = (ATools.DataSourceFromXml(xmlData, "Query"))[0];
            editMode = true;
        }
        var form1Proto = "\n          <style>\n            #CreateOrderForm th { padding: 5px 0px 0px 7px; }\n          </style>\n          <form id=\"CreateOrderForm\">\n            <table role=\"grid\" style=\"width:  300px;\">\n              <thead class=\"k-grid-header\" role=\"rowgroup\"><tr><th class=\"k-header\">\u0418\u043C\u044F \u043F\u0440\u043E\u0446\u0435\u0434\u0443\u0440\u044B</th></tr></thead>\n              <tr><td class=\"td\"> <input id=\"ofs1-tabl\" name=\"tabl\" type=\"text\" active=\"on\" style=\"width:100%;\" /></td></tr>\n              \n            </table>\n            <button class=\"k-button k-primary ofs-submit\" id=\"sdadwd2\" type=\"submit\">\u041F\u0440\u0438\u043D\u044F\u0442\u044C</button>\n          </form>";
        DataBaseControl.SendRequest(XMLquery.getSchemaList(), function (xml) {
            $(".forInsertionForms").html(form1Proto);
            OFTools.createComboBox("ofs1-tabl", OFTools.pickDataSource(xml, "ObjectRefs > ObjectRef", { value: "ID", text: "ID| : |BriefText" }, "ObjectType=QUERY"), function (tab) {
                DataBaseControl.SendRequest(XMLquery.QueryByName(tab), function (xmlstr) {
                    mythis.constData = xmlstr;
                });
            });
            $.validator.setDefaults({ submitHandler: function () { finishCallback(mythis.getXmlData, editMode); }, ignore: "" });
            $("#CreateOrderForm").validate({
                rules: {
                    tabl: {
                        required: true
                    }
                }
            });
            if (xmlData !== "") {
                OFTools.setValComboBox("ofs1-tabl", prevals.ID, true);
                xmlData = "";
            }
        });
    },
    getXmlData: function (data) {
        var constData = OFTools.getOrderFormByLabelXml("delete QUERY").constData;
        var constr = (new XMLSerializer()).serializeToString($($.parseXML(constData)).find("Query")[0]);
        var result = "<Subject>\n               <Action>delete</Action>\n               <ObjectType>QUERY</ObjectType>\n               <Object>\n                 " + constr + " \n               </Object>\n             </Subject>";
        return result;
    }
});
pOrdersForms.push({
    label: "Удалить последовательность",
    labelXml: "delete SEQN",
    constData: {},
    getForm: function (xmlData, finishCallback) {
        if (xmlData === void 0) { xmlData = ""; }
        if (finishCallback === void 0) { finishCallback = function () { }; }
        var mythis = this, prevals, editMode = false;
        if (xmlData !== "") {
            prevals = (ATools.DataSourceFromXml(xmlData, "Sequence"))[0];
            editMode = true;
        }
        var form1Proto = "\n          <style>\n            #CreateOrderForm th { padding: 5px 0px 0px 7px; }\n          </style>\n          <form id=\"CreateOrderForm\">\n            <table role=\"grid\" style=\"width:  300px;\">\n              <thead class=\"k-grid-header\" role=\"rowgroup\"><tr><th class=\"k-header\">\u0418\u043C\u044F \u043F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u0438</th></tr></thead>\n              <tr><td class=\"td\"> <input id=\"ofs1-tabl\" name=\"tabl\" type=\"text\" active=\"on\" style=\"width:100%;\" /></td></tr>\n              \n            </table>\n            <button class=\"k-button k-primary ofs-submit\" id=\"sdadwd2\" type=\"submit\">\u041F\u0440\u0438\u043D\u044F\u0442\u044C</button>\n          </form>";
        DataBaseControl.SendRequest(XMLquery.getSchemaList(), function (xml) {
            $(".forInsertionForms").html(form1Proto);
            OFTools.createDropDownList("ofs1-tabl", OFTools.pickDataSource(xml, "ObjectRefs > ObjectRef", { value: "ID", text: "ID| : |BriefText" }, "ObjectType=SEQUENCE"), function (tab) {
                DataBaseControl.SendRequest(XMLquery.SequenceByName(tab), function (xmlstr) {
                    mythis.constData = xmlstr;
                });
            });
            $.validator.setDefaults({ submitHandler: function () { finishCallback(mythis.getXmlData, editMode); }, ignore: "" });
            $("#CreateOrderForm").validate({
                rules: {
                    tabl: {
                        required: true
                    }
                }
            });
            if (xmlData !== "") {
                OFTools.setValDropDownList("ofs1-tabl", prevals.ID, true);
                xmlData = "";
            }
        });
    },
    getXmlData: function (data) {
        var mythis = this;
        var constData = OFTools.getOrderFormByLabelXml("delete SEQN").constData;
        var constr = "";
        constr = (new XMLSerializer()).serializeToString($($.parseXML(constData)).find("Sequence")[0]);
        var result = "<Subject>\n               <Action>delete</Action>\n               <ObjectType>SEQN</ObjectType>\n               <Object>\n                 " + constr + " \n               </Object>\n             </Subject>";
        return result;
    }
});
pOrdersForms.push({
    label: "Удалить таблицу",
    labelXml: "delete TABLE",
    constData: {},
    getForm: function (xmlData, finishCallback) {
        if (xmlData === void 0) { xmlData = ""; }
        if (finishCallback === void 0) { finishCallback = function () { }; }
        var mythis = this, prevals, editMode = false;
        if (xmlData !== "") {
            prevals = (ATools.DataSourceFromXml(xmlData, "Table"))[0];
            editMode = true;
        }
        var form1Proto = "\n          <style>\n            #CreateOrderForm th { padding: 5px 0px 0px 7px; }\n          </style>\n          <form id=\"CreateOrderForm\">\n            <table role=\"grid\" style=\"width:  300px;\">\n              <thead class=\"k-grid-header\" role=\"rowgroup\"><tr><th class=\"k-header\">\u0418\u043C\u044F \u0442\u0430\u0431\u043B\u0438\u0446\u044B</th></tr></thead>\n              <tr><td class=\"td\"> <input id=\"ofs1-tabl\" name=\"tabl\" type=\"text\" active=\"on\" style=\"width:100%;\" /></td></tr>\n              \n            </table>\n            <button class=\"k-button k-primary ofs-submit\" id=\"sdadwd2\" type=\"submit\">\u041F\u0440\u0438\u043D\u044F\u0442\u044C</button>\n          </form>";
        DataBaseControl.SendRequest(XMLquery.getSchemaList(), function (xml) {
            $(".forInsertionForms").html(form1Proto);
            OFTools.createComboBox("ofs1-tabl", OFTools.pickDataSource(xml, "ObjectRefs > ObjectRef", { value: "ID", text: "ID| : |BriefText" }, "ObjectType=TABLE"), function (tab) {
                DataBaseControl.SendRequest(XMLquery.FieldsByTabName(tab), function (xmlstr) {
                    mythis.constData = xmlstr;
                });
            });
            $.validator.setDefaults({ submitHandler: function () { finishCallback(mythis.getXmlData, editMode); }, ignore: "" });
            $("#CreateOrderForm").validate({
                rules: {
                    tabl: {
                        required: true
                    }
                }
            });
            if (xmlData !== "") {
                OFTools.setValComboBox("ofs1-tabl", prevals.ID, true);
                xmlData = "";
            }
        });
    },
    getXmlData: function (data) {
        var mythis = this;
        var constData = OFTools.getOrderFormByLabelXml("delete TABLE").constData;
        var constr = "";
        constr = (new XMLSerializer()).serializeToString($($.parseXML(constData)).find("Table")[0]);
        var result = "<Subject>\n               <Action>delete</Action>\n               <ObjectType>TABLE</ObjectType>\n               <Object> \n                 " + constr + " \n               </Object>\n             </Subject>";
        return result;
    }
});
pOrdersForms.push({
    label: "Удалить представление",
    labelXml: "delete VIEW",
    constData: {},
    getForm: function (xmlData, finishCallback) {
        if (xmlData === void 0) { xmlData = ""; }
        if (finishCallback === void 0) { finishCallback = function () { }; }
        var mythis = this, prevals, editMode = false;
        if (xmlData !== "") {
            prevals = (ATools.DataSourceFromXml(xmlData, "View"))[0];
            editMode = true;
        }
        var form1Proto = "\n          <style>\n            #CreateOrderForm th { padding: 5px 0px 0px 7px; }\n          </style>\n          <form id=\"CreateOrderForm\">\n            <table role=\"grid\" style=\"width:  300px;\">\n              <thead class=\"k-grid-header\" role=\"rowgroup\"><tr><th class=\"k-header\">\u0418\u043C\u044F \u043F\u0440\u0435\u0434\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u0438\u044F</th></tr></thead>\n              <tr><td class=\"td\"> <input id=\"ofs1-tabl\" name=\"tabl\" type=\"text\" active=\"on\" style=\"width:100%;\" /></td></tr>\n              \n            </table>\n            <button class=\"k-button k-primary ofs-submit\" id=\"sdadwd2\" type=\"submit\">\u041F\u0440\u0438\u043D\u044F\u0442\u044C</button>\n          </form>";
        DataBaseControl.SendRequest(XMLquery.getSchemaList(), function (xml) {
            $(".forInsertionForms").html(form1Proto);
            OFTools.createComboBox("ofs1-tabl", OFTools.pickDataSource(xml, "ObjectRefs > ObjectRef", { value: "ID", text: "ID| : |BriefText" }, "ObjectType=VIEW"), function (tab) {
                DataBaseControl.SendRequest(XMLquery.ViewByName(tab), function (xmlstr) {
                    mythis.constData = xmlstr;
                });
            });
            $.validator.setDefaults({ submitHandler: function () { finishCallback(mythis.getXmlData, editMode); }, ignore: "" });
            $("#CreateOrderForm").validate({
                rules: {
                    tabl: {
                        required: true
                    }
                }
            });
            if (xmlData !== "") {
                OFTools.setValComboBox("ofs1-tabl", prevals.ID, true);
                xmlData = "";
            }
        });
    },
    getXmlData: function (data) {
        var constData = OFTools.getOrderFormByLabelXml("delete VIEW").constData;
        var constr = (new XMLSerializer()).serializeToString($($.parseXML(constData)).find("View")[0]);
        var result = "<Subject>\n               <Action>delete</Action>\n               <ObjectType>VIEW</ObjectType>\n               <Object>\n                 " + constr + " \n               </Object>\n             </Subject>";
        return result;
    }
});
pOrdersForms.push({
    label: "Изменить констрейнт",
    labelXml: "modify CONSTRAINT",
    getForm: function (xmlData, finishCallback) {
        if (xmlData === void 0) { xmlData = ""; }
        if (finishCallback === void 0) { finishCallback = function () { }; }
        var delete_CONSTRAINT = OFTools.getOrderFormByLabelXml("delete CONSTRAINT");
        var add_CONSTRAINT = OFTools.getOrderFormByLabelXml("add CONSTRAINT");
        if (xmlData == "") {
            delete_CONSTRAINT.getForm(xmlData, function (getXmlData, xcz) {
                var xmlOrderItem = getXmlData(OFTools.getFormData('CreateOrderForm'));
                add_CONSTRAINT.getForm(xmlOrderItem, function (xmlz, mod) {
                    var xxx = OFTools.chActionOrder(xmlz(OFTools.getFormData('CreateOrderForm')));
                    pOrders.submitForm(function (x) { return xxx; }, false);
                });
            });
        }
        else {
            add_CONSTRAINT.getForm(xmlData, function (xmlz, mod) {
                var xxx = OFTools.chActionOrder(xmlz(OFTools.getFormData('CreateOrderForm')));
                pOrders.submitForm(function (x) { return xxx; }, true);
            });
        }
    }
});
pOrdersForms.push({
    label: "Изменить поле",
    labelXml: "modify FIELD",
    getForm: function (xmlData, finishCallback) {
        if (xmlData === void 0) { xmlData = ""; }
        if (finishCallback === void 0) { finishCallback = function () { }; }
        var delete_FIELD = OFTools.getOrderFormByLabelXml("delete FIELD");
        var add_FIELD = OFTools.getOrderFormByLabelXml("add FIELD");
        if (xmlData == "") {
            delete_FIELD.getForm(xmlData, function (getXmlData, xcz) {
                var xmlOrderItem = getXmlData(OFTools.getFormData('CreateOrderForm'));
                add_FIELD.getForm(xmlOrderItem, function (xmlz, mod) {
                    var xxx = OFTools.chActionOrder(xmlz(OFTools.getFormData('CreateOrderForm')));
                    pOrders.submitForm(function (x) { return xxx; }, false);
                });
            });
        }
        else {
            add_FIELD.getForm(xmlData, function (xmlz, mod) {
                var xxx = OFTools.chActionOrder(xmlz(OFTools.getFormData('CreateOrderForm')));
                pOrders.submitForm(function (x) { return xxx; }, true);
            });
        }
    }
});
pOrdersForms.push({
    label: "Изменить индекс",
    labelXml: "modify INDEX",
    getForm: function (xmlData, finishCallback) {
        if (xmlData === void 0) { xmlData = ""; }
        if (finishCallback === void 0) { finishCallback = function () { }; }
        var delete_INDEX = OFTools.getOrderFormByLabelXml("delete INDEX");
        var add_INDEX = OFTools.getOrderFormByLabelXml("add INDEX");
        if (xmlData == "") {
            delete_INDEX.getForm(xmlData, function (getXmlData, xcz) {
                var xmlOrderItem = getXmlData(OFTools.getFormData('CreateOrderForm'));
                add_INDEX.getForm(xmlOrderItem, function (xmlz, mod) {
                    var xxx = OFTools.chActionOrder(xmlz(OFTools.getFormData('CreateOrderForm')));
                    pOrders.submitForm(function (x) { return xxx; }, false);
                });
            });
        }
        else {
            add_INDEX.getForm(xmlData, function (xmlz, mod) {
                var xxx = OFTools.chActionOrder(xmlz(OFTools.getFormData('CreateOrderForm')));
                pOrders.submitForm(function (x) { return xxx; }, true);
            });
        }
    }
});
pOrdersForms.push({
    label: "Изменить процедуру",
    labelXml: "modify QUERY",
    getForm: function (xmlData, finishCallback) {
        if (xmlData === void 0) { xmlData = ""; }
        if (finishCallback === void 0) { finishCallback = function () { }; }
        var delete_QUERY = OFTools.getOrderFormByLabelXml("delete QUERY");
        var add_QUERY = OFTools.getOrderFormByLabelXml("add QUERY");
        if (xmlData == "") {
            delete_QUERY.getForm(xmlData, function (getXmlData, xcz) {
                var xmlOrderItem = getXmlData(OFTools.getFormData('CreateOrderForm'));
                add_QUERY.getForm(xmlOrderItem, function (xmlz, mod) {
                    var xxx = OFTools.chActionOrder(xmlz(OFTools.getFormData('CreateOrderForm')));
                    pOrders.submitForm(function (x) { return xxx; }, false);
                });
            });
        }
        else {
            add_QUERY.getForm(xmlData, function (xmlz, mod) {
                var xxx = OFTools.chActionOrder(xmlz(OFTools.getFormData('CreateOrderForm')));
                pOrders.submitForm(function (x) { return xxx; }, true);
            });
        }
    }
});
pOrdersForms.push({
    label: "Изменить последовательность",
    labelXml: "modify SEQN",
    getForm: function (xmlData, finishCallback) {
        if (xmlData === void 0) { xmlData = ""; }
        if (finishCallback === void 0) { finishCallback = function () { }; }
        var delete_SEQN = OFTools.getOrderFormByLabelXml("delete SEQN");
        var add_SEQN = OFTools.getOrderFormByLabelXml("add SEQN");
        if (xmlData == "") {
            delete_SEQN.getForm(xmlData, function (getXmlData, xcz) {
                var xmlOrderItem = getXmlData(OFTools.getFormData('CreateOrderForm'));
                add_SEQN.getForm(xmlOrderItem, function (xmlz, mod) {
                    var xxx = OFTools.chActionOrder(xmlz(OFTools.getFormData('CreateOrderForm')));
                    pOrders.submitForm(function (x) { return xxx; }, false);
                });
            });
        }
        else {
            add_SEQN.getForm(xmlData, function (xmlz, mod) {
                var xxx = OFTools.chActionOrder(xmlz(OFTools.getFormData('CreateOrderForm')));
                pOrders.submitForm(function (x) { return xxx; }, true);
            });
        }
    }
});
pOrdersForms.push({
    label: "Изменить представление",
    labelXml: "modify VIEW",
    getForm: function (xmlData, finishCallback) {
        if (xmlData === void 0) { xmlData = ""; }
        if (finishCallback === void 0) { finishCallback = function () { }; }
        var delete_VIEW = OFTools.getOrderFormByLabelXml("delete VIEW");
        var add_VIEW = OFTools.getOrderFormByLabelXml("add VIEW");
        if (xmlData == "") {
            delete_VIEW.getForm(xmlData, function (getXmlData, xcz) {
                var xmlOrderItem = getXmlData(OFTools.getFormData('CreateOrderForm'));
                add_VIEW.getForm(xmlOrderItem, function (xmlz, mod) {
                    var xxx = OFTools.chActionOrder(xmlz(OFTools.getFormData('CreateOrderForm')));
                    pOrders.submitForm(function (x) { return xxx; }, false);
                });
            });
        }
        else {
            add_VIEW.getForm(xmlData, function (xmlz, mod) {
                var xxx = OFTools.chActionOrder(xmlz(OFTools.getFormData('CreateOrderForm')));
                pOrders.submitForm(function (x) { return xxx; }, true);
            });
        }
    }
});
var pProcedures = (function () {
    function pProcedures() {
    }
    pProcedures.Initialize = function () {
        gSuperPage.constructSimpleTable('QUERY');
    };
    pProcedures.getBody = function (xmlData, IdBodyTag, otherTabStrip) {
        $('#' + IdBodyTag).html(ATools.getXmlVal(xmlData, 'Body'));
        $('#' + IdBodyTag).css('height', '400px');
        var editor = ace.edit(IdBodyTag);
        editor.setTheme("ace/theme/xcode");
        editor.getSession().setMode("ace/mode/sql");
        editor.setShowInvisibles(true);
        editor.setReadOnly(true);
        editor.setHighlightActiveLine(false);
        LoadEventManager.execEvent("load_pSimpleTable_obj");
    };
    return pProcedures;
}());
var pSearch = (function () {
    function pSearch() {
    }
    pSearch.Initialize = function () {
        $("#content").html(this.template);
        if (typeof pSearch.mytsd === 'undefined' || pSearch.mytsd == 'error' || pSearch.mytsd.length < 100) {
            $('#SearchBody').html('<div class="SearchUnit">Ошибка загрузки TSD файла! Поиск невозможен.</div>');
        }
        else {
            var tabCount = pSearch.mytsd.match(new RegExp("<Table ID", "g"));
            var filCount = pSearch.mytsd.match(new RegExp("<Field ID", "g"));
            $('#SearchBody').html('<div class="SearchUnit">Поискавая база содержит ' + tabCount.length + ' таблиц и ' + filCount.length + ' полей.</div>');
        }
    };
    pSearch.loadTsd = function () {
        var startStr = QueryCache.storage.getTsd.xml;
        if (typeof startStr === 'undefined' || startStr.indexOf("<Content>") == -1) {
            console.log("Ошибка загрузки поискового tsd файла");
        }
        else {
            var firstStr = startStr.substr(startStr.indexOf("<Content>") + 9);
            var finalStr = firstStr.substr(0, firstStr.indexOf("</Content>"));
            function unEntity(str) {
                return str
                    .replace(/&amp;/g, '&')
                    .replace(/&lt;/g, "<")
                    .replace(/&gt;/g, ">")
                    .replace(/&quot;/g, '"')
                    .replace(/&apos;/g, "'");
            }
            pSearch.mytsd = unEntity(finalStr);
        }
    };
    pSearch.LinkProcess = function () {
        $('#SearchBody').html('<div class="k-loading-image"></div>');
        setTimeout(function () { pSearch.process(); }, 300);
        return false;
    };
    pSearch.process = function () {
        var Search_text = $('#Search_text').val();
        var result = '';
        var data_tab = [];
        function TabObject(data_tab) {
            return $("<div></div>").kendoGrid({
                dataSource: data_tab,
                scrollable: false,
                columns: [
                    { field: "id", title: "Поле", format: "{0:c}", width: "90px" },
                    { field: "Type", title: "Тип", format: "{0:c}", width: "90px" },
                    { field: "Nullable", title: "Не Null", format: "{0:c}", width: "90px" },
                    { field: "BriefText", title: "Краткое описание", format: "{0:c}", width: "130px" },
                    { field: "FullText", title: "Полное описание" }
                ]
            }).html();
        }
        $(pSearch.mytsd).find("Object").each(function () {
            var isTable = $(this).find("Table").length;
            var isView = $(this).find("View").length;
            var isSequence = $(this).find("Sequence").length;
            var isQuery = $(this).find("Query").length;
            if (isTable > 0) {
                var TabID = $(this).find("Table").attr("ID");
                var TabBriefText = $(this).find("BriefText").last().text();
                var TabFullText = $(this).find("FullText").last().text();
                var displayFlag = false;
                data_tab = [];
                if ((new RegExp(Search_text, "i")).test(TabBriefText)) {
                    displayFlag = true;
                    TabBriefText = TabBriefText.replace(new RegExp(Search_text, "gim"), 'serchtxtbegin' + Search_text + 'serchtxtend');
                }
                if ((new RegExp(Search_text, "i")).test(TabFullText)) {
                    displayFlag = true;
                    TabFullText = TabFullText.replace(new RegExp(Search_text, "gim"), 'serchtxtbegin' + Search_text + 'serchtxtend');
                }
                ;
                $(this).find("Field").each(function () {
                    var Type = $(this).find("Type").text();
                    if (Type.length > 0) {
                        var ID = $(this).attr("ID");
                        var Nullable = $(this).find("Nullable").text();
                        var BriefText = $(this).find("BriefText").text();
                        var FullText = $(this).find("FullText").text();
                        if ((new RegExp(Search_text, "i")).test(ID)) {
                            ID = ID.replace(new RegExp(Search_text, "gim"), 'serchtxtbegin' + Search_text + 'serchtxtend');
                            displayFlag = true;
                        }
                        if ((new RegExp(Search_text, "i")).test(BriefText)) {
                            BriefText = BriefText.replace(new RegExp(Search_text, "gim"), 'serchtxtbegin' + Search_text + 'serchtxtend');
                            displayFlag = true;
                        }
                        else if ((new RegExp(Search_text, "i")).test(FullText)) {
                            FullText = FullText.replace(new RegExp(Search_text, "gim"), 'serchtxtbegin' + Search_text + 'serchtxtend');
                            displayFlag = true;
                        }
                        ;
                        data_tab.push({
                            id: ID,
                            Type: Type,
                            Nullable: Nullable,
                            BriefText: BriefText,
                            FullText: FullText
                        });
                    }
                });
                if (displayFlag) {
                    result += '<div class="SearchUnit">' +
                        '<a href="/#Structure-' + TabID + '"><div class="STitle">Таблица ' + TabID + '</div></a>' +
                        '<i>Краткое описание таблицы:</i> ' + TabBriefText + '<br>' +
                        '<i>Полное описание таблицы:</i> ' + TabFullText + '<br>' +
                        TabObject(data_tab) +
                        '</div>';
                }
            }
            ;
            if (isView > 0) {
                var ViewID = $(this).find("View").attr("ID");
                var ViewBody = $(this).find("Body").text();
                var ViewBriefText = $(this).find("BriefText").text();
                var displayFlag = false;
                if ((new RegExp(Search_text, "i")).test(ViewBody)) {
                    ViewBody = ViewBody.replace(new RegExp(Search_text, "gim"), 'serchtxtbegin' + Search_text + 'serchtxtend');
                    displayFlag = true;
                }
                else if ((new RegExp(Search_text, "i")).test(ViewBriefText)) {
                    ViewBriefText = ViewBriefText.replace(new RegExp(Search_text, "gim"), 'serchtxtbegin' + Search_text + 'serchtxtend');
                    displayFlag = true;
                }
                ;
                if (displayFlag) {
                    result += '<div class="SearchUnit">' +
                        '<div class="STitle">Представление ' + ViewID + '</div>' +
                        '<i>Краткое описание представления:</i> ' + ViewBriefText + '<br>' +
                        '<pre>' + ViewBody + '</pre>' +
                        '</div>';
                }
            }
            ;
            if (isQuery > 0) {
                var QueryID = $(this).find("Query").attr("ID");
                var QueryBody = $(this).find("Body").text();
                var QueryBriefText = $(this).find("BriefText").text();
                var displayFlag = false;
                if ((new RegExp(Search_text, "i")).test(QueryBody)) {
                    QueryBody = QueryBody.replace(new RegExp(Search_text, "gim"), 'serchtxtbegin' + Search_text + 'serchtxtend');
                    displayFlag = true;
                }
                else if ((new RegExp(Search_text, "i")).test(QueryBriefText)) {
                    QueryBriefText = QueryBriefText.replace(new RegExp(Search_text, "gim"), 'serchtxtbegin' + Search_text + 'serchtxtend');
                    displayFlag = true;
                }
                ;
                if (displayFlag) {
                    result += '<div class="SearchUnit">' +
                        '<div class="STitle">Триггер ' + QueryID + '</div>' +
                        '<i>Краткое описание триггера:</i> ' + QueryBriefText + '<br>' +
                        '<pre>' + QueryBody + '</pre>' +
                        '</div>';
                }
            }
            ;
        });
        if (result.length > 0) {
            result = result.replace(new RegExp('serchtxtbegin', "gim"), '<span class="serchtxt">');
            result = result.replace(new RegExp('serchtxtend', "gim"), '</span>');
        }
        if (result.length == 0)
            result = '<div class="SearchUnit">Совпадений не найдено</div>';
        $('#SearchBody').html(result);
        return false;
    };
    pSearch.template = "\n    <style type=\"text/css\">\n        #SearchForm {\n            position:absolute;\n            margin-top: -76px;\n            height: 76px;\n            background-color: rgb(231, 242, 185);\n            width: 100%;\n        }\n        \n        #SearchFormTop {\n            display: block;\n            margin-top: 23px;\n            margin-left: 240px;\n        }\n        \n        #SearchBody {\n            width: 100%;\n            height: 100%;\n            overflow-y: scroll;\n        }\n        \n        #Search_button {\n            height: 28px;\n            margin-top: -3px;\n        }\n        \n        \n        #Search_text {\n            margin: 0px;\n            padding: 1px 0px 0px 9px;\n            border: 0px;\n            height: 28px;\n            width: 400px;\n            background-color: #ffffff !important;\n        }\n        \n        .serchtxt {\n            background-color:#FFFF00;\n        }\n        \n        .SearchUnit {\n            margin: 10px 20px 30px 26px;\n        }\n        .STitle {\n            font-weight: bold;\n            color: #268B1A;\n            margin-bottom: 5px;\n        }\n        \n        a .STitle {\n            text-decoration: none !important;\n        }\n    </style>\n\n    <div id= \"SearchForm\">\n        <form id=\"SearchFormTop\" name= \"form\" onSubmit= \"return pSearch.LinkProcess()\" >\n            <input type='text' value='' id='Search_text'/>\n            <button id='Search_button' class=\"k-button k-primary\">\u041D\u0430\u0439\u0442\u0438</button>\n        </form>\n    </div>\n\n    <div id=\"SearchBody\"></div>\n    ";
    return pSearch;
}());
var pSequence = (function () {
    function pSequence() {
    }
    pSequence.Initialize = function () {
        gSuperPage.constructSimpleTable('SEQUENCE');
    };
    pSequence.getBody = function (xmlData, IdBodyTag, otherTabStrip) {
        var xmldom = $($.parseXML('<b>' + xmlData + '</b>'));
        var seq = '<div><span>Начальное значение:    </span>' + $(xmldom).find("StartWith").text() + '</div>' +
            '<div><span>Минимальное значение:  </span>' + $(xmldom).find("MinValue").text() + '</div>' +
            '<div><span>Максимальное значение: </span>' + $(xmldom).find("MaxValue").text() + '</div>' +
            '<div><span>Инкремент:             </span>' + $(xmldom).find("IncrBy").text() + '</div>' +
            '<div><span>Размер кеша:           </span>' + $(xmldom).find("CacheSize").text() + '</div>' +
            '<div><span>Цикл:                  </span>' + $(xmldom).find("CycleFlg").text() + '</div>' +
            '<div><span>Порядок:               </span>' + $(xmldom).find("OrderFlg").text() + '</div>';
        $('#' + IdBodyTag).css({ 'height': '200px', 'white-space': 'pre', 'font-family': 'monospace', 'font-size': '14px' });
        $('#' + IdBodyTag).html(seq);
        LoadEventManager.execEvent("load_pSimpleTable_obj");
    };
    return pSequence;
}());
var pStructure = (function () {
    function pStructure() {
    }
    pStructure.Initialize = function () {
        gSuperPage.constructSimpleTable('TABLE');
    };
    pStructure.getBody = function (xmlData, IdBodyTag, otherTabStrip) {
        $("#" + IdBodyTag).html("<div id='" + IdBodyTag + "_FullText'></div><div id='" + IdBodyTag + "_tab'></div>");
        $("#" + IdBodyTag + "_FullText").html("\u041F\u043E\u0434\u0440\u043E\u0431\u043D\u043E\u0435 \u043E\u043F\u0438\u0441\u0430\u043D\u0438\u0435: " + ATools.editText(ATools.getXmlVal(xmlData, 'Table > FullText'), ATools.getXmlVal(xmlData, 'TableID'), 'TABLE', 'FullText', '0') + "\n            <br><br>");
        $("#" + IdBodyTag + "_tab").kendoGrid({
            dataSource: {
                data: xmlData,
                schema: {
                    type: 'xml',
                    data: '/UCMsg/RequestHead/Requests/Request/Subject/Object/Table/Fields/Field',
                    model: {
                        fields: {
                            ID: '@ID',
                            Type: 'Type/text()',
                            Position: 'Position/text()',
                            Nullable: 'Nullable/text()',
                            BriefText: 'BriefText/text()',
                            FullText: 'FullText/text()',
                            DefVal: 'DefVal/text()',
                        }
                    }
                }
            },
            scrollable: false,
            columns: [
                { field: "ID", title: 'Поле', format: "{0:c}", width: "90px" },
                { field: "Type", title: 'Тип', format: "{0:c}", width: "130px" },
                { field: "Nullable", title: 'Nullable', format: "{0:c}", width: "100px" },
                { field: "DefVal", title: 'Default', format: "{0:c}", width: "70px" },
                { field: "BriefText", title: "Кратко", width: "210px",
                    template: "<span class='s-edit-text' ID='#: ID #' ObjectType='FIELD' TextType='BriefText' RequestID='0' ><div></div>#: ATools.changeTextFix(BriefText) #</span>"
                },
                { field: "FullText", title: 'Подробно',
                    template: "<span class='s-edit-text' ID='#: ID #' ObjectType='FIELD' TextType='FullText'  RequestID='0' ><div></div>#: ATools.changeTextFix(FullText)  #</span>"
                }
            ]
        });
        var result = '';
        var err = 0;
        var Indexes = ATools.DataSourceFromXml(xmlData, "Object > Table > Indexes > Index");
        if (Indexes.length > 0) {
            result += '<div class="br1" />Индексы:<ul>';
            for (var i in Indexes) {
                Indexes[i].Uniqueness = ATools.getXmlVal(Indexes[i].html, "Uniqueness");
                Indexes[i].TableID = ATools.getXmlVal(Indexes[i].html, "TableID");
                Indexes[i].Fields = gSuperPage.getFieldsListID(ATools.getXmlVal(Indexes[i].html, "Fields"));
                result += '<li>';
                result += (Indexes[i].Uniqueness == 1) ? "<b style=color:#f35800;>Unique</b> " : "";
                result += Indexes[i].ID;
                result += " (" + Indexes[i].Fields + ')';
                result += '</li>';
            }
            result += '</ul>';
        }
        else {
            err++;
        }
        var Constraints = ATools.DataSourceFromXml(xmlData, "Object > Table > Constraints > Constraint");
        if (Constraints.length > 0) {
            result += '<div class="br1" />Констрейты:<ul>';
            for (var i in Constraints) {
                Constraints[i].Validate = ATools.getXmlVal(Constraints[i].html, "Validate");
                Constraints[i].Type = ATools.getXmlVal(Constraints[i].html, "Type");
                Constraints[i].Condition = ATools.getXmlVal(Constraints[i].html, "Condition");
                Constraints[i].Fields = gSuperPage.getFieldsListID(ATools.getXmlVal(Constraints[i].html, "Fields"));
                result += '<li>';
                result += (Constraints[i].Type == 'P') ? "<b style=color:#f35800;>Primary</b> " : "";
                result += Constraints[i].ID;
                result += ' [';
                result += Constraints[i].Type;
                result += (Constraints[i].Condition.length > 0) ? ' (' + Constraints[i].Condition + ')' : '';
                result += '] ';
                result += Constraints[i].Validate;
                result += " (" + Constraints[i].Fields + ')';
                result += '</li>';
            }
            result += '</ul>';
        }
        else {
            err++;
        }
        if (result == "")
            result = "Таблица не содержит индексов и констрейнтов.";
        otherTabStrip.insertAfter({ text: "Индексы и констрейнты", content: result }, otherTabStrip.tabGroup.children("li:first"));
        LoadEventManager.execEvent("load_pSimpleTable_obj");
    };
    return pStructure;
}());
var pView = (function (_super) {
    __extends(pView, _super);
    function pView() {
        _super.apply(this, arguments);
    }
    pView.Initialize = function () {
        gSuperPage.constructSimpleTable('VIEW');
    };
    pView.getBody = function (xmlData, IdBodyTag, otherTabStrip) {
        $('#' + IdBodyTag).html(ATools.getXmlVal(xmlData, 'Body'));
        $('#' + IdBodyTag).css('height', '400px');
        var editor = ace.edit(IdBodyTag);
        editor.setTheme("ace/theme/xcode");
        editor.getSession().setMode("ace/mode/sql");
        editor.setShowInvisibles(true);
        editor.setReadOnly(true);
        editor.setHighlightActiveLine(false);
        LoadEventManager.execEvent("load_pSimpleTable_obj");
    };
    return pView;
}(gSuperPage));
$(document).ready(function () {
    DataBaseControl.OpenConnect(MainConfig.socketString, function () {
        PageControl.Initialize();
    });
});
var req = {
    on: function () {
        MainConfig.showreq = true;
        return 'Вывод запросов включен';
    },
    off: function () {
        MainConfig.showreq = false;
        return 'Вывод запросов выключен';
    }
};
